"""
主动反制系统 - 法律反制引擎
Legal Countermeasure Engine - 生成法律文书和支持维权
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class LegalActionType(Enum):
    """法律行动类型"""
    POLICE_REPORT = "police_report"  # 报警
    CIVIL_LAWSUIT = "civil_lawsuit"  # 民事诉讼
    CRIMINAL_COMPLAINT = "criminal_complaint"  # 刑事举报
    REGULATORY_REPORT = "regulatory_report"  # 监管举报
    INTERNATIONAL_COOP = "international_cooperation"  # 国际合作


@dataclass
class LegalDocument:
    """法律文书"""
    document_id: str
    document_type: LegalActionType
    title: str
    content: str
    target_info: Dict
    evidence_summary: str
    created_at: str
    status: str


class LegalCountermeasureEngine:
    """法律反制引擎"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.jurisdiction = self.config.get('jurisdiction', 'CN')
        self.documents = []

    def generate_legal_document(self, action_type: LegalActionType,
                                evidence: Dict) -> LegalDocument:
        """
        生成法律文书

        Args:
            action_type: 法律行动类型
            evidence: 证据材料

        Returns:
            法律文书
        """
        import hashlib

        document_id = f"LEGAL-{hashlib.md5(datetime.now().isoformat().encode()).hexdigest()[:12].upper()}"

        content = self._generate_content(action_type, evidence)

        document = LegalDocument(
            document_id=document_id,
            document_type=action_type,
            title=self._get_title(action_type),
            content=content,
            target_info=evidence.get('target_info', {}),
            evidence_summary=evidence.get('summary', ''),
            created_at=datetime.now().isoformat(),
            status='draft'
        )

        self.documents.append(document)
        return document

    def _generate_content(self, action_type: LegalActionType, evidence: Dict) -> str:
        """生成文书内容"""
        if action_type == LegalActionType.POLICE_REPORT:
            return f"""报警回执

报案人：{evidence.get('reporter_name', 'N/A')}
报案时间：{datetime.now().isoformat()}
涉案IP地址：{evidence.get('target_ip', 'N/A')}
涉案域名：{evidence.get('target_domain', 'N/A')}
涉案金额：{evidence.get('estimated_damage', 0)}元

案情描述：
{evidence.get('description', 'N/A')}

证据清单：
{evidence.get('evidence_list', 'N/A')}
"""
        elif action_type == LegalActionType.CIVIL_LAWSUIT:
            return f"""民事起诉状

原告：{evidence.get('plaintiff', 'N/A')}
被告：{evidence.get('defendant', 'N/A')}
诉讼请求：
{evidence.get('claims', 'N/A')}

事实与理由：
{evidence.get('facts', 'N/A')}

证据：
{evidence.get('evidence', 'N/A')}
"""
        else:
            return "法律文书内容"

    def _get_title(self, action_type: LegalActionType) -> str:
        """获取标题"""
        titles = {
            LegalActionType.POLICE_REPORT: "网络安全事件报警材料",
            LegalActionType.CIVIL_LAWSUIT: "民事起诉状",
            LegalActionType.CRIMINAL_COMPLAINT: "刑事举报材料",
            LegalActionType.REGULATORY_REPORT: "监管举报材料",
            LegalActionType.INTERNATIONAL_COOP: "国际执法合作请求"
        }
        return titles.get(action_type, "法律文书")

    def submit_document(self, document_id: str) -> Dict:
        """
        提交法律文书

        Args:
            document_id: 文书ID

        Returns:
            提交结果
        """
        for doc in self.documents:
            if doc.document_id == document_id:
                doc.status = 'submitted'
                return {
                    'success': True,
                    'document_id': document_id,
                    'submitted_at': datetime.now().isoformat(),
                    'reference_number': f"REF-{document_id}"
                }
        return {'success': False, 'error': 'Document not found'}

    def get_pending_documents(self) -> List[LegalDocument]:
        """获取待提交文书"""
        return [d for d in self.documents if d.status == 'draft']


# 独立运行测试
if __name__ == "__main__":
    engine = LegalCountermeasureEngine()

    # 生成报警材料
    evidence = {
        'reporter_name': 'Security Team',
        'target_ip': '192.168.1.100',
        'target_domain': 'attacker.com',
        'estimated_damage': 500000,
        'description': '遭受DDoS攻击导致服务中断',
        'evidence_list': '攻击日志、流量记录等'
    }

    doc = engine.generate_legal_document(LegalActionType.POLICE_REPORT, evidence)
    print(f"法律文书已生成: {doc.document_id}")
    print(f"标题: {doc.title}")
    print(f"状态: {doc.status}")

    # 提交文书
    result = engine.submit_document(doc.document_id)
    print(f"\n提交结果: {result}")
