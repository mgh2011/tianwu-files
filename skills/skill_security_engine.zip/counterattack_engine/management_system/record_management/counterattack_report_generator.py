"""
反击管理系统 - 反击报告生成模块
Counterattack Report Generator - 生成反击行动报告
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class ReportType(Enum):
    """报告类型"""
    INCIDENT = "incident"  # 事件报告
    RESPONSE = "response"  # 响应报告
    SUMMARY = "summary"  # 总结报告
    FORENSIC = "forensic"  # 取证报告
    COMPLIANCE = "compliance"  # 合规报告
    EXECUTIVE = "executive"  # 执行摘要


class ReportFormat(Enum):
    """报告格式"""
    PDF = "pdf"
    HTML = "html"
    JSON = "json"
    MARKDOWN = "markdown"


@dataclass
class ReportSection:
    """报告章节"""
    title: str
    content: str
    subsections: List['ReportSection'] = field(default_factory=list)
    data: Dict = field(default_factory=dict)


@dataclass
class Report:
    """报告"""
    report_id: str
    title: str
    report_type: ReportType
    generated_at: str
    period_start: str
    period_end: str
    sections: List[ReportSection]
    metadata: Dict = field(default_factory=dict)
    attachments: List[str] = field(default_factory=list)


class CounterattackReportGenerator:
    """反击报告生成器"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化报告生成器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.template_dir = self.config.get('template_dir', './templates')
        self.output_dir = self.config.get('output_dir', './reports')
        self.default_format = ReportFormat(self.config.get('format', 'html'))

    def generate_incident_report(self, incident_data: Dict) -> Report:
        """
        生成事件报告

        Args:
            incident_data: 事件数据

        Returns:
            报告对象
        """
        sections = []

        # 执行摘要
        summary = self._generate_executive_summary(incident_data)
        sections.append(ReportSection(
            title="执行摘要",
            content=summary
        ))

        # 事件概述
        overview = self._generate_incident_overview(incident_data)
        sections.append(ReportSection(
            title="事件概述",
            content=overview,
            data=incident_data.get('overview', {})
        ))

        # 攻击分析
        attack_analysis = self._generate_attack_analysis(incident_data)
        sections.append(ReportSection(
            title="攻击分析",
            content="",
            data=incident_data.get('attack_analysis', {})
        ))

        # 反击行动
        response_actions = self._generate_response_actions(incident_data)
        sections.append(ReportSection(
            title="反击行动",
            content="",
            data=incident_data.get('response', {})
        ))

        # 影响评估
        impact = self._generate_impact_assessment(incident_data)
        sections.append(ReportSection(
            title="影响评估",
            content="",
            data=incident_data.get('impact', {})
        ))

        # 建议
        recommendations = self._generate_recommendations(incident_data)
        sections.append(ReportSection(
            title="改进建议",
            content="",
            data={'recommendations': recommendations}
        ))

        return Report(
            report_id=self._generate_report_id(),
            title=f"安全事件报告 - {incident_data.get('incident_id', 'N/A')}",
            report_type=ReportType.INCIDENT,
            generated_at=datetime.now().isoformat(),
            period_start=incident_data.get('detected_at', ''),
            period_end=incident_data.get('resolved_at', datetime.now().isoformat()),
            sections=sections,
            metadata=incident_data.get('metadata', {})
        )

    def generate_response_report(self, response_data: Dict) -> Report:
        """
        生成响应报告

        Args:
            response_data: 响应数据

        Returns:
            报告对象
        """
        sections = []

        # 响应摘要
        summary = ReportSection(
            title="响应摘要",
            content=self._generate_response_summary(response_data)
        )
        sections.append(summary)

        # 行动详情
        actions = ReportSection(
            title="行动详情",
            content="",
            data=response_data.get('actions', [])
        )
        sections.append(actions)

        # 时间线
        timeline = ReportSection(
            title="响应时间线",
            content="",
            data=response_data.get('timeline', [])
        )
        sections.append(timeline)

        # 效果评估
        effectiveness = ReportSection(
            title="效果评估",
            content="",
            data=response_data.get('effectiveness', {})
        )
        sections.append(effectiveness)

        return Report(
            report_id=self._generate_report_id(),
            title="反击响应报告",
            report_type=ReportType.RESPONSE,
            generated_at=datetime.now().isoformat(),
            period_start=response_data.get('start_time', ''),
            period_end=response_data.get('end_time', ''),
            sections=sections
        )

    def generate_summary_report(self, summary_data: Dict) -> Report:
        """
        生成总结报告

        Args:
            summary_data: 汇总数据

        Returns:
            报告对象
        """
        sections = []

        # 统计概览
        stats = ReportSection(
            title="统计概览",
            content="",
            data=summary_data.get('statistics', {})
        )
        sections.append(stats)

        # 趋势分析
        trends = ReportSection(
            title="趋势分析",
            content="",
            data=summary_data.get('trends', {})
        )
        sections.append(trends)

        # 热点事件
        hotspots = ReportSection(
            title="热点事件",
            content="",
            data=summary_data.get('hotspots', [])
        )
        sections.append(hotspots)

        # 建议
        recommendations = ReportSection(
            title="建议",
            content="",
            data={'recommendations': summary_data.get('recommendations', [])}
        )
        sections.append(recommendations)

        return Report(
            report_id=self._generate_report_id(),
            title="反击行动月度总结报告",
            report_type=ReportType.SUMMARY,
            generated_at=datetime.now().isoformat(),
            period_start=summary_data.get('period_start', ''),
            period_end=summary_data.get('period_end', ''),
            sections=sections,
            metadata=summary_data.get('metadata', {})
        )

    def generate_forensic_report(self, forensic_data: Dict) -> Report:
        """
        生成取证报告

        Args:
            forensic_data: 取证数据

        Returns:
            报告对象
        """
        sections = []

        # 证据概述
        evidence = ReportSection(
            title="证据概述",
            content="",
            data=forensic_data.get('evidence_summary', {})
        )
        sections.append(evidence)

        # 证据清单
        evidence_list = ReportSection(
            title="证据清单",
            content="",
            data={'items': forensic_data.get('evidence_items', [])}
        )
        sections.append(evidence_list)

        # 分析结果
        analysis = ReportSection(
            title="分析结果",
            content="",
            data=forensic_data.get('analysis', {})
        )
        sections.append(analysis)

        # 结论
        conclusion = ReportSection(
            title="结论",
            content=forensic_data.get('conclusion', ''),
            data=forensic_data.get('conclusion_details', {})
        )
        sections.append(conclusion)

        return Report(
            report_id=self._generate_report_id(),
            title="安全事件取证报告",
            report_type=ReportType.FORENSIC,
            generated_at=datetime.now().isoformat(),
            period_start=forensic_data.get('incident_start', ''),
            period_end=forensic_data.get('investigation_end', ''),
            sections=sections,
            attachments=forensic_data.get('attachments', [])
        )

    def export_report(self, report: Report, format: ReportFormat = None) -> str:
        """
        导出报告

        Args:
            report: 报告对象
            format: 格式

        Returns:
            报告内容
        """
        format = format or self.default_format

        if format == ReportFormat.JSON:
            return self._export_json(report)
        elif format == ReportFormat.HTML:
            return self._export_html(report)
        elif format == ReportFormat.MARKDOWN:
            return self._export_markdown(report)
        else:
            return self._export_json(report)

    def save_report(self, report: Report, format: ReportFormat = None,
                   filename: str = None) -> str:
        """
        保存报告

        Args:
            report: 报告对象
            format: 格式
            filename: 文件名

        Returns:
            文件路径
        """
        import os

        format = format or self.default_format
        filename = filename or f"{report.report_type.value}_{report.report_id}.{format.value}"

        content = self.export_report(report, format)
        filepath = os.path.join(self.output_dir, filename)

        os.makedirs(self.output_dir, exist_ok=True)

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)

        return filepath

    def _generate_report_id(self) -> str:
        """生成报告ID"""
        import hashlib
        timestamp = datetime.now().isoformat()
        return f"RPT-{hashlib.md5(timestamp.encode()).hexdigest()[:12].upper()}"

    def _generate_executive_summary(self, data: Dict) -> str:
        """生成执行摘要"""
        incident_type = data.get('type', 'Unknown')
        severity = data.get('severity', 'Unknown')
        status = data.get('status', 'Unknown')

        return f"""
本次安全事件为{incident_type}攻击，严重程度为{severity}级。
事件状态：{status}。

关键发现：
- 攻击持续时间：{data.get('duration', 'N/A')}
- 受影响系统：{data.get('affected_systems', 'N/A')}
- 预计损失：{data.get('estimated_loss', 'N/A')}

已采取的反击措施包括阻断攻击源、部署蜜罐诱捕等。
        """.strip()

    def _generate_incident_overview(self, data: Dict) -> str:
        """生成事件概述"""
        return f"""
事件ID: {data.get('incident_id', 'N/A')}
检测时间: {data.get('detected_at', 'N/A')}
攻击类型: {data.get('type', 'N/A')}
攻击源: {data.get('source', 'N/A')}
受影响目标: {data.get('targets', [])}
        """

    def _generate_attack_analysis(self, data: Dict) -> str:
        """生成攻击分析"""
        analysis = data.get('attack_analysis', {})
        return f"""
攻击特征：
- 攻击向量: {analysis.get('attack_vector', 'N/A')}
- 使用的工具: {analysis.get('tools', [])}
- 攻击模式: {analysis.get('pattern', 'N/A')}

攻击者信息：
- 估计来源: {analysis.get('attacker_origin', 'N/A')}
- 攻击者类型: {analysis.get('attacker_type', 'N/A')}
- 威胁等级: {analysis.get('threat_level', 'N/A')}
        """

    def _generate_response_actions(self, data: Dict) -> str:
        """生成反击行动"""
        actions = data.get('response', {}).get('actions', [])
        action_list = '\n'.join([f"- {a}" for a in actions])
        return f"""
已执行的反击行动：
{action_list or '无'}

反击效果：{data.get('response', {}).get('effectiveness', 'N/A')}
        """

    def _generate_impact_assessment(self, data: Dict) -> str:
        """生成影响评估"""
        impact = data.get('impact', {})
        return f"""
业务影响：{impact.get('business_impact', 'N/A')}
数据泄露：{impact.get('data_breach', 'N/A')}
系统损失：{impact.get('system_damage', 'N/A')}
声誉影响：{impact.get('reputation_impact', 'N/A')}
        """

    def _generate_recommendations(self, data: Dict) -> List[str]:
        """生成建议"""
        return [
            "加强网络监控和异常检测能力",
            "定期更新安全规则和特征库",
            "完善应急响应流程和授权机制",
            "加强员工安全意识培训",
            "部署更高级的威胁检测系统"
        ]

    def _generate_response_summary(self, data: Dict) -> str:
        """生成响应摘要"""
        return f"""
响应开始时间: {data.get('start_time', 'N/A')}
响应结束时间: {data.get('end_time', 'N/A')}
总行动数: {len(data.get('actions', []))}
成功行动数: {data.get('success_count', 0)}
        """

    def _export_json(self, report: Report) -> str:
        """导出为JSON"""
        return json.dumps({
            'report_id': report.report_id,
            'title': report.title,
            'type': report.report_type.value,
            'generated_at': report.generated_at,
            'period': {
                'start': report.period_start,
                'end': report.period_end
            },
            'sections': [self._section_to_dict(s) for s in report.sections],
            'metadata': report.metadata,
            'attachments': report.attachments
        }, indent=2, ensure_ascii=False)

    def _export_html(self, report: Report) -> str:
        """导出为HTML"""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{report.title}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; }}
        h1 {{ color: #333; border-bottom: 2px solid #333; }}
        h2 {{ color: #666; margin-top: 30px; }}
        .meta {{ color: #999; font-size: 14px; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #f5f5f5; }}
    </style>
</head>
<body>
    <h1>{report.title}</h1>
    <div class="meta">
        <p>报告ID: {report.report_id}</p>
        <p>生成时间: {report.generated_at}</p>
        <p>报告周期: {report.period_start} 至 {report.period_end}</p>
    </div>
"""

        for section in report.sections:
            html += f"<h2>{section.title}</h2>\n"
            if section.content:
                html += f"<p>{section.content}</p>\n"
            if section.data:
                html += self._data_to_html_table(section.data)

        html += """
</body>
</html>"""
        return html

    def _export_markdown(self, report: Report) -> str:
        """导出为Markdown"""
        md = f"# {report.title}\n\n"
        md += f"**报告ID**: {report.report_id}\n"
        md += f"**生成时间**: {report.generated_at}\n"
        md += f"**报告周期**: {report.period_start} 至 {report.period_end}\n\n"

        for section in report.sections:
            md += f"## {section.title}\n\n"
            if section.content:
                md += f"{section.content}\n\n"
            if section.data:
                md += self._data_to_markdown(section.data)
            md += "\n"

        return md

    def _section_to_dict(self, section: ReportSection) -> Dict:
        """章节转字典"""
        return {
            'title': section.title,
            'content': section.content,
            'subsections': [self._section_to_dict(s) for s in section.subsections],
            'data': section.data
        }

    def _data_to_html_table(self, data: Dict) -> str:
        """数据转HTML表格"""
        html = "<table>\n"
        for key, value in data.items():
            html += f"  <tr><th>{key}</th><td>{value}</td></tr>\n"
        html += "</table>\n"
        return html

    def _data_to_markdown(self, data: Dict) -> str:
        """数据转Markdown表格"""
        md = "| 项目 | 值 |\n|------|-----|\n"
        for key, value in data.items():
            md += f"| {key} | {value} |\n"
        return md + "\n"


# 独立运行测试
if __name__ == "__main__":
    generator = CounterattackReportGenerator()

    # 测试事件报告
    incident_data = {
        'incident_id': 'INC-2024-001',
        'type': 'DDoS',
        'severity': 'High',
        'status': 'Resolved',
        'detected_at': '2024-01-15T10:30:00',
        'resolved_at': '2024-01-15T14:45:00',
        'duration': '4小时15分钟',
        'source': '192.168.1.100',
        'affected_systems': ['web_server', 'api_gateway'],
        'estimated_loss': '$50,000',
        'attack_analysis': {
            'attack_vector': 'UDP Flood',
            'tools': ['LOIC', 'HOIC'],
            'pattern': 'Volumetric',
            'attacker_origin': 'Unknown',
            'attacker_type': 'Botnet',
            'threat_level': 'High'
        },
        'response': {
            'actions': ['block_source_ip', 'enable_rate_limiting', 'activate_waf_rules'],
            'effectiveness': '85%'
        },
        'impact': {
            'business_impact': '中度',
            'data_breach': '无',
            'system_damage': '轻微',
            'reputation_impact': '低'
        }
    }

    report = generator.generate_incident_report(incident_data)
    print(f"报告已生成: {report.report_id}")
    print(f"标题: {report.title}")
    print(f"章节数: {len(report.sections)}")

    # 导出为JSON
    json_content = generator.export_report(report, ReportFormat.JSON)
    print(f"\nJSON报告长度: {len(json_content)}字符")

    # 导出为Markdown
    md_content = generator.export_report(report, ReportFormat.MARKDOWN)
    print(f"\nMarkdown报告:\n{md_content[:500]}...")

    # 保存报告
    filepath = generator.save_report(report, ReportFormat.HTML)
    print(f"\n报告已保存: {filepath}")
