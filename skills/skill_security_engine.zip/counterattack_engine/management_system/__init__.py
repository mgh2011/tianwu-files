"""
管理系统模块
Management System Module

提供反击系统的合规、记录、规则、策略管理功能
"""

__version__ = "v3.0.0"
__all__ = []
