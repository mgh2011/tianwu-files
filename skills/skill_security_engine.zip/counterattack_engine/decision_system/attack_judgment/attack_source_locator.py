"""
攻击来源定位模块
Attack Source Locator - 定位攻击来源的物理位置和网络位置
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import json
import hashlib


@dataclass
class GeoLocation:
    """地理位置信息"""
    country: str
    country_code: str
    region: str
    city: str
    latitude: float
    longitude: float
    timezone: str
    isp: str
    organization: str
    as_number: int


@dataclass
class NetworkLocation:
    """网络位置信息"""
    ip_address: str
    hostname: Optional[str]
    reverse_dns: Optional[str]
    is_proxy: bool
    is_vpn: bool
    is_tor: bool
    is_datacenter: bool
    is_bot: bool
    as_number: int
    as_name: str
    isp: str
    network_prefix: str
    network_type: str  # residential, business, datacenter


class IPAnalysisResult:
    """IP分析结果"""

    def __init__(self, ip: str):
        self.ip = ip
        self.geo_location: Optional[GeoLocation] = None
        self.network_location: Optional[NetworkLocation] = None
        self.reputation_score: float = 0.0
        self.threat_intel: Dict = {}
        self.first_seen: Optional[str] = None
        self.last_seen: Optional[str] = None
        self.attack_history: List[Dict] = []
        self.tags: List[str] = []
        self.isp_reputation: str = "unknown"
        self.anonymization_detected: bool = False

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'ip': self.ip,
            'geo_location': {
                'country': self.geo_location.country if self.geo_location else None,
                'country_code': self.geo_location.country_code if self.geo_location else None,
                'city': self.geo_location.city if self.geo_location else None,
                'latitude': self.geo_location.latitude if self.geo_location else None,
                'longitude': self.geo_location.longitude if self.geo_location else None,
                'isp': self.geo_location.isp if self.geo_location else None,
            } if self.geo_location else None,
            'reputation_score': self.reputation_score,
            'threat_intel': self.threat_intel,
            'attack_history_count': len(self.attack_history),
            'tags': self.tags,
            'is_anonymized': self.anonymization_detected,
            'first_seen': self.first_seen,
            'last_seen': self.last_seen,
        }


class AttackSourceLocator:
    """攻击来源定位器"""

    # 常用IP黑名单CIDR范围
    KNOWN_MALICIOUS_RANGES = [
        "103.21.244.0/22",
        "103.22.200.0/22",
        "103.31.4.0/22",
        "104.16.0.0/12",
        "108.177.0.0/17",
    ]

    # 高风险国家列表
    HIGH_RISK_COUNTRIES = ["KP", "IR", "SY", "CU", "RU"]

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化攻击来源定位器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.geo_database = self._init_geo_database()
        self.threat_intel_cache = {}
        self.location_history = {}
        self.max_cache_size = 10000

    def locate(self, source_info: Dict) -> Dict:
        """
        定位攻击来源

        Args:
            source_info: 来源信息，包含：
                - ip: IP地址
                - headers: HTTP头信息
                - request_data: 请求数据
                - timestamp: 时间戳

        Returns:
            定位结果，包含：
                - geo_location: 地理位置
                - network_location: 网络位置
                - confidence: 可信度
                - threat_level: 威胁等级
                - recommendations: 建议
        """
        ip = source_info.get('ip', '')
        headers = source_info.get('headers', {})
        request_data = source_info.get('request_data', '')
        timestamp = source_info.get('timestamp', datetime.now().isoformat())

        # 初始化分析结果
        result = IPAnalysisResult(ip)

        # 地理位置分析
        result.geo_location = self._analyze_geo_location(ip, headers)

        # 网络位置分析
        result.network_location = self._analyze_network_location(ip, headers, request_data)

        # 威胁情报查询
        result.threat_intel = self._query_threat_intel(ip)

        # 信誉评分
        result.reputation_score = self._calculate_reputation(result)

        # 匿名化检测
        result.anonymization_detected = self._detect_anonymization(headers, ip)

        # 获取历史记录
        self._update_location_history(ip, result, timestamp)

        # 生成定位报告
        return self._generate_location_report(result, source_info)

    def _analyze_geo_location(self, ip: str, headers: Dict) -> GeoLocation:
        """分析地理位置"""
        # 模拟地理位置数据（实际应用中应连接真实GeoIP服务）
        geo_data = self._get_geo_data_from_cache(ip)

        if not geo_data:
            # 使用模拟数据
            geo_data = self._query_geo_service(ip)

        return GeoLocation(
            country=geo_data.get('country', 'Unknown'),
            country_code=geo_data.get('country_code', 'XX'),
            region=geo_data.get('region', ''),
            city=geo_data.get('city', ''),
            latitude=geo_data.get('latitude', 0.0),
            longitude=geo_data.get('longitude', 0.0),
            timezone=geo_data.get('timezone', 'UTC'),
            isp=geo_data.get('isp', 'Unknown'),
            organization=geo_data.get('org', ''),
            as_number=geo_data.get('asn', 0)
        )

    def _analyze_network_location(self, ip: str, headers: Dict,
                                  request_data: str) -> NetworkLocation:
        """分析网络位置"""
        # 检测是否为代理/VPN/TOR
        is_proxy = self._check_proxy_headers(headers)
        is_vpn = self._check_vpn(ip)
        is_tor = self._check_tor_exit_node(ip)
        is_datacenter = self._check_datacenter_ip(ip)
        is_bot = self._check_bot_signature(headers, request_data)

        # 获取AS信息
        as_info = self._get_as_info(ip)

        # 确定网络类型
        network_type = self._determine_network_type(
            is_proxy, is_vpn, is_tor, is_datacenter
        )

        # 尝试获取反向DNS
        reverse_dns = self._get_reverse_dns(ip)

        return NetworkLocation(
            ip_address=ip,
            hostname=self._get_hostname(ip),
            reverse_dns=reverse_dns,
            is_proxy=is_proxy,
            is_vpn=is_vpn,
            is_tor=is_tor,
            is_datacenter=is_datacenter,
            is_bot=is_bot,
            as_number=as_info.get('asn', 0),
            as_name=as_info.get('name', ''),
            isp=as_info.get('isp', ''),
            network_prefix=self._get_network_prefix(ip),
            network_type=network_type
        )

    def _check_proxy_headers(self, headers: Dict) -> bool:
        """检查代理头"""
        proxy_headers = [
            'X-Forwarded-For',
            'X-Real-IP',
            'Via',
            'Proxy-Connection',
            'X-ProxyId',
            'True-Client-IP',
        ]
        return any(header in headers for header in proxy_headers)

    def _check_vpn(self, ip: str) -> bool:
        """检查VPN"""
        # 模拟VPN检测逻辑
        vpn_patterns = ['10.', '172.16.', '192.168.', '5.', '45.', '91.']
        for pattern in vpn_patterns:
            if ip.startswith(pattern):
                return True
        return False

    def _check_tor_exit_node(self, ip: str) -> bool:
        """检查TOR出口节点"""
        # 实际应用中应查询TOR出口节点列表
        return False

    def _check_datacenter_ip(self, ip: str) -> bool:
        """检查数据中心IP"""
        # 模拟数据中心IP检测
        datacenter_prefixes = ['104.', '130.', '147.', '160.', '185.']
        return any(ip.startswith(p) for p in datacenter_prefixes)

    def _check_bot_signature(self, headers: Dict, request_data: str) -> bool:
        """检查机器人特征"""
        user_agent = headers.get('User-Agent', '').lower()

        # 常见爬虫/机器人UA
        bot_patterns = [
            'bot', 'crawler', 'spider', 'scraper',
            'curl', 'wget', 'python-requests',
            'httpclient', 'java/', 'go-http'
        ]

        return any(pattern in user_agent for pattern in bot_patterns)

    def _get_as_info(self, ip: str) -> Dict:
        """获取AS信息"""
        # 模拟AS查询
        return {
            'asn': 15169,
            'name': 'Google LLC',
            'isp': 'Google LLC',
            'rir': 'ARIN'
        }

    def _get_reverse_dns(self, ip: str) -> Optional[str]:
        """获取反向DNS"""
        # 模拟反向DNS查询
        return None

    def _get_hostname(self, ip: str) -> Optional[str]:
        """获取主机名"""
        return self._get_reverse_dns(ip)

    def _get_network_prefix(self, ip: str) -> str:
        """获取网络前缀"""
        parts = ip.split('.')
        if len(parts) == 4:
            return f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"
        return ip

    def _determine_network_type(self, is_proxy: bool, is_vpn: bool,
                                 is_tor: bool, is_datacenter: bool) -> str:
        """确定网络类型"""
        if is_tor:
            return "tor"
        if is_vpn:
            return "vpn"
        if is_proxy:
            return "proxy"
        if is_datacenter:
            return "datacenter"
        return "residential"

    def _query_threat_intel(self, ip: str) -> Dict:
        """查询威胁情报"""
        # 检查缓存
        if ip in self.threat_intel_cache:
            return self.threat_intel_cache[ip]

        # 模拟威胁情报查询
        threat_intel = {
            'is_malicious': False,
            'threat_categories': [],
            'confidence': 0.0,
            'last_reported': None,
            'report_count': 0,
            'tags': [],
        }

        # 简单检测逻辑
        if ip.startswith('192.168.') or ip.startswith('10.') or ip.startswith('172.'):
            threat_intel['is_private'] = True
        else:
            # 模拟恶意IP检测
            threat_intel['is_malicious'] = False

        # 更新缓存
        if len(self.threat_intel_cache) >= self.max_cache_size:
            oldest_keys = list(self.threat_intel_cache.keys())[:100]
            for key in oldest_keys:
                del self.threat_intel_cache[key]

        self.threat_intel_cache[ip] = threat_intel
        return threat_intel

    def _calculate_reputation(self, result: IPAnalysisResult) -> float:
        """计算信誉评分"""
        score = 100.0  # 从100开始，越低越可疑

        # 地理位置因素
        if result.geo_location:
            if result.geo_location.country_code in self.HIGH_RISK_COUNTRIES:
                score -= 20
            if not result.geo_location.country:
                score -= 10

        # 匿名化因素
        if result.network_location:
            if result.network_location.is_tor:
                score -= 40
            if result.network_location.is_vpn:
                score -= 20
            if result.network_location.is_proxy:
                score -= 15
            if result.network_location.is_datacenter:
                score -= 10
            if result.network_location.is_bot:
                score -= 30

        # 威胁情报因素
        if result.threat_intel.get('is_malicious'):
            score -= 50
        if result.threat_intel.get('report_count', 0) > 0:
            score -= min(30, result.threat_intel['report_count'] * 5)

        # 历史攻击因素
        if len(result.attack_history) > 0:
            score -= min(20, len(result.attack_history) * 2)

        return max(0.0, min(100.0, score))

    def _detect_anonymization(self, headers: Dict, ip: str) -> bool:
        """检测匿名化"""
        indicators = []

        # 检查HTTP头中的匿名化指示
        suspicious_headers = [
            'X-Forwarded-For',
            'X-Real-IP',
            'CF-Connecting-IP',
            'True-Client-IP',
        ]
        for header in suspicious_headers:
            if header in headers:
                indicators.append(f"has_{header}")

        # 检查VPN/TOR
        if self._check_vpn(ip) or self._check_tor_exit_node(ip):
            indicators.append("anonymizer_detected")

        # 检查User-Agent异常
        user_agent = headers.get('User-Agent', '')
        if not user_agent or user_agent == '-':
            indicators.append("missing_user_agent")

        return len(indicators) > 0

    def _get_geo_data_from_cache(self, ip: str) -> Optional[Dict]:
        """从缓存获取地理数据"""
        return None

    def _query_geo_service(self, ip: str) -> Dict:
        """查询地理服务"""
        # 模拟GeoIP查询
        if ip.startswith('192.168.'):
            return {
                'country': 'Private Network',
                'country_code': 'XX',
                'region': '',
                'city': '',
                'latitude': 0.0,
                'longitude': 0.0,
                'timezone': 'UTC',
                'isp': 'Private Network',
                'org': '',
                'asn': 0
            }
        elif ip.startswith('10.'):
            return {
                'country': 'Private Network',
                'country_code': 'XX',
                'region': '',
                'city': '',
                'latitude': 0.0,
                'longitude': 0.0,
                'timezone': 'UTC',
                'isp': 'Private Network',
                'org': '',
                'asn': 0
            }

        # 默认返回美国数据
        return {
            'country': 'United States',
            'country_code': 'US',
            'region': 'California',
            'city': 'Mountain View',
            'latitude': 37.4056,
            'longitude': -122.0775,
            'timezone': 'America/Los_Angeles',
            'isp': 'Google LLC',
            'org': 'Google LLC',
            'asn': 15169
        }

    def _update_location_history(self, ip: str, result: IPAnalysisResult, timestamp: str):
        """更新位置历史"""
        if ip not in self.location_history:
            self.location_history[ip] = []

        self.location_history[ip].append({
            'result': result.to_dict(),
            'timestamp': timestamp
        })

        # 限制历史大小
        if len(self.location_history[ip]) > 100:
            self.location_history[ip] = self.location_history[ip][-100:]

    def _generate_location_report(self, result: IPAnalysisResult,
                                  source_info: Dict) -> Dict:
        """生成定位报告"""
        # 计算定位可信度
        confidence = 0.8
        if result.anonymization_detected:
            confidence *= 0.5
        if result.network_location and (result.network_location.is_vpn or
                                        result.network_location.is_tor):
            confidence *= 0.6

        # 计算威胁等级
        threat_level = "low"
        if result.reputation_score < 30:
            threat_level = "critical"
        elif result.reputation_score < 50:
            threat_level = "high"
        elif result.reputation_score < 70:
            threat_level = "medium"

        # 生成建议
        recommendations = self._generate_recommendations(result, threat_level)

        return {
            'ip': result.ip,
            'geo_location': result.geo_location.to_dict() if result.geo_location else None,
            'network_location': {
                'is_proxy': result.network_location.is_proxy if result.network_location else False,
                'is_vpn': result.network_location.is_vpn if result.network_location else False,
                'is_tor': result.network_location.is_tor if result.network_location else False,
                'is_datacenter': result.network_location.is_datacenter if result.network_location else False,
                'network_type': result.network_location.network_type if result.network_location else 'unknown',
            } if result.network_location else None,
            'confidence': confidence,
            'reputation_score': result.reputation_score,
            'threat_level': threat_level,
            'is_anonymized': result.anonymization_detected,
            'threat_intel': result.threat_intel,
            'recommendations': recommendations,
            'timestamp': source_info.get('timestamp', datetime.now().isoformat()),
        }

    def _generate_recommendations(self, result: IPAnalysisResult,
                                 threat_level: str) -> List[str]:
        """生成建议"""
        recommendations = []

        if threat_level in ['critical', 'high']:
            recommendations.append("建议立即阻断该IP的所有连接")
            recommendations.append("建议加入威胁情报黑名单")

        if result.anonymization_detected:
            recommendations.append("检测到匿名化工具，需提高警惕")

        if result.network_location:
            if result.network_location.is_tor:
                recommendations.append("来源为TOR网络，建议封禁TOR出口节点")
            if result.network_location.is_vpn:
                recommendations.append("来源为VPN，建议记录VPN提供商信息")

        if result.reputation_score < 50:
            recommendations.append("信誉评分较低，建议持续监控")

        if not recommendations:
            recommendations.append("继续监控该IP的行为")

        return recommendations

    def _init_geo_database(self) -> Dict:
        """初始化地理数据库"""
        return {}


# 独立运行测试
if __name__ == "__main__":
    locator = AttackSourceLocator()

    # 测试IP定位
    source_info = {
        'ip': '8.8.8.8',
        'headers': {
            'User-Agent': 'Mozilla/5.0',
            'X-Forwarded-For': '8.8.8.8'
        },
        'request_data': '',
        'timestamp': datetime.now().isoformat()
    }

    result = locator.locate(source_info)
    print("定位结果:")
    print(json.dumps(result, indent=2, ensure_ascii=False))

    # 测试内部IP
    internal_source = {
        'ip': '192.168.1.100',
        'headers': {'User-Agent': 'Test'},
        'request_data': '',
        'timestamp': datetime.now().isoformat()
    }

    result = locator.locate(internal_source)
    print("\n内部IP定位结果:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
