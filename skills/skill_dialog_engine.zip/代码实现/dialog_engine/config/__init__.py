# dialog_engine/config/__init__.py
"""配置模块"""
from .default_config import DefaultConfig, config, get_config, merge_config
