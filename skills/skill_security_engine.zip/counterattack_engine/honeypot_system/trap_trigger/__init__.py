"""
陷阱触发模块
Trap Trigger Module

提供蜜罐陷阱触发功能
"""

__version__ = "v3.0.0"
__all__ = []
