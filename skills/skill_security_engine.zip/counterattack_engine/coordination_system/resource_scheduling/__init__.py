"""
资源调度模块
Resource Scheduling Module

提供反击资源的动态调度功能
"""

__version__ = "v3.0.0"
__all__ = []
