"""
企业级综合监控引擎 v3.0.0
Enterprise Monitor Engine

【设计理念】
- 完全自主可控，无外部依赖
- 全方位监控系统
- 本地化运行，数据不出域
- 企业级架构，稳定可靠

【核心功能】
1. 监控数据采集层 - 基础设施/应用服务/安全状态/业务状态监控
2. 监控数据处理层 - 数据汇聚/处理/存储/查询
3. 监控分析层 - 实时/智能/关联/报告分析
4. 监控展示层 - 监控大屏/仪表盘/拓扑/趋势
5. 监控管理中心 - 配置/策略/运维管理

【版本】v3.0.0 (2026-04-10)
"""

import os
import json
import time
import uuid
import logging
import threading
import random
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
from collections import deque, defaultdict

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# ========== 枚举定义 ==========

class MonitorType(Enum):
    """监控类型"""
    INFRASTRUCTURE = "infrastructure"    # 基础设施监控
    APPLICATION = "application"        # 应用服务监控
    SECURITY = "security"              # 安全状态监控
    BUSINESS = "business"              # 业务状态监控


class MetricType(Enum):
    """指标类型"""
    GAUGE = "gauge"                   # 瞬时值
    COUNTER = "counter"              # 计数器
    HISTOGRAM = "histogram"          # 直方图
    SUMMARY = "summary"             # 摘要


class AlertThreshold:
    """告警阈值"""
    def __init__(self, warning: float, critical: float):
        self.warning = warning
        self.critical = critical


# ========== 数据类定义 ==========

@dataclass
class Metric:
    """指标"""
    metric_id: str
    name: str
    value: float
    metric_type: MetricType
    monitor_type: MonitorType
    category: str
    timestamp: datetime
    unit: str = ""
    tags: Dict = field(default_factory=dict)
    
    def __post_init__(self):
        if not self.metric_id:
            self.metric_id = str(uuid.uuid4())


@dataclass
class MonitorTarget:
    """监控目标"""
    target_id: str
    name: str
    monitor_type: MonitorType
    category: str
    status: str = "healthy"
    last_check: datetime = None
    metrics: Dict = field(default_factory=dict)
    alerts: List[Dict] = field(default_factory=list)


@dataclass
class MonitorAlert:
    """监控告警"""
    alert_id: str
    target_id: str
    target_name: str
    metric_name: str
    level: str  # warning, critical
    value: float
    threshold: float
    message: str
    timestamp: datetime


# ========== 监控数据采集器 ==========

class MonitorCollector:
    """监控数据采集器"""
    
    def __init__(self, config: Dict = None):
        """初始化监控数据采集器"""
        self.config = config or {}
        self._collectors: Dict[str, 'Collector'] = {}
        self._targets: Dict[str, MonitorTarget] = {}
        self._metrics_buffer: deque = deque(maxlen=50000)
        self._lock = threading.Lock()
        self._running = False
        self._collector_thread: threading.Thread = None
        
        # 初始化默认采集器
        self._init_default_collectors()
        
        logger.info("监控数据采集器初始化完成")
    
    def _init_default_collectors(self):
        """初始化默认采集器"""
        # 服务器监控
        self.register_collector('server', ServerMonitor(self.config))
        
        # 网络设备监控
        self.register_collector('network', NetworkMonitor(self.config))
        
        # 容器监控
        self.register_collector('container', ContainerMonitor(self.config))
        
        # 服务监控
        self.register_collector('service', ServiceMonitor(self.config))
        
        # 应用性能监控
        self.register_collector('app_perf', AppPerformanceMonitor(self.config))
        
        # 中间件监控
        self.register_collector('middleware', MiddlewareMonitor(self.config))
        
        # API监控
        self.register_collector('api', APIMonitor(self.config))
        
        # 威胁监控
        self.register_collector('threat', ThreatMonitor(self.config))
        
        # 漏洞监控
        self.register_collector('vulnerability', VulnerabilityMonitor(self.config))
        
        # 合规监控
        self.register_collector('compliance', ComplianceMonitor(self.config))
        
        # 风险监控
        self.register_collector('risk', RiskMonitor(self.config))
        
        # 业务监控
        self.register_collector('business', BusinessMonitor(self.config))
    
    def register_collector(self, name: str, collector: 'Collector'):
        """注册采集器"""
        self._collectors[name] = collector
        logger.info(f"注册监控采集器: {name}")
    
    def register_target(self, target: MonitorTarget):
        """注册监控目标"""
        with self._lock:
            self._targets[target.target_id] = target
        logger.info(f"注册监控目标: {target.name}")
    
    def start(self):
        """启动采集"""
        if self._running:
            return
        self._running = True
        self._collector_thread = threading.Thread(target=self._collect_loop, daemon=True)
        self._collector_thread.start()
        logger.info("监控数据采集已启动")
    
    def stop(self):
        """停止采集"""
        self._running = False
        if self._collector_thread:
            self._collector_thread.join(timeout=5)
        logger.info("监控数据采集已停止")
    
    def _collect_loop(self):
        """采集循环"""
        while self._running:
            try:
                for name, collector in self._collectors.items():
                    metrics = collector.collect()
                    with self._lock:
                        self._metrics_buffer.extend(metrics)
                time.sleep(5)  # 每5秒采集一次
            except Exception as e:
                logger.error(f"采集循环异常: {e}")
    
    def record_metric(self, metric: Metric):
        """记录指标"""
        with self._lock:
            self._metrics_buffer.append(metric)
    
    def get_metrics(self, start_time: datetime = None, end_time: datetime = None,
                   monitor_type: MonitorType = None, limit: int = 1000) -> List[Metric]:
        """获取指标"""
        with self._lock:
            metrics = list(self._metrics_buffer)
        
        if start_time:
            metrics = [m for m in metrics if m.timestamp >= start_time]
        if end_time:
            metrics = [m for m in metrics if m.timestamp <= end_time]
        if monitor_type:
            metrics = [m for m in metrics if m.monitor_type == monitor_type]
        
        return metrics[-limit:]
    
    def get_targets(self) -> List[MonitorTarget]:
        """获取监控目标"""
        with self._lock:
            return list(self._targets.values())


# ========== 采集器实现 ==========

class Collector(ABC):
    """采集器基类"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    @abstractmethod
    def collect(self) -> List[Metric]:
        """采集指标"""
        pass


class ServerMonitor(Collector):
    """服务器监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
        self._servers = ['server-1', 'server-2', 'server-3']
    
    def collect(self) -> List[Metric]:
        """采集服务器指标"""
        metrics = []
        
        for server in self._servers:
            metrics.extend([
                Metric(
                    metric_id=str(uuid.uuid4()),
                    name=f'{server}.cpu_usage',
                    value=random.uniform(20, 80),
                    metric_type=MetricType.GAUGE,
                    monitor_type=MonitorType.INFRASTRUCTURE,
                    category='server',
                    timestamp=datetime.now(),
                    unit='%',
                    tags={'server': server}
                ),
                Metric(
                    metric_id=str(uuid.uuid4()),
                    name=f'{server}.memory_usage',
                    value=random.uniform(30, 70),
                    metric_type=MetricType.GAUGE,
                    monitor_type=MonitorType.INFRASTRUCTURE,
                    category='server',
                    timestamp=datetime.now(),
                    unit='%',
                    tags={'server': server}
                ),
                Metric(
                    metric_id=str(uuid.uuid4()),
                    name=f'{server}.disk_usage',
                    value=random.uniform(40, 60),
                    metric_type=MetricType.GAUGE,
                    monitor_type=MonitorType.INFRASTRUCTURE,
                    category='server',
                    timestamp=datetime.now(),
                    unit='%',
                    tags={'server': server}
                ),
                Metric(
                    metric_id=str(uuid.uuid4()),
                    name=f'{server}.network_in',
                    value=random.uniform(100, 500),
                    metric_type=MetricType.COUNTER,
                    monitor_type=MonitorType.INFRASTRUCTURE,
                    category='server',
                    timestamp=datetime.now(),
                    unit='MB/s',
                    tags={'server': server}
                )
            ])
        
        return metrics


class NetworkMonitor(Collector):
    """网络设备监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集网络指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='network.bandwidth',
                value=random.uniform(100, 800),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.INFRASTRUCTURE,
                category='network',
                timestamp=datetime.now(),
                unit='Mbps'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='network.packet_loss',
                value=random.uniform(0, 0.1),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.INFRASTRUCTURE,
                category='network',
                timestamp=datetime.now(),
                unit='%'
            )
        ]


class ContainerMonitor(Collector):
    """容器云监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集容器指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='container.running',
                value=random.randint(10, 50),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.INFRASTRUCTURE,
                category='container',
                timestamp=datetime.now(),
                unit='count'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='container.cpu_usage',
                value=random.uniform(20, 60),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.INFRASTRUCTURE,
                category='container',
                timestamp=datetime.now(),
                unit='%'
            )
        ]


class ServiceMonitor(Collector):
    """服务状态监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
        self._services = ['auth-service', 'api-gateway', 'data-service']
    
    def collect(self) -> List[Metric]:
        """采集服务指标"""
        metrics = []
        
        for service in self._services:
            metrics.extend([
                Metric(
                    metric_id=str(uuid.uuid4()),
                    name=f'{service}.status',
                    value=1 if random.random() > 0.05 else 0,
                    metric_type=MetricType.GAUGE,
                    monitor_type=MonitorType.APPLICATION,
                    category='service',
                    timestamp=datetime.now(),
                    tags={'service': service}
                ),
                Metric(
                    metric_id=str(uuid.uuid4()),
                    name=f'{service}.response_time',
                    value=random.uniform(10, 100),
                    metric_type=MetricType.GAUGE,
                    monitor_type=MonitorType.APPLICATION,
                    category='service',
                    timestamp=datetime.now(),
                    unit='ms',
                    tags={'service': service}
                )
            ])
        
        return metrics


class AppPerformanceMonitor(Collector):
    """应用性能监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集应用性能指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='app.response_time',
                value=random.uniform(50, 200),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.APPLICATION,
                category='performance',
                timestamp=datetime.now(),
                unit='ms'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='app.throughput',
                value=random.uniform(1000, 5000),
                metric_type=MetricType.COUNTER,
                monitor_type=MonitorType.APPLICATION,
                category='performance',
                timestamp=datetime.now(),
                unit='req/s'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='app.error_rate',
                value=random.uniform(0, 0.05),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.APPLICATION,
                category='performance',
                timestamp=datetime.now(),
                unit='%'
            )
        ]


class MiddlewareMonitor(Collector):
    """中间件监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集中间件指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='db.connections',
                value=random.randint(10, 100),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.APPLICATION,
                category='database',
                timestamp=datetime.now(),
                unit='count'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='cache.hit_rate',
                value=random.uniform(80, 99),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.APPLICATION,
                category='cache',
                timestamp=datetime.now(),
                unit='%'
            )
        ]


class APIMonitor(Collector):
    """API接口监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集API指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='api.calls',
                value=random.randint(10000, 50000),
                metric_type=MetricType.COUNTER,
                monitor_type=MonitorType.APPLICATION,
                category='api',
                timestamp=datetime.now(),
                unit='count'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='api.latency',
                value=random.uniform(10, 50),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.APPLICATION,
                category='api',
                timestamp=datetime.now(),
                unit='ms'
            )
        ]


class ThreatMonitor(Collector):
    """威胁状态监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集威胁指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='threat.detected',
                value=random.randint(0, 5),
                metric_type=MetricType.COUNTER,
                monitor_type=MonitorType.SECURITY,
                category='threat',
                timestamp=datetime.now(),
                unit='count'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='threat.level',
                value=random.uniform(0, 30),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.SECURITY,
                category='threat',
                timestamp=datetime.now(),
                unit='score'
            )
        ]


class VulnerabilityMonitor(Collector):
    """漏洞状态监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集漏洞指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='vuln.total',
                value=random.randint(0, 20),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.SECURITY,
                category='vulnerability',
                timestamp=datetime.now(),
                unit='count'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='vuln.critical',
                value=random.randint(0, 3),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.SECURITY,
                category='vulnerability',
                timestamp=datetime.now(),
                unit='count'
            )
        ]


class ComplianceMonitor(Collector):
    """合规状态监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集合规指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='compliance.score',
                value=random.uniform(85, 99),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.SECURITY,
                category='compliance',
                timestamp=datetime.now(),
                unit='score'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='compliance.violations',
                value=random.randint(0, 5),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.SECURITY,
                category='compliance',
                timestamp=datetime.now(),
                unit='count'
            )
        ]


class RiskMonitor(Collector):
    """风险状态监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集风险指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='risk.score',
                value=random.uniform(10, 50),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.SECURITY,
                category='risk',
                timestamp=datetime.now(),
                unit='score'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='risk.level',
                value=random.randint(1, 3),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.SECURITY,
                category='risk',
                timestamp=datetime.now(),
                unit='level'
            )
        ]


class BusinessMonitor(Collector):
    """业务状态监控"""
    
    def __init__(self, config: Dict = None):
        super().__init__(config)
    
    def collect(self) -> List[Metric]:
        """采集业务指标"""
        return [
            Metric(
                metric_id=str(uuid.uuid4()),
                name='business.transactions',
                value=random.randint(10000, 100000),
                metric_type=MetricType.COUNTER,
                monitor_type=MonitorType.BUSINESS,
                category='business',
                timestamp=datetime.now(),
                unit='count'
            ),
            Metric(
                metric_id=str(uuid.uuid4()),
                name='business.success_rate',
                value=random.uniform(95, 99.9),
                metric_type=MetricType.GAUGE,
                monitor_type=MonitorType.BUSINESS,
                category='business',
                timestamp=datetime.now(),
                unit='%'
            )
        ]


# ========== 监控分析引擎 ==========

class MonitorAnalyzer:
    """监控分析引擎"""
    
    def __init__(self, collector: MonitorCollector):
        """初始化监控分析引擎"""
        self.collector = collector
        self._thresholds: Dict[str, AlertThreshold] = {
            'cpu_usage': AlertThreshold(70, 90),
            'memory_usage': AlertThreshold(80, 95),
            'disk_usage': AlertThreshold(80, 95),
            'response_time': AlertThreshold(200, 500),
            'error_rate': AlertThreshold(1, 5),
            'threat.level': AlertThreshold(20, 50),
            'vuln.critical': AlertThreshold(1, 3),
            'compliance.score': AlertThreshold(80, 60)
        }
        self._alerts: List[MonitorAlert] = []
        logger.info("监控分析引擎初始化完成")
    
    def analyze_realtime(self) -> Dict:
        """实时分析"""
        metrics = self.collector.get_metrics(limit=1000)
        
        # 按指标名分组统计
        by_metric = defaultdict(list)
        for m in metrics:
            by_metric[m.name].append(m.value)
        
        analysis = {
            'timestamp': datetime.now().isoformat(),
            'total_metrics': len(metrics),
            'summary': {},
            'alerts': []
        }
        
        for metric_name, values in by_metric.items():
            if not values:
                continue
            
            avg = sum(values) / len(values)
            analysis['summary'][metric_name] = {
                'avg': round(avg, 2),
                'min': round(min(values), 2),
                'max': round(max(values), 2),
                'count': len(values)
            }
            
            # 检查阈值
            if metric_name in self._thresholds:
                threshold = self._thresholds[metric_name]
                if avg >= threshold.critical:
                    alert = MonitorAlert(
                        alert_id=str(uuid.uuid4()),
                        target_id='system',
                        target_name='监控系统',
                        metric_name=metric_name,
                        level='critical',
                        value=avg,
                        threshold=threshold.critical,
                        message=f'{metric_name}严重超标: {avg:.2f}',
                        timestamp=datetime.now()
                    )
                    analysis['alerts'].append(alert)
                    self._alerts.append(alert)
                elif avg >= threshold.warning:
                    alert = MonitorAlert(
                        alert_id=str(uuid.uuid4()),
                        target_id='system',
                        target_name='监控系统',
                        metric_name=metric_name,
                        level='warning',
                        value=avg,
                        threshold=threshold.warning,
                        message=f'{metric_name}告警: {avg:.2f}',
                        timestamp=datetime.now()
                    )
                    analysis['alerts'].append(alert)
                    self._alerts.append(alert)
        
        return analysis
    
    def get_trends(self, metric_name: str, hours: int = 24) -> Dict:
        """获取趋势"""
        start_time = datetime.now() - timedelta(hours=hours)
        metrics = self.collector.get_metrics(start_time=start_time, limit=10000)
        
        metric_metrics = [m for m in metrics if m.name == metric_name]
        metric_metrics.sort(key=lambda x: x.timestamp)
        
        if not metric_metrics:
            return {'metric': metric_name, 'data': []}
        
        # 按小时聚合
        hourly_data = defaultdict(list)
        for m in metric_metrics:
            hour_key = m.timestamp.strftime('%Y-%m-%d %H:00')
            hourly_data[hour_key].append(m.value)
        
        data = []
        for hour, values in sorted(hourly_data.items()):
            data.append({
                'timestamp': hour,
                'avg': round(sum(values) / len(values), 2),
                'min': round(min(values), 2),
                'max': round(max(values), 2)
            })
        
        return {
            'metric': metric_name,
            'data': data,
            'trend': self._calculate_trend([d['avg'] for d in data])
        }
    
    def _calculate_trend(self, values: List[float]) -> str:
        """计算趋势"""
        if len(values) < 2:
            return 'stable'
        
        recent = sum(values[-3:]) / 3
        older = sum(values[:-3]) / max(1, len(values) - 3)
        
        if recent > older * 1.2:
            return 'increasing'
        elif recent < older * 0.8:
            return 'decreasing'
        return 'stable'
    
    def get_active_alerts(self) -> List[MonitorAlert]:
        """获取活跃告警"""
        return self._alerts[-100:]


# ========== 监控展示引擎 ==========

class MonitorDashboard:
    """监控展示引擎"""
    
    def __init__(self, collector: MonitorCollector, analyzer: MonitorAnalyzer):
        """初始化监控展示引擎"""
        self.collector = collector
        self.analyzer = analyzer
        logger.info("监控展示引擎初始化完成")
    
    def generate_dashboard(self, dashboard_type: str = 'overview') -> Dict:
        """生成监控面板"""
        if dashboard_type == 'overview':
            return self._generate_overview_dashboard()
        elif dashboard_type == 'infrastructure':
            return self._generate_infrastructure_dashboard()
        elif dashboard_type == 'security':
            return self._generate_security_dashboard()
        elif dashboard_type == 'business':
            return self._generate_business_dashboard()
        else:
            return self._generate_overview_dashboard()
    
    def _generate_overview_dashboard(self) -> Dict:
        """生成概览面板"""
        analysis = self.analyzer.analyze_realtime()
        targets = self.collector.get_targets()
        
        return {
            'dashboard': 'overview',
            'title': '综合监控概览',
            'timestamp': datetime.now().isoformat(),
            'summary': {
                'total_targets': len(targets),
                'healthy_targets': sum(1 for t in targets if t.status == 'healthy'),
                'total_alerts': len(analysis['alerts']),
                'critical_alerts': sum(1 for a in analysis['alerts'] if a.level == 'critical')
            },
            'metrics': analysis['summary'],
            'recent_alerts': analysis['alerts'][-10:]
        }
    
    def _generate_infrastructure_dashboard(self) -> Dict:
        """生成基础设施面板"""
        metrics = self.collector.get_metrics(
            monitor_type=MonitorType.INFRASTRUCTURE, limit=500
        )
        
        return {
            'dashboard': 'infrastructure',
            'title': '基础设施监控',
            'timestamp': datetime.now().isoformat(),
            'server_metrics': self._aggregate_metrics(metrics, 'server'),
            'network_metrics': self._aggregate_metrics(metrics, 'network'),
            'container_metrics': self._aggregate_metrics(metrics, 'container')
        }
    
    def _generate_security_dashboard(self) -> Dict:
        """生成安全监控面板"""
        metrics = self.collector.get_metrics(
            monitor_type=MonitorType.SECURITY, limit=500
        )
        
        return {
            'dashboard': 'security',
            'title': '安全状态监控',
            'timestamp': datetime.now().isoformat(),
            'threat_metrics': self._aggregate_metrics(metrics, 'threat'),
            'vulnerability_metrics': self._aggregate_metrics(metrics, 'vulnerability'),
            'compliance_metrics': self._aggregate_metrics(metrics, 'compliance'),
            'risk_metrics': self._aggregate_metrics(metrics, 'risk'),
            'active_alerts': self.analyzer.get_active_alerts()[-20:]
        }
    
    def _generate_business_dashboard(self) -> Dict:
        """生成业务监控面板"""
        metrics = self.collector.get_metrics(
            monitor_type=MonitorType.BUSINESS, limit=500
        )
        
        return {
            'dashboard': 'business',
            'title': '业务状态监控',
            'timestamp': datetime.now().isoformat(),
            'business_metrics': self._aggregate_metrics(metrics, 'business')
        }
    
    def _aggregate_metrics(self, metrics: List[Metric], category: str) -> Dict:
        """聚合指标"""
        category_metrics = [m for m in metrics if m.category == category]
        
        by_name = defaultdict(list)
        for m in category_metrics:
            by_name[m.name].append(m.value)
        
        result = {}
        for name, values in by_name.items():
            result[name] = {
                'avg': round(sum(values) / len(values), 2),
                'min': round(min(values), 2),
                'max': round(max(values), 2)
            }
        
        return result


# ========== 企业级综合监控引擎主类 ==========

class EnterpriseMonitorEngine:
    """企业级综合监控引擎"""
    
    def __init__(self, config: Dict = None):
        """初始化企业级综合监控引擎"""
        self.config = config or {}
        self.version = "v3.0.0"
        
        # 初始化组件
        self._collector = MonitorCollector(self.config)
        self._analyzer = MonitorAnalyzer(self._collector)
        self._dashboard = MonitorDashboard(self._collector, self._analyzer)
        
        logger.info(f"企业级综合监控引擎 {self.version} 初始化完成")
    
    def start(self):
        """启动引擎"""
        self._collector.start()
        logger.info("企业级综合监控引擎已启动")
    
    def stop(self):
        """停止引擎"""
        self._collector.stop()
        logger.info("企业级综合监控引擎已停止")
    
    def record_metric(self, name: str, value: float, monitor_type: MonitorType,
                     category: str = '', **kwargs):
        """记录指标"""
        metric = Metric(
            metric_id=str(uuid.uuid4()),
            name=name,
            value=value,
            metric_type=kwargs.get('metric_type', MetricType.GAUGE),
            monitor_type=monitor_type,
            category=category,
            timestamp=datetime.now(),
            unit=kwargs.get('unit', ''),
            tags=kwargs.get('tags', {})
        )
        self._collector.record_metric(metric)
        return metric
    
    def analyze(self) -> Dict:
        """分析监控数据"""
        return self._analyzer.analyze_realtime()
    
    def get_dashboard(self, dashboard_type: str = 'overview') -> Dict:
        """获取监控面板"""
        return self._dashboard.generate_dashboard(dashboard_type)
    
    def get_trends(self, metric_name: str, hours: int = 24) -> Dict:
        """获取指标趋势"""
        return self._analyzer.get_trends(metric_name, hours)
    
    def get_statistics(self) -> Dict:
        """获取统计信息"""
        targets = self._collector.get_targets()
        analysis = self._analyzer.analyze_realtime()
        
        return {
            'total_targets': len(targets),
            'healthy_targets': sum(1 for t in targets if t.status == 'healthy'),
            'total_alerts': len(analysis['alerts']),
            'critical_alerts': sum(1 for a in analysis['alerts'] if a.level == 'critical')
        }
    
    def get_capabilities(self) -> Dict:
        """获取引擎能力"""
        return {
            'version': self.version,
            'monitor_types': [t.value for t in MonitorType],
            'metric_types': [t.value for t in MetricType],
            'dashboard_types': ['overview', 'infrastructure', 'security', 'business'],
            'collection_interval': 5
        }


# ========== 便捷函数 ==========

def create_monitor_engine(config: Dict = None) -> EnterpriseMonitorEngine:
    """创建企业级综合监控引擎"""
    return EnterpriseMonitorEngine(config)


# ========== 主函数 ==========

if __name__ == '__main__':
    print("=" * 80)
    print("企业级综合安全引擎 - 企业级综合监控引擎 v3.0.0")
    print("【全方位监控系统 - 完全自主实现】")
    print("=" * 80)
    
    engine = create_monitor_engine()
    engine.start()
    
    capabilities = engine.get_capabilities()
    print("\n引擎能力:")
    for key, value in capabilities.items():
        print(f"  {key}: {value}")
    
    time.sleep(2)
    
    # 分析
    print("\n执行实时分析...")
    analysis = engine.analyze()
    print(f"分析结果: {analysis['total_metrics']}个指标")
    print(f"告警数量: {len(analysis['alerts'])}个")
    
    # 面板
    print("\n生成监控面板...")
    dashboard = engine.get_dashboard('security')
    print(f"面板标题: {dashboard['title']}")
    
    # 统计
    stats = engine.get_statistics()
    print(f"\n监控统计:")
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    engine.stop()
    print("\n测试完成!")
