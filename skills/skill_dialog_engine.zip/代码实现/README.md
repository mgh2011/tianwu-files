# AI对话引擎

企业级AI技能综合开发引擎的对话模块，提供多轮对话能力。

## 功能特性

### 1. 对话管理引擎
- 多轮对话状态管理
- 上下文维护与压缩
- 对话流转控制
- 完整的生命周期管理

### 2. 意图识别系统
- 多策略意图分类(规则/ML/混合)
- 实体抽取(正则/词典/NER)
- 槽位填充与管理
- 置信度评估

### 3. 对话策略引擎
- 灵活的策略路由
- 模板化回复生成
- 多模态输出支持
- 快捷回复推荐

### 4. 对话记忆系统
- 短期记忆(Session级)
- 长期记忆(持久化)
- 用户画像管理
- 行为模式分析

### 5. 合规性设计
- 敏感内容过滤
- PII隐私保护
- 审计日志
- 多级安全策略

## 项目结构

```
代码实现/
├── dialog_engine/           # 主引擎包
│   ├── core/                 # 核心模块
│   │   ├── dialog_engine.py  # 对话引擎主控制器
│   │   ├── state_manager.py  # 状态管理器
│   │   └── context_manager.py # 上下文管理器
│   ├── nlu/                  # 语义理解
│   │   ├── intent_classifier.py  # 意图分类器
│   │   ├── entity_extractor.py   # 实体抽取器
│   │   └── slot_filler.py        # 槽位填充器
│   ├── policy/               # 策略模块
│   │   ├── policy_router.py      # 策略路由器
│   │   └── response_generator.py # 回复生成器
│   ├── memory/               # 记忆模块
│   │   ├── short_term_memory.py  # 短期记忆
│   │   ├── long_term_memory.py   # 长期记忆
│   │   └── user_profile.py      # 用户画像
│   ├── security/            # 安全模块
│   │   ├── content_filter.py     # 内容过滤
│   │   ├── privacy_guard.py     # 隐私保护
│   │   └── audit_logger.py      # 审计日志
│   ├── models/              # 数据模型
│   ├── config/              # 配置
│   └── utils/               # 工具函数
├── tests/                   # 测试用例
└── requirements.txt         # 依赖
```

## 快速开始

### 安装依赖

```bash
pip install -r requirements.txt
```

### 基本使用

```python
from dialog_engine import DialogEngine
from dialog_engine.models.data_models import DialogRequest, MessageType

# 创建引擎实例
engine = DialogEngine()

# 注册组件
from dialog_engine.nlu import IntentClassifier, EntityExtractor, SlotFiller
from dialog_engine.policy import PolicyRouter, ResponseGenerator
from dialog_engine.security import ContentFilter, PrivacyGuard, AuditLogger

engine.register_component("intent_classifier", IntentClassifier())
engine.register_component("entity_extractor", EntityExtractor())
engine.register_component("slot_filler", SlotFiller())
engine.register_component("policy_router", PolicyRouter())
engine.register_component("response_generator", ResponseGenerator())
engine.register_component("content_filter", ContentFilter())
engine.register_component("privacy_guard", PrivacyGuard())
engine.register_component("audit_logger", AuditLogger())

# 开始会话
await engine.start_session("session_001", "user_001")

# 处理消息
request = DialogRequest(
    session_id="session_001",
    user_id="user_001",
    message="你好，我想查询明天的天气",
    message_type=MessageType.TEXT
)

response = await engine.process_message(request)
print(response.message.content)

# 结束会话
await engine.end_session("session_001")
```

### 启动API服务

```bash
cd API接口
uvicorn dialogue_api:app --host 0.0.0.0 --port 8000
```

访问API文档: http://localhost:8000/docs

## API接口

| 方法 | 路径 | 描述 |
|------|------|------|
| POST | /api/v1/dialogue/chat | 发送消息 |
| POST | /api/v1/dialogue/session/start | 开始会话 |
| POST | /api/v1/dialogue/session/end | 结束会话 |
| GET | /api/v1/dialogue/session/{id} | 获取会话状态 |
| GET | /api/v1/dialogue/history | 获取历史记录 |
| POST | /api/v1/dialogue/feedback | 提交反馈 |
| GET | /api/v1/dialogue/intents | 获取意图列表 |
| GET | /api/v1/dialogue/health | 健康检查 |
| GET | /api/v1/dialogue/metrics | 获取指标 |

详细API文档请参考: `API接口/API接口文档.md`

## 配置

### 默认配置

引擎使用 `dialog_engine/config/default_config.py` 中的默认配置，包括:

- 对话引擎设置
- NLU配置(意图规则、实体模式)
- 策略配置
- 记忆配置
- 安全配置

### 自定义配置

```python
from dialog_engine.config import merge_config

custom_config = {
    "INTENT_CLASSIFIER": {
        "default_confidence_threshold": 0.8
    },
    "SECURITY": {
        "enable_content_filter": True
    }
}

merge_config(custom_config)
```

## 测试

```bash
# 运行所有测试
pytest tests/ -v

# 运行特定测试
pytest tests/test_dialog_engine.py::TestDialogEngine::test_process_message -v
```

## 文档

- [架构设计文档](./架构设计/架构设计文档.md)
- [API接口文档](./API接口/API接口文档.md)
- [合规性设计文档](./合规设计/合规性设计文档.md)

## 许可证

MIT License
