"""
行动执行模块
Action Execution Module

提供反击行动的底层执行功能
"""

__version__ = "v3.0.0"
__all__ = []
