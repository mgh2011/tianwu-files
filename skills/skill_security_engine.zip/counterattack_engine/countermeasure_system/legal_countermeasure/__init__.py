"""
法律反击模块
Legal Countermeasure Module

提供法律文书生成等功能
"""

from .legal_document_generator import LegalDocumentGenerator

__version__ = "v3.0.0"
__all__ = [
    'LegalDocumentGenerator'
]
