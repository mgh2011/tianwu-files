# dialog_engine/security/content_filter.py
"""
敏感内容过滤器
检测和过滤敏感词汇
"""

import re
import logging
from typing import Dict, List, Optional, Set
from dataclasses import dataclass

from ..models.data_models import ContentCheckResult, SensitiveLevel
from ..config.default_config import config


logger = logging.getLogger(__name__)


@dataclass
class SensitiveWord:
    """敏感词定义"""
    word: str
    level: SensitiveLevel
    category: str
    replacement: Optional[str] = None


class ContentFilter:
    """
    敏感内容过滤器
    支持多级敏感词过滤和替换
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        self.config = config_dict or config.SECURITY
        self.filter_action = self.config.get("filter_action", "block")
        
        # 敏感词库
        self.sensitive_words: Dict[str, List[SensitiveWord]] = {
            "politics": [],      # 政治敏感
            "porn": [],          # 色情低俗
            "violence": [],      # 暴力恐怖
            "fraud": [],         # 欺诈诈骗
            "custom": []         # 自定义
        }
        
        # 预加载敏感词
        self._load_default_words()
        
        # 编译正则
        self._compile_patterns()
        
    def _load_default_words(self):
        """加载默认敏感词"""
        # 从配置加载
        word_lists = self.config.get("sensitive_word_lists", {})
        
        for category, words in word_lists.items():
            for word in words:
                self.add_word(word, category, SensitiveLevel.HIGH)
    
    def _compile_patterns(self):
        """编译匹配模式"""
        self._patterns: Dict[str, re.Pattern] = {}
        
        for category, words in self.sensitive_words.items():
            if words:
                # 构建联合正则
                pattern_str = "|".join(
                    re.escape(w.word) for w in words
                )
                try:
                    self._patterns[category] = re.compile(pattern_str)
                except re.error as e:
                    logger.error(f"Failed to compile pattern for {category}: {e}")
    
    async def check(self, text: str) -> ContentCheckResult:
        """
        内容安全检查
        
        Args:
            text: 待检查文本
            
        Returns:
            ContentCheckResult: 检查结果
        """
        if not text:
            return ContentCheckResult(
                is_safe=True,
                sensitive_level=SensitiveLevel.SAFE,
                sensitive_words=[]
            )
        
        found_sensitive: List[str] = []
        max_level = SensitiveLevel.SAFE
        
        # 检查各类敏感词
        for category, pattern in self._patterns.items():
            matches = pattern.findall(text)
            
            for match in matches:
                if match not in found_sensitive:
                    found_sensitive.append(match)
                
                # 获取敏感词级别
                words = self.sensitive_words.get(category, [])
                for word in words:
                    if word.word == match:
                        if word.level.value > max_level.value:
                            max_level = word.level
                        break
        
        # 决定是否通过
        is_safe = max_level == SensitiveLevel.SAFE
        
        if not is_safe and self.filter_action == "replace":
            filtered_text = await self.replace(text)
            return ContentCheckResult(
                is_safe=True,  # 替换后认为安全
                sensitive_level=max_level,
                sensitive_words=found_sensitive,
                filtered_content=filtered_text,
                suggestion="内容已脱敏处理"
            )
        
        # 生成建议
        suggestion = None
        if not is_safe:
            suggestion = self._get_suggestion(max_level)
        
        return ContentCheckResult(
            is_safe=is_safe,
            sensitive_level=max_level,
            sensitive_words=found_sensitive,
            suggestion=suggestion
        )
    
    async def replace(self, text: str) -> str:
        """
        替换敏感内容
        
        Args:
            text: 原始文本
            
        Returns:
            str: 替换后的文本
        """
        result = text
        
        for category, pattern in self._patterns.items():
            words = self.sensitive_words.get(category, [])
            
            def replacer(match):
                word = match.group()
                for sw in words:
                    if sw.word == word:
                        return sw.replacement or "*" * len(word)
                return "*" * len(word)
            
            result = pattern.sub(replacer, result)
        
        return result
    
    def _get_suggestion(self, level: SensitiveLevel) -> str:
        """获取处理建议"""
        suggestions = {
            SensitiveLevel.SAFE: None,
            SensitiveLevel.LOW: "内容可能引起不适,请注意措辞",
            SensitiveLevel.MEDIUM: "内容包含敏感信息,已被拦截",
            SensitiveLevel.HIGH: "内容严重违规,已被拦截",
            SensitiveLevel.BLOCK: "内容违规,账号已被标记"
        }
        return suggestions.get(level)
    
    def add_word(self, word: str, category: str = "custom",
                level: SensitiveLevel = SensitiveLevel.MEDIUM,
                replacement: Optional[str] = None):
        """
        添加敏感词
        
        Args:
            word: 敏感词
            category: 分类
            level: 敏感级别
            replacement: 替换词
        """
        if category not in self.sensitive_words:
            self.sensitive_words[category] = []
        
        # 检查是否已存在
        if not any(w.word == word for w in self.sensitive_words[category]):
            sensitive_word = SensitiveWord(
                word=word,
                level=level,
                category=category,
                replacement=replacement
            )
            self.sensitive_words[category].append(sensitive_word)
            
            # 重新编译模式
            self._compile_patterns()
            
            logger.info(f"Added sensitive word: {word} to {category}")
    
    def remove_word(self, word: str, category: str = "custom") -> bool:
        """移除敏感词"""
        if category in self.sensitive_words:
            original_len = len(self.sensitive_words[category])
            self.sensitive_words[category] = [
                w for w in self.sensitive_words[category] if w.word != word
            ]
            
            if len(self.sensitive_words[category]) < original_len:
                self._compile_patterns()
                return True
        
        return False
    
    def get_words_by_category(self, category: str) -> List[str]:
        """获取指定分类的敏感词"""
        return [w.word for w in self.sensitive_words.get(category, [])]
    
    def get_all_words(self) -> Dict[str, List[str]]:
        """获取所有敏感词"""
        return {
            category: [w.word for w in words]
            for category, words in self.sensitive_words.items()
        }
    
    def set_filter_action(self, action: str):
        """设置过滤动作"""
        if action in ["block", "warn", "replace"]:
            self.filter_action = action
            logger.info(f"Filter action set to: {action}")
    
    def batch_add(self, words: List[str], category: str = "custom",
                 level: SensitiveLevel = SensitiveLevel.MEDIUM):
        """批量添加敏感词"""
        for word in words:
            self.add_word(word, category, level)
