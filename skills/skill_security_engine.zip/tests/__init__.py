"""
测试模块
Tests Module

提供集成测试等测试功能
"""

__version__ = "v3.0.0"
__all__ = []
