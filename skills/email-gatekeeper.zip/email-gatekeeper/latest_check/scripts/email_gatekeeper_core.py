# ========== 邮件安全守门员核心引擎 v3.0.3 ==========
# 文件: scripts/email_gatekeeper_core.py
# 版本: 3.0.3
# 更新: 新增域名验证、BEC检测、勒索邮件检测

"""
邮件安全守门员核心引擎
支持: 邮件分类、可疑识别、钓鱼检测、域名验证
"""

import re
import hashlib
import logging
import json
import asyncio
import socket
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from urllib.parse import urlparse
import aiohttp

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# ========== 数据结构定义 ==========

class EmailCategory(Enum):
    """邮件分类枚举"""
    TOOL = "tool"           # 工具类
    SOCIAL = "social"       # 社交类
    BUSINESS = "business"    # 事务类
    SUSPICIOUS = "suspicious"  # 可疑类


class RiskLevel(Enum):
    """风险等级枚举"""
    VERY_LOW = (0, 20, "极低", "🟢")
    LOW = (21, 40, "低", "🟡")
    MEDIUM = (41, 60, "中", "🟠")
    HIGH = (61, 80, "高", "🔴")
    VERY_HIGH = (81, 100, "极高", "⚫")
    
    def __init__(self, min_score: int, max_score: int, label: str, emoji: str):
        self.min_score = min_score
        self.max_score = max_score
        self.label = label
        self.emoji = emoji
    
    @classmethod
    def from_score(cls, score: int) -> 'RiskLevel':
        for level in cls:
            if level.min_score <= score <= level.max_score:
                return level
        return cls.VERY_HIGH


@dataclass
class Email:
    """邮件数据结构"""
    message_id: str
    sender: str
    recipients: List[str]
    subject: str
    body: str
    html_body: str = ""
    attachments: List[Dict] = field(default_factory=list)
    headers: Dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    
    @property
    def sender_domain(self) -> str:
        """获取发件人域名"""
        if "@" in self.sender:
            return self.sender.split("@")[-1].lower()
        return ""


@dataclass
class DetectionResult:
    """检测结果数据结构"""
    risk_score: int = 0
    risk_level: RiskLevel = RiskLevel.VERY_LOW
    category: EmailCategory = EmailCategory.BUSINESS
    triggered_rules: List[str] = field(default_factory=list)
    suspicious_features: List[str] = field(default_factory=list)
    recommended_action: str = "deliver"
    confidence: float = 0.0
    details: Dict = field(default_factory=dict)
    phishing_check: Dict = field(default_factory=dict)
    domain_verification: Dict = field(default_factory=dict)


# ========== 品牌域名白名单 ==========

KNOWN_BRAND_DOMAINS = {
    "paypal": ["paypal.com", "paypal.co.uk", "paypal.de"],
    "bank-of-china": ["bank-of-china.com", "boc.cn", "bankofchina.com"],
    "icbc": ["icbc.com.cn", "icbc.com", "95588.com"],
    "amazon": ["amazon.com", "amazon.co.uk", "amazon.de", "amazon.cn"],
    "alibaba": ["alibaba.com", "aliyun.com", "alipay.com"],
    "apple": ["apple.com", "icloud.com", "me.com"],
    "microsoft": ["microsoft.com", "microsoftonline.com", "office.com"],
    "google": ["google.com", "google.co.uk", "google.de"],
    "dhl": ["dhl.com", "dhl.de", "dhl.co.uk"],
    "fedex": ["fedex.com", "fedex.co.uk"],
}


# ========== 域名验证器 v3.0.3 ==========

class DomainVerifier:
    """
    域名验证器 - 新增功能
    支持: SPF/DKIM/DMARC检查、MX记录验证
    """
    
    def __init__(self):
        self.cache = {}
        logger.info("域名验证器初始化完成 (v3.0.3)")
    
    async def verify_sender_domain(self, email_data: Dict) -> Dict:
        """
        验证发件人域名
        
        Args:
            email_data: 包含sender, from_header等信息
            
        Returns:
            验证结果字典
        """
        sender = email_data.get("sender", "")
        from_header = email_data.get("from_header", sender)
        
        # 提取域名
        domain = sender.split("@")[-1].lower() if "@" in sender else ""
        
        result = {
            "domain": domain,
            "spf_result": "unknown",
            "dkim_result": "unknown", 
            "dmarc_result": "unknown",
            "mx_valid": False,
            "mx_records": [],
            "is_verified": False,
            "risk_factors": []
        }
        
        if not domain:
            return result
        
        # 1. MX记录验证
        mx_result = await self._check_mx_records(domain)
        result["mx_valid"] = mx_result["has_mx"]
        result["mx_records"] = mx_result.get("mx", [])
        if not mx_result["has_mx"]:
            result["risk_factors"].append("无MX记录")
        
        # 2. SPF检查 (简化版)
        spf_result = await self._check_spf(domain)
        result["spf_result"] = spf_result["status"]
        if spf_result["status"] == "fail":
            result["risk_factors"].append("SPF验证失败")
        
        # 3. DMARC检查 (简化版)
        dmarc_result = await self._check_dmarc(domain)
        result["dmarc_result"] = dmarc_result["status"]
        if dmarc_result["status"] == "fail":
            result["risk_factors"].append("DMARC验证失败")
        
        # 4. DKIM检查 (基于域名特征)
        dkim_result = self._check_dkim(domain)
        result["dkim_result"] = dkim_result["status"]
        
        # 综合判断
        passed_checks = sum(1 for r in [mx_result["has_mx"], spf_result["status"] != "fail", dkim_result["status"] != "fail"] if r)
        result["is_verified"] = passed_checks >= 2
        
        return result
    
    async def _check_mx_records(self, domain: str) -> Dict:
        """检查MX记录"""
        result = {"has_mx": False, "mx": []}
        
        try:
            # 简化实现：检查DNS MX记录
            mx_records = socket.getaddrinfo(domain, 25)
            if mx_records:
                result["has_mx"] = True
                result["mx"] = list(set([r[4][0] for r in mx_records[:3]]))
        except (socket.gaierror, socket.herror):
            # 如果getaddrinfo失败，尝试直接DNS查询
            try:
                import dns.resolver
                answers = dns.resolver.resolve(domain, 'MX')
                result["has_mx"] = len(answers) > 0
                result["mx"] = [str(r.exchange) for r in answers[:3]]
            except:
                result["has_mx"] = domain in ["gmail.com", "outlook.com", "qq.com"]
        
        return result
    
    async def _check_spf(self, domain: str) -> Dict:
        """检查SPF记录 (简化版)"""
        result = {"status": "unknown", "details": {}}
        
        # 已知大型邮件服务商有SPF
        known_spf_domains = [
            "gmail.com", "google.com", "outlook.com", "microsoft.com",
            "qq.com", "163.com", "126.com", "sina.com",
            "amazon.com", "paypal.com", "alibaba.com"
        ]
        
        if domain in known_spf_domains:
            result["status"] = "pass"
        elif domain.endswith((".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".top")):
            result["status"] = "softfail"
        else:
            result["status"] = "unknown"
        
        return result
    
    async def _check_dmarc(self, domain: str) -> Dict:
        """检查DMARC记录 (简化版)"""
        result = {"status": "unknown", "policy": None}
        
        # 已知使用DMARC的域名
        known_dmarc = [
            "gmail.com", "google.com", "outlook.com", "microsoft.com",
            "amazon.com", "paypal.com", "apple.com"
        ]
        
        if domain in known_dmarc:
            result["status"] = "pass"
        elif domain.endswith((".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".top")):
            result["status"] = "fail"
        
        return result
    
    def _check_dkim(self, domain: str) -> Dict:
        """检查DKIM支持 (简化版)"""
        result = {"status": "unknown"}
        
        # 已知使用DKIM的域名
        known_dkim = [
            "gmail.com", "yahoo.com", "outlook.com", 
            "amazon.com", "paypal.com"
        ]
        
        if domain in known_dkim:
            result["status"] = "pass"
        
        return result


# ========== 钓鱼检测器 ==========

class PhishingDetector:
    """钓鱼检测器 v3.0.3"""
    
    def __init__(self):
        self.known_brands = KNOWN_BRAND_DOMAINS
        self.suspicious_tlds = ['.tk', '.ml', '.ga', '.cf', '.gq', '.xyz', '.top', '.work']
        self.phishing_keywords = ["verify", "account", "suspended", "locked", "urgent", "验证", "账户", "冻结"]
        self.urgent_keywords = ["immediately", "within 24 hours", "限时", "立即", "马上", "24小时"]
        logger.info("钓鱼检测器初始化完成 (v3.0.3)")
    
    def detect_phishing(self, email: Email) -> Dict:
        """全面钓鱼检测"""
        results = {
            'is_phishing': False,
            'confidence': 0,
            'detected_issues': [],
            'details': {'domain_check': {}, 'content_check': {}, 'link_check': {}}
        }
        
        # 1. 域名伪造检测
        domain_result = self._check_domain_spoofing(email)
        results['details']['domain_check'] = domain_result
        
        if domain_result.get('is_spoofed'):
            results['detected_issues'].append(f"域名伪造: {domain_result.get('reason', '')}")
            results['is_phishing'] = True
            results['confidence'] = max(60, domain_result.get('confidence', 60))
            return results
        
        # 2. 内容检测
        content_result = self._check_malicious_content(email)
        results['details']['content_check'] = content_result
        if content_result.get('is_malicious'):
            results['detected_issues'].extend(content_result.get('issues', []))
            results['confidence'] += content_result.get('confidence', 0)
        
        # 3. 链接检测
        link_result = self._check_suspicious_links(email)
        results['details']['link_check'] = link_result
        if link_result.get('has_suspicious'):
            results['detected_issues'].extend(link_result.get('issues', []))
            results['confidence'] += link_result.get('confidence', 0)
        
        results['confidence'] = max(0, min(100, results['confidence']))
        results['is_phishing'] = results['confidence'] >= 50
        
        return results
    
    def _check_domain_spoofing(self, email: Email) -> Dict:
        """检测域名伪造"""
        result = {'is_spoofed': False, 'confidence': 0, 'reason': '', 'actual_domain': email.sender_domain}
        
        sender_domain = email.sender_domain
        if not sender_domain:
            return result
        
        # 同形字攻击检测
        homograph_result = self._detect_homograph_attack(sender_domain)
        if homograph_result['is_attack']:
            result['is_spoofed'] = True  # 必须显式设置
            result['confidence'] = homograph_result['confidence']
            result['reason'] = homograph_result['reason']
            return result
        
        # 品牌域名相似度检测
        claimed_brand = self._extract_claimed_brand(email)
        if claimed_brand:
            similarity_result = self._check_brand_similarity(sender_domain, claimed_brand)
            if similarity_result['is_suspicious']:
                result['is_spoofed'] = True  # 必须显式设置
                result['confidence'] = similarity_result['confidence']
                result['reason'] = similarity_result['reason']
                return result
        
        # 可疑域名检查
        suspicious_result = self._check_suspicious_domain(sender_domain)
        result['confidence'] = suspicious_result.get('confidence', 0)
        result['reason'] = suspicious_result.get('reason', '')
        
        return result
    
    def _extract_claimed_brand(self, email: Email) -> Optional[str]:
        """从邮件中提取声称的品牌"""
        text = f"{email.subject} {email.body}".lower()
        brand_keywords = {
            "paypal": ["paypal", "贝宝"],
            "bank of china": ["bank of china", "中国银行", "中行"],
            "amazon": ["amazon", "亚马逊"],
            "apple": ["apple", "苹果"],
            "microsoft": ["microsoft", "微软"],
            "dhl": ["dhl"],
        }
        for brand, keywords in brand_keywords.items():
            if any(kw in text for kw in keywords):
                return brand
        return None
    
    def _detect_homograph_attack(self, domain: str) -> Dict:
        """检测同形字攻击"""
        result = {'is_attack': False, 'confidence': 0, 'reason': ''}
        normalized = self._normalize_domain(domain)
        
        for brand, valid_domains in self.known_brands.items():
            for valid in valid_domains:
                if normalized == valid and domain != valid:
                    result['is_attack'] = True
                    result['confidence'] = 95
                    result['reason'] = f"同形字攻击: {domain} 冒充 {valid}"
                    return result
        return result
    
    def _normalize_domain(self, domain: str) -> str:
        """标准化域名"""
        normalized = domain.lower()
        for prefix in ['www.', 'mail.', 'secure.', 'login.']:
            if normalized.startswith(prefix):
                normalized = normalized[len(prefix):]
        
        homograph_map = {'0': 'o', '1': 'l'}
        if not normalized.replace('.', '').isdigit():
            for digit, letter in homograph_map.items():
                normalized = normalized.replace(digit, letter)
        return normalized
    
    def _check_brand_similarity(self, domain: str, claimed_brand: str) -> Dict:
        """检测品牌域名相似度"""
        result = {'is_suspicious': False, 'confidence': 0, 'reason': ''}
        brand_domains = self.known_brands.get(claimed_brand, [])
        
        if domain in brand_domains:
            return result
        
        max_similarity = 0
        most_similar = None
        for known in brand_domains:
            similarity = self._calculate_similarity(domain, known)
            if similarity > max_similarity:
                max_similarity = similarity
                most_similar = known
        
        if max_similarity > 0.7:
            result['is_suspicious'] = True
            result['confidence'] = int(max_similarity * 70)
            result['reason'] = f"域名相似: {domain} 与官方 {most_similar}"
        
        return result
    
    def _calculate_similarity(self, domain1: str, domain2: str) -> float:
        """计算域名相似度"""
        d1 = domain1.split('.')[0] if '.' in domain1 else domain1
        d2 = domain2.split('.')[0] if '.' in domain2 else domain2
        max_len = max(len(d1), len(d2))
        if max_len == 0:
            return 0
        distance = self._levenshtein_distance(d1, d2)
        similarity = 1 - (distance / max_len)
        if d2.lower() in d1.lower() or d1.lower() in d2.lower():
            similarity = max(similarity, 0.8)
        return similarity
    
    def _levenshtein_distance(self, s1: str, s2: str) -> int:
        """计算编辑距离"""
        if len(s1) < len(s2):
            return self._levenshtein_distance(s2, s1)
        if len(s2) == 0:
            return len(s1)
        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
        return previous_row[-1]
    
    def _check_suspicious_domain(self, domain: str) -> Dict:
        """检查可疑域名"""
        result = {'is_suspicious': False, 'confidence': 0, 'reason': ''}
        
        for tld in self.suspicious_tlds:
            if domain.endswith(tld):
                result['is_suspicious'] = True
                result['confidence'] = 25
                result['reason'] = f"可疑域名后缀: {tld}"
                break
        
        ip_pattern = r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'
        if re.match(ip_pattern, domain.split(':')[0]):
            result['is_suspicious'] = True
            result['confidence'] = 50
            result['reason'] = "使用IP地址而非域名"
        
        return result
    
    def _check_malicious_content(self, email: Email) -> Dict:
        """检测恶意内容"""
        result = {'is_malicious': False, 'confidence': 0, 'issues': []}
        text = f"{email.subject} {email.body}".lower()
        
        # 钓鱼关键词
        phishing_count = sum(1 for kw in self.phishing_keywords if kw.lower() in text)
        if phishing_count >= 2:
            result['issues'].append(f"包含{phishing_count}个钓鱼关键词")
            result['confidence'] += phishing_count * 5
        
        # 紧急施压
        urgent_count = sum(1 for kw in self.urgent_keywords if kw.lower() in text)
        if urgent_count >= 1:
            result['issues'].append("包含紧急施压词汇")
            result['confidence'] += 15
        
        # 敏感信息请求
        sensitive_patterns = [
            (r'password|密码', "请求密码"),
            (r'credit card|银行卡|信用卡', "请求信用卡信息"),
            (r'bank account|银行账户', "请求银行账户"),
        ]
        for pattern, issue in sensitive_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                result['issues'].append(issue)
                result['confidence'] += 20
        
        # 奖励诱惑
        prize_keywords = ['won', 'prize', 'winner', '中奖', '大奖', '恭喜', '恭喜您', 'free gift']
        prize_count = sum(1 for kw in prize_keywords if kw in text)
        if prize_count >= 1:
            result['issues'].append(f"包含中奖诱惑({prize_count}个关键词)")
            result['confidence'] += 15 * prize_count
        
        result['confidence'] = max(0, result['confidence'])
        result['is_malicious'] = result['confidence'] >= 20
        return result
    
    def _check_suspicious_links(self, email: Email) -> Dict:
        """检测可疑链接"""
        result = {'has_suspicious': False, 'confidence': 0, 'issues': [], 'suspicious_urls': []}
        
        url_pattern = re.compile(r'https?://[^\s<>"\u0060{}|\\^`\[\]]+', re.IGNORECASE)
        urls = url_pattern.findall(email.body)
        
        for url in urls:
            parsed = urlparse(url)
            domain = parsed.netloc.lower().split(':')[0]
            
            normalized = self._normalize_domain(domain)
            for brand, valid_domains in self.known_brands.items():
                for valid in valid_domains:
                    if normalized == valid and domain != valid:
                        result['has_suspicious'] = True
                        result['issues'].append(f"链接域名伪造: {domain} 冒充 {valid}")
                        result['confidence'] += 30
                        result['suspicious_urls'].append(url)
            
            for indicator, issue in [('@', "链接包含@符号"), ('bit.ly', "使用短链接")]:
                if indicator in url:
                    result['issues'].append(issue)
                    result['confidence'] += 5
        
        result['confidence'] = max(0, result['confidence'])
        return result


# ========== 攻击模式检测器 ==========

class AttackPatternDetector:
    """攻击模式检测器 - v3.0.3 新增BEC和勒索检测"""
    
    ATTACK_PATTERNS = {
        "identity_forgery": {
            "keywords": [r"我是.*银行", r"客服", r"官方"],
            "score": 30,
            "description": "身份伪造"
        },
        "urgent_pressure": {
            "keywords": [r"立即", r"马上", r"紧急", r"24小时"],
            "score": 25,
            "description": "紧急施压"
        },
        "credential_request": {
            "keywords": [r"密码", r"password", r"验证码", r"银行卡"],
            "score": 40,
            "description": "权限索取"
        },
        "emotional_manipulation": {
            "keywords": [r"朋友.*出事", r"紧急.*借钱"],
            "score": 30,
            "description": "情感操纵"
        },
        # v3.0.3新增
        "bec_fraud": {
            "keywords": [
                r"供应商.*更新", r"付款.*账户", r"银行.*账户.*变更",
                r"invoice.*payment", r"wire transfer", r"payment details.*change",
                r"供应商", r"采购", r"付款", r"转账"
            ],
            "score": 45,
            "description": "商务邮件诈骗(BEC)"
        },
        "ransomware": {
            "keywords": [
                r"您的.*文件.*加密", r"ransom", r"解密.*需要",
                r"bitcoin|比特币|加密货币.*付款", r"pay.*bitcoin",
                r"文件.*锁定", r"48小时.*不付款"
            ],
            "score": 50,
            "description": "勒索邮件"
        },
        "internal_threat": {
            "keywords": [
                r"内部.*通知", r"人事.*调整", r"工资.*变动",
                r"内部邮件", r"机密.*文件"
            ],
            "score": 20,
            "description": "内部威胁邮件"
        }
    }
    
    def __init__(self):
        self.compiled_patterns = self._compile_patterns()
        self.phishing_detector = PhishingDetector()
        logger.info("攻击模式检测器初始化完成 (v3.0.3)")
    
    def _compile_patterns(self) -> Dict:
        """编译正则表达式"""
        compiled = {}
        for name, pattern in self.ATTACK_PATTERNS.items():
            if "keywords" in pattern:
                compiled[name] = [re.compile(kw, re.IGNORECASE) for kw in pattern["keywords"]]
        return compiled
    
    def detect(self, email: Email) -> Tuple[int, List[str], List[str], Dict]:
        """检测邮件攻击模式"""
        total_score = 0
        triggered_rules = []
        suspicious_features = []
        
        # 钓鱼检测
        phishing_result = self.phishing_detector.detect_phishing(email)
        if phishing_result['is_phishing']:
            total_score += phishing_result['confidence']
            triggered_rules.append("phishing_detected")
            suspicious_features.extend(phishing_result['detected_issues'])
        
        # 其他攻击模式检测
        for pattern_name, pattern_data in self.ATTACK_PATTERNS.items():
            patterns = self.compiled_patterns.get(pattern_name, [])
            for pattern in patterns:
                if pattern.search(email.subject) or pattern.search(email.body):
                    total_score += pattern_data["score"]
                    triggered_rules.append(pattern_name)
                    suspicious_features.append(pattern_data["description"])
                    break
        
        # 附件风险
        for attachment in email.attachments:
            filename = attachment.get("filename", "")
            ext = "." + filename.split(".")[-1].lower() if "." in filename else ""
            high_risk_exts = [".exe", ".scr", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jar"]
            if ext in high_risk_exts:
                total_score += 45
                triggered_rules.append("attachment_risk")
                suspicious_features.append(f"高风险附件: {filename}")
        
        total_score = min(total_score, 100)
        return total_score, triggered_rules, suspicious_features, phishing_result


# ========== 发件人信任度评分器 ==========

class SenderTrustScorer:
    """发件人信任度评分器"""
    
    def __init__(self, whitelist: List[str] = None, blacklist: List[str] = None):
        self.whitelist = set(whitelist or [])
        self.blacklist = set(blacklist or [])
        self.phishing_detector = PhishingDetector()
        logger.info(f"信任度评分器初始化: 白名单={len(self.whitelist)}, 黑名单={len(self.blacklist)}")
    
    def calculate_trust_score(self, email: Email) -> Tuple[int, str, Dict]:
        """计算发件人信任度"""
        score = 50
        details = {"factors": []}
        sender_domain = email.sender_domain
        
        if email.sender in self.whitelist:
            return 100, "极高", {"factors": ["在白名单中"]}
        if sender_domain in self.whitelist:
            return 90, "高", {"factors": ["域名在白名单中"]}
        
        if email.sender in self.blacklist:
            return 0, "极低", {"factors": ["在黑名单中"]}
        if sender_domain in self.blacklist:
            return 5, "极低", {"factors": ["域名在黑名单中"]}
        
        phishing_result = self.phishing_detector._check_domain_spoofing(email)
        if phishing_result['is_spoofed']:
            score -= phishing_result['confidence'] * 0.5
            details["factors"].append(f"域名疑似伪造")
        
        if self._is_official_domain(sender_domain):
            score += 20
            details["factors"].append("官方域名")
        
        score = max(0, min(100, int(score)))
        rating = "极高" if score >= 80 else "高" if score >= 50 else "低" if score >= 20 else "极低"
        
        return score, rating, details
    
    def _is_official_domain(self, domain: str) -> bool:
        """检查官方域名"""
        all_official = set()
        for domains in KNOWN_BRAND_DOMAINS.values():
            all_official.update(domains)
        return domain in all_official
    
    def _is_valid_email_format(self, email_addr: str) -> bool:
        """验证邮件格式"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email_addr))


# ========== 邮件分类器 ==========

class EmailClassifier:
    """邮件分类器"""
    
    TOOL_KEYWORDS = ["验证码", "code", "注册", "激活", "notification", "快递", "订单"]
    SOCIAL_KEYWORDS = ["你好", "hi", "hello", "最近", "朋友", "friend"]
    
    def classify(self, email: Email) -> EmailCategory:
        """对邮件进行分类"""
        combined_text = f"{email.subject} {email.body}"
        
        if any(kw.lower() in combined_text.lower() for kw in self.TOOL_KEYWORDS):
            return EmailCategory.TOOL
        if any(kw.lower() in combined_text.lower() for kw in self.SOCIAL_KEYWORDS):
            return EmailCategory.SOCIAL
        return EmailCategory.BUSINESS


# ========== 邮件安全守门员主类 ==========

class EmailSecurityGatekeeper:
    """邮件安全守门员主类 v3.0.3"""
    
    def __init__(
        self,
        config: Dict = None,
        whitelist: List[str] = None,
        blacklist: List[str] = None
    ):
        self.config = config or {}
        self.attack_detector = AttackPatternDetector()
        self.trust_scorer = SenderTrustScorer(whitelist, blacklist)
        self.classifier = EmailClassifier()
        self.domain_verifier = DomainVerifier()
        self.permission_mode = self.config.get("permission_mode", "standard")
        
        logger.info(f"邮件安全守门员初始化完成: 权限模式={self.permission_mode}")
    
    async def verify_sender_domain(self, email_data: Dict) -> Dict:
        """验证发件人域名 - v3.0.3新增"""
        return await self.domain_verifier.verify_sender_domain(email_data)
    
    async def analyze_email(self, email: Email) -> DetectionResult:
        """分析邮件并返回检测结果"""
        logger.info(f"开始分析邮件: {email.message_id}")
        
        result = DetectionResult()
        
        # 1. 钓鱼检测
        phishing_result = self.attack_detector.phishing_detector.detect_phishing(email)
        result.phishing_check = phishing_result
        
        if phishing_result['is_phishing']:
            result.risk_score += phishing_result['confidence']
            result.triggered_rules.append("phishing_detected")
            result.suspicious_features.extend(phishing_result['detected_issues'])
        
        # 2. 攻击模式检测
        attack_score, rules, features, phishing_detail = self.attack_detector.detect(email)
        if phishing_result['is_phishing']:
            non_phishing_rules = [r for r in rules if r != "phishing_detected"]
            result.risk_score += attack_score * len(non_phishing_rules) / max(1, len(rules)) if rules else 0
        else:
            result.risk_score += attack_score
        result.triggered_rules.extend(rules)
        result.suspicious_features.extend(features)
        
        # 3. 发件人信任度
        trust_score, trust_rating, trust_details = self.trust_scorer.calculate_trust_score(email)
        if trust_rating in ["低", "极低"]:
            trust_penalty = 30 if trust_rating == "极低" else 15
            result.risk_score += trust_penalty
        
        # 4. 域名验证 - v3.0.3新增
        email_data = {"sender": email.sender, "from_header": email.sender}
        domain_verification = await self.domain_verifier.verify_sender_domain(email_data)
        result.domain_verification = domain_verification
        if not domain_verification.get("is_verified"):
            risk_factor_count = len(domain_verification.get("risk_factors", []))
            result.risk_score += risk_factor_count * 10
        
        # 5. 邮件分类
        result.category = self.classifier.classify(email)
        
        # 6. 风险等级
        result.risk_score = max(0, min(100, result.risk_score))
        result.risk_level = RiskLevel.from_score(result.risk_score)
        
        # 7. 动作建议
        result.recommended_action = self._determine_action(result)
        
        # 8. 置信度
        result.confidence = self._calculate_confidence(result, phishing_result)
        
        # 9. 详情
        result.details = {
            "trust_score": trust_score,
            "trust_rating": trust_rating,
            "domain_verification": domain_verification,
            "detection_layers": ["域名检测", "内容检测", "链接检测", "信任度评估", "域名验证"]
        }
        
        logger.info(
            f"邮件分析完成: ID={email.message_id}, "
            f"风险={result.risk_score}({result.risk_level.label}), "
            f"钓鱼={phishing_result['is_phishing']}, "
            f"置信度={result.confidence:.1%}"
        )
        
        return result
    
    def _determine_action(self, result: DetectionResult) -> str:
        """根据检测结果确定处理动作"""
        if result.risk_level == RiskLevel.VERY_HIGH:
            if self.permission_mode == "aggressive":
                return "delete_and_blacklist"
            return "quarantine"
        if result.risk_level == RiskLevel.HIGH:
            return "quarantine"
        if result.risk_level == RiskLevel.MEDIUM:
            if self.permission_mode == "aggressive":
                return "quarantine"
            return "deliver_with_warning"
        return "deliver"
    
    def _calculate_confidence(self, result: DetectionResult, phishing_result: Dict) -> float:
        """计算检测置信度"""
        base = 0.5
        if phishing_result['is_phishing']:
            base += 0.3
        if len(result.triggered_rules) >= 5:
            base += 0.2
        elif len(result.triggered_rules) >= 3:
            base += 0.1
        return min(1.0, base)
    
    async def process_email(self, email: Email) -> Tuple[DetectionResult, str]:
        """处理邮件的完整流程"""
        result = await self.analyze_email(email)
        
        action = result.recommended_action
        
        if action == "delete_and_blacklist":
            self.trust_scorer.blacklist.add(email.sender)
            status = "已删除并加入黑名单"
        elif action == "quarantine":
            status = "已隔离"
        elif action == "deliver_with_warning":
            status = "已放行(带警告)"
        else:
            status = "已放行"
        
        return result, status


# ========== 使用示例 ==========

if __name__ == "__main__":
    async def main():
        print("="*70)
        print("🛡️ 邮件安全守门员 v3.0.3 测试")
        print("="*70)
        
        gatekeeper = EmailSecurityGatekeeper(
            config={"permission_mode": "standard"},
            whitelist=["trusted@example.com"],
            blacklist=["blocked@spam.com"]
        )
        
        # 测试1：域名伪造
        print("\n📧 测试1：paypa1.com 冒充 paypal")
        email1 = Email(
            message_id="test_001",
            sender="security@paypa1.com",
            recipients=["user@example.com"],
            subject="【紧急】您的PayPal账户已被锁定",
            body="请立即验证您的身份: http://paypa1-secure.com/verify"
        )
        result1, status1 = await gatekeeper.process_email(email1)
        print(f"   风险评分: {result1.risk_score}/100")
        print(f"   钓鱼检测: {'🚨 是' if result1.phishing_check.get('is_phishing') else '✅ 否'}")
        print(f"   域名验证: {'✅ 通过' if result1.domain_verification.get('is_verified') else '⚠️ 未通过'}")
        
        # 测试2：域名验证
        print("\n📧 测试2：域名验证")
        email_data = {"sender": "boss@company.com"}
        domain_result = await gatekeeper.verify_sender_domain(email_data)
        print(f"   域名: {domain_result.get('domain')}")
        print(f"   MX记录: {'✅ 有' if domain_result.get('mx_valid') else '❌ 无'}")
        print(f"   SPF: {domain_result.get('spf_result')}")
        
        # 测试3：BEC诈骗
        print("\n📧 测试3：商务邮件诈骗(BEC)")
        email3 = Email(
            message_id="test_003",
            sender="accounting@vendor-company.com",
            recipients=["finance@yourcompany.com"],
            subject="紧急：供应商银行账户变更通知",
            body="您好，供应商的银行账户已更新，请使用新账户付款。新账户：xxxxx"
        )
        result3, _ = await gatekeeper.process_email(email3)
        print(f"   触发规则: {result3.triggered_rules}")
        print(f"   可疑特征: {result3.suspicious_features}")
        
        print("\n✅ v3.0.3 测试完成！")
    
    asyncio.run(main())
