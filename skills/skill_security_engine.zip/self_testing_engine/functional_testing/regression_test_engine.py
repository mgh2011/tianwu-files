"""
回归测试引擎
Regression Test Engine

提供自动回归、选择性回归、增量回归测试能力
"""

import logging
import time
import uuid
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class RegressionTestEngine:
    """回归测试引擎"""
    
    def __init__(self, config: Dict = None):
        """初始化回归测试引擎"""
        self.config = config or {}
        self._test_history = []
        self._baseline_results = {}
        self._regression_configs = {}
        
        # 测试策略
        self._strategies = {
            'full': FullRegressionRunner(self.config),
            'selective': SelectiveRegressionRunner(self.config),
            'incremental': IncrementalRegressionRunner(self.config)
        }
        
        logger.info("回归测试引擎初始化完成")
    
    def set_baseline(self, baseline_results: Dict):
        """设置基准结果"""
        self._baseline_results = baseline_results
    
    def add_regression_config(self, name: str, config: Dict):
        """添加回归配置"""
        self._regression_configs[name] = config
    
    def run_regression_test(self, strategy: str, test_cases: List[Dict]) -> Dict:
        """运行回归测试"""
        if strategy in self._strategies:
            return self._strategies[strategy].run(test_cases)
        else:
            return {'error': f'未知回归策略: {strategy}'}
    
    def run_full_regression(self, test_cases: List[Dict]) -> Dict:
        """运行完整回归测试"""
        return self._strategies['full'].run(test_cases)
    
    def run_selective_regression(self, changed_items: List[str]) -> Dict:
        """运行选择性回归测试"""
        # 获取受影响的测试用例
        affected_tests = self._get_affected_tests(changed_items)
        return self._strategies['selective'].run(affected_tests)
    
    def run_incremental_regression(self, new_tests: List[Dict], baseline_tests: List[Dict]) -> Dict:
        """运行增量回归测试"""
        return self._strategies['incremental'].run({
            'new_tests': new_tests,
            'baseline_tests': baseline_tests
        })
    
    def compare_with_baseline(self, current_results: Dict) -> Dict:
        """与基准对比"""
        if not self._baseline_results:
            return {'error': '没有设置基准结果'}
        
        comparison = {
            'baseline_pass_rate': self._baseline_results.get('pass_rate', 0),
            'current_pass_rate': current_results.get('pass_rate', 0),
            'pass_rate_change': current_results.get('pass_rate', 0) - self._baseline_results.get('pass_rate', 0),
            'regression_detected': current_results.get('failed', 0) > self._baseline_results.get('failed', 0),
            'improvements': [],
            'regressions': []
        }
        
        # 分析改进和回归
        baseline_failed = set(self._baseline_results.get('failed_tests', []))
        current_failed = set(current_results.get('failed_tests', []))
        
        comparison['regressions'] = list(current_failed - baseline_failed)
        comparison['improvements'] = list(baseline_failed - current_failed)
        
        return comparison
    
    def generate_regression_report(self, results: List[Dict]) -> Dict:
        """生成回归报告"""
        report = {
            'report_id': str(uuid.uuid4()),
            'timestamp': datetime.now().isoformat(),
            'total_runs': len(results),
            'summary': self._summarize_results(results),
            'trends': self._analyze_trends(results),
            'recommendations': []
        }
        
        # 生成建议
        failed_count = sum(1 for r in results if r.get('status') == 'failed')
        if failed_count > 0:
            report['recommendations'].append(f"有 {failed_count} 个测试失败，需要修复")
        
        regression_detected = any(r.get('regression', False) for r in results)
        if regression_detected:
            report['recommendations'].append("检测到回归，建议回滚最近的更改")
        
        return report
    
    def _get_affected_tests(self, changed_items: List[str]) -> List[Dict]:
        """获取受影响的测试用例"""
        # 模拟影响分析
        affected = []
        for item in changed_items:
            affected.append({
                'id': f'reg_test_{item}',
                'name': f'测试: {item}',
                'changed_item': item
            })
        return affected
    
    def _summarize_results(self, results: List[Dict]) -> Dict:
        """汇总结果"""
        passed = sum(1 for r in results if r.get('status') == 'passed')
        failed = sum(1 for r in results if r.get('status') == 'failed')
        
        return {
            'total': len(results),
            'passed': passed,
            'failed': failed,
            'pass_rate': (passed / len(results) * 100) if results else 0
        }
    
    def _analyze_trends(self, results: List[Dict]) -> Dict:
        """分析趋势"""
        if len(results) < 2:
            return {'trend': 'stable'}
        
        recent = results[-5:]
        old = results[:-5]
        
        if not old:
            return {'trend': 'stable'}
        
        recent_pass_rate = sum(1 for r in recent if r.get('status') == 'passed') / len(recent) * 100
        old_pass_rate = sum(1 for r in old if r.get('status') == 'passed') / len(old) * 100
        
        if recent_pass_rate > old_pass_rate + 5:
            return {'trend': 'improving', 'change': recent_pass_rate - old_pass_rate}
        elif recent_pass_rate < old_pass_rate - 5:
            return {'trend': 'degrading', 'change': recent_pass_rate - old_pass_rate}
        else:
            return {'trend': 'stable'}


class FullRegressionRunner:
    """完整回归测试运行器"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def run(self, test_cases: List[Dict]) -> Dict:
        """运行完整回归测试"""
        start_time = time.time()
        
        results = []
        passed = failed = skipped = 0
        
        for case in test_cases:
            result = self._execute_test(case)
            results.append(result)
            
            if result['status'] == 'passed':
                passed += 1
            elif result['status'] == 'failed':
                failed += 1
            else:
                skipped += 1
        
        duration = time.time() - start_time
        
        return {
            'type': 'full_regression',
            'strategy': 'full',
            'total': len(test_cases),
            'passed': passed,
            'failed': failed,
            'skipped': skipped,
            'pass_rate': (passed / len(test_cases) * 100) if test_cases else 0,
            'duration': duration,
            'results': results
        }
    
    def _execute_test(self, test_case: Dict) -> Dict:
        """执行测试"""
        return {
            'id': test_case.get('id', ''),
            'name': test_case.get('name', ''),
            'status': 'passed',
            'execution_time': 0.1,
            'regression': False
        }


class SelectiveRegressionRunner:
    """选择性回归测试运行器"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def run(self, test_cases: List[Dict]) -> Dict:
        """运行选择性回归测试"""
        start_time = time.time()
        
        results = []
        passed = failed = skipped = 0
        
        for case in test_cases:
            result = self._execute_test(case)
            results.append(result)
            
            if result['status'] == 'passed':
                passed += 1
            elif result['status'] == 'failed':
                failed += 1
            else:
                skipped += 1
        
        duration = time.time() - start_time
        
        return {
            'type': 'selective_regression',
            'strategy': 'selective',
            'total': len(test_cases),
            'passed': passed,
            'failed': failed,
            'skipped': skipped,
            'pass_rate': (passed / len(test_cases) * 100) if test_cases else 0,
            'duration': duration,
            'results': results,
            'selection_criteria': 'affected_by_changes'
        }


class IncrementalRegressionRunner:
    """增量回归测试运行器"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def run(self, config: Dict) -> Dict:
        """运行增量回归测试"""
        start_time = time.time()
        
        new_tests = config.get('new_tests', [])
        baseline_tests = config.get('baseline_tests', [])
        
        # 测试新增用例
        new_results = []
        new_passed = new_failed = 0
        for test in new_tests:
            result = self._execute_test(test)
            new_results.append(result)
            if result['status'] == 'passed':
                new_passed += 1
            else:
                new_failed += 1
        
        # 验证基线用例（回归检查）
        baseline_results = []
        regression_count = 0
        for test in baseline_tests:
            result = self._execute_test(test)
            if result.get('regression', False):
                regression_count += 1
            baseline_results.append(result)
        
        duration = time.time() - start_time
        
        return {
            'type': 'incremental_regression',
            'strategy': 'incremental',
            'new_tests': {
                'total': len(new_tests),
                'passed': new_passed,
                'failed': new_failed,
                'pass_rate': (new_passed / len(new_tests) * 100) if new_tests else 0
            },
            'baseline_tests': {
                'total': len(baseline_tests),
                'regressions': regression_count
            },
            'duration': duration
        }
    
    def _execute_test(self, test_case: Dict) -> Dict:
        """执行测试"""
        return {
            'id': test_case.get('id', ''),
            'name': test_case.get('name', ''),
            'status': 'passed',
            'execution_time': 0.05,
            'regression': False
        }


# 便捷函数
def create_regression_test_engine(config: Dict = None) -> RegressionTestEngine:
    """创建回归测试引擎"""
    return RegressionTestEngine(config)
