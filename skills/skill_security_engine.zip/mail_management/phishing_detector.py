"""
邮件安全系统 - 钓鱼邮件检测器
Phishing Email Detector

【功能说明】
- 6大类攻击识别
- 30+检测模式
- 品牌仿冒检测
- 紧急诱导检测
- 完全本地化实现
"""

import re
import hashlib
from typing import Dict, List, Optional, Any
import logging

logger = logging.getLogger(__name__)


class PhishingDetector:
    """
    钓鱼邮件检测器
    
    完整实现30+种钓鱼检测模式
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 钓鱼模式库
        self._phishing_patterns = {
            # 品牌仿冒字符
            'homoglyph': [
                ('paypa1', 'paypal'), ('micros0ft', 'microsoft'),
                ('app1e', 'apple'), ('bank0fchina', 'bank of china'),
                ('amaz0n', 'amazon'), ('g00gle', 'google'),
            ],
            # 紧急诱导关键词
            'urgency': [
                '紧急', 'urgent', '立刻', 'immediately', '立即',
                '账户异常', 'account suspended', 'frozen', 'locked',
                'verify', 'confirm', 'update', '验证', '确认'
            ],
            # 威胁关键词
            'threat': [
                '冻结', '锁定', '停用', '注销', 'frozen', 'locked',
                'suspended', 'compromised', 'hacked', '风险', 'danger'
            ]
        }
        
        # 钓鱼URL模式
        self._suspicious_url_patterns = [
            r'http[s]?://[^\s]*\.(xyz|tk|ml|ga|cf|gq|top|work|click)',
            r'http[s]?://[^\s]*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}',
        ]
    
    def check(self, request: Dict) -> Dict:
        """检测钓鱼邮件"""
        email_from = request.get('from', '')
        subject = request.get('subject', '')
        body = request.get('body', '')
        
        indicators = []
        score = 0.0
        
        # 1. 品牌仿冒检测
        if self._check_brand_spoofing(email_from):
            indicators.append('brand_spoofing')
            score += 0.4
        
        # 2. 紧急诱导检测
        urgency_count = self._check_urgency(subject, body)
        if urgency_count >= 2:
            indicators.append('urgency_tactics')
            score += 0.2
        
        # 3. 威胁恐吓检测
        threat_count = self._check_threat_keywords(body)
        if threat_count >= 2:
            indicators.append('threat_tactics')
            score += 0.15
        
        # 4. 敏感信息请求检测
        if self._check_sensitive_request(body):
            indicators.append('sensitive_request')
            score += 0.2
        
        # 5. URL安全检测
        urls = self._extract_urls(body)
        if self._check_suspicious_urls(urls):
            indicators.append('suspicious_urls')
            score += 0.25
        
        # 6. 威胁情报检查
        if self.storage and self.storage.check_threat(email_from):
            indicators.append('threat_intel')
            score += 0.3
        
        threat_score = min(score, 1.0)
        
        return {
            'detected': threat_score >= 0.4,
            'threat_score': threat_score,
            'confidence': 0.7 + len(indicators) * 0.05,
            'is_phishing': threat_score >= 0.6,
            'indicators': indicators,
            'brand_spoofing': 'brand_spoofing' in indicators,
            'urgency_tactics': 'urgency_tactics' in indicators,
        }
    
    def _check_brand_spoofing(self, email_from: str) -> bool:
        """检查品牌仿冒"""
        if '@' not in email_from:
            return False
        
        domain = email_from.split('@')[-1].lower()
        
        for fake, brand in self._phishing_patterns['homoglyph']:
            if fake in domain:
                return True
        
        return False
    
    def _check_urgency(self, subject: str, body: str) -> int:
        """检查紧急诱导"""
        text = (subject + ' ' + body).lower()
        count = 0
        for keyword in self._phishing_patterns['urgency']:
            count += text.count(keyword.lower())
        return count
    
    def _check_threat_keywords(self, body: str) -> int:
        """检查威胁关键词"""
        text = body.lower()
        count = 0
        for keyword in self._phishing_patterns['threat']:
            count += text.count(keyword.lower())
        return count
    
    def _check_sensitive_request(self, body: str) -> bool:
        """检查敏感信息请求"""
        sensitive_keywords = ['密码', 'password', '账号', 'account', '信用卡', 'credit card']
        request_keywords = ['填写', '输入', 'enter', 'provide', '提交']
        
        body_lower = body.lower()
        has_sensitive = any(kw.lower() in body_lower for kw in sensitive_keywords)
        has_request = any(kw.lower() in body_lower for kw in request_keywords)
        
        return has_sensitive and has_request
    
    def _check_suspicious_urls(self, urls: List[str]) -> bool:
        """检查可疑URL"""
        for url in urls:
            for pattern in self._suspicious_url_patterns:
                if re.search(pattern, url, re.IGNORECASE):
                    return True
        return False
    
    def _extract_urls(self, text: str) -> List[str]:
        """提取URL"""
        return re.findall(r'https?://\S+', text)


if __name__ == '__main__':
    print("钓鱼邮件检测器测试")
    
    detector = PhishingDetector(None, None)
    
    test_cases = [
        {
            'from': 'security@paypa1.com',
            'subject': '【紧急】您的账户存在风险',
            'body': '请立即点击链接验证您的账户信息...',
        },
        {
            'from': 'colleague@company.com',
            'subject': '项目会议通知',
            'body': '明天下午3点有产品评审会议。',
        }
    ]
    
    for test in test_cases:
        result = detector.check(test)
        print(f"\n发件人: {test['from']}")
        print(f"钓鱼检测: {'是' if result['is_phishing'] else '否'}")
        print(f"威胁分数: {result['threat_score']:.2%}")
