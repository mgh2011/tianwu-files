# ========== 新闻邮件检测引擎 v3.0.5 ==========
# 文件: scripts/news_email_detector.py
# 版本: 3.0.5
# 功能: 新闻邮件分类、可信度评估、假新闻检测、钓鱼链接检测

"""
新闻邮件检测引擎
支持: 新闻分类、来源可信度、假新闻检测、订阅识别
"""

import re
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


# ========== 数据结构定义 ==========

class NewsCategory(Enum):
    """新闻分类枚举"""
    TECHNOLOGY = "科技"
    FINANCE = "财经"
    POLITICS = "政治"
    ENTERTAINMENT = "娱乐"
    SPORTS = "体育"
    HEALTH = "健康"
    EDUCATION = "教育"
    WORLD = "国际"
    LOCAL = "本地"
    OTHER = "其他"


class SourceCredibility(Enum):
    """新闻来源可信度"""
    HIGHLY_CREDIBLE = (90, 100, "高可信", "🟢")
    CREDIBLE = (70, 89, "可信", "🟡")
    QUESTIONABLE = (50, 69, "存疑", "🟠")
    UNRELIABLE = (0, 49, "不可信", "🔴")
    
    def __init__(self, min_score: int, max_score: int, label: str, emoji: str):
        self.min_score = min_score
        self.max_score = max_score
        self.label = label
        self.emoji = emoji
    
    @classmethod
    def from_score(cls, score: int) -> 'SourceCredibility':
        for level in cls:
            if level.min_score <= score <= level.max_score:
                return level
        return cls.UNRELIABLE


@dataclass
class NewsEmail:
    """新闻邮件数据结构"""
    message_id: str
    sender: str
    subject: str
    body: str
    html_body: str = ""
    links: List[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)
    
    @property
    def sender_domain(self) -> str:
        if "@" in self.sender:
            return self.sender.split("@")[-1].lower()
        return ""


@dataclass
class NewsDetectionResult:
    """新闻检测结果"""
    is_news: bool = False
    category: NewsCategory = NewsCategory.OTHER
    credibility_score: int = 0
    credibility_level: SourceCredibility = SourceCredibility.UNRELIABLE
    is_fake_news: bool = False
    fake_news_indicators: List[str] = field(default_factory=list)
    is_subscription: bool = False
    has_suspicious_links: bool = False
    suspicious_links: List[str] = field(default_factory=list)
    recommended_action: str = "deliver"
    confidence: float = 0.0
    details: Dict = field(default_factory=dict)


# ========== 可信新闻源数据库 ==========

CREDIBLE_NEWS_SOURCES = {
    # 国际主流媒体（高可信度）
    "reuters.com": {"score": 98, "category": "world", "bias": "neutral"},
    "apnews.com": {"score": 97, "category": "world", "bias": "neutral"},
    "bbc.com": {"score": 95, "category": "world", "bias": "slight_left"},
    "npr.org": {"score": 94, "category": "world", "bias": "center"},
    "economist.com": {"score": 93, "category": "finance", "bias": "center_right"},
    "wsj.com": {"score": 92, "category": "finance", "bias": "center_right"},
    "ft.com": {"score": 91, "category": "finance", "bias": "center"},
    "nytimes.com": {"score": 88, "category": "world", "bias": "slight_left"},
    "washingtonpost.com": {"score": 87, "category": "world", "bias": "slight_left"},
    "theguardian.com": {"score": 86, "category": "world", "bias": "left"},
    
    # 中国主流媒体
    "xinhuanet.com": {"score": 90, "category": "world", "bias": "state"},
    "people.com.cn": {"score": 89, "category": "world", "bias": "state"},
    "cctv.com": {"score": 88, "category": "world", "bias": "state"},
    "chinadaily.com.cn": {"score": 85, "category": "world", "bias": "state"},
    "caixin.com": {"score": 84, "category": "finance", "bias": "center"},
    "yicai.com": {"score": 83, "category": "finance", "bias": "center"},
    "36kr.com": {"score": 82, "category": "tech", "bias": "center"},
    "huxiu.com": {"score": 80, "category": "tech", "bias": "center"},
    
    # 科技媒体
    "techcrunch.com": {"score": 85, "category": "tech", "bias": "center"},
    "theverge.com": {"score": 84, "category": "tech", "bias": "center"},
    "wired.com": {"score": 83, "category": "tech", "bias": "center"},
    "arstechnica.com": {"score": 82, "category": "tech", "bias": "center"},
    
    # 财经媒体
    "bloomberg.com": {"score": 92, "category": "finance", "bias": "center"},
    "cnbc.com": {"score": 85, "category": "finance", "bias": "center"},
    "marketwatch.com": {"score": 82, "category": "finance", "bias": "center"},
}

# 不可信新闻源黑名单
UNRELIABLE_SOURCES = {
    # 已知假新闻网站
    "naturalnews.com": {"score": 20, "reason": "健康谣言、阴谋论"},
    "infowars.com": {"score": 15, "reason": "阴谋论、虚假信息"},
    "breitbart.com": {"score": 25, "reason": "极端偏见、误导性标题"},
    "dailymail.co.uk": {"score": 35, "reason": "标题党、事实核查不足"},
    "theonion.com": {"score": 10, "reason": "讽刺网站，非真实新闻"},
    
    # 点击农场
    "buzzfeed.com": {"score": 45, "reason": "标题党、内容质量不稳定"},
    "huffpost.com": {"score": 50, "reason": "观点偏激、事实核查不足"},
}

# 假新闻关键词
FAKE_NEWS_INDICATORS = [
    # 英文假新闻关键词
    "breaking: you won't believe",
    "shocking truth",
    "they don't want you to know",
    "doctors hate this",
    "one weird trick",
    "miracle cure",
    "secret that",
    "what they're hiding",
    "mainstream media won't tell you",
    "fake news media",
    "cover up exposed",
    "hidden truth",
    
    # 中文假新闻关键词
    "震惊",
    "惊人真相",
    "他们不想让你知道",
    "医生最怕",
    "一个简单的方法",
    "奇迹疗法",
    "秘密曝光",
    "隐藏的真相",
    "主流媒体不敢报道",
    "惊天大秘密",
    "不可告人的秘密",
    "彻底颠覆你的认知",
    "震惊全国",
    "看完全文惊呆了",
    "不转不是中国人",
    "马上删除",
    "速看马上删",
]

# 订阅邮件关键词
SUBSCRIPTION_KEYWORDS = [
    # 英文
    "unsubscribe", "opt-out", "manage subscription", "email preferences",
    "click here to unsubscribe", "update your preferences",
    "you're receiving this because", "sent to",
    
    # 中文
    "退订", "取消订阅", "管理订阅", "邮件偏好",
    "点击退订", "更新偏好设置", "您收到此邮件是因为",
]


# ========== 新闻邮件检测引擎 ==========

class NewsEmailDetector:
    """新闻邮件检测引擎 v3.0.5"""
    
    def __init__(self):
        self.credible_sources = CREDIBLE_NEWS_SOURCES
        self.unreliable_sources = UNRELIABLE_SOURCES
        self.fake_news_indicators = FAKE_NEWS_INDICATORS
        self.subscription_keywords = SUBSCRIPTION_KEYWORDS
        
        # 新闻分类关键词
        self.category_keywords = {
            NewsCategory.TECHNOLOGY: [
                "technology", "tech", "ai", "人工智能", "科技", "软件", "硬件",
                "互联网", "云计算", "大数据", "区块链", "芯片", "手机", "电脑"
            ],
            NewsCategory.FINANCE: [
                "finance", "market", "stock", "economy", "财经", "股市", "金融",
                "经济", "投资", "基金", "银行", "证券", "理财", "货币"
            ],
            NewsCategory.POLITICS: [
                "politics", "government", "election", "policy", "政治", "政府",
                "选举", "政策", "国会", "议会", "立法", "外交"
            ],
            NewsCategory.ENTERTAINMENT: [
                "entertainment", "celebrity", "movie", "music", "娱乐", "明星",
                "电影", "音乐", "综艺", "电视剧", "演员", "歌手"
            ],
            NewsCategory.SPORTS: [
                "sports", "football", "basketball", "olympic", "体育", "足球",
                "篮球", "奥运", "比赛", "冠军", "联赛"
            ],
            NewsCategory.HEALTH: [
                "health", "medical", "hospital", "disease", "健康", "医疗",
                "医院", "疾病", "疫苗", "药品", "医生"
            ],
            NewsCategory.EDUCATION: [
                "education", "school", "university", "student", "教育", "学校",
                "大学", "学生", "考试", "招生", "培训"
            ],
            NewsCategory.WORLD: [
                "world", "international", "global", "international news", "国际",
                "全球", "世界", "联合国", "外交"
            ],
        }
        
        logger.info("新闻邮件检测引擎初始化完成 v3.0.5")
    
    def detect(self, email: NewsEmail) -> NewsDetectionResult:
        """
        检测新闻邮件
        
        检测维度：
        1. 是否为新闻邮件
        2. 新闻分类
        3. 来源可信度
        4. 假新闻检测
        5. 订阅识别
        6. 可疑链接检测
        """
        result = NewsDetectionResult()
        
        # 1. 判断是否为新闻邮件
        result.is_news = self._is_news_email(email)
        if not result.is_news:
            result.recommended_action = "deliver"
            return result
        
        # 2. 新闻分类
        result.category = self._classify_news(email)
        
        # 3. 来源可信度评估
        result.credibility_score = self._assess_credibility(email)
        result.credibility_level = SourceCredibility.from_score(result.credibility_score)
        
        # 4. 假新闻检测
        fake_result = self._detect_fake_news(email)
        result.is_fake_news = fake_result['is_fake']
        result.fake_news_indicators = fake_result['indicators']
        
        # 5. 订阅识别
        result.is_subscription = self._detect_subscription(email)
        
        # 6. 可疑链接检测
        link_result = self._detect_suspicious_links(email)
        result.has_suspicious_links = link_result['has_suspicious']
        result.suspicious_links = link_result['suspicious_urls']
        
        # 7. 确定推荐动作
        result.recommended_action = self._determine_action(result)
        
        # 8. 计算置信度
        result.confidence = self._calculate_confidence(result)
        
        # 9. 详情
        result.details = {
            "sender_domain": email.sender_domain,
            "category": result.category.value,
            "credibility": result.credibility_level.label,
            "is_subscription": result.is_subscription,
        }
        
        return result
    
    def _is_news_email(self, email: NewsEmail) -> bool:
        """判断是否为新闻邮件"""
        # 检查发件人域名是否在可信源列表
        domain = email.sender_domain
        if domain in self.credible_sources or domain in self.unreliable_sources:
            return True
        
        # 检查邮件主题是否包含新闻相关词汇
        news_keywords = [
            "news", "newsletter", "daily", "weekly", "digest", "breaking",
            "新闻", "快讯", "日报", "周报", "早报", "晚报", "速递"
        ]
        subject_lower = email.subject.lower()
        if any(kw in subject_lower for kw in news_keywords):
            return True
        
        # 检查是否有订阅退订链接
        body_lower = email.body.lower()
        if any(kw in body_lower for kw in self.subscription_keywords):
            return True
        
        return False
    
    def _classify_news(self, email: NewsEmail) -> NewsCategory:
        """分类新闻"""
        text = f"{email.subject} {email.body}".lower()
        
        # 首先检查域名对应的分类
        domain = email.sender_domain
        if domain in self.credible_sources:
            category_str = self.credible_sources[domain].get("category", "")
            category_map = {
                "tech": NewsCategory.TECHNOLOGY,
                "finance": NewsCategory.FINANCE,
                "world": NewsCategory.WORLD,
            }
            if category_str in category_map:
                return category_map[category_str]
        
        # 根据关键词分类
        scores = {}
        for category, keywords in self.category_keywords.items():
            score = sum(1 for kw in keywords if kw in text)
            if score > 0:
                scores[category] = score
        
        if scores:
            return max(scores, key=scores.get)
        
        return NewsCategory.OTHER
    
    def _assess_credibility(self, email: NewsEmail) -> int:
        """评估来源可信度"""
        domain = email.sender_domain
        
        # 检查可信源
        if domain in self.credible_sources:
            return self.credible_sources[domain]["score"]
        
        # 检查不可信源
        if domain in self.unreliable_sources:
            return self.unreliable_sources[domain]["score"]
        
        # 未知来源，基于内容评估
        score = 50  # 基础分
        
        # 检查是否使用HTTPS链接
        if email.links and all(link.startswith("https://") for link in email.links):
            score += 5
        
        # 检查是否有明确的作者和日期
        if re.search(r'\d{4}[-/年]\d{1,2}[-/月]\d{1,2}[日]?', email.body):
            score += 5
        
        # 检查是否有引用来源
        if "来源：" in email.body or "Source:" in email.body:
            score += 5
        
        # 检查假新闻指标（扣分）
        fake_count = sum(1 for ind in self.fake_news_indicators if ind in email.body.lower())
        score -= fake_count * 10
        
        return max(0, min(100, score))
    
    def _detect_fake_news(self, email: NewsEmail) -> Dict:
        """检测假新闻"""
        result = {
            'is_fake': False,
            'indicators': []
        }
        
        text = f"{email.subject} {email.body}".lower()
        
        # 检查假新闻关键词
        for indicator in self.fake_news_indicators:
            if indicator.lower() in text:
                result['indicators'].append(f"包含假新闻关键词: {indicator}")
        
        # 检查标题党
        clickbait_patterns = [
            r'你绝对.*相信',
            r'震惊.*真相',
            r'.*惊呆了',
            r'不得不看',
            r'紧急通知',
            r'速看.*删',
        ]
        for pattern in clickbait_patterns:
            if re.search(pattern, email.subject):
                result['indicators'].append(f"标题党: {pattern}")
        
        # 检查过度感叹
        exclamation_count = email.subject.count('!') + email.subject.count('！')
        if exclamation_count >= 3:
            result['indicators'].append(f"过度感叹: {exclamation_count}个感叹号")
        
        # 综合判断
        result['is_fake'] = len(result['indicators']) >= 2
        
        if result['is_fake']:
            logger.warning(f"🚨 假新闻检测: {email.message_id}, 指标={result['indicators']}")
        
        return result
    
    def _detect_subscription(self, email: NewsEmail) -> bool:
        """检测是否为订阅邮件"""
        text = f"{email.subject} {email.body}".lower()
        
        # 检查订阅关键词
        subscription_count = sum(1 for kw in self.subscription_keywords if kw in text)
        
        return subscription_count >= 1
    
    def _detect_suspicious_links(self, email: NewsEmail) -> Dict:
        """检测可疑链接"""
        result = {
            'has_suspicious': False,
            'suspicious_urls': []
        }
        
        for url in email.links:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            
            # 检查是否为可疑短链接
            short_domains = ['bit.ly', 'tinyurl.com', 't.cn', 'dwz.cn', 'b23.tv']
            if any(sd in domain for sd in short_domains):
                result['suspicious_urls'].append(url)
                result['has_suspicious'] = True
            
            # 检查是否为IP地址
            ip_pattern = r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'
            if re.match(ip_pattern, domain):
                result['suspicious_urls'].append(url)
                result['has_suspicious'] = True
        
        return result
    
    def _determine_action(self, result: NewsDetectionResult) -> str:
        """确定推荐动作"""
        # 假新闻 -> 隔离
        if result.is_fake_news:
            return "quarantine"
        
        # 不可信来源 -> 警告
        if result.credibility_level == SourceCredibility.UNRELIABLE:
            return "deliver_with_warning"
        
        # 可疑链接 -> 警告
        if result.has_suspicious_links:
            return "deliver_with_warning"
        
        # 正常新闻 -> 放行
        return "deliver"
    
    def _calculate_confidence(self, result: NewsDetectionResult) -> float:
        """计算检测置信度"""
        base = 0.5
        
        # 已知来源加分
        if result.credibility_score > 70:
            base += 0.2
        elif result.credibility_score < 30:
            base += 0.1  # 低可信度也意味着判断更确定
        
        # 假新闻指标多加分
        if len(result.fake_news_indicators) >= 2:
            base += 0.2
        
        # 有可疑链接加分
        if result.has_suspicious_links:
            base += 0.1
        
        return min(1.0, base)
    
    def quick_scan(self, email: NewsEmail) -> Dict:
        """
        快速扫描模式（跳过耗时操作）
        
        适用场景：
        - 批量处理大量邮件
        - 实时性要求高
        """
        result = {
            'is_news': self._is_news_email(email),
            'credibility': self._assess_credibility(email),
            'is_subscription': self._detect_subscription(email),
        }
        
        # 快速判断
        result['recommended_action'] = 'deliver'
        if result['credibility'] < 30:
            result['recommended_action'] = 'deliver_with_warning'
        
        return result


# ========== 批量处理器 ==========

class BatchNewsProcessor:
    """批量新闻邮件处理器"""
    
    def __init__(self, detector: NewsEmailDetector = None):
        self.detector = detector or NewsEmailDetector()
    
    async def process_batch(self, emails: List[NewsEmail], quick_mode: bool = False) -> Dict:
        """
        批量处理新闻邮件
        
        Args:
            emails: 邮件列表
            quick_mode: 是否使用快速模式
        
        Returns:
            处理结果汇总
        """
        results = {
            'total': len(emails),
            'news_count': 0,
            'fake_news_count': 0,
            'suspicious_count': 0,
            'by_category': {},
            'by_credibility': {},
            'details': []
        }
        
        for email in emails:
            if quick_mode:
                detail = self.detector.quick_scan(email)
            else:
                detail = self.detector.detect(email)
            
            results['details'].append(detail)
            
            # 统计
            if detail.is_news:
                results['news_count'] += 1
            
            if hasattr(detail, 'is_fake_news') and detail.is_fake_news:
                results['fake_news_count'] += 1
            
            if hasattr(detail, 'has_suspicious_links') and detail.has_suspicious_links:
                results['suspicious_count'] += 1
            
            # 分类统计
            if hasattr(detail, 'category'):
                cat = detail.category.value
                results['by_category'][cat] = results['by_category'].get(cat, 0) + 1
            
            # 可信度统计
            if hasattr(detail, 'credibility_level'):
                cred = detail.credibility_level.label
                results['by_credibility'][cred] = results['by_credibility'].get(cred, 0) + 1
        
        return results


# ========== 使用示例 ==========

if __name__ == "__main__":
    # 示例：检测新闻邮件
    detector = NewsEmailDetector()
    
    # 创建测试邮件
    test_email = NewsEmail(
        message_id="news_001",
        sender="newsletter@techcrunch.com",
        subject="TechCrunch Daily: AI Breakthrough",
        body="""
        Today's top tech news:
        - OpenAI announces GPT-5
        - Apple's new AI features
        
        To unsubscribe, click here.
        """,
        links=["https://techcrunch.com/article/1"]
    )
    
    # 检测
    result = detector.detect(test_email)
    
    print(f"Is News: {result.is_news}")
    print(f"Category: {result.category.value}")
    print(f"Credibility: {result.credibility_level.label} ({result.credibility_score})")
    print(f"Is Fake: {result.is_fake_news}")
    print(f"Action: {result.recommended_action}")
