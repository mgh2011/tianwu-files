"""
态势感知模块
Situation Awareness Module

提供环境、行为、状态、态势感知功能
"""

__version__ = "v3.0.0"
__all__ = []
