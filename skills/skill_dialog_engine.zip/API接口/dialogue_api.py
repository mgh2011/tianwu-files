# 对话API接口文档
# dialog_engine/api/dialogue_api.py

"""
对话引擎API接口
提供HTTP API访问对话能力
"""

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
import asyncio
import logging

# 导入对话引擎
from dialog_engine import DialogEngine
from dialog_engine.models.data_models import (
    DialogRequest, DialogResponse, DialogState, 
    MessageType, ResponseCode
)


logger = logging.getLogger(__name__)


# ============== 请求/响应模型 ==============

class ChatRequest(BaseModel):
    """聊天请求"""
    session_id: str = Field(..., description="会话ID")
    user_id: str = Field(..., description="用户ID")
    message: str = Field(..., description="用户消息")
    message_type: str = Field(default="text", description="消息类型")
    context: Optional[Dict[str, Any]] = Field(default_factory=dict, description="额外上下文")
    stream: bool = Field(default=False, description="是否流式响应")


class ChatResponse(BaseModel):
    """聊天响应"""
    code: int = Field(default=0, description="状态码")
    message: str = Field(default="success", description="状态消息")
    data: Optional[Dict[str, Any]] = Field(default=None, description="响应数据")


class SessionStartRequest(BaseModel):
    """会话开始请求"""
    user_id: str = Field(..., description="用户ID")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="元数据")


class SessionResponse(BaseModel):
    """会话响应"""
    session_id: str
    user_id: str
    state: str
    created_at: str


class FeedbackRequest(BaseModel):
    """反馈请求"""
    session_id: str
    response_id: str
    rating: int = Field(..., ge=1, le=5, description="评分1-5")
    comment: Optional[str] = Field(None, description="评论")
    tags: Optional[List[str]] = Field(default_factory=list, description="标签")


class IntentInfo(BaseModel):
    """意图信息"""
    name: str
    description: str
    required_slots: List[str] = Field(default_factory=list)


# ============== API实例 ==============

# 全局对话引擎实例
dialog_engine: Optional[DialogEngine] = None

# 创建FastAPI应用
app = FastAPI(
    title="AI对话引擎API",
    description="企业级AI技能综合开发引擎的对话模块API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_dialog_engine() -> DialogEngine:
    """获取对话引擎实例"""
    global dialog_engine
    if dialog_engine is None:
        dialog_engine = DialogEngine()
        # 初始化组件
        from dialog_engine.nlu import IntentClassifier, EntityExtractor, SlotFiller
        from dialog_engine.policy import PolicyRouter, ResponseGenerator
        from dialog_engine.security import ContentFilter, PrivacyGuard, AuditLogger
        
        dialog_engine.register_component("intent_classifier", IntentClassifier())
        dialog_engine.register_component("entity_extractor", EntityExtractor())
        dialog_engine.register_component("slot_filler", SlotFiller())
        dialog_engine.register_component("policy_router", PolicyRouter())
        dialog_engine.register_component("response_generator", ResponseGenerator())
        dialog_engine.register_component("content_filter", ContentFilter())
        dialog_engine.register_component("privacy_guard", PrivacyGuard())
        dialog_engine.register_component("audit_logger", AuditLogger())
    
    return dialog_engine


# ============== API端点 ==============

@app.post("/api/v1/dialogue/chat", response_model=ChatResponse, tags=["对话"])
async def chat(request: ChatRequest):
    """
    发送消息
    
    处理用户消息并返回对话响应
    """
    try:
        engine = get_dialog_engine()
        
        # 转换为内部请求
        dialog_request = DialogRequest(
            session_id=request.session_id,
            user_id=request.user_id,
            message=request.message,
            message_type=MessageType(request.message_type),
            context=request.context,
            stream=request.stream
        )
        
        # 处理消息
        response = await engine.process_message(dialog_request)
        
        # 转换响应
        return ChatResponse(
            code=ResponseCode.SUCCESS,
            message="success",
            data=response.to_dict()
        )
        
    except Exception as e:
        logger.error(f"Chat error: {e}", exc_info=True)
        return ChatResponse(
            code=ResponseCode.GENERAL_ERROR,
            message=str(e),
            data=None
        )


@app.post("/api/v1/dialogue/session/start", response_model=ChatResponse, tags=["会话"])
async def start_session(request: SessionStartRequest):
    """
    开始会话
    
    创建新的对话会话
    """
    try:
        from uuid import uuid4
        from dialog_engine.models.data_models import Session
        
        engine = get_dialog_engine()
        session_id = f"sess_{uuid4().hex[:12]}"
        
        session = await engine.start_session(session_id, request.user_id, **request.metadata)
        
        return ChatResponse(
            code=ResponseCode.SUCCESS,
            message="success",
            data={
                "session_id": session.session_id,
                "user_id": session.user_id,
                "state": session.state.value if isinstance(session.state, DialogState) else session.state,
                "created_at": session.created_at.isoformat()
            }
        )
        
    except Exception as e:
        logger.error(f"Start session error: {e}", exc_info=True)
        return ChatResponse(
            code=ResponseCode.GENERAL_ERROR,
            message=str(e),
            data=None
        )


@app.post("/api/v1/dialogue/session/end", response_model=ChatResponse, tags=["会话"])
async def end_session(session_id: str):
    """
    结束会话
    
    关闭指定的对话会话
    """
    try:
        engine = get_dialog_engine()
        result = await engine.end_session(session_id)
        
        if result:
            return ChatResponse(
                code=ResponseCode.SUCCESS,
                message="Session ended",
                data={"session_id": session_id}
            )
        else:
            return ChatResponse(
                code=ResponseCode.SESSION_NOT_FOUND,
                message="Session not found",
                data=None
            )
            
    except Exception as e:
        logger.error(f"End session error: {e}", exc_info=True)
        return ChatResponse(
            code=ResponseCode.GENERAL_ERROR,
            message=str(e),
            data=None
        )


@app.get("/api/v1/dialogue/session/{session_id}", response_model=ChatResponse, tags=["会话"])
async def get_session(session_id: str):
    """
    获取会话状态
    
    查询指定会话的当前状态
    """
    try:
        engine = get_dialog_engine()
        state = await engine.get_session_state(session_id)
        
        if state:
            return ChatResponse(
                code=ResponseCode.SUCCESS,
                message="success",
                data=state
            )
        else:
            return ChatResponse(
                code=ResponseCode.SESSION_NOT_FOUND,
                message="Session not found",
                data=None
            )
            
    except Exception as e:
        logger.error(f"Get session error: {e}", exc_info=True)
        return ChatResponse(
            code=ResponseCode.GENERAL_ERROR,
            message=str(e),
            data=None
        )


@app.get("/api/v1/dialogue/history", response_model=ChatResponse, tags=["历史"])
async def get_history(session_id: str, limit: int = 20):
    """
    获取对话历史
    
    获取指定会话的对话历史记录
    """
    try:
        engine = get_dialog_engine()
        context = engine.context_manager.get_context(session_id)
        
        if context:
            history = engine.context_manager.get_history(session_id, limit)
            return ChatResponse(
                code=ResponseCode.SUCCESS,
                message="success",
                data={
                    "session_id": session_id,
                    "history": [
                        {
                            "turn_id": turn.turn_id,
                            "user_message": turn.user_message,
                            "bot_response": turn.bot_response,
                            "intent": turn.intent,
                            "timestamp": turn.timestamp.isoformat()
                        }
                        for turn in history
                    ]
                }
            )
        else:
            return ChatResponse(
                code=ResponseCode.SESSION_NOT_FOUND,
                message="Session not found",
                data=None
            )
            
    except Exception as e:
        logger.error(f"Get history error: {e}", exc_info=True)
        return ChatResponse(
            code=ResponseCode.GENERAL_ERROR,
            message=str(e),
            data=None
        )


@app.post("/api/v1/dialogue/feedback", response_model=ChatResponse, tags=["反馈"])
async def submit_feedback(request: FeedbackRequest):
    """
    提交反馈
    
    用户对对话响应进行评分和评论
    """
    try:
        # 存储反馈(实际应存入数据库)
        feedback_data = {
            "session_id": request.session_id,
            "response_id": request.response_id,
            "rating": request.rating,
            "comment": request.comment,
            "tags": request.tags,
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Feedback received: {feedback_data}")
        
        return ChatResponse(
            code=ResponseCode.SUCCESS,
            message="Feedback submitted",
            data=feedback_data
        )
        
    except Exception as e:
        logger.error(f"Feedback error: {e}", exc_info=True)
        return ChatResponse(
            code=ResponseCode.GENERAL_ERROR,
            message=str(e),
            data=None
        )


@app.get("/api/v1/dialogue/intents", response_model=ChatResponse, tags=["信息"])
async def get_intents():
    """
    获取支持的意图列表
    
    返回所有支持的对话意图
    """
    try:
        engine = get_dialog_engine()
        intents = engine.get_supported_intents()
        
        intent_infos = []
        for intent in intents:
            intent_infos.append(IntentInfo(
                name=intent,
                description=f"处理{intent}类型的意图",
                required_slots=[]
            ))
        
        return ChatResponse(
            code=ResponseCode.SUCCESS,
            message="success",
            data={"intents": [info.dict() for info in intent_infos]}
        )
        
    except Exception as e:
        logger.error(f"Get intents error: {e}", exc_info=True)
        return ChatResponse(
            code=ResponseCode.GENERAL_ERROR,
            message=str(e),
            data=None
        )


@app.get("/api/v1/dialogue/health", tags=["系统"])
async def health_check():
    """
    健康检查
    
    检查对话引擎的运行状态
    """
    try:
        engine = get_dialog_engine()
        health = engine.health_check()
        
        return {
            "status": "healthy" if health["status"] == "healthy" else "degraded",
            "timestamp": datetime.now().isoformat(),
            "components": health.get("components", {}),
            "metrics": health.get("metrics", {}),
            "active_sessions": health.get("active_sessions", 0)
        }
        
    except Exception as e:
        logger.error(f"Health check error: {e}", exc_info=True)
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }


@app.get("/api/v1/dialogue/metrics", tags=["系统"])
async def get_metrics():
    """
    获取性能指标
    
    返回对话引擎的性能统计数据
    """
    try:
        engine = get_dialog_engine()
        metrics = engine.get_metrics()
        
        return {
            "code": 0,
            "message": "success",
            "data": metrics
        }
        
    except Exception as e:
        logger.error(f"Get metrics error: {e}", exc_info=True)
        return {
            "code": ResponseCode.GENERAL_ERROR,
            "message": str(e),
            "data": None
        }


# ============== 错误处理 ==============

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """HTTP异常处理"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "code": exc.status_code,
            "message": exc.detail,
            "data": None
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """通用异常处理"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "code": ResponseCode.GENERAL_ERROR,
            "message": "Internal server error",
            "data": None
        }
    )


# ============== 启动 ==============

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
