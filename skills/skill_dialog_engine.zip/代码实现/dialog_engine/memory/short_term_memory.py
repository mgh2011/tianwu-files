# dialog_engine/memory/short_term_memory.py
"""
短期记忆管理
基于Session的临时存储
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from collections import OrderedDict


logger = logging.getLogger(__name__)


class ShortTermMemory:
    """
    短期记忆管理
    基于Session的临时存储，模拟Redis的行为
    """
    
    def __init__(self, session_id: str, ttl: int = 1800):
        self.session_id = session_id
        self.ttl = ttl  # 生存时间(秒)
        
        # 存储结构: OrderedDict以保持插入顺序
        self._store: OrderedDict = OrderedDict()
        self._expiry: Dict[str, datetime] = {}
        
        # 后台清理任务
        self._cleanup_task: Optional[asyncio.Task] = None
        
    async def start(self):
        """启动记忆管理器"""
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        logger.debug(f"ShortTermMemory started for session: {self.session_id}")
    
    async def stop(self):
        """停止记忆管理器"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        logger.debug(f"ShortTermMemory stopped for session: {self.session_id}")
    
    async def remember(self, key: str, value: Any) -> None:
        """
        存储记忆
        
        Args:
            key: 记忆键
            value: 记忆值
        """
        self._store[key] = value
        self._expiry[key] = datetime.now() + timedelta(seconds=self.ttl)
        logger.debug(f"Remembered: {key} in session {self.session_id}")
    
    async def recall(self, key: str) -> Optional[Any]:
        """
        回忆(获取)记忆
        
        Args:
            key: 记忆键
            
        Returns:
            记忆值,如果不存在或已过期返回None
        """
        # 检查是否过期
        if key in self._expiry:
            if datetime.now() > self._expiry[key]:
                # 已过期,删除
                await self.forget(key)
                return None
        
        return self._store.get(key)
    
    async def forget(self, key: str) -> None:
        """
        遗忘(删除)记忆
        
        Args:
            key: 记忆键
        """
        if key in self._store:
            del self._store[key]
        if key in self._expiry:
            del self._expiry[key]
        logger.debug(f"Forgotten: {key}")
    
    async def clear(self) -> None:
        """清空所有记忆"""
        self._store.clear()
        self._expiry.clear()
        logger.debug(f"Cleared all memories for session: {self.session_id}")
    
    async def get_recent(self, count: int = 10) -> List[Any]:
        """
        获取最近的记忆
        
        Args:
            count: 返回数量
            
        Returns:
            最近的值列表
        """
        # 过滤过期项
        valid_items = []
        expired_keys = []
        
        now = datetime.now()
        for key, value in reversed(list(self._store.items())):
            if key in self._expiry and now > self._expiry[key]:
                expired_keys.append(key)
            else:
                valid_items.append(value)
        
        # 清理过期项
        for key in expired_keys:
            await self.forget(key)
        
        return valid_items[:count]
    
    async def get_all(self) -> Dict[str, Any]:
        """获取所有有效记忆"""
        result = {}
        now = datetime.now()
        
        for key, value in list(self._store.items()):
            if key in self._expiry and now > self._expiry[key]:
                await self.forget(key)
            else:
                result[key] = value
        
        return result
    
    async def has(self, key: str) -> bool:
        """检查记忆是否存在"""
        return await self.recall(key) is not None
    
    async def expire(self, key: str, seconds: int) -> bool:
        """
        设置记忆过期时间
        
        Args:
            key: 记忆键
            seconds: 过期秒数
            
        Returns:
            是否设置成功
        """
        if key in self._store:
            self._expiry[key] = datetime.now() + timedelta(seconds=seconds)
            return True
        return False
    
    async def ttl_of(self, key: str) -> int:
        """
        获取记忆剩余存活时间
        
        Args:
            key: 记忆键
            
        Returns:
            剩余秒数,-1表示永久,-2表示不存在
        """
        if key not in self._expiry:
            return -2
        
        remaining = (self._expiry[key] - datetime.now()).total_seconds()
        if remaining <= 0:
            await self.forget(key)
            return -2
        
        return int(remaining)
    
    async def size(self) -> int:
        """获取记忆数量"""
        # 先清理过期项
        await self._cleanup()
        return len(self._store)
    
    async def keys(self, pattern: str = "*") -> List[str]:
        """
        获取匹配的键列表
        
        Args:
            pattern: 通配符模式
            
        Returns:
            匹配的键列表
        """
        import fnmatch
        
        # 先清理过期项
        await self._cleanup()
        
        keys = list(self._store.keys())
        if pattern == "*":
            return keys
        
        return [k for k in keys if fnmatch.fnmatch(k, pattern)]
    
    async def increment(self, key: str, amount: int = 1) -> int:
        """递增(用于计数)"""
        current = await self.recall(key) or 0
        new_value = int(current) + amount
        await self.remember(key, new_value)
        return new_value
    
    async def append(self, key: str, value: Any) -> int:
        """追加到列表"""
        current = await self.recall(key) or []
        if not isinstance(current, list):
            current = [current]
        current.append(value)
        await self.remember(key, current)
        return len(current)
    
    async def get_list(self, key: str) -> List[Any]:
        """获取列表"""
        value = await self.recall(key)
        if isinstance(value, list):
            return value
        return []
    
    async def _cleanup(self) -> None:
        """清理过期记忆"""
        now = datetime.now()
        expired_keys = [
            key for key, expiry in self._expiry.items()
            if now > expiry
        ]
        
        for key in expired_keys:
            await self.forget(key)
        
        if expired_keys:
            logger.debug(f"Cleaned up {len(expired_keys)} expired memories")
    
    async def _cleanup_loop(self) -> None:
        """定期清理循环"""
        while True:
            try:
                await asyncio.sleep(60)  # 每分钟检查一次
                await self._cleanup()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Cleanup error: {e}")
