"""
环境感知引擎 - 环境感知
Environment Sensor

感知网络、系统、应用、数据、威胁环境
"""

import logging
from typing import Dict, List, Optional
from datetime import datetime
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class EnvironmentSensor:
    """环境感知引擎"""
    
    def __init__(self, config: Dict = None):
        """初始化环境感知引擎"""
        self.config = config or {}
        self._sensors = {
            'network': NetworkEnvironmentSensor(self.config),
            'system': SystemEnvironmentSensor(self.config),
            'application': ApplicationEnvironmentSensor(self.config),
            'data': DataEnvironmentSensor(self.config),
            'threat': ThreatEnvironmentSensor(self.config)
        }
        logger.info("环境感知引擎初始化完成")
    
    def perceive(self, data: Dict) -> 'PerceptionResult':
        """感知环境数据"""
        sensor_type = data.get('sensor_type', 'all')
        
        if sensor_type == 'all':
            # 全局感知
            results = {}
            for name, sensor in self._sensors.items():
                results[name] = sensor.sense(data.get(name, {}))
            
            return PerceptionResult(
                perception_type='environment',
                perception_data=results,
                confidence=0.85,
                timestamp=datetime.now(),
                metadata={'sensor_count': len(self._sensors)}
            )
        elif sensor_type in self._sensors:
            return PerceptionResult(
                perception_type=f'environment_{sensor_type}',
                perception_data=self._sensors[sensor_type].sense(data.get(sensor_type, {})),
                confidence=0.9,
                timestamp=datetime.now()
            )
        
        return PerceptionResult(
            perception_type='environment',
            perception_data=data,
            confidence=0.5,
            timestamp=datetime.now()
        )
    
    def sense_network(self, data: Dict) -> Dict:
        """感知网络环境"""
        return self._sensors['network'].sense(data)
    
    def sense_system(self, data: Dict) -> Dict:
        """感知系统环境"""
        return self._sensors['system'].sense(data)
    
    def sense_application(self, data: Dict) -> Dict:
        """感知应用环境"""
        return self._sensors['application'].sense(data)
    
    def sense_data(self, data: Dict) -> Dict:
        """感知数据环境"""
        return self._sensors['data'].sense(data)
    
    def sense_threat(self, data: Dict) -> Dict:
        """感知威胁环境"""
        return self._sensors['threat'].sense(data)


class NetworkEnvironmentSensor:
    """网络环境感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知网络环境"""
        return {
            'network_topology': self._sense_topology(data),
            'network_connections': self._sense_connections(data),
            'network_traffic': self._sense_traffic(data),
            'network_devices': self._sense_devices(data),
            'network_services': self._sense_services(data),
            'bandwidth_usage': data.get('bandwidth_usage', 0.5),
            'latency': data.get('latency', 10),
            'packet_loss': data.get('packet_loss', 0.01)
        }
    
    def _sense_topology(self, data: Dict) -> Dict:
        """感知网络拓扑"""
        return {
            'subnets': data.get('subnets', ['192.168.1.0/24']),
            'gateways': data.get('gateways', ['192.168.1.1']),
            'routers': data.get('routers', []),
            'switches': data.get('switches', []),
            'firewalls': data.get('firewalls', [])
        }
    
    def _sense_connections(self, data: Dict) -> Dict:
        """感知网络连接"""
        return {
            'active_connections': data.get('active_connections', 100),
            'established': data.get('established', 80),
            'time_wait': data.get('time_wait', 10),
            'close_wait': data.get('close_wait', 5)
        }
    
    def _sense_traffic(self, data: Dict) -> Dict:
        """感知网络流量"""
        return {
            'bytes_in': data.get('bytes_in', 0),
            'bytes_out': data.get('bytes_out', 0),
            'packets_in': data.get('packets_in', 0),
            'packets_out': data.get('packets_out', 0),
            'throughput_in': data.get('throughput_in', 0),
            'throughput_out': data.get('throughput_out', 0)
        }
    
    def _sense_devices(self, data: Dict) -> List[Dict]:
        """感知网络设备"""
        devices = data.get('devices', [])
        return [
            {
                'ip': d.get('ip', ''),
                'mac': d.get('mac', ''),
                'type': d.get('type', 'unknown'),
                'status': d.get('status', 'unknown')
            }
            for d in devices
        ]
    
    def _sense_services(self, data: Dict) -> List[Dict]:
        """感知网络服务"""
        services = data.get('services', [])
        return [
            {
                'name': s.get('name', ''),
                'port': s.get('port', 0),
                'protocol': s.get('protocol', 'tcp'),
                'status': s.get('status', 'unknown')
            }
            for s in services
        ]


class SystemEnvironmentSensor:
    """系统环境感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知系统环境"""
        return {
            'os_info': self._sense_os(data),
            'cpu_info': self._sense_cpu(data),
            'memory_info': self._sense_memory(data),
            'disk_info': self._sense_disk(data),
            'processes': self._sense_processes(data),
            'services': self._sense_system_services(data),
            'uptime': data.get('uptime', 86400),
            'load_average': data.get('load_average', [1.0, 1.0, 1.0])
        }
    
    def _sense_os(self, data: Dict) -> Dict:
        """感知操作系统"""
        return {
            'name': data.get('os_name', 'Linux'),
            'version': data.get('os_version', 'Unknown'),
            'kernel': data.get('kernel', 'Unknown'),
            'architecture': data.get('architecture', 'x86_64')
        }
    
    def _sense_cpu(self, data: Dict) -> Dict:
        """感知CPU"""
        return {
            'model': data.get('cpu_model', 'Unknown'),
            'cores': data.get('cpu_cores', 4),
            'usage': data.get('cpu_usage', 0.3),
            'temperature': data.get('cpu_temp', 50)
        }
    
    def _sense_memory(self, data: Dict) -> Dict:
        """感知内存"""
        return {
            'total': data.get('mem_total', 8192),
            'used': data.get('mem_used', 4096),
            'free': data.get('mem_free', 4096),
            'usage': data.get('mem_usage', 0.5),
            'swap_total': data.get('swap_total', 2048),
            'swap_used': data.get('swap_used', 256)
        }
    
    def _sense_disk(self, data: Dict) -> Dict:
        """感知磁盘"""
        return {
            'total': data.get('disk_total', 100000),
            'used': data.get('disk_used', 50000),
            'free': data.get('disk_free', 50000),
            'usage': data.get('disk_usage', 0.5),
            'io_wait': data.get('io_wait', 0.05)
        }
    
    def _sense_processes(self, data: Dict) -> List[Dict]:
        """感知进程"""
        processes = data.get('processes', [])
        return [
            {
                'pid': p.get('pid', 0),
                'name': p.get('name', ''),
                'cpu_usage': p.get('cpu', 0),
                'mem_usage': p.get('mem', 0),
                'status': p.get('status', 'running')
            }
            for p in processes[:20]
        ]
    
    def _sense_system_services(self, data: Dict) -> List[Dict]:
        """感知系统服务"""
        services = data.get('system_services', [])
        return [
            {
                'name': s.get('name', ''),
                'status': s.get('status', 'unknown'),
                'enabled': s.get('enabled', False)
            }
            for s in services
        ]


class ApplicationEnvironmentSensor:
    """应用环境感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知应用环境"""
        return {
            'applications': self._sense_applications(data),
            'dependencies': self._sense_dependencies(data),
            'configurations': self._sense_configurations(data),
            'vulnerabilities': self._sense_vulnerabilities(data),
            'updates': self._sense_updates(data)
        }
    
    def _sense_applications(self, data: Dict) -> List[Dict]:
        """感知应用"""
        apps = data.get('applications', [])
        return [
            {
                'name': a.get('name', ''),
                'version': a.get('version', ''),
                'status': a.get('status', 'unknown'),
                'port': a.get('port', 0)
            }
            for a in apps
        ]
    
    def _sense_dependencies(self, data: Dict) -> List[Dict]:
        """感知依赖"""
        deps = data.get('dependencies', [])
        return [
            {
                'name': d.get('name', ''),
                'version': d.get('version', ''),
                'vulnerable': d.get('vulnerable', False)
            }
            for d in deps
        ]
    
    def _sense_configurations(self, data: Dict) -> Dict:
        """感知配置"""
        return {
            'secure_mode': data.get('secure_mode', True),
            'debug_mode': data.get('debug_mode', False),
            'logging_level': data.get('logging_level', 'INFO')
        }
    
    def _sense_vulnerabilities(self, data: Dict) -> List[Dict]:
        """感知漏洞"""
        vulns = data.get('vulnerabilities', [])
        return [
            {
                'id': v.get('id', ''),
                'severity': v.get('severity', 'MEDIUM'),
                'description': v.get('description', '')
            }
            for v in vulns
        ]
    
    def _sense_updates(self, data: Dict) -> List[Dict]:
        """感知更新"""
        updates = data.get('updates', [])
        return [
            {
                'package': u.get('package', ''),
                'current_version': u.get('current', ''),
                'available_version': u.get('available', '')
            }
            for u in updates
        ]


class DataEnvironmentSensor:
    """数据环境感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知数据环境"""
        return {
            'databases': self._sense_databases(data),
            'data_volumes': self._sense_volumes(data),
            'data_types': self._sense_types(data),
            'sensitive_data': self._sense_sensitive(data),
            'data_flows': self._sense_flows(data)
        }
    
    def _sense_databases(self, data: Dict) -> List[Dict]:
        """感知数据库"""
        dbs = data.get('databases', [])
        return [
            {
                'name': db.get('name', ''),
                'type': db.get('type', 'unknown'),
                'size': db.get('size', 0),
                'tables': db.get('tables', 0)
            }
            for db in dbs
        ]
    
    def _sense_volumes(self, data: Dict) -> List[Dict]:
        """感知数据卷"""
        volumes = data.get('volumes', [])
        return [
            {
                'name': v.get('name', ''),
                'size': v.get('size', 0),
                'used': v.get('used', 0),
                'mount_point': v.get('mount', '')
            }
            for v in volumes
        ]
    
    def _sense_types(self, data: Dict) -> Dict:
        """感知数据类型"""
        return {
            'structured': data.get('structured_size', 0),
            'unstructured': data.get('unstructured_size', 0),
            'semi_structured': data.get('semi_structured_size', 0)
        }
    
    def _sense_sensitive(self, data: Dict) -> Dict:
        """感知敏感数据"""
        return {
            'pii_count': data.get('pii_count', 0),
            'financial_count': data.get('financial_count', 0),
            'health_count': data.get('health_count', 0),
            'classified_count': data.get('classified_count', 0)
        }
    
    def _sense_flows(self, data: Dict) -> List[Dict]:
        """感知数据流"""
        flows = data.get('data_flows', [])
        return [
            {
                'source': f.get('source', ''),
                'destination': f.get('destination', ''),
                'type': f.get('type', 'unknown')
            }
            for f in flows
        ]


class ThreatEnvironmentSensor:
    """威胁环境感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知威胁环境"""
        return {
            'threat_intelligence': self._sense_intelligence(data),
            'active_threats': self._sense_active_threats(data),
            'historical_threats': self._sense_historical(data),
            'threat_actors': self._sense_actors(data),
            'attack_campaigns': self._sense_campaigns(data)
        }
    
    def _sense_intelligence(self, data: Dict) -> Dict:
        """感知威胁情报"""
        return {
            'iocs': data.get('iocs', []),
            'ttps': data.get('ttps', []),
            'threat_actors': data.get('threat_actors', []),
            'malware_signatures': data.get('signatures', [])
        }
    
    def _sense_active_threats(self, data: Dict) -> List[Dict]:
        """感知活跃威胁"""
        threats = data.get('active_threats', [])
        return [
            {
                'id': t.get('id', ''),
                'type': t.get('type', 'unknown'),
                'severity': t.get('severity', 'MEDIUM'),
                'affected_assets': t.get('affected', [])
            }
            for t in threats
        ]
    
    def _sense_historical(self, data: Dict) -> Dict:
        """感知历史威胁"""
        return {
            'total_incidents': data.get('total_incidents', 0),
            'last_30_days': data.get('incidents_30d', 0),
            'attack_types': data.get('attack_types', {})
        }
    
    def _sense_actors(self, data: Dict) -> List[Dict]:
        """感知威胁行为者"""
        actors = data.get('actors', [])
        return [
            {
                'name': a.get('name', ''),
                'capabilities': a.get('capabilities', []),
                'intent': a.get('intent', 'unknown')
            }
            for a in actors
        ]
    
    def _sense_campaigns(self, data: Dict) -> List[Dict]:
        """感知攻击活动"""
        campaigns = data.get('campaigns', [])
        return [
            {
                'name': c.get('name', ''),
                'status': c.get('status', 'unknown'),
                'target_sectors': c.get('targets', [])
            }
            for c in campaigns
        ]


# 数据类
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class PerceptionResult:
    """感知结果"""
    perception_type: str
    perception_data: Dict
    confidence: float
    timestamp: datetime
    metadata: Dict = field(default_factory=dict)


# 便捷函数
def create_environment_sensor(config: Dict = None) -> EnvironmentSensor:
    """创建环境感知引擎"""
    return EnvironmentSensor(config)
