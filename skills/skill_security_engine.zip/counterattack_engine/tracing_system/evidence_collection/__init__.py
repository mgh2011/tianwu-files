"""
证据收集模块
Evidence Collection Module

提供攻击证据收集功能
"""

__version__ = "v3.0.0"
__all__ = []
