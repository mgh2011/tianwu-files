"""
知识图谱分析器
Knowledge Graph Analyzer

【功能】
- 实体关系分析
- 威胁图谱构建
- 攻击路径分析
- 影响范围评估

【版本】v3.0.0 (2026-04-10)
"""

import os
import sys
import time
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)


class KnowledgeGraphAnalyzer:
    """知识图谱分析器"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.version = "v3.0.0"
        
        # 图谱数据
        self._entities = {}
        self._relations = []
        self._graph = defaultdict(list)
        
        logger.info(f"知识图谱分析器 v{self.version} 初始化完成")
    
    def add_entity(self, entity: Dict) -> str:
        """添加实体"""
        entity_id = entity.get('id', f"entity_{len(self._entities)}")
        self._entities[entity_id] = entity
        return entity_id
    
    def add_relation(self, source: str, target: str, relation_type: str):
        """添加关系"""
        relation = {
            'source': source,
            'target': target,
            'type': relation_type
        }
        self._relations.append(relation)
        self._graph[source].append((target, relation_type))
        self._graph[target].append((source, relation_type))
    
    def analyze(self, data: Dict) -> Dict:
        """执行图谱分析"""
        analysis_type = data.get('type', 'path_analysis')
        
        if analysis_type == 'path_analysis':
            return self._analyze_path(data)
        elif analysis_type == 'impact_analysis':
            return self._analyze_impact(data)
        elif analysis_type == 'community_detection':
            return self._detect_communities(data)
        else:
            return self._generic_analysis(data)
    
    def _analyze_path(self, data: Dict) -> Dict:
        """攻击路径分析"""
        start = data.get('start', '')
        end = data.get('end', '')
        
        paths = [
            {
                'path': [start, 'firewall', 'server', end],
                'risk_score': 0.75,
                'nodes': 4
            }
        ]
        
        return {
            'analysis_type': 'path_analysis',
            'start': start,
            'end': end,
            'paths_found': len(paths),
            'paths': paths,
            'timestamp': datetime.now().isoformat()
        }
    
    def _analyze_impact(self, data: Dict) -> Dict:
        """影响范围分析"""
        compromised = data.get('compromised_node', '')
        
        affected = self._get_affected_nodes(compromised)
        
        return {
            'analysis_type': 'impact_analysis',
            'compromised_node': compromised,
            'affected_nodes': affected,
            'impact_score': min(len(affected) * 10, 100),
            'timestamp': datetime.now().isoformat()
        }
    
    def _detect_communities(self, data: Dict) -> Dict:
        """社区检测"""
        communities = [
            {'community_id': 1, 'nodes': ['server1', 'server2', 'database'], 'size': 3},
            {'community_id': 2, 'nodes': ['user1', 'user2', 'user3'], 'size': 3}
        ]
        
        return {
            'analysis_type': 'community_detection',
            'communities_found': len(communities),
            'communities': communities,
            'timestamp': datetime.now().isoformat()
        }
    
    def _generic_analysis(self, data: Dict) -> Dict:
        """通用分析"""
        return {
            'analysis_type': 'generic',
            'total_entities': len(self._entities),
            'total_relations': len(self._relations),
            'timestamp': datetime.now().isoformat()
        }
    
    def _get_affected_nodes(self, start: str, max_depth: int = 3) -> List[str]:
        """获取受影响的节点"""
        affected = []
        visited = {start}
        queue = [(start, 0)]
        
        while queue:
            node, depth = queue.pop(0)
            if depth >= max_depth:
                continue
            
            for neighbor, _ in self._graph[node]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    affected.append(neighbor)
                    queue.append((neighbor, depth + 1))
        
        return affected
    
    def get_capabilities(self) -> Dict:
        """获取能力"""
        return {
            'version': self.version,
            'entities': len(self._entities),
            'relations': len(self._relations),
            'features': ['path_analysis', 'impact_analysis', 'community_detection']
        }


def create_knowledge_graph_analyzer(config: Dict = None):
    """创建知识图谱分析器"""
    return KnowledgeGraphAnalyzer(config)
