"""
回滚管理模块
Rollback Module

提供反击行动的回滚功能
"""

from .counterattack_rollback import CounterattackRollback

__version__ = "v3.0.0"
__all__ = [
    'CounterattackRollback'
]
