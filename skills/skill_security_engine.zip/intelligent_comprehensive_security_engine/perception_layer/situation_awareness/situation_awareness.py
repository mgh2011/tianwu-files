"""
态势感知模块
Situation Awareness Module

【功能】
- 全局安全态势感知
- 威胁趋势分析
- 风险评估
- 态势预测

【版本】v3.0.0 (2026-04-10)
"""

import os
import sys
import time
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)


class ThreatTrendAnalyzer:
    """威胁趋势分析器"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self._threat_history = []
        self._trend_data = defaultdict(list)
    
    def analyze(self, threat_data: Dict) -> Dict:
        """分析威胁趋势"""
        timestamp = time.time()
        threat_type = threat_data.get('type', 'unknown')
        severity = threat_data.get('severity', 'low')
        
        # 记录威胁
        self._threat_history.append({
            'timestamp': timestamp,
            'type': threat_type,
            'severity': severity
        })
        
        # 保持最近1000条记录
        if len(self._threat_history) > 1000:
            self._threat_history = self._threat_history[-1000:]
        
        # 计算趋势
        trend = {
            'total_threats': len(self._threat_history),
            'threat_types': self._get_threat_type_distribution(),
            'severity_distribution': self._get_severity_distribution(),
            'trend_direction': self._calculate_trend_direction(),
            'risk_level': self._calculate_risk_level()
        }
        
        return trend
    
    def _get_threat_type_distribution(self) -> Dict[str, int]:
        """获取威胁类型分布"""
        distribution = defaultdict(int)
        for threat in self._threat_history:
            distribution[threat['type']] += 1
        return dict(distribution)
    
    def _get_severity_distribution(self) -> Dict[str, int]:
        """获取严重程度分布"""
        distribution = defaultdict(int)
        for threat in self._threat_history:
            distribution[threat['severity']] += 1
        return dict(distribution)
    
    def _calculate_trend_direction(self) -> str:
        """计算趋势方向"""
        if len(self._threat_history) < 10:
            return 'stable'
        
        # 最近5分钟 vs 前5分钟
        now = time.time()
        recent = sum(1 for t in self._threat_history if now - t['timestamp'] < 300)
        previous = sum(1 for t in self._threat_history if 300 <= now - t['timestamp'] < 600)
        
        if recent > previous * 1.5:
            return 'increasing'
        elif recent < previous * 0.5:
            return 'decreasing'
        else:
            return 'stable'
    
    def _calculate_risk_level(self) -> str:
        """计算风险等级"""
        severity_scores = {'critical': 5, 'high': 4, 'medium': 3, 'low': 2, 'info': 1}
        if not self._threat_history:
            return 'low'
        
        total_score = sum(
            severity_scores.get(t['severity'], 1) 
            for t in self._threat_history[-100:]
        )
        avg_score = total_score / min(len(self._threat_history), 100)
        
        if avg_score >= 4:
            return 'critical'
        elif avg_score >= 3:
            return 'high'
        elif avg_score >= 2:
            return 'medium'
        else:
            return 'low'


class RiskAssessmentEngine:
    """风险评估引擎"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self._asset_values = {}
        self._vulnerabilities = []
        self._threat_levels = {}
    
    def assess_risk(self, asset_id: str, threat_data: Dict) -> Dict:
        """评估风险"""
        asset_value = self._asset_values.get(asset_id, 50)
        vulnerability_score = self._calculate_vulnerability_score(asset_id)
        threat_likelihood = self._calculate_threat_likelihood(threat_data)
        
        # 风险 = 资产价值 * 漏洞得分 * 威胁可能性
        risk_score = (asset_value / 100) * vulnerability_score * threat_likelihood
        
        return {
            'asset_id': asset_id,
            'risk_score': min(risk_score, 100),
            'risk_level': self._score_to_level(risk_score),
            'components': {
                'asset_value': asset_value,
                'vulnerability_score': vulnerability_score,
                'threat_likelihood': threat_likelihood
            },
            'recommendations': self._generate_recommendations(risk_score)
        }
    
    def _calculate_vulnerability_score(self, asset_id: str) -> float:
        """计算漏洞得分"""
        asset_vulns = [v for v in self._vulnerabilities if v.get('asset_id') == asset_id]
        if not asset_vulns:
            return 0.2
        
        severity_scores = {'critical': 1.0, 'high': 0.75, 'medium': 0.5, 'low': 0.25}
        return sum(severity_scores.get(v.get('severity', 'low'), 0.25) for v in asset_vulns) / len(asset_vulns)
    
    def _calculate_threat_likelihood(self, threat_data: Dict) -> float:
        """计算威胁可能性"""
        threat_level = threat_data.get('level', 'low')
        likelihood_map = {'critical': 1.0, 'high': 0.8, 'medium': 0.5, 'low': 0.2}
        return likelihood_map.get(threat_level, 0.2)
    
    def _score_to_level(self, score: float) -> str:
        """分数转等级"""
        if score >= 75:
            return 'critical'
        elif score >= 50:
            return 'high'
        elif score >= 25:
            return 'medium'
        else:
            return 'low'
    
    def _generate_recommendations(self, risk_score: float) -> List[str]:
        """生成建议"""
        recommendations = []
        if risk_score >= 75:
            recommendations.append('立即采取行动，建议升级到应急响应流程')
            recommendations.append('限制受影响的系统访问')
        if risk_score >= 50:
            recommendations.append('加快修复进度，优先处理高风险漏洞')
        if risk_score >= 25:
            recommendations.append('规划修复时间表，监控风险变化')
        else:
            recommendations.append('继续监控，维持当前安全措施')
        return recommendations


class SituationAwarenessEngine:
    """态势感知引擎"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.version = "v3.0.0"
        
        # 子模块
        self._threat_analyzer = ThreatTrendAnalyzer(config)
        self._risk_engine = RiskAssessmentEngine(config)
        
        # 态势数据
        self._current_situation = {
            'overall_risk': 'low',
            'threat_level': 'normal',
            'protected_assets': 0,
            'detected_threats': 0,
            'blocked_attacks': 0
        }
        
        logger.info(f"态势感知引擎 v{self.version} 初始化完成")
    
    def perceive(self, sensor_data: Dict) -> Dict:
        """感知态势"""
        threat_data = sensor_data.get('threat_data', {})
        
        # 威胁趋势分析
        trend = self._threat_analyzer.analyze(threat_data)
        
        # 更新当前态势
        self._current_situation.update({
            'overall_risk': trend.get('risk_level', 'low'),
            'detected_threats': trend.get('total_threats', 0),
            'last_update': datetime.now().isoformat()
        })
        
        return {
            'situation': self._current_situation,
            'trend': trend,
            'timestamp': datetime.now().isoformat()
        }
    
    def assess_risk(self, asset_id: str, threat_data: Dict) -> Dict:
        """风险评估"""
        return self._risk_engine.assess_risk(asset_id, threat_data)
    
    def predict(self, time_horizon: int = 3600) -> Dict:
        """态势预测"""
        # 基于历史趋势预测未来态势
        return {
            'predicted_risk': 'medium',
            'predicted_threat_count': 10,
            'confidence': 0.75,
            'time_horizon': time_horizon,
            'factors': ['historical_trend', 'seasonal_pattern', 'threat_intelligence']
        }
    
    def get_capabilities(self) -> Dict:
        """获取能力"""
        return {
            'version': self.version,
            'features': [
                'threat_trend_analysis',
                'risk_assessment',
                'situation_prediction',
                'risk_level_calculation'
            ]
        }


def create_situation_awareness_engine(config: Dict = None):
    """创建态势感知引擎"""
    return SituationAwarenessEngine(config)


# 入口
if __name__ == '__main__':
    engine = create_situation_awareness_engine()
    print(f"态势感知引擎 v{engine.version}")
    
    # 测试感知
    result = engine.perceive({
        'threat_data': {
            'type': 'malware',
            'severity': 'high'
        }
    })
    print(f"态势感知结果: {result['situation']}")
