"""
反击执行系统 - 反击回滚模块
Counterattack Rollback - 回滚反击动作
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class RollbackType(Enum):
    """回滚类型"""
    FULL = "full"  # 完全回滚
    PARTIAL = "partial"  # 部分回滚
    COMPENSATING = "compensating"  # 补偿式回滚


class RollbackStatus(Enum):
    """回滚状态"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class RollbackAction:
    """回滚动作"""
    action_id: str
    action_type: str
    reverse_action: str
    parameters: Dict
    executed_at: str
    result: Optional[Dict] = None


@dataclass
class Snapshot:
    """系统快照"""
    snapshot_id: str
    created_at: str
    description: str
    state: Dict
    checksums: Dict = field(default_factory=dict)


@dataclass
class RollbackPlan:
    """回滚计划"""
    plan_id: str
    target_task_id: str
    rollback_type: RollbackType
    actions: List[RollbackAction]
    estimated_duration: int  # 秒
    risk_level: str
    conditions: List[str] = field(default_factory=list)


@dataclass
class RollbackResult:
    """回滚结果"""
    success: bool
    plan_id: str
    executed_actions: List[RollbackAction]
    skipped_actions: List[str]
    failed_actions: List[str]
    duration: float
    message: str


class CounterattackRollback:
    """反击回滚系统"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化回滚系统

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.snapshots: Dict[str, Snapshot] = {}
        self.rollback_history = []
        self.action_handlers: Dict[str, Any] = {}
        self._register_default_handlers()

    def _register_default_handlers(self):
        """注册默认处理器"""
        self.action_handlers = {
            'block': self._rollback_block,
            'unblock': self._rollback_unblock,
            'deploy_honeypot': self._rollback_deploy_honeypot,
            'remove_honeypot': self._rollback_remove_honeypot,
            'rate_limit': self._rollback_rate_limit,
            'filter': self._rollback_filter,
            'disrupt': self._rollback_disrupt,
        }

    def create_snapshot(self, task_id: str, state: Dict,
                       description: str = "") -> Snapshot:
        """
        创建快照

        Args:
            task_id: 任务ID
            state: 系统状态
            description: 描述

        Returns:
            快照对象
        """
        import hashlib

        snapshot_id = f"SNAP-{hashlib.md5(f'{task_id}:{datetime.now().isoformat()}'.encode()).hexdigest()[:12].upper()}"

        # 计算校验和
        checksums = {}
        for key, value in state.items():
            if isinstance(value, (str, dict, list)):
                checksums[key] = hashlib.md5(str(value).encode()).hexdigest()

        snapshot = Snapshot(
            snapshot_id=snapshot_id,
            created_at=datetime.now().isoformat(),
            description=description or f"Snapshot for task {task_id}",
            state=state,
            checksums=checksums
        )

        self.snapshots[snapshot_id] = snapshot
        return snapshot

    def get_snapshot(self, snapshot_id: str) -> Optional[Snapshot]:
        """获取快照"""
        return self.snapshots.get(snapshot_id)

    def create_rollback_plan(self, task_id: str, executed_actions: List[Dict],
                           rollback_type: RollbackType = RollbackType.FULL) -> RollbackPlan:
        """
        创建回滚计划

        Args:
            task_id: 任务ID
            executed_actions: 已执行的动作列表
            rollback_type: 回滚类型

        Returns:
            回滚计划
        """
        import hashlib

        plan_id = f"RB-PLAN-{hashlib.md5(f'{task_id}:{datetime.now().isoformat()}'.encode()).hexdigest()[:12].upper()}"

        # 生成回滚动作
        rollback_actions = []
        estimated_duration = 0

        for action in reversed(executed_actions):  # 逆序回滚
            action_type = action.get('type')
            reverse_type = self._get_reverse_action_type(action_type)

            if reverse_type and reverse_type in self.action_handlers:
                rollback_action = RollbackAction(
                    action_id=f"{action.get('id', 'unknown')}-rb",
                    action_type=action_type,
                    reverse_action=reverse_type,
                    parameters=action.get('parameters', {}),
                    executed_at=action.get('executed_at', '')
                )
                rollback_actions.append(rollback_action)
                estimated_duration += 30  # 每个动作预估30秒

        # 评估风险
        risk_level = self._assess_rollback_risk(rollback_actions)

        return RollbackPlan(
            plan_id=plan_id,
            target_task_id=task_id,
            rollback_type=rollback_type,
            actions=rollback_actions,
            estimated_duration=estimated_duration,
            risk_level=risk_level,
            conditions=["确认回滚", "准备应急方案"]
        )

    def execute_rollback(self, plan: RollbackPlan) -> RollbackResult:
        """
        执行回滚

        Args:
            plan: 回滚计划

        Returns:
            回滚结果
        """
        executed = []
        skipped = []
        failed = []
        start_time = datetime.now()

        for action in plan.actions:
            try:
                # 获取处理器
                handler = self.action_handlers.get(action.reverse_action)
                if not handler:
                    skipped.append(action.action_id)
                    continue

                # 执行回滚
                result = handler(action.parameters)
                action.result = result
                executed.append(action)

            except Exception as e:
                action.result = {'error': str(e)}
                failed.append(action.action_id)

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()

        success = len(failed) == 0

        result = RollbackResult(
            success=success,
            plan_id=plan.plan_id,
            executed_actions=executed,
            skipped_actions=skipped,
            failed_actions=failed,
            duration=duration,
            message="回滚完成" if success else f"回滚完成但有{len(failed)}个动作失败"
        )

        # 记录历史
        self._record_rollback(result, plan)

        return result

    def restore_from_snapshot(self, snapshot_id: str) -> bool:
        """
        从快照恢复

        Args:
            snapshot_id: 快照ID

        Returns:
            是否成功
        """
        snapshot = self.snapshots.get(snapshot_id)
        if not snapshot:
            return False

        # 实际应用中会将snapshot.state恢复到系统
        # 这里仅返回成功
        return True

    def _rollback_block(self, params: Dict) -> Dict:
        """回滚阻断动作"""
        target = params.get('target')
        block_id = params.get('block_id')

        # 实际应用中会调用unblock API
        return {
            'action': 'unblock',
            'target': target,
            'status': 'success'
        }

    def _rollback_unblock(self, params: Dict) -> Dict:
        """回滚解除阻断动作"""
        target = params.get('target')

        # 重新阻断
        return {
            'action': 'block',
            'target': target,
            'status': 'success'
        }

    def _rollback_deploy_honeypot(self, params: Dict) -> Dict:
        """回滚蜜罐部署"""
        honeypot_id = params.get('honeypot_id')

        return {
            'action': 'undeploy_honeypot',
            'honeypot_id': honeypot_id,
            'status': 'success'
        }

    def _rollback_remove_honeypot(self, params: Dict) -> Dict:
        """回滚蜜罐移除"""
        honeypot_id = params.get('honeypot_id')

        return {
            'action': 'redeploy_honeypot',
            'honeypot_id': honeypot_id,
            'status': 'success'
        }

    def _rollback_rate_limit(self, params: Dict) -> Dict:
        """回滚限速"""
        return {
            'action': 'remove_rate_limit',
            'target': params.get('target'),
            'status': 'success'
        }

    def _rollback_filter(self, params: Dict) -> Dict:
        """回滚过滤"""
        return {
            'action': 'remove_filter',
            'target': params.get('target'),
            'status': 'success'
        }

    def _rollback_disrupt(self, params: Dict) -> Dict:
        """回滚中断"""
        return {
            'action': 'restore_service',
            'target': params.get('target'),
            'status': 'success'
        }

    def _get_reverse_action_type(self, action_type: str) -> Optional[str]:
        """获取反向动作类型"""
        reverse_map = {
            'block': 'unblock',
            'unblock': 'block',
            'deploy_honeypot': 'remove_honeypot',
            'remove_honeypot': 'deploy_honeypot',
            'rate_limit': 'remove_rate_limit',
            'filter': 'remove_filter',
            'disrupt': 'restore_service',
        }
        return reverse_map.get(action_type)

    def _assess_rollback_risk(self, actions: List[RollbackAction]) -> str:
        """评估回滚风险"""
        if not actions:
            return "negligible"

        high_risk_actions = ['block', 'disrupt', 'remove_honeypot']
        high_risk_count = sum(1 for a in actions if a.action_type in high_risk_actions)

        if high_risk_count > 3:
            return "high"
        elif high_risk_count > 0:
            return "medium"
        else:
            return "low"

    def _record_rollback(self, result: RollbackResult, plan: RollbackPlan):
        """记录回滚历史"""
        self.rollback_history.append({
            'plan_id': result.plan_id,
            'target_task_id': plan.target_task_id,
            'success': result.success,
            'executed_count': len(result.executed_actions),
            'failed_count': len(result.failed_actions),
            'duration': result.duration,
            'timestamp': datetime.now().isoformat()
        })

        if len(self.rollback_history) > 1000:
            self.rollback_history = self.rollback_history[-800:]

    def get_rollback_history(self, limit: int = 100) -> List[Dict]:
        """获取回滚历史"""
        return self.rollback_history[-limit:]

    def get_statistics(self) -> Dict:
        """获取统计"""
        if not self.rollback_history:
            return {
                'total_rollbacks': 0,
                'success_rate': 0,
                'average_duration': 0
            }

        total = len(self.rollback_history)
        success = sum(1 for r in self.rollback_history if r['success'])
        durations = [r['duration'] for r in self.rollback_history]

        return {
            'total_rollbacks': total,
            'success_rate': success / total if total > 0 else 0,
            'average_duration': sum(durations) / len(durations) if durations else 0,
            'snapshot_count': len(self.snapshots)
        }


# 独立运行测试
if __name__ == "__main__":
    rollback = CounterattackRollback()

    # 创建快照
    current_state = {
        'firewall_rules': ['allow 80', 'block 443'],
        'honeypots': ['HP-001', 'HP-002'],
        'rate_limits': {'192.168.1.0/24': 100}
    }
    snapshot = rollback.create_snapshot('TASK-001', current_state, "反击前状态")
    print(f"快照已创建: {snapshot.snapshot_id}")

    # 模拟已执行的动作
    executed_actions = [
        {'id': 'ACT-001', 'type': 'block', 'parameters': {'target': '192.168.1.100'}, 'executed_at': datetime.now().isoformat()},
        {'id': 'ACT-002', 'type': 'deploy_honeypot', 'parameters': {'honeypot_id': 'HP-NEW'}, 'executed_at': datetime.now().isoformat()},
        {'id': 'ACT-003', 'type': 'rate_limit', 'parameters': {'target': '10.0.0.0/8', 'limit': 50}, 'executed_at': datetime.now().isoformat()},
    ]

    # 创建回滚计划
    plan = rollback.create_rollback_plan('TASK-001', executed_actions)
    print(f"\n回滚计划已创建: {plan.plan_id}")
    print(f"回滚动作数: {len(plan.actions)}")
    print(f"预估时长: {plan.estimated_duration}秒")
    print(f"风险等级: {plan.risk_level}")

    # 执行回滚
    result = rollback.execute_rollback(plan)
    print(f"\n回滚结果:")
    print(f"成功: {result.success}")
    print(f"执行动作: {len(result.executed_actions)}")
    print(f"跳过动作: {len(result.skipped_actions)}")
    print(f"失败动作: {len(result.failed_actions)}")
    print(f"耗时: {result.duration:.2f}秒")

    # 获取统计
    stats = rollback.get_statistics()
    print(f"\n回滚统计:")
    print(json.dumps(stats, indent=2))
