"""
身份防护模块
Identity Protection Module

提供身份认证和授权管理功能
"""

__version__ = "v3.0.0"
__all__ = []
