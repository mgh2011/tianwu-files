"""
规则管理模块
Rule Management Module

提供反击规则管理功能
"""

__version__ = "v3.0.0"
__all__ = []
