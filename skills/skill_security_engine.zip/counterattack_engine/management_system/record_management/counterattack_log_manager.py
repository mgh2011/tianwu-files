"""
反击管理系统 - 反击日志管理模块
Counterattack Log Manager - 管理反击行动的日志记录
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import json
import os


class LogLevel(Enum):
    """日志级别"""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class LogCategory(Enum):
    """日志类别"""
    DECISION = "decision"  # 决策日志
    EXECUTION = "execution"  # 执行日志
    TRACING = "tracing"  # 溯源日志
    RESPONSE = "response"  # 响应日志
    SYSTEM = "system"  # 系统日志
    AUDIT = "audit"  # 审计日志


@dataclass
class LogEntry:
    """日志条目"""
    log_id: str
    timestamp: str
    level: LogLevel
    category: LogCategory
    event: str
    details: Dict
    source: str
    user: Optional[str] = None
    task_id: Optional[str] = None
    correlation_id: Optional[str] = None


@dataclass
class LogQuery:
    """日志查询"""
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    level: Optional[LogLevel] = None
    category: Optional[LogCategory] = None
    event: Optional[str] = None
    source: Optional[str] = None
    task_id: Optional[str] = None
    limit: int = 100


class CounterattackLogManager:
    """反击日志管理器"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化日志管理器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.log_dir = self.config.get('log_dir', './logs')
        self.retention_days = self.config.get('retention_days', 365)
        self.max_memory_logs = self.config.get('max_memory_logs', 10000)

        self.logs: List[LogEntry] = []
        self.indices: Dict[str, List[int]] = {}  # 索引
        self.correlation_tracker: Dict[str, List[str]] = {}  # 关联追踪

        # 确保日志目录存在
        os.makedirs(self.log_dir, exist_ok=True)

    def log(self, level: LogLevel, category: LogCategory, event: str,
            details: Dict = None, source: str = "system",
            user: str = None, task_id: str = None,
            correlation_id: str = None) -> LogEntry:
        """
        记录日志

        Args:
            level: 日志级别
            category: 日志类别
            event: 事件
            details: 详情
            source: 来源
            user: 用户
            task_id: 任务ID
            correlation_id: 关联ID

        Returns:
            日志条目
        """
        import hashlib

        log_id = f"LOG-{hashlib.md5(f'{event}:{datetime.now().isoformat()}'.encode()).hexdigest()[:16].upper()}"

        entry = LogEntry(
            log_id=log_id,
            timestamp=datetime.now().isoformat(),
            level=level,
            category=category,
            event=event,
            details=details or {},
            source=source,
            user=user,
            task_id=task_id,
            correlation_id=correlation_id
        )

        # 添加到内存
        self.logs.append(entry)

        # 更新索引
        self._update_indices(entry)

        # 管理关联追踪
        if correlation_id:
            self._track_correlation(correlation_id, log_id)

        # 管理内存大小
        self._manage_memory()

        # 写入文件
        self._write_to_file(entry)

        return entry

    def log_decision(self, decision: Dict, source: str = "decision_tree",
                    user: str = None, correlation_id: str = None) -> LogEntry:
        """记录决策日志"""
        return self.log(
            level=LogLevel.INFO,
            category=LogCategory.DECISION,
            event="counterattack_decision",
            details=decision,
            source=source,
            user=user,
            correlation_id=correlation_id
        )

    def log_execution(self, task_id: str, action: str, result: Dict,
                     correlation_id: str = None) -> LogEntry:
        """记录执行日志"""
        return self.log(
            level=LogLevel.INFO,
            category=LogCategory.EXECUTION,
            event=f"task_{action}",
            details=result,
            source="executor",
            task_id=task_id,
            correlation_id=correlation_id
        )

    def log_trace(self, trace_id: str, trace_result: Dict) -> LogEntry:
        """记录溯源日志"""
        return self.log(
            level=LogLevel.INFO,
            category=LogCategory.TRACING,
            event="trace_completed",
            details=trace_result,
            source="tracer",
            correlation_id=trace_id
        )

    def log_response(self, response_type: str, response_data: Dict,
                    correlation_id: str = None) -> LogEntry:
        """记录响应日志"""
        return self.log(
            level=LogLevel.INFO,
            category=LogCategory.RESPONSE,
            event=f"response_{response_type}",
            details=response_data,
            source="responder",
            correlation_id=correlation_id
        )

    def log_audit(self, action: str, actor: str, target: str,
                 result: str, details: Dict = None) -> LogEntry:
        """记录审计日志"""
        return self.log(
            level=LogLevel.INFO,
            category=LogCategory.AUDIT,
            event=f"audit_{action}",
            details={
                'actor': actor,
                'target': target,
                'result': result,
                **(details or {})
            },
            source="audit_system",
            user=actor
        )

    def log_error(self, error_type: str, error_message: str,
                 context: Dict = None, source: str = "system") -> LogEntry:
        """记录错误日志"""
        return self.log(
            level=LogLevel.ERROR,
            category=LogCategory.SYSTEM,
            event=f"error_{error_type}",
            details={
                'message': error_message,
                'context': context or {}
            },
            source=source
        )

    def query(self, query: LogQuery) -> List[LogEntry]:
        """
        查询日志

        Args:
            query: 查询条件

        Returns:
            日志列表
        """
        results = self.logs

        # 时间范围筛选
        if query.start_time:
            start = datetime.fromisoformat(query.start_time)
            results = [r for r in results
                      if datetime.fromisoformat(r.timestamp) >= start]

        if query.end_time:
            end = datetime.fromisoformat(query.end_time)
            results = [r for r in results
                      if datetime.fromisoformat(r.timestamp) <= end]

        # 级别筛选
        if query.level:
            results = [r for r in results if r.level == query.level]

        # 类别筛选
        if query.category:
            results = [r for r in results if r.category == query.category]

        # 事件筛选
        if query.event:
            results = [r for r in results if query.event in r.event]

        # 来源筛选
        if query.source:
            results = [r for r in results if query.source in r.source]

        # 任务ID筛选
        if query.task_id:
            results = [r for r in results if r.task_id == query.task_id]

        # 排序和限制
        results.sort(key=lambda x: x.timestamp, reverse=True)
        return results[:query.limit]

    def get_logs_by_correlation(self, correlation_id: str) -> List[LogEntry]:
        """获取关联日志"""
        log_ids = self.correlation_tracker.get(correlation_id, [])
        result = []

        for log in self.logs:
            if log.log_id in log_ids or log.correlation_id == correlation_id:
                result.append(log)

        result.sort(key=lambda x: x.timestamp)
        return result

    def get_task_logs(self, task_id: str) -> List[LogEntry]:
        """获取任务相关日志"""
        return [log for log in self.logs if log.task_id == task_id]

    def export_logs(self, start_time: str, end_time: str,
                   format: str = "json") -> str:
        """
        导出日志

        Args:
            start_time: 开始时间
            end_time: 结束时间
            format: 格式（json/csv）

        Returns:
            导出内容
        """
        query = LogQuery(
            start_time=start_time,
            end_time=end_time,
            limit=100000
        )
        logs = self.query(query)

        if format == "json":
            return json.dumps([self._log_to_dict(l) for l in logs], indent=2)
        elif format == "csv":
            return self._logs_to_csv(logs)
        else:
            return ""

    def cleanup_old_logs(self) -> int:
        """
        清理过期日志

        Returns:
            清理数量
        """
        cutoff = datetime.now() - timedelta(days=self.retention_days)
        cutoff_str = cutoff.isoformat()

        original_count = len(self.logs)
        self.logs = [log for log in self.logs
                    if log.timestamp >= cutoff_str]

        return original_count - len(self.logs)

    def get_statistics(self) -> Dict:
        """获取统计"""
        total = len(self.logs)

        by_level = {}
        by_category = {}

        for log in self.logs:
            level = log.level.value
            category = log.category.value
            by_level[level] = by_level.get(level, 0) + 1
            by_category[category] = by_category.get(category, 0) + 1

        return {
            'total_logs': total,
            'by_level': by_level,
            'by_category': by_category,
            'oldest_log': self.logs[0].timestamp if self.logs else None,
            'newest_log': self.logs[-1].timestamp if self.logs else None
        }

    def _update_indices(self, entry: LogEntry):
        """更新索引"""
        # 按时间索引
        date_key = entry.timestamp[:10]
        if date_key not in self.indices:
            self.indices[date_key] = []
        self.indices[date_key].append(len(self.logs) - 1)

        # 按类别索引
        category_key = f"cat_{entry.category.value}"
        if category_key not in self.indices:
            self.indices[category_key] = []
        self.indices[category_key].append(len(self.logs) - 1)

        # 按级别索引
        level_key = f"level_{entry.level.value}"
        if level_key not in self.indices:
            self.indices[level_key] = []
        self.indices[level_key].append(len(self.logs) - 1)

    def _track_correlation(self, correlation_id: str, log_id: str):
        """追踪关联"""
        if correlation_id not in self.correlation_tracker:
            self.correlation_tracker[correlation_id] = []
        self.correlation_tracker[correlation_id].append(log_id)

    def _manage_memory(self):
        """管理内存"""
        if len(self.logs) > self.max_memory_logs:
            # 删除最旧的日志
            excess = len(self.logs) - self.max_memory_logs
            self.logs = self.logs[excess:]

    def _write_to_file(self, entry: LogEntry):
        """写入文件"""
        date_key = entry.timestamp[:10]
        filename = os.path.join(self.log_dir, f"counterattack_{date_key}.log")

        try:
            with open(filename, 'a', encoding='utf-8') as f:
                f.write(json.dumps(self._log_to_dict(entry), ensure_ascii=False) + '\n')
        except Exception:
            pass  # 忽略写入错误

    def _log_to_dict(self, entry: LogEntry) -> Dict:
        """日志转字典"""
        return {
            'log_id': entry.log_id,
            'timestamp': entry.timestamp,
            'level': entry.level.value,
            'category': entry.category.value,
            'event': entry.event,
            'details': entry.details,
            'source': entry.source,
            'user': entry.user,
            'task_id': entry.task_id,
            'correlation_id': entry.correlation_id
        }

    def _logs_to_csv(self, logs: List[LogEntry]) -> str:
        """日志转CSV"""
        lines = ["log_id,timestamp,level,category,event,source,user,task_id"]
        for log in logs:
            lines.append(
                f"{log.log_id},{log.timestamp},{log.level.value},"
                f"{log.category.value},{log.event},{log.source},"
                f"{log.user or ''},{log.task_id or ''}"
            )
        return '\n'.join(lines)


# 独立运行测试
if __name__ == "__main__":
    manager = CounterattackLogManager({'log_dir': './test_logs'})

    # 记录各类日志
    manager.log_decision({
        'action': 'block',
        'target': '192.168.1.100',
        'result': 'approved'
    }, user='security_analyst', correlation_id='CORR-001')

    manager.log_execution('TASK-001', 'execute', {
        'blocked_ips': ['192.168.1.100'],
        'duration': 30
    }, correlation_id='CORR-001')

    manager.log_trace('TRACE-001', {
        'ip': '192.168.1.100',
        'origin': 'China',
        'confidence': 0.85
    })

    manager.log_error('execution_failed', 'Task timeout', {
        'task_id': 'TASK-002'
    })

    manager.log_audit('approve', 'admin', 'counterattack', 'success', {
        'authorization_level': 3
    })

    # 查询日志
    print("所有日志:")
    all_logs = manager.query(LogQuery(limit=10))
    for log in all_logs:
        print(f"  [{log.level.value}] {log.timestamp}: {log.event}")

    # 按类别查询
    print("\n执行日志:")
    exec_logs = manager.query(LogQuery(category=LogCategory.EXECUTION))
    for log in exec_logs:
        print(f"  {log.event}: {log.details}")

    # 获取关联日志
    print("\n关联日志 (CORR-001):")
    corr_logs = manager.get_logs_by_correlation('CORR-001')
    for log in corr_logs:
        print(f"  [{log.category.value}] {log.event}")

    # 获取统计
    stats = manager.get_statistics()
    print("\n日志统计:")
    print(json.dumps(stats, indent=2))
