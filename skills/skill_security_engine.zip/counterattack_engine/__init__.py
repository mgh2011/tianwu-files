"""
反击引擎模块
Counterattack Engine Module

提供完整的反击系统，包括决策、执行、追踪等子系统
"""

from .counterattack_engine import CounterattackEngine
from .decision_system.attack_judgment.attack_type_identifier import AttackTypeIdentifier
from .decision_system.attack_judgment.attack_intensity_assessor import AttackIntensityAssessor
from .decision_system.attack_judgment.attack_source_locator import AttackSourceLocator
from .countermeasure_system.blocking.attack_source_blocker import AttackSourceBlocker
from .countermeasure_system.blocking.traffic_scrubber import TrafficScrubber

__version__ = "v3.0.0"
__all__ = [
    'CounterattackEngine',
    'AttackTypeIdentifier',
    'AttackIntensityAssessor',
    'AttackSourceLocator',
    'AttackSourceBlocker',
    'TrafficScrubber'
]
