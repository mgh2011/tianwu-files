"""
防护系统 - IDS入侵检测模块
Intrusion Detection System
"""

import re
from typing import Dict, List, Optional
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)


class IDSModule:
    """
    入侵检测系统
    
    检测网络攻击和异常行为
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 攻击模式库
        self._attack_patterns = {
            'sql_injection': [
                r"('|(\'')){1,}",
                r"union\s+select",
                r"exec\s*\(",
                r"(or|and)\s+\d+\s*=\s*\d+",
            ],
            'xss': [
                r"<script",
                r"javascript:",
                r"onerror\s*=",
            ],
            'command_injection': [
                r";\s*cat\s+",
                r";\s*ls\s+",
                r"\|",
                r"`.*`",
            ],
            'path_traversal': [
                r"\.\./",
                r"\.\.\\",
            ]
        }
        
        # 检测计数器
        self._attack_counters = defaultdict(int)
    
    def check(self, request: Dict) -> Dict:
        """检查入侵"""
        data = str(request.get('data', '')) + str(request.get('body', '')) + str(request.get('url', ''))
        source_ip = request.get('source_ip', '')
        
        detections = []
        threat_score = 0.0
        
        # 模式匹配检测
        for attack_type, patterns in self._attack_patterns.items():
            for pattern in patterns:
                if re.search(pattern, data, re.IGNORECASE):
                    detections.append(attack_type)
                    threat_score = max(threat_score, 0.85)
                    break
        
        # 暴力破解检测
        if source_ip:
            self._attack_counters[source_ip] += 1
            if self._attack_counters[source_ip] > 10:
                detections.append('brute_force')
                threat_score = max(threat_score, 0.8)
        
        return {
            'detected': len(detections) > 0,
            'threat_score': threat_score,
            'attack_types': detections,
            'source_ip': source_ip
        }


if __name__ == '__main__':
    print("IDS模块测试")
    
    ids = IDSModule(None, None)
    
    # SQL注入检测
    result = ids.check({
        'data': "username=admin' OR 1=1 --",
        'source_ip': '192.168.1.100'
    })
    
    print(f"攻击检测: {'是' if result['detected'] else '否'}")
    print(f"攻击类型: {result['attack_types']}")
