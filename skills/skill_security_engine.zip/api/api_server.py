"""
企业级综合安全引擎 - REST API 模块
Enterprise Security Engine REST API Module

提供RESTful API接口，支持安全检查、事件查询、配置管理等
"""

import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading
import uuid

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class APIResponse:
    """API响应封装"""
    
    @staticmethod
    def success(data: Any = None, message: str = "Success") -> Dict:
        """成功响应"""
        return {
            'status': 'success',
            'code': 200,
            'message': message,
            'data': data,
            'timestamp': datetime.now().isoformat(),
            'request_id': str(uuid.uuid4())
        }
    
    @staticmethod
    def error(message: str, code: int = 400, details: Any = None) -> Dict:
        """错误响应"""
        return {
            'status': 'error',
            'code': code,
            'message': message,
            'details': details,
            'timestamp': datetime.now().isoformat(),
            'request_id': str(uuid.uuid4())
        }


class SecurityAPIHandler(BaseHTTPRequestHandler):
    """API请求处理器"""
    
    # 类级别的engine和应用实例
    _engine = None
    _app = None
    
    def _set_headers(self, status_code: int = 200):
        """设置响应头"""
        self.send_response(status_code)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.end_headers()
    
    def _get_request_body(self) -> Dict:
        """获取请求体"""
        content_length = int(self.headers.get('Content-Length', 0))
        if content_length > 0:
            body = self.rfile.read(content_length)
            return json.loads(body.decode('utf-8'))
        return {}
    
    def _send_json_response(self, data: Dict, status_code: int = 200):
        """发送JSON响应"""
        self._set_headers(status_code)
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))
    
    def do_OPTIONS(self):
        """处理OPTIONS请求"""
        self._set_headers(200)
    
    def do_GET(self):
        """处理GET请求"""
        path = self.path.split('?')[0]
        
        # 健康检查
        if path == '/health':
            self._handle_health()
            return
        
        # 获取引擎能力
        elif path == '/api/v1/capabilities':
            self._handle_capabilities()
            return
        
        # 获取统计信息
        elif path == '/api/v1/statistics':
            self._handle_statistics()
            return
        
        # 安全检查结果
        elif path.startswith('/api/v1/results/'):
            self._handle_get_result(path)
            return
        
        # 列表资源
        elif path == '/api/v1/modules':
            self._handle_list_modules()
            return
        
        elif path == '/api/v1/policies':
            self._handle_list_policies()
            return
        
        elif path == '/api/v1/rules':
            self._handle_list_rules()
            return
        
        # 未知路径
        else:
            self._send_json_response(
                APIResponse.error(f"Path not found: {path}", 404),
                404
            )
    
    def do_POST(self):
        """处理POST请求"""
        path = self.path.split('?')[0]
        body = self._get_request_body()
        
        # 安全检查
        if path == '/api/v1/check':
            self._handle_security_check(body)
            return
        
        # 邮件检查
        elif path == '/api/v1/check/email':
            self._handle_email_check(body)
            return
        
        # 批量检查
        elif path == '/api/v1/check/batch':
            self._handle_batch_check(body)
            return
        
        # 策略更新
        elif path == '/api/v1/policies':
            self._handle_create_policy(body)
            return
        
        # 规则更新
        elif path == '/api/v1/rules':
            self._handle_create_rule(body)
            return
        
        # 未知路径
        else:
            self._send_json_response(
                APIResponse.error(f"Path not found: {path}", 404),
                404
            )
    
    def _handle_health(self):
        """处理健康检查"""
        health = {
            'status': 'healthy',
            'version': 'v3.0.1',
            'timestamp': datetime.now().isoformat()
        }
        self._send_json_response(APIResponse.success(health))
    
    def _handle_capabilities(self):
        """处理获取引擎能力"""
        if self._engine:
            caps = self._engine.get_capabilities()
            self._send_json_response(APIResponse.success(caps))
        else:
            self._send_json_response(
                APIResponse.error("Engine not initialized", 500),
                500
            )
    
    def _handle_statistics(self):
        """处理获取统计信息"""
        if self._engine:
            stats = self._engine.get_statistics()
            self._send_json_response(APIResponse.success(stats))
        else:
            self._send_json_response(
                APIResponse.error("Engine not initialized", 500),
                500
            )
    
    def _handle_get_result(self, path: str):
        """处理获取检查结果"""
        result_id = path.split('/')[-1]
        # TODO: 从结果存储中获取结果
        self._send_json_response(APIResponse.success({
            'result_id': result_id,
            'status': 'completed'
        }))
    
    def _handle_list_modules(self):
        """处理获取模块列表"""
        modules = [
            {'name': 'phishing', 'type': 'detection', 'enabled': True},
            {'name': 'spam', 'type': 'filter', 'enabled': True},
            {'name': 'firewall', 'type': 'protection', 'enabled': True},
            {'name': 'ids', 'type': 'detection', 'enabled': True},
            {'name': 'antivirus', 'type': 'protection', 'enabled': True}
        ]
        self._send_json_response(APIResponse.success(modules))
    
    def _handle_list_policies(self):
        """处理获取策略列表"""
        self._send_json_response(APIResponse.success({
            'policies': [
                {'id': 'POL-001', 'name': '最小权限原则', 'enabled': True},
                {'id': 'POL-002', 'name': '密码复杂度要求', 'enabled': True}
            ]
        }))
    
    def _handle_list_rules(self):
        """处理获取规则列表"""
        self._send_json_response(APIResponse.success({
            'rules': [
                {'id': 'RULE-PHISH-001', 'name': '品牌仿冒检测', 'enabled': True},
                {'id': 'RULE-NET-001', 'name': '端口扫描检测', 'enabled': True}
            ]
        }))
    
    def _handle_security_check(self, body: Dict):
        """处理安全检查请求"""
        if not body:
            self._send_json_response(
                APIResponse.error("Request body is required", 400),
                400
            )
            return
        
        check_type = body.get('type', 'general')
        # TODO: 调用实际的安全检查逻辑
        result = {
            'check_id': str(uuid.uuid4()),
            'type': check_type,
            'threat_level': 'LOW',
            'confidence': 0.95,
            'result': 'Safe'
        }
        self._send_json_response(APIResponse.success(result))
    
    def _handle_email_check(self, body: Dict):
        """处理邮件安全检查"""
        if not body:
            self._send_json_response(
                APIResponse.error("Email data is required", 400),
                400
            )
            return
        
        # TODO: 调用实际的邮件检查逻辑
        result = {
            'check_id': str(uuid.uuid4()),
            'type': 'email',
            'is_phishing': False,
            'is_spam': False,
            'threat_level': 'SAFE'
        }
        self._send_json_response(APIResponse.success(result))
    
    def _handle_batch_check(self, body: Dict):
        """处理批量安全检查"""
        items = body.get('items', [])
        results = []
        for item in items:
            # TODO: 对每个条目执行检查
            results.append({
                'item_id': item.get('id'),
                'threat_level': 'LOW',
                'status': 'completed'
            })
        self._send_json_response(APIResponse.success({
            'total': len(items),
            'completed': len(results),
            'results': results
        }))
    
    def _handle_create_policy(self, body: Dict):
        """处理创建策略"""
        policy_id = body.get('id')
        if not policy_id:
            self._send_json_response(
                APIResponse.error("Policy ID is required", 400),
                400
            )
            return
        
        # TODO: 保存策略
        self._send_json_response(APIResponse.success({
            'id': policy_id,
            'status': 'created'
        }))
    
    def _handle_create_rule(self, body: Dict):
        """处理创建规则"""
        rule_id = body.get('id')
        if not rule_id:
            self._send_json_response(
                APIResponse.error("Rule ID is required", 400),
                400
            )
            return
        
        # TODO: 保存规则
        self._send_json_response(APIResponse.success({
            'id': rule_id,
            'status': 'created'
        }))
    
    def log_message(self, format, *args):
        """重写日志方法"""
        logger.info(f"{self.address_string()} - {format % args}")


class SecurityAPIServer:
    """安全引擎API服务器"""
    
    def __init__(self, host: str = '0.0.0.0', port: int = 8080, engine=None):
        """
        初始化API服务器
        
        Args:
            host: 监听主机地址
            port: 监听端口
            engine: 安全引擎实例
        """
        self.host = host
        self.port = port
        self.engine = engine
        self.server = None
        self._thread = None
        self._running = False
        
        # 设置处理器使用的engine
        SecurityAPIHandler._engine = engine
        SecurityAPIHandler._app = self
    
    def start(self):
        """启动API服务器"""
        if self._running:
            logger.warning("API server is already running")
            return
        
        self.server = HTTPServer((self.host, self.port), SecurityAPIHandler)
        self._running = True
        
        # 在后台线程中运行服务器
        self._thread = threading.Thread(target=self._run_server, daemon=True)
        self._thread.start()
        
        logger.info(f"API server started on {self.host}:{self.port}")
    
    def _run_server(self):
        """运行服务器"""
        try:
            self.server.serve_forever()
        except Exception as e:
            logger.error(f"API server error: {e}")
        finally:
            self._running = False
    
    def stop(self):
        """停止API服务器"""
        if not self._running:
            return
        
        if self.server:
            self.server.shutdown()
            self.server.server_close()
        
        self._running = False
        logger.info("API server stopped")
    
    def is_running(self) -> bool:
        """检查服务器是否运行"""
        return self._running


def create_api_server(host: str = '0.0.0.0', port: int = 8080, engine=None) -> SecurityAPIServer:
    """
    创建API服务器实例
    
    Args:
        host: 监听主机地址
        port: 监听端口
        engine: 安全引擎实例
    
    Returns:
        SecurityAPIServer实例
    """
    return SecurityAPIServer(host, port, engine)


# ========== 便捷函数 ==========

def start_api_server(host: str = '0.0.0.0', port: int = 8080, engine=None):
    """启动API服务器（便捷函数）"""
    server = create_api_server(host, port, engine)
    server.start()
    return server


if __name__ == '__main__':
    print("=" * 60)
    print("企业级综合安全引擎 - API服务器")
    print("=" * 60)
    
    # 创建并启动API服务器
    server = start_api_server('0.0.0.0', 8080)
    
    print("\nAPI端点:")
    print("  GET  /health              - 健康检查")
    print("  GET  /api/v1/capabilities - 获取引擎能力")
    print("  GET  /api/v1/statistics   - 获取统计信息")
    print("  GET  /api/v1/modules      - 获取模块列表")
    print("  POST /api/v1/check        - 安全检查")
    print("  POST /api/v1/check/email  - 邮件安全检查")
    print("  POST /api/v1/check/batch  - 批量安全检查")
    print("\n按Ctrl+C停止服务器")
    print("=" * 60)
    
    try:
        while True:
            pass
    except KeyboardInterrupt:
        print("\n停止服务器...")
        server.stop()
        print("服务器已停止")
