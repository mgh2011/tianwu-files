"""
威胁等级评估模块
Threat Level Assessor - 评估威胁等级
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class ThreatLevel(Enum):
    """威胁等级"""
    INFO = (0, "信息", "仅需记录和监控")
    LOW = (1, "低", "常规监控")
    MEDIUM = (2, "中", "需要关注")
    HIGH = (3, "高", "需要立即处理")
    CRITICAL = (4, "严重", "需要紧急响应")
    EMERGENCY = (5, "紧急", "需要最高级别响应")

    def __init__(self, level: int, name_cn: str, action: str):
        self.level = level
        self.name_cn = name_cn
        self.action = action


@dataclass
class ThreatIndicator:
    """威胁指标"""
    name: str
    value: float
    weight: float
    threshold: float
    description: str


@dataclass
class ThreatAssessment:
    """威胁评估结果"""
    level: ThreatLevel
    score: float
    indicators: List[ThreatIndicator]
    factors: List[str]
    recommended_actions: List[str]
    response_time: str  # 建议响应时间


class ThreatLevelAssessor:
    """威胁等级评估器"""

    # 威胁因素权重
    FACTOR_WEIGHTS = {
        'attack_confidence': 0.15,  # 攻击置信度
        'severity': 0.20,  # 攻击严重程度
        'intensity': 0.15,  # 攻击强度
        'damage_potential': 0.15,  # 潜在损失
        'likelihood': 0.15,  # 发生可能性
        'impact': 0.20,  # 影响范围
    }

    # 评分阈值
    SCORE_THRESHOLDS = {
        'info': (0, 10),
        'low': (10, 30),
        'medium': (30, 50),
        'high': (50, 75),
        'critical': (75, 90),
        'emergency': (90, 100),
    }

    # 响应时间要求（分钟）
    RESPONSE_TIMES = {
        ThreatLevel.EMERGENCY: 15,
        ThreatLevel.CRITICAL: 30,
        ThreatLevel.HIGH: 60,
        ThreatLevel.MEDIUM: 240,
        ThreatLevel.LOW: 1440,
        ThreatLevel.INFO: 10080,
    }

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化威胁等级评估器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.factor_weights = self.FACTOR_WEIGHTS.copy()
        self.score_thresholds = self.SCORE_THRESHOLDS.copy()
        self.assessment_history = []

    def assess(self, threat_data: Dict) -> ThreatAssessment:
        """
        评估威胁等级

        Args:
            threat_data: 威胁数据，包含：
                - attack_type: 攻击类型
                - attack_confidence: 攻击置信度 (0-100)
                - severity: 严重程度 (1-10)
                - intensity: 强度评估结果
                - damage_potential: 潜在损失
                - target_info: 目标信息
                - source_info: 来源信息
                - historical_threats: 历史威胁数据

        Returns:
            威胁评估结果
        """
        # 提取各项指标
        attack_confidence = threat_data.get('attack_confidence', 0)
        severity = threat_data.get('severity', 5)
        intensity_result = threat_data.get('intensity', {})
        damage_potential = threat_data.get('damage_potential', {})
        target_info = threat_data.get('target_info', {})
        source_info = threat_data.get('source_info', {})
        historical_threats = threat_data.get('historical_threats', [])
        attack_type = threat_data.get('attack_type', 'unknown')

        # 计算各项威胁指标
        indicators = []

        # 攻击置信度指标
        confidence_indicator = ThreatIndicator(
            name='attack_confidence',
            value=attack_confidence,
            weight=self.factor_weights['attack_confidence'],
            threshold=50,
            description='攻击检测置信度'
        )
        indicators.append(confidence_indicator)

        # 严重程度指标
        severity_indicator = ThreatIndicator(
            name='severity',
            value=severity * 10,  # 转换为0-100
            weight=self.factor_weights['severity'],
            threshold=50,
            description='攻击类型严重程度'
        )
        indicators.append(severity_indicator)

        # 强度指标
        intensity_score = intensity_result.get('overall_score', 50)
        intensity_indicator = ThreatIndicator(
            name='intensity',
            value=intensity_score,
            weight=self.factor_weights['intensity'],
            threshold=50,
            description='攻击强度评分'
        )
        indicators.append(intensity_indicator)

        # 损失潜力指标
        damage_score = self._calculate_damage_score(damage_potential)
        damage_indicator = ThreatIndicator(
            name='damage_potential',
            value=damage_score,
            weight=self.factor_weights['damage_potential'],
            threshold=50,
            description='潜在损失评估'
        )
        indicators.append(damage_indicator)

        # 发生可能性指标
        likelihood_score = self._calculate_likelihood(
            attack_type, source_info, historical_threats
        )
        likelihood_indicator = ThreatIndicator(
            name='likelihood',
            value=likelihood_score,
            weight=self.factor_weights['likelihood'],
            threshold=50,
            description='攻击发生可能性'
        )
        indicators.append(likelihood_indicator)

        # 影响范围指标
        impact_score = self._calculate_impact_score(target_info, intensity_result)
        impact_indicator = ThreatIndicator(
            name='impact',
            value=impact_score,
            weight=self.factor_weights['impact'],
            threshold=50,
            description='影响范围评估'
        )
        indicators.append(impact_indicator)

        # 计算综合评分
        overall_score = self._calculate_overall_score(indicators)

        # 确定威胁等级
        threat_level = self._determine_threat_level(overall_score)

        # 分析影响因素
        factors = self._analyze_factors(
            indicators, attack_type, target_info, source_info
        )

        # 生成建议动作
        recommended_actions = self._generate_recommended_actions(
            threat_level, indicators, factors
        )

        # 获取响应时间要求
        response_time = self._format_response_time(threat_level)

        # 构建评估结果
        assessment = ThreatAssessment(
            level=threat_level,
            score=round(overall_score, 2),
            indicators=indicators,
            factors=factors,
            recommended_actions=recommended_actions,
            response_time=response_time
        )

        # 更新历史
        self._update_history(assessment, threat_data)

        return assessment

    def _calculate_damage_score(self, damage_potential: Dict) -> float:
        """计算损失潜力评分"""
        if not damage_potential:
            return 50.0

        # 直接损失
        direct_loss = damage_potential.get('direct_financial', 0)
        # 间接损失
        indirect_loss = damage_potential.get('indirect_financial', 0)
        # 数据泄露
        data_breach = damage_potential.get('data_compromised', 0)

        # 转换为评分
        score = 0.0

        # 损失金额评分
        total_loss = direct_loss + indirect_loss
        if total_loss > 10000000:
            score += 40
        elif total_loss > 1000000:
            score += 30
        elif total_loss > 100000:
            score += 20
        elif total_loss > 10000:
            score += 10

        # 数据泄露评分
        if data_breach > 100000:
            score += 30
        elif data_breach > 10000:
            score += 20
        elif data_breach > 1000:
            score += 10

        return min(100, score)

    def _calculate_likelihood(self, attack_type: str,
                              source_info: Dict,
                              historical_threats: List) -> float:
        """计算发生可能性"""
        score = 50.0  # 基础分数

        # 历史威胁频率
        if historical_threats:
            recent_count = sum(1 for t in historical_threats
                             if t.get('type') == attack_type)
            if recent_count > 10:
                score += 30
            elif recent_count > 5:
                score += 20
            elif recent_count > 1:
                score += 10

        # 来源信誉
        source_reputation = source_info.get('reputation_score', 50)
        if source_reputation < 20:
            score += 20
        elif source_reputation < 40:
            score += 10

        # 匿名化检测
        if source_info.get('is_anonymized', False):
            score += 15

        # 高风险来源
        if source_info.get('threat_level') in ['high', 'critical']:
            score += 15

        return min(100, score)

    def _calculate_impact_score(self, target_info: Dict,
                               intensity_result: Dict) -> float:
        """计算影响范围评分"""
        score = 0.0

        # 目标重要性
        target_criticality = target_info.get('criticality', 'medium')
        criticality_scores = {
            'critical': 30,
            'high': 20,
            'medium': 10,
            'low': 5,
        }
        score += criticality_scores.get(target_criticality, 10)

        # 目标数量
        unique_targets = intensity_result.get('metrics', {}).get('unique_targets', 1)
        if unique_targets > 10:
            score += 25
        elif unique_targets > 5:
            score += 15
        elif unique_targets > 1:
            score += 10

        # 核心系统影响
        if target_info.get('is_core_system', False):
            score += 20

        # 业务关键服务
        if target_info.get('is_business_critical', False):
            score += 15

        return min(100, score)

    def _calculate_overall_score(self, indicators: List[ThreatIndicator]) -> float:
        """计算综合评分"""
        weighted_sum = sum(
            indicator.value * indicator.weight
            for indicator in indicators
        )
        return weighted_sum

    def _determine_threat_level(self, score: float) -> ThreatLevel:
        """确定威胁等级"""
        if score >= 90:
            return ThreatLevel.EMERGENCY
        elif score >= 75:
            return ThreatLevel.CRITICAL
        elif score >= 50:
            return ThreatLevel.HIGH
        elif score >= 30:
            return ThreatLevel.MEDIUM
        elif score >= 10:
            return ThreatLevel.LOW
        else:
            return ThreatLevel.INFO

    def _analyze_factors(self, indicators: List[ThreatIndicator],
                        attack_type: str,
                        target_info: Dict,
                        source_info: Dict) -> List[str]:
        """分析影响因素"""
        factors = []

        for indicator in indicators:
            if indicator.value > 70:
                factors.append(f"高{indicator.description}: {indicator.value:.1f}")
            elif indicator.value < 30:
                factors.append(f"低{indicator.description}: {indicator.value:.1f}")

        # 特殊因素
        if source_info.get('is_anonymized'):
            factors.append("检测到匿名化工具使用")

        if source_info.get('threat_level') == 'high':
            factors.append("攻击源信誉较低")

        if target_info.get('is_core_system'):
            factors.append("攻击目标为核心系统")

        if target_info.get('is_business_critical'):
            factors.append("目标为业务关键系统")

        # 攻击类型特定因素
        type_factors = {
            'ransomware': ["可能导致数据加密", "恢复成本高昂"],
            'apt': ["高级持续性威胁", "可能长期潜伏"],
            'ddos': ["可能导致服务中断", "影响业务可用性"],
            'data_breach': ["可能导致数据泄露", "合规风险"],
        }

        if attack_type in type_factors:
            factors.extend(type_factors[attack_type])

        return factors

    def _generate_recommended_actions(self, level: ThreatLevel,
                                     indicators: List[ThreatIndicator],
                                     factors: List[str]) -> List[str]:
        """生成建议动作"""
        actions = []

        # 基于等级的通用动作
        if level == ThreatLevel.EMERGENCY:
            actions.extend([
                "立即启动紧急响应预案",
                "通知安全运营中心(SOC)",
                "召集应急响应团队(ERT)",
                "隔离受影响的系统",
                "准备对外公告"
            ])
        elif level == ThreatLevel.CRITICAL:
            actions.extend([
                "立即开始响应流程",
                "通知相关管理人员",
                "隔离受影响的系统",
                "开始取证调查"
            ])
        elif level == ThreatLevel.HIGH:
            actions.extend([
                "优先处理此威胁",
                "通知安全团队",
                "加强相关系统监控"
            ])
        elif level == ThreatLevel.MEDIUM:
            actions.extend([
                "安排时间处理",
                "加强监控",
                "准备响应预案"
            ])
        else:
            actions.append("持续监控")

        # 基于指标的动作
        for indicator in indicators:
            if indicator.name == 'damage_potential' and indicator.value > 70:
                actions.append("准备业务连续性计划")
            if indicator.name == 'impact' and indicator.value > 70:
                actions.append("通知业务部门")

        return actions

    def _format_response_time(self, level: ThreatLevel) -> str:
        """格式化响应时间"""
        minutes = self.RESPONSE_TIMES.get(level, 1440)

        if minutes < 60:
            return f"{minutes}分钟"
        elif minutes < 1440:
            hours = minutes // 60
            return f"{hours}小时"
        else:
            days = minutes // 1440
            return f"{days}天"

    def _update_history(self, assessment: ThreatAssessment, threat_data: Dict):
        """更新历史记录"""
        self.assessment_history.append({
            'level': assessment.level.name,
            'score': assessment.score,
            'threat_data': threat_data,
            'timestamp': datetime.now().isoformat()
        })

        if len(self.assessment_history) > 1000:
            self.assessment_history = self.assessment_history[-800:]

    def get_statistics(self) -> Dict:
        """获取统计信息"""
        if not self.assessment_history:
            return {}

        level_counts = {}
        for record in self.assessment_history:
            level = record['level']
            level_counts[level] = level_counts.get(level, 0) + 1

        scores = [r['score'] for r in self.assessment_history]

        return {
            'total_assessments': len(scores),
            'average_score': sum(scores) / len(scores),
            'max_score': max(scores),
            'min_score': min(scores),
            'by_level': level_counts,
        }


# 独立运行测试
if __name__ == "__main__":
    assessor = ThreatLevelAssessor()

    # 测试威胁评估
    threat_data = {
        'attack_type': 'ransomware',
        'attack_confidence': 95,
        'severity': 9,
        'intensity': {
            'overall_score': 80,
            'metrics': {
                'unique_targets': 15,
                'request_rate': 5000
            }
        },
        'damage_potential': {
            'direct_financial': 5000000,
            'indirect_financial': 2000000,
            'data_compromised': 50000
        },
        'target_info': {
            'criticality': 'critical',
            'is_core_system': True,
            'is_business_critical': True
        },
        'source_info': {
            'reputation_score': 15,
            'is_anonymized': True,
            'threat_level': 'high'
        },
        'historical_threats': [
            {'type': 'ransomware', 'count': 5}
        ]
    }

    assessment = assessor.assess(threat_data)
    print("威胁等级评估结果:")
    print(f"等级: {assessment.level.name_cn} ({assessment.level.name})")
    print(f"评分: {assessment.score}")
    print(f"响应时间: {assessment.response_time}")
    print(f"\n影响因素:")
    for factor in assessment.factors:
        print(f"  - {factor}")
    print(f"\n建议动作:")
    for action in assessment.recommended_actions:
        print(f"  - {action}")

    print(f"\n\n历史统计:")
    print(json.dumps(assessor.get_statistics(), indent=2))
