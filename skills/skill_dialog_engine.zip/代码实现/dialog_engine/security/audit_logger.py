# dialog_engine/security/audit_logger.py
"""
审计日志模块
记录对话内容和操作审计
"""

import logging
import json
from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import uuid4

from ..models.data_models import AuditLog
from ..config.default_config import config


logger = logging.getLogger(__name__)


class AuditLogger:
    """
    审计日志模块
    记录对话内容和操作审计
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        self.config = config_dict or config.SECURITY
        self.enabled = self.config.get("enable_audit", True)
        self.log_level = self.config.get("audit_log_level", "info")
        self.audit_actions = set(self.config.get("audit_actions", []))
        self.retention_days = self.config.get("audit_retention_days", 90)
        
        # 存储审计日志
        self._logs: List[AuditLog] = []
        
        # 索引
        self._session_index: Dict[str, List[str]] = {}
        self._user_index: Dict[str, List[str]] = {}
        
        # 日志处理器
        self._handlers: List[callable] = []
    
    async def log(self, session_id: str, user_id: str,
                 action: str, content: str, result: str,
                 metadata: Optional[Dict] = None,
                 ip_address: Optional[str] = None,
                 user_agent: Optional[str] = None) -> str:
        """
        记录审计日志
        
        Args:
            session_id: 会话ID
            user_id: 用户ID
            action: 操作类型
            content: 操作内容
            result: 操作结果
            metadata: 额外元数据
            ip_address: IP地址
            user_agent: 用户代理
            
        Returns:
            log_id: 日志ID
        """
        if not self.enabled:
            return None
        
        # 检查是否需要记录该操作
        if self.audit_actions and action not in self.audit_actions:
            return None
        
        log_id = f"audit_{uuid4().hex[:12]}"
        
        audit_log = AuditLog(
            log_id=log_id,
            session_id=session_id,
            user_id=user_id,
            action=action,
            content=content,
            result=result,
            timestamp=datetime.now(),
            ip_address=ip_address,
            user_agent=user_agent,
            metadata=metadata or {}
        )
        
        # 存储
        self._logs.append(audit_log)
        
        # 更新索引
        if session_id not in self._session_index:
            self._session_index[session_id] = []
        self._session_index[session_id].append(log_id)
        
        if user_id not in self._user_index:
            self._user_index[user_id] = []
        self._user_index[user_id].append(log_id)
        
        # 调用处理器
        await self._notify_handlers(audit_log)
        
        # 清理过期日志
        await self._cleanup_old_logs()
        
        logger.debug(f"Logged audit: {action} for session {session_id}")
        return log_id
    
    async def _notify_handlers(self, audit_log: AuditLog):
        """通知日志处理器"""
        for handler in self._handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(audit_log)
                else:
                    handler(audit_log)
            except Exception as e:
                logger.error(f"Audit handler error: {e}")
    
    async def get_logs(self, session_id: Optional[str] = None,
                      user_id: Optional[str] = None,
                      action: Optional[str] = None,
                      start_time: Optional[datetime] = None,
                      end_time: Optional[datetime] = None,
                      limit: int = 100) -> List[AuditLog]:
        """
        查询审计日志
        
        Args:
            session_id: 会话ID
            user_id: 用户ID
            action: 操作类型
            start_time: 开始时间
            end_time: 结束时间
            limit: 返回数量限制
            
        Returns:
            审计日志列表
        """
        # 确定查询范围
        if session_id and session_id in self._session_index:
            log_ids = self._session_index[session_id]
        elif user_id and user_id in self._user_index:
            log_ids = self._user_index[user_id]
        else:
            log_ids = None
        
        results = []
        
        for audit_log in reversed(self._logs):
            # 检查ID过滤
            if log_ids and audit_log.log_id not in log_ids:
                continue
            
            # 检查操作类型
            if action and audit_log.action != action:
                continue
            
            # 检查时间范围
            if start_time and audit_log.timestamp < start_time:
                continue
            if end_time and audit_log.timestamp > end_time:
                continue
            
            results.append(audit_log)
            
            if len(results) >= limit:
                break
        
        return results
    
    async def get_session_logs(self, session_id: str) -> List[AuditLog]:
        """获取会话的所有审计日志"""
        return await self.get_logs(session_id=session_id, limit=1000)
    
    async def get_user_logs(self, user_id: str, 
                           limit: int = 100) -> List[AuditLog]:
        """获取用户的所有审计日志"""
        return await self.get_logs(user_id=user_id, limit=limit)
    
    async def search_logs(self, keyword: str, 
                         limit: int = 100) -> List[AuditLog]:
        """搜索包含关键词的审计日志"""
        results = []
        keyword_lower = keyword.lower()
        
        for audit_log in reversed(self._logs):
            if keyword_lower in audit_log.content.lower():
                results.append(audit_log)
            
            if len(results) >= limit:
                break
        
        return results
    
    async def get_statistics(self, start_time: Optional[datetime] = None,
                            end_time: Optional[datetime] = None) -> Dict[str, Any]:
        """
        获取审计统计
        
        Returns:
            统计数据
        """
        logs = await self.get_logs(start_time=start_time, 
                                   end_time=end_time, 
                                   limit=10000)
        
        # 统计各操作类型数量
        action_counts: Dict[str, int] = {}
        result_counts: Dict[str, int] = {}
        user_counts: Dict[str, int] = {}
        
        for log in logs:
            action_counts[log.action] = action_counts.get(log.action, 0) + 1
            result_counts[log.result] = result_counts.get(log.result, 0) + 1
            user_counts[log.user_id] = user_counts.get(log.user_id, 0) + 1
        
        return {
            "total_logs": len(logs),
            "action_distribution": action_counts,
            "result_distribution": result_counts,
            "unique_users": len(user_counts),
            "top_users": sorted(user_counts.items(), 
                               key=lambda x: x[1], 
                               reverse=True)[:10],
            "time_range": {
                "earliest": logs[0].timestamp.isoformat() if logs else None,
                "latest": logs[-1].timestamp.isoformat() if logs else None
            }
        }
    
    async def export_logs(self, start_time: Optional[datetime] = None,
                        end_time: Optional[datetime] = None,
                        format: str = "json") -> str:
        """
        导出审计日志
        
        Args:
            start_time: 开始时间
            end_time: 结束时间
            format: 导出格式
            
        Returns:
            导出的日志内容
        """
        logs = await self.get_logs(start_time=start_time,
                                   end_time=end_time,
                                   limit=100000)
        
        if format == "json":
            return json.dumps([log.__dict__ for log in logs], 
                            default=str, ensure_ascii=False)
        elif format == "csv":
            lines = ["log_id,session_id,user_id,action,content,result,timestamp"]
            for log in logs:
                lines.append(
                    f"{log.log_id},{log.session_id},{log.user_id},"
                    f"{log.action},\"{log.content}\",{log.result},{log.timestamp}"
                )
            return "\n".join(lines)
        
        return str(logs)
    
    async def _cleanup_old_logs(self):
        """清理过期日志"""
        if not self.retention_days:
            return
        
        cutoff = datetime.now() - timedelta(days=self.retention_days)
        
        # 找出过期的日志
        old_log_ids = set()
        for i, log in enumerate(self._logs):
            if log.timestamp < cutoff:
                old_log_ids.add(log.log_id)
        
        # 删除
        if old_log_ids:
            self._logs = [log for log in self._logs 
                        if log.log_id not in old_log_ids]
            
            # 清理索引
            for session_id in list(self._session_index.keys()):
                self._session_index[session_id] = [
                    lid for lid in self._session_index[session_id]
                    if lid not in old_log_ids
                ]
            
            for user_id in list(self._user_index.keys()):
                self._user_index[user_id] = [
                    lid for lid in self._user_index[user_id]
                    if lid not in old_log_ids
                ]
            
            logger.info(f"Cleaned up {len(old_log_ids)} old audit logs")
    
    def add_handler(self, handler: callable):
        """添加日志处理器"""
        if handler not in self._handlers:
            self._handlers.append(handler)
    
    def remove_handler(self, handler: callable) -> bool:
        """移除日志处理器"""
        if handler in self._handlers:
            self._handlers.remove(handler)
            return True
        return False
    
    def set_audit_actions(self, actions: List[str]):
        """设置审计的操作类型"""
        self.audit_actions = set(actions)
    
    def enable_action(self, action: str):
        """启用审计操作"""
        self.audit_actions.add(action)
    
    def disable_action(self, action: str):
        """禁用审计操作"""
        self.audit_actions.discard(action)


# 需要导入asyncio
import asyncio
from datetime import timedelta
