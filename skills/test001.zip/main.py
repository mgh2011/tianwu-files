print("Hello, 天武共享市场!")
