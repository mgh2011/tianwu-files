"""
攻击类型识别模块
Attack Type Identifier - 识别网络攻击的类型和特征
"""

from typing import Dict, List, Optional, Tuple
from enum import Enum
import re
from datetime import datetime
import hashlib


class AttackType(Enum):
    """攻击类型枚举"""
    # 侦察类
    RECONNAISSANCE = "reconnaissance"  # 侦察
    PORT_SCAN = "port_scan"  # 端口扫描
    VULN_SCAN = "vulnerability_scan"  # 漏洞扫描
    OS_FINGERPRINT = "os_fingerprint"  # 操作系统指纹识别

    # 入侵类
    BRUTE_FORCE = "brute_force"  # 暴力破解
    SQL_INJECTION = "sql_injection"  # SQL注入
    XSS = "cross_site_scripting"  # 跨站脚本
    CSRF = "csrf"  # 跨站请求伪造
    FILE_INCLUSION = "file_inclusion"  # 文件包含
    COMMAND_INJECTION = "command_injection"  # 命令注入
    BUFFER_OVERFLOW = "buffer_overflow"  # 缓冲区溢出

    # 拒绝服务类
    DOS = "denial_of_service"  # 拒绝服务
    DDOS = "distributed_dos"  # 分布式拒绝服务
    SYN_FLOOD = "syn_flood"  # SYN洪水
    UDP_FLOOD = "udp_flood"  # UDP洪水
    HTTP_FLOOD = "http_flood"  # HTTP洪水

    # 数据窃取类
    DATA_EXFILTRATION = "data_exfiltration"  # 数据窃取
    CREDENTIAL_THEFT = "credential_theft"  # 凭据窃取
    MALWARE_DOWNLOAD = "malware_download"  # 恶意软件下载

    # 权限提升类
    PRIVILEGE_ESCALATION = "privilege_escalation"  # 权限提升
    ROOTKIT = "rootkit"  # Rootkit安装
    BACKDOOR = "backdoor"  # 后门植入

    # 横向移动类
    LATERAL_MOVEMENT = "lateral_movement"  # 横向移动
    PIVOTING = "pivoting"  # 跳转攻击

    # 未知/混合
    UNKNOWN = "unknown"
    MULTI_STAGE = "multi_stage"  # 多阶段攻击


class AttackSignature:
    """攻击特征签名"""

    SIGNATURES = {
        AttackType.SQL_INJECTION: {
            'patterns': [
                r"(?i)(union\s+select|select\s+.*\s+from|insert\s+into|delete\s+from|drop\s+table|update\s+.*\s+set)",
                r"(?i)(or\s+1\s*=\s*1|and\s+1\s*=\s*1|'--|;--|xp_)",
                r"(?i)(exec\s*\(|execute\s*\(|eval\s*\(|system\s*\()",
            ],
            'severity': 9,
            'description': "SQL注入攻击"
        },
        AttackType.XSS: {
            'patterns': [
                r"<script[^>]*>.*?</script>",
                r"javascript:",
                r"on\w+\s*=",
                r"(<|%3C)img[^>]+onerror=",
            ],
            'severity': 7,
            'description': "跨站脚本攻击"
        },
        AttackType.COMMAND_INJECTION: {
            'patterns': [
                r"[;&|`$]",
                r"\(\s*\)",
                r"\$\{.*\}",
                r"eval\s*\(",
                r"base64_decode\s*\(",
            ],
            'severity': 10,
            'description': "命令注入攻击"
        },
        AttackType.BRUTE_FORCE: {
            'patterns': [
                r"(?i)failed\s+(login|attempt)",
                r"(?i)authentication\s+failure",
                r"(?i)invalid\s+(password|credential)",
            ],
            'severity': 6,
            'description': "暴力破解攻击"
        },
        AttackType.PORT_SCAN: {
            'patterns': [
                r"SYN",
                r"FIN",
                r"NULL",
                r"XMAS",
                r"connect\s+scan",
            ],
            'severity': 4,
            'description': "端口扫描"
        },
        AttackType.DOS: {
            'patterns': [
                r"flood",
                r"amplification",
                r"reflection",
                r"slowloris",
            ],
            'severity': 8,
            'description': "拒绝服务攻击"
        },
        AttackType.FILE_INCLUSION: {
            'patterns': [
                r"(?i)(path|file|include)\s*=\s*",
                r"\.\./",
                r"\.\.%2f",
                r"php://",
                r"zip://",
            ],
            'severity': 8,
            'description': "文件包含攻击"
        },
    }


class AttackTypeIdentifier:
    """攻击类型识别器"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化攻击类型识别器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.signatures = AttackSignature()
        self.identification_cache = {}
        self.identification_history = []

    def identify(self, attack_data: Dict) -> Dict:
        """
        识别攻击类型

        Args:
            attack_data: 攻击数据，包含以下字段：
                - request: HTTP请求内容
                - source_ip: 源IP地址
                - target: 攻击目标
                - timestamp: 时间戳
                - raw_data: 原始数据

        Returns:
            识别结果，包含：
                - attack_type: 攻击类型
                - confidence: 置信度
                - severity: 严重程度
                - indicators: 攻击指标列表
                - metadata: 元数据
        """
        request = attack_data.get('request', '')
        source_ip = attack_data.get('source_ip', '')
        target = attack_data.get('target', '')
        timestamp = attack_data.get('timestamp', datetime.now().isoformat())
        raw_data = attack_data.get('raw_data', '')

        # 生成缓存键
        cache_key = self._generate_cache_key(request, source_ip)

        # 检查缓存
        if cache_key in self.identification_cache:
            cached_result = self.identification_cache[cache_key]
            if self._is_cache_valid(cached_result, timestamp):
                return cached_result['result']

        # 执行识别
        result = self._perform_identification(request, source_ip, target, raw_data)

        # 缓存结果
        self._cache_result(cache_key, result, timestamp)

        # 记录历史
        self._record_history(result)

        return result

    def _perform_identification(self, request: str, source_ip: str,
                                 target: str, raw_data: str) -> Dict:
        """执行识别逻辑"""
        detected_types = []
        indicators = []

        # 合并检测数据
        combined_data = f"{request} {raw_data}"

        # 使用正则表达式匹配攻击特征
        for attack_type, sig_info in self.signatures.SIGNATURES.items():
            for pattern in sig_info['patterns']:
                match = re.search(pattern, combined_data, re.IGNORECASE | re.DOTALL)
                if match:
                    indicators.append({
                        'type': attack_type.value,
                        'pattern': pattern,
                        'match': match.group(0)[:100],
                        'position': match.start(),
                    })
                    if attack_type not in detected_types:
                        detected_types.append(attack_type)

        # 判断是否为多阶段攻击
        if len(detected_types) > 1:
            final_type = AttackType.MULTI_STAGE
            confidence = 0.9
        elif detected_types:
            final_type = detected_types[0]
            confidence = min(0.95, 0.6 + 0.1 * len(indicators))
        else:
            # 使用启发式规则
            final_type = self._heuristic_identification(combined_data, source_ip)
            confidence = 0.4

        # 计算严重程度
        severity = self._calculate_severity(final_type, indicators)

        return {
            'attack_type': final_type.value,
            'attack_type_name': final_type.name,
            'confidence': confidence,
            'severity': severity,
            'indicators': indicators,
            'detected_types': [t.value for t in detected_types],
            'metadata': {
                'request_length': len(request),
                'has_malicious_patterns': len(indicators) > 0,
                'source_ip': source_ip,
                'target': target,
                'timestamp': timestamp if 'timestamp' in locals() else datetime.now().isoformat(),
            }
        }

    def _heuristic_identification(self, data: str, source_ip: str) -> AttackType:
        """启发式识别"""
        # 异常的请求长度
        if len(data) > 10000:
            return AttackType.COMMAND_INJECTION

        # 异常的字符分布
        special_chars = sum(1 for c in data if c in '<>&\'"`;|$')
        if special_chars > len(data) * 0.3:
            return AttackType.COMMAND_INJECTION

        # 常见攻击关键字
        attack_keywords = {
            'admin': AttackType.BRUTE_FORCE,
            'login': AttackType.BRUTE_FORCE,
            'exec': AttackType.COMMAND_INJECTION,
            'system': AttackType.COMMAND_INJECTION,
            'ping': AttackType.DOS,
            'test': AttackType.RECONNAISSANCE,
        }

        for keyword, attack_type in attack_keywords.items():
            if keyword.lower() in data.lower():
                return attack_type

        return AttackType.UNKNOWN

    def _calculate_severity(self, attack_type: AttackType, indicators: List[Dict]) -> int:
        """计算严重程度"""
        base_severity = 5

        # 从签名获取基础严重程度
        for at, sig_info in self.signatures.SIGNATURES.items():
            if at == attack_type:
                base_severity = sig_info['severity']
                break

        # 根据指标数量调整
        if len(indicators) > 3:
            base_severity = min(10, base_severity + 1)

        # 多阶段攻击提升严重程度
        if attack_type == AttackType.MULTI_STAGE:
            base_severity = min(10, base_severity + 2)

        return base_severity

    def _generate_cache_key(self, request: str, source_ip: str) -> str:
        """生成缓存键"""
        data = f"{request}:{source_ip}"
        return hashlib.md5(data.encode()).hexdigest()

    def _is_cache_valid(self, cached: Dict, current_time: str) -> bool:
        """检查缓存是否有效"""
        cache_time = cached.get('timestamp', '')
        # 缓存有效期：5分钟
        if cache_time and isinstance(cache_time, str):
            try:
                cached_dt = datetime.fromisoformat(cache_time)
                current_dt = datetime.fromisoformat(current_time)
                delta = (current_dt - cached_dt).total_seconds()
                return delta < 300
            except:
                pass
        return False

    def _cache_result(self, cache_key: str, result: Dict, timestamp: str):
        """缓存结果"""
        self.identification_cache[cache_key] = {
            'result': result,
            'timestamp': timestamp
        }

        # 限制缓存大小
        if len(self.identification_cache) > 1000:
            oldest_keys = list(self.identification_cache.keys())[:100]
            for key in oldest_keys:
                del self.identification_cache[key]

    def _record_history(self, result: Dict):
        """记录历史"""
        self.identification_history.append({
            'result': result,
            'recorded_at': datetime.now().isoformat()
        })

        # 限制历史记录大小
        if len(self.identification_history) > 500:
            self.identification_history = self.identification_history[-400:]

    def get_attack_type_info(self, attack_type: str) -> Optional[Dict]:
        """获取攻击类型信息"""
        try:
            at = AttackType(attack_type)
            for type_enum, sig_info in self.signatures.SIGNATURES.items():
                if type_enum == at:
                    return sig_info
            return {
                'severity': 5,
                'description': at.value
            }
        except ValueError:
            return None

    def batch_identify(self, attack_data_list: List[Dict]) -> List[Dict]:
        """批量识别攻击类型"""
        return [self.identify(data) for data in attack_data_list]

    def get_statistics(self) -> Dict:
        """获取识别统计信息"""
        stats = {}
        for record in self.identification_history:
            result = record['result']
            attack_type = result['attack_type']
            stats[attack_type] = stats.get(attack_type, 0) + 1

        return {
            'total_identifications': len(self.identification_history),
            'by_type': stats,
            'cache_size': len(self.identification_cache),
        }


# 独立运行测试
if __name__ == "__main__":
    # 测试攻击类型识别
    identifier = AttackTypeIdentifier()

    # SQL注入测试
    sql_injection_data = {
        'request': "GET /search?q=1' OR '1'='1 HTTP/1.1",
        'source_ip': '192.168.1.100',
        'target': '/search',
        'timestamp': datetime.now().isoformat(),
        'raw_data': ''
    }

    result = identifier.identify(sql_injection_data)
    print("SQL注入识别结果:", result)

    # XSS测试
    xss_data = {
        'request': "POST /comment <script>alert('XSS')</script>",
        'source_ip': '192.168.1.101',
        'target': '/comment',
        'timestamp': datetime.now().isoformat(),
        'raw_data': ''
    }

    result = identifier.identify(xss_data)
    print("XSS识别结果:", result)

    # 暴力破解测试
    brute_force_data = {
        'request': "POST /login username=admin&password=admin123",
        'source_ip': '192.168.1.102',
        'target': '/login',
        'timestamp': datetime.now().isoformat(),
        'raw_data': 'failed login attempt'
    }

    result = identifier.identify(brute_force_data)
    print("暴力破解识别结果:", result)

    print("\n识别统计:", identifier.get_statistics())
