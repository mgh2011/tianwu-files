"""
自我检测引擎模块
Self-Detection Engine Module

提供十大检测系统的核心功能
"""

from .self_detection_engine import (
    SelfDetectionEngine,
    DetectionType,
    SeverityLevel,
    DetectionStatus,
    DetectionResult,
    Vulnerability,
    RiskItem,
    ThreatIndicator,
    BaseDetector,
    create_self_detection_engine
)

__version__ = "v3.0.0"
__all__ = [
    'SelfDetectionEngine',
    'DetectionType',
    'SeverityLevel',
    'DetectionStatus',
    'DetectionResult',
    'Vulnerability',
    'RiskItem',
    'ThreatIndicator',
    'BaseDetector',
    'create_self_detection_engine'
]
