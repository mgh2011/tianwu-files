"""
攻击强度评估模块
Attack Intensity Assessor - 评估攻击的强度和规模
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import json


class IntensityLevel(Enum):
    """强度等级"""
    NEGLIGIBLE = (1, "可忽略")
    LOW = (2, "低")
    MEDIUM = (3, "中")
    HIGH = (4, "高")
    SEVERE = (5, "严重")
    CRITICAL = (6, "危急")

    def __init__(self, level: int, description: str):
        self.level = level
        self.description = description


@dataclass
class AttackMetrics:
    """攻击指标"""
    request_count: int = 0  # 请求数量
    request_rate: float = 0.0  # 请求速率 (req/s)
    bandwidth: float = 0.0  # 带宽消耗 (Mbps)
    connection_count: int = 0  # 并发连接数
    unique_targets: int = 0  # 攻击目标数量
    attack_duration: float = 0.0  # 攻击持续时间 (秒)
    payload_size: float = 0.0  # 载荷大小 (bytes)
    error_rate: float = 0.0  # 错误率
    success_rate: float = 0.0  # 成功率


@dataclass
class IntensityScore:
    """强度评分"""
    overall_score: float = 0.0  # 综合评分 (0-100)
    level: IntensityLevel = IntensityLevel.NEGLIGIBLE
    component_scores: Dict[str, float] = field(default_factory=dict)
    factors: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)


class AttackIntensityAssessor:
    """攻击强度评估器"""

    # 强度阈值配置
    THRESHOLDS = {
        'request_rate': {
            'low': 10,  # req/s
            'medium': 100,
            'high': 1000,
            'severe': 10000,
            'critical': 100000
        },
        'bandwidth': {
            'low': 1,  # Mbps
            'medium': 10,
            'high': 100,
            'severe': 1000,
            'critical': 10000
        },
        'connections': {
            'low': 10,
            'medium': 100,
            'high': 1000,
            'severe': 10000,
            'critical': 100000
        },
        'duration': {
            'low': 10,  # seconds
            'medium': 60,
            'high': 300,
            'severe': 3600,
            'critical': 86400
        }
    }

    # 权重配置
    WEIGHTS = {
        'request_rate': 0.25,
        'bandwidth': 0.20,
        'connections': 0.15,
        'duration': 0.15,
        'payload_size': 0.10,
        'target_count': 0.10,
        'error_rate': 0.05
    }

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化攻击强度评估器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.thresholds = self.THRESHOLDS.copy()
        self.weights = self.WEIGHTS.copy()
        self.assessment_history = []
        self.baseline_metrics = {}

    def assess(self, attack_data: Dict) -> Dict:
        """
        评估攻击强度

        Args:
            attack_data: 攻击数据，包含：
                - metrics: 攻击指标
                - type: 攻击类型
                - source_count: 攻击来源数量
                - target_info: 目标信息
                - historical_data: 历史数据

        Returns:
            评估结果，包含：
                - score: 强度评分
                - level: 强度等级
                - components: 各维度评分
                - factors: 影响因素
                - recommendations: 建议
        """
        metrics = attack_data.get('metrics', {})
        attack_type = attack_data.get('type', 'unknown')
        source_count = attack_data.get('source_count', 1)
        target_info = attack_data.get('target_info', {})
        historical_data = attack_data.get('historical_data', [])

        # 提取攻击指标
        attack_metrics = self._extract_metrics(metrics, source_count)

        # 计算各维度评分
        component_scores = self._calculate_component_scores(attack_metrics)

        # 计算综合评分
        overall_score = self._calculate_overall_score(component_scores)

        # 确定强度等级
        level = self._determine_level(overall_score)

        # 分析影响因素
        factors = self._analyze_factors(attack_metrics, attack_type)

        # 生成建议
        recommendations = self._generate_recommendations(
            overall_score, level, attack_metrics, attack_type
        )

        # 构建评估结果
        result = {
            'overall_score': overall_score,
            'level': level.description,
            'level_code': level.name,
            'component_scores': component_scores,
            'metrics': {
                'request_rate': attack_metrics.request_rate,
                'bandwidth': attack_metrics.bandwidth,
                'connections': attack_metrics.connection_count,
                'duration': attack_metrics.attack_duration,
                'payload_size': attack_metrics.payload_size,
                'unique_targets': attack_metrics.unique_targets,
                'request_count': attack_metrics.request_count,
            },
            'factors': factors,
            'recommendations': recommendations,
            'is_ddos': self._is_ddos(attack_metrics, source_count),
            'source_count': source_count,
            'attack_type': attack_type,
            'timestamp': datetime.now().isoformat()
        }

        # 更新历史记录
        self._update_history(result, attack_data)

        return result

    def _extract_metrics(self, metrics: Dict, source_count: int) -> AttackMetrics:
        """提取攻击指标"""
        return AttackMetrics(
            request_count=metrics.get('request_count', 0),
            request_rate=metrics.get('request_rate', 0.0),
            bandwidth=metrics.get('bandwidth', 0.0),
            connection_count=metrics.get('connections', 0),
            unique_targets=metrics.get('unique_targets', 0),
            attack_duration=metrics.get('duration', 0.0),
            payload_size=metrics.get('payload_size', 0.0),
            error_rate=metrics.get('error_rate', 0.0),
            success_rate=metrics.get('success_rate', 1.0)
        )

    def _calculate_component_scores(self, metrics: AttackMetrics) -> Dict[str, float]:
        """计算各维度评分"""
        scores = {}

        # 请求速率评分
        scores['request_rate'] = self._score_metric(
            metrics.request_rate,
            self.thresholds['request_rate']
        )

        # 带宽评分
        scores['bandwidth'] = self._score_metric(
            metrics.bandwidth,
            self.thresholds['bandwidth']
        )

        # 连接数评分
        scores['connections'] = self._score_metric(
            metrics.connection_count,
            self.thresholds['connections']
        )

        # 持续时间评分
        scores['duration'] = self._score_metric(
            metrics.attack_duration,
            self.thresholds['duration']
        )

        # 载荷大小评分
        scores['payload_size'] = self._score_payload_size(metrics.payload_size)

        # 目标数量评分
        scores['target_count'] = self._score_target_count(metrics.unique_targets)

        # 错误率评分（越低越危险）
        scores['error_rate'] = self._score_error_rate(metrics.error_rate)

        return scores

    def _score_metric(self, value: float, thresholds: Dict[str, int]) -> float:
        """评分指标"""
        if value <= thresholds['low']:
            return 10.0
        elif value <= thresholds['medium']:
            return 30.0
        elif value <= thresholds['high']:
            return 50.0
        elif value <= thresholds['severe']:
            return 70.0
        elif value <= thresholds['critical']:
            return 90.0
        else:
            # 超过critical阈值，指数增长
            return min(100.0, 100.0 + (value / thresholds['critical'] - 1) * 10)

    def _score_payload_size(self, size: float) -> float:
        """评分载荷大小"""
        # 正常请求通常小于10KB
        kb = size / 1024
        if kb < 10:
            return 10.0
        elif kb < 100:
            return 30.0
        elif kb < 1024:
            return 50.0
        elif kb < 10240:
            return 70.0
        else:
            return 90.0

    def _score_target_count(self, count: int) -> float:
        """评分目标数量"""
        if count <= 1:
            return 10.0
        elif count <= 5:
            return 30.0
        elif count <= 20:
            return 50.0
        elif count <= 100:
            return 70.0
        else:
            return 90.0

    def _score_error_rate(self, rate: float) -> float:
        """评分错误率（高错误率可能表示攻击失败）"""
        if rate < 0.1:
            return 90.0  # 低错误率表示攻击成功
        elif rate < 0.3:
            return 70.0
        elif rate < 0.5:
            return 50.0
        elif rate < 0.7:
            return 30.0
        else:
            return 10.0  # 高错误率表示攻击可能失败

    def _calculate_overall_score(self, component_scores: Dict[str, float]) -> float:
        """计算综合评分"""
        total_score = 0.0
        total_weight = 0.0

        for metric, weight in self.weights.items():
            if metric in component_scores:
                total_score += component_scores[metric] * weight
                total_weight += weight

        if total_weight > 0:
            return round(total_score / total_weight, 2)
        return 0.0

    def _determine_level(self, score: float) -> IntensityLevel:
        """确定强度等级"""
        if score < 20:
            return IntensityLevel.NEGLIGIBLE
        elif score < 40:
            return IntensityLevel.LOW
        elif score < 55:
            return IntensityLevel.MEDIUM
        elif score < 70:
            return IntensityLevel.HIGH
        elif score < 85:
            return IntensityLevel.SEVERE
        else:
            return IntensityLevel.CRITICAL

    def _analyze_factors(self, metrics: AttackMetrics, attack_type: str) -> List[str]:
        """分析影响因素"""
        factors = []

        # 分析请求速率
        if metrics.request_rate > 1000:
            factors.append(f"异常请求速率: {metrics.request_rate:.0f} req/s")
        elif metrics.request_rate > 100:
            factors.append(f"较高请求速率: {metrics.request_rate:.0f} req/s")

        # 分析带宽
        if metrics.bandwidth > 1000:
            factors.append(f"大量带宽消耗: {metrics.bandwidth:.0f} Mbps")
        elif metrics.bandwidth > 100:
            factors.append(f"中等带宽消耗: {metrics.bandwidth:.0f} Mbps")

        # 分析连接数
        if metrics.connection_count > 1000:
            factors.append(f"高并发连接: {metrics.connection_count}")

        # 分析持续时间
        if metrics.attack_duration > 3600:
            factors.append(f"长时间攻击: {metrics.attack_duration/3600:.1f}小时")
        elif metrics.attack_duration > 300:
            factors.append(f"中等持续时间: {metrics.attack_duration/60:.1f}分钟")

        # 分析载荷
        if metrics.payload_size > 1024 * 1024:
            factors.append(f"大载荷攻击: {metrics.payload_size/1024/1024:.1f} MB")

        # 分析目标
        if metrics.unique_targets > 10:
            factors.append(f"多目标攻击: {metrics.unique_targets}个目标")

        # 分析攻击类型特征
        type_specific = self._analyze_type_specific(attack_type, metrics)
        factors.extend(type_specific)

        return factors

    def _analyze_type_specific(self, attack_type: str, metrics: AttackMetrics) -> List[str]:
        """分析特定攻击类型"""
        factors = []

        if attack_type in ['syn_flood', 'udp_flood', 'http_flood']:
            if metrics.request_rate > 10000:
                factors.append("典型DDoS攻击特征")
            if metrics.error_rate < 0.1:
                factors.append("攻击效率高")

        elif attack_type in ['sql_injection', 'xss', 'command_injection']:
            if metrics.payload_size > 1024:
                factors.append("恶意载荷较大")
            if "'" in str(metrics.payload_size) or "<script>" in str(metrics.payload_size):
                factors.append("包含恶意payload特征")

        elif attack_type == 'brute_force':
            if metrics.request_count > 100:
                factors.append("暴力破解尝试频繁")

        return factors

    def _generate_recommendations(self, score: float, level: IntensityLevel,
                                  metrics: AttackMetrics, attack_type: str) -> List[str]:
        """生成建议"""
        recommendations = []

        # 基于评分的建议
        if score >= 85:
            recommendations.append("启动紧急响应预案")
            recommendations.append("立即联系ISP进行流量清洗")
            recommendations.append("启用所有可用的防御措施")
        elif score >= 70:
            recommendations.append("启动高级防御机制")
            recommendations.append("扩大带宽容量")
            recommendations.append("启用流量限制")
        elif score >= 55:
            recommendations.append("加强监控频率")
            recommendations.append("准备备用资源")
        else:
            recommendations.append("持续监控当前状态")

        # 基于指标的建议
        if metrics.bandwidth > 1000:
            recommendations.append("考虑启用CDN或DDoS防护服务")

        if metrics.request_rate > 10000:
            recommendations.append("启用请求速率限制")

        if metrics.connection_count > 5000:
            recommendations.append("限制并发连接数")

        # 基于攻击类型的建议
        type_recommendations = {
            'syn_flood': "启用SYN Cookie或SYN Proxy",
            'udp_flood': "过滤UDP流量或限制UDP带宽",
            'http_flood': "启用挑战响应机制或CAPTCHA",
            'sql_injection': "启用WAF规则并检查输入验证",
            'xss': "启用内容安全策略(CSP)",
            'brute_force': "启用账户锁定和IP封禁",
        }

        if attack_type in type_recommendations:
            recommendations.append(type_recommendations[attack_type])

        return recommendations

    def _is_ddos(self, metrics: AttackMetrics, source_count: int) -> bool:
        """判断是否为DDoS攻击"""
        # 多源+高请求速率
        if source_count > 10 and metrics.request_rate > 100:
            return True

        # 大量带宽消耗
        if metrics.bandwidth > 1000:
            return True

        # 大量并发连接
        if metrics.connection_count > 5000:
            return True

        return False

    def _update_history(self, result: Dict, attack_data: Dict):
        """更新历史记录"""
        self.assessment_history.append({
            'result': result,
            'attack_data': attack_data,
            'timestamp': datetime.now().isoformat()
        })

        # 限制历史大小
        if len(self.assessment_history) > 1000:
            self.assessment_history = self.assessment_history[-800:]

    def get_baseline(self) -> Dict:
        """获取基准指标"""
        if not self.baseline_metrics:
            return {
                'request_rate': 10,
                'bandwidth': 1,
                'connections': 10,
                'duration': 10
            }
        return self.baseline_metrics.copy()

    def update_baseline(self, metrics: Dict):
        """更新基准指标"""
        self.baseline_metrics.update(metrics)

    def compare_with_baseline(self, current_metrics: Dict) -> Dict:
        """与基准比较"""
        baseline = self.get_baseline()
        comparison = {}

        for key in baseline:
            if key in current_metrics:
                current = current_metrics[key]
                base = baseline[key]
                if base > 0:
                    ratio = current / base
                    comparison[key] = {
                        'current': current,
                        'baseline': base,
                        'ratio': round(ratio, 2),
                        'increase': ratio > 1.5  # 超过基准50%视为异常
                    }

        return comparison


# 独立运行测试
if __name__ == "__main__":
    assessor = AttackIntensityAssessor()

    # 测试普通攻击
    attack_data = {
        'type': 'http_flood',
        'source_count': 100,
        'metrics': {
            'request_rate': 5000,
            'bandwidth': 500,
            'connections': 2000,
            'duration': 600,
            'payload_size': 1024 * 50,
            'unique_targets': 5,
            'request_count': 3000000,
        },
        'target_info': {'service': 'web_server'},
        'historical_data': []
    }

    result = assessor.assess(attack_data)
    print("攻击强度评估结果:")
    print(json.dumps(result, indent=2, ensure_ascii=False))

    # 测试轻微异常
    light_attack = {
        'type': 'port_scan',
        'source_count': 1,
        'metrics': {
            'request_rate': 50,
            'bandwidth': 0.5,
            'connections': 5,
            'duration': 30,
            'payload_size': 64,
            'unique_targets': 100,
            'request_count': 1500,
        },
        'target_info': {},
        'historical_data': []
    }

    result = assessor.assess(light_attack)
    print("\n轻微异常评估结果:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
