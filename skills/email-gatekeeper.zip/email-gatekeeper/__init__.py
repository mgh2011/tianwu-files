# ========== 邮件安全守门员 v3.0 ==========

"""
企业级邮件安全守门员
版本: v3.0.0 企业级超级版

模块列表:
- email_gatekeeper_core: 核心引擎（含钓鱼检测修复）
- security_modules: 企业安全模块（加密、备份、扫描、自检）
- offense_defense: 反击与联动系统
- api_server: REST API服务
- tests: 测试套件
"""

__version__ = "3.0.0"
__author__ = "Email Security Team"
__description__ = "企业级邮件安全守门员"

from .scripts.email_gatekeeper_core import EmailSecurityGatekeeper, Email, DetectionResult
from .scripts.security_modules import SecuritySelfCheck, DataEncryption, BackupManager
from .scripts.offense_defense import UnifiedDefenseManager

__all__ = [
    "EmailSecurityGatekeeper",
    "Email",
    "DetectionResult",
    "SecuritySelfCheck",
    "DataEncryption",
    "BackupManager",
    "UnifiedDefenseManager"
]
