"""
兼容引擎模块
Compatibility Engine Module

提供多平台、多协议、多接口的兼容性支持
"""

from .compatibility_engine import (
    CompatibilityEngine,
    PlatformType,
    ProtocolType,
    DatabaseType,
    create_compatibility_engine
)

__version__ = "v3.0.0"
__all__ = [
    'CompatibilityEngine',
    'PlatformType',
    'ProtocolType',
    'DatabaseType',
    'create_compatibility_engine'
]
