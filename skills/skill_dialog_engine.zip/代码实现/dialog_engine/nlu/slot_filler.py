# dialog_engine/nlu/slot_filler.py
"""
槽位填充器
管理对话所需的槽位状态
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable

from ..models.data_models import (
    Slot, SlotType, SlotStatus, SlotFillingResult,
    IntentResult, Entity, EntityType, DialogContext
)
from ..config.default_config import config


logger = logging.getLogger(__name__)


class SlotFiller:
    """
    槽位填充管理器
    管理对话所需的槽位状态
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        self.config = config_dict or config.SLOT_FILLER
        self.auto_fill_threshold = self.config.get("auto_fill_threshold", 0.8)
        self.confirm_threshold = self.config.get("confirm_threshold", 0.6)
        self.max_fill_attempts = self.config.get("max_fill_attempts", 3)
        self.enable_carryover = self.config.get("enable_slot_carryover", True)
        self.slot_expiration = self.config.get("slot_expiration", 3600)
        self.common_slots = self.config.get("common_slots", {})
        
        # 意图-槽位映射
        self.intent_slot_mapping = self._build_intent_slot_mapping()
        
        # 验证器
        self.validators: Dict[str, Callable] = {}
        self._register_default_validators()
        
    def _build_intent_slot_mapping(self) -> Dict[str, List[Dict]]:
        """构建意图-槽位映射"""
        return {
            "booking": [
                {"name": "service_type", "type": SlotType.REQUIRED, "prompt": "请问您想预约什么服务？"},
                {"name": "date", "type": SlotType.REQUIRED, "prompt": "请问预约哪一天？"},
                {"name": "time", "type": SlotType.REQUIRED, "prompt": "请问预约几点？"},
                {"name": "location", "type": SlotType.OPTIONAL, "prompt": "请问在哪个地点？"},
                {"name": "contact", "type": SlotType.REQUIRED, "prompt": "请留下您的联系方式"},
            ],
            "query": [
                {"name": "query_type", "type": SlotType.REQUIRED, "prompt": "请问您想查询什么？"},
                {"name": "keywords", "type": SlotType.OPTIONAL, "prompt": "还有什么关键词？"},
            ],
            "payment": [
                {"name": "amount", "type": SlotType.REQUIRED, "prompt": "请问支付金额是多少？"},
                {"name": "payment_method", "type": SlotType.OPTIONAL, "prompt": "请问使用什么支付方式？"},
            ],
            "refund": [
                {"name": "order_id", "type": SlotType.REQUIRED, "prompt": "请提供订单号"},
                {"name": "reason", "type": SlotType.OPTIONAL, "prompt": "请问退款原因是什么？"},
            ],
        }
    
    def _register_default_validators(self):
        """注册默认验证器"""
        self.validators["phone"] = self._validate_phone
        self.validators["email"] = self._validate_email
        self.validators["date"] = self._validate_date
        self.validators["time"] = self._validate_time
        self.validators["number"] = self._validate_number
        self.validators["money"] = self._validate_money
    
    async def fill_slots(self, intent_result: IntentResult,
                        entities: List[Entity],
                        context: Optional[DialogContext] = None) -> SlotFillingResult:
        """
        槽位填充
        
        Args:
            intent_result: 意图识别结果
            entities: 实体列表
            context: 对话上下文
            
        Returns:
            SlotFillingResult: 槽位填充结果
        """
        intent_name = intent_result.intent.value if intent_result else "unknown"
        
        # 获取该意图需要的槽位定义
        required_slots = self._get_required_slots(intent_name)
        
        # 初始化槽位
        slots = self._initialize_slots(required_slots)
        
        # 从上下文中继承槽位
        if context and self.enable_carryover:
            slots = self._carryover_slots(slots, context)
        
        # 用实体填充槽位
        slots = self._fill_from_entities(slots, entities)
        
        # 检查是否完成
        is_complete, missing_slots, prompting_slot = self._check_completeness(slots)
        
        return SlotFillingResult(
            is_complete=is_complete,
            filled_slots=slots,
            missing_slots=missing_slots,
            invalid_slots=[],
            prompting_slot=prompting_slot
        )
    
    def _get_required_slots(self, intent_name: str) -> List[Dict]:
        """获取意图需要的槽位"""
        # 先检查特定意图
        if intent_name in self.intent_slot_mapping:
            return self.intent_slot_mapping[intent_name]
        
        # 检查通用槽位
        if intent_name in self.common_slots:
            return [self.common_slots[intent_name]]
        
        return []
    
    def _initialize_slots(self, slot_definitions: List[Dict]) -> Dict[str, Slot]:
        """初始化槽位"""
        slots = {}
        
        for slot_def in slot_definitions:
            slot_name = slot_def["name"]
            slot = Slot(
                name=slot_name,
                type=SlotType(slot_def.get("type", "optional")),
                prompt_template=slot_def.get("prompt"),
                default_value=slot_def.get("default")
            )
            
            # 设置默认值
            if slot_def.get("default"):
                slot.value = slot_def["default"]
                slot.status = SlotStatus.FILLED
            
            slots[slot_name] = slot
        
        return slots
    
    def _carryover_slots(self, slots: Dict[str, Slot],
                        context: DialogContext) -> Dict[str, Slot]:
        """从上下文继承槽位"""
        context_slots = context.slots
        
        for slot_name, slot in slots.items():
            if slot_name in context_slots:
                context_slot = context_slots[slot_name]
                
                # 检查是否过期
                if context_slot.filled_at:
                    age = (datetime.now() - context_slot.filled_at).total_seconds()
                    if age < self.slot_expiration:
                        # 未过期，继承
                        slot.value = context_slot.value
                        slot.status = SlotStatus.FILLED
                        slot.confidence = context_slot.confidence
                        slot.source = "carryover"
                        logger.debug(f"Carried over slot: {slot_name}")
        
        return slots
    
    def _fill_from_entities(self, slots: Dict[str, Slot],
                           entities: List[Entity]) -> Dict[str, Slot]:
        """用实体填充槽位"""
        entity_type_to_slot = {
            EntityType.PHONE: "phone",
            EntityType.EMAIL: "email",
            EntityType.DATE: "date",
            EntityType.TIME: "time",
            EntityType.NUMBER: "number",
            EntityType.MONEY: "amount",
            EntityType.LOCATION: "location",
            EntityType.PERSON: "name",
        }
        
        for entity in entities:
            slot_name = entity_type_to_slot.get(entity.type)
            
            if slot_name and slot_name in slots:
                slot = slots[slot_name]
                
                # 检查是否已有值
                if slot.status != SlotStatus.FILLED or slot.confidence < entity.confidence:
                    slot.value = entity.normalized_value or entity.value
                    slot.status = SlotStatus.FILLED
                    slot.confidence = entity.confidence
                    slot.source = "entity"
                    slot.filled_at = datetime.now()
                    logger.debug(f"Filled slot {slot_name} from entity: {entity.value}")
        
        return slots
    
    def _check_completeness(self, slots: Dict[str, Slot]) -> tuple:
        """
        检查槽位完整性
        
        Returns:
            (is_complete, missing_slots, prompting_slot)
        """
        missing = []
        prompting = None
        
        # 按优先级排序槽位
        sorted_slots = sorted(
            slots.items(),
            key=lambda x: (
                0 if x[1].type == SlotType.REQUIRED else 1,
                -x[1].confidence if x[1].status == SlotStatus.FILLED else 0
            )
        )
        
        for slot_name, slot in sorted_slots:
            if slot.status != SlotStatus.FILLED:
                if slot.type == SlotType.REQUIRED:
                    missing.append(slot_name)
                    if prompting is None:
                        prompting = slot_name
        
        is_complete = len(missing) == 0
        
        return is_complete, missing, prompting
    
    async def validate_slot(self, slot_name: str, value: Any) -> bool:
        """验证槽位值"""
        validator = self.validators.get(slot_name)
        
        if validator:
            return await validator(value)
        
        # 默认验证：非空
        return value is not None and value != ""
    
    async def confirm_slot(self, slot_name: str, value: Any,
                          context: Optional[DialogContext] = None) -> SlotFillingResult:
        """确认槽位值"""
        # 验证
        is_valid = await self.validate_slot(slot_name, value)
        
        if context and slot_name in context.slots:
            slot = context.slots[slot_name]
        else:
            slot = Slot(name=slot_name, type=SlotType.REQUIRED)
        
        if is_valid:
            slot.value = value
            slot.status = SlotStatus.VALIDATED
            slot.filled_at = datetime.now()
            slot.confidence = self.confirm_threshold
            slot.source = "user_confirmed"
        else:
            slot.status = SlotStatus.INVALID
        
        # 更新上下文
        if context:
            context.slots[slot_name] = slot
        
        # 重新检查完整性
        is_complete, missing, prompting = self._check_completeness(context.slots if context else {slot_name: slot})
        
        return SlotFillingResult(
            is_complete=is_complete,
            filled_slots={slot_name: slot},
            missing_slots=missing,
            invalid_slots=[] if is_valid else [slot_name],
            prompting_slot=prompting
        )
    
    def get_missing_slots(self, context: DialogContext) -> List[Slot]:
        """获取缺失的槽位列表"""
        missing = []
        
        for slot_name, slot in context.slots.items():
            if slot.status != SlotStatus.FILLED:
                missing.append(slot)
        
        # 按类型排序(必填优先)
        return sorted(missing, key=lambda s: 0 if s.type == SlotType.REQUIRED else 1)
    
    def get_slot_prompt(self, slot: Slot) -> str:
        """获取槽位提示"""
        if slot.prompt_template:
            return slot.prompt_template
        
        prompts = {
            "phone": "请输入您的电话号码",
            "email": "请输入您的邮箱地址",
            "date": "请选择日期",
            "time": "请选择时间",
            "location": "请输入地点",
            "name": "请输入您的姓名",
        }
        
        return prompts.get(slot.name, f"请提供{slot.name}")
    
    def _validate_phone(self, value: str) -> bool:
        """验证手机号"""
        import re
        pattern = r"1[3-9]\d{9}$"
        return bool(re.match(pattern, str(value)))
    
    def _validate_email(self, value: str) -> bool:
        """验证邮箱"""
        import re
        pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        return bool(re.match(pattern, str(value)))
    
    def _validate_date(self, value: str) -> bool:
        """验证日期"""
        import re
        patterns = [
            r"\d{4}-\d{2}-\d{2}",
            r"\d{4}/\d{2}/\d{2}",
            r"今天|明天|后天|昨天"
        ]
        return any(re.search(p, str(value)) for p in patterns)
    
    def _validate_time(self, value: str) -> bool:
        """验证时间"""
        import re
        pattern = r"\d{1,2}:\d{2}"
        return bool(re.search(pattern, str(value)))
    
    def _validate_number(self, value: Any) -> bool:
        """验证数字"""
        try:
            float(value)
            return True
        except (ValueError, TypeError):
            return False
    
    def _validate_money(self, value: str) -> bool:
        """验证金额"""
        import re
        pattern = r"\d+(?:\.\d{1,2})?"
        return bool(re.search(pattern, str(value)))
    
    def register_validator(self, slot_name: str, validator: Callable):
        """注册验证器"""
        self.validators[slot_name] = validator
    
    def add_slot_definition(self, intent: str, slot_def: Dict):
        """添加槽位定义"""
        if intent not in self.intent_slot_mapping:
            self.intent_slot_mapping[intent] = []
        self.intent_slot_mapping[intent].append(slot_def)
        logger.info(f"Added slot definition for intent: {intent}")
