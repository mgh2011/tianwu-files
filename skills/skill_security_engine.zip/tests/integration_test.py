"""
企业级综合安全引擎 - 集成测试
Integration Tests
"""

import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def test_core_engine():
    """测试核心引擎"""
    print("\n" + "=" * 60)
    print("测试: 核心引擎")
    print("=" * 60)
    
    try:
        from core.engine import SecurityEngineCore
        
        engine = SecurityEngineCore()
        print(f"✓ 引擎初始化成功")
        print(f"✓ 模块数量: {len(engine.get_all_modules())}")
        
        # 测试邮件检查
        result = engine.check({
            'type': 'email',
            'from': 'test@example.com',
            'subject': '测试邮件',
            'body': '这是一封正常的测试邮件'
        })
        
        print(f"✓ 安全检查完成")
        print(f"  - 威胁等级: {result.threat_level}")
        print(f"  - 处理动作: {result.action}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {e}")
        return False


def test_phishing_detector():
    """测试钓鱼检测"""
    print("\n" + "=" * 60)
    print("测试: 钓鱼邮件检测")
    print("=" * 60)
    
    try:
        from mail_management.phishing_detector import PhishingDetector
        
        detector = PhishingDetector(None, None)
        print(f"✓ 钓鱼检测器初始化成功")
        
        test_cases = [
            {
                'name': '钓鱼邮件',
                'from': 'security@paypa1.com',
                'subject': '【紧急】您的账户存在风险',
                'body': '请立即点击链接验证您的账户信息'
            },
            {
                'name': '正常邮件',
                'from': 'colleague@company.com',
                'subject': '会议通知',
                'body': '明天下午3点有产品评审会议'
            }
        ]
        
        for test in test_cases:
            result = detector.check(test)
            print(f"\n✓ {test['name']}:")
            print(f"  - 钓鱼检测: {'是' if result['is_phishing'] else '否'}")
            print(f"  - 威胁分数: {result['threat_score']:.2%}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {e}")
        return False


def test_spam_filter():
    """测试垃圾邮件过滤"""
    print("\n" + "=" * 60)
    print("测试: 垃圾邮件过滤")
    print("=" * 60)
    
    try:
        from mail_management.spam_filter import SpamFilter
        
        filter = SpamFilter(None, None)
        print(f"✓ 垃圾邮件过滤器初始化成功")
        
        result = filter.check({
            'subject': '【限时优惠】免费领取iphone！',
            'body': '点击立即领取，不容错过！名额有限，马上行动！'
        })
        
        print(f"✓ 垃圾邮件: {'是' if result['is_spam'] else '否'}")
        print(f"  - 威胁分数: {result['threat_score']:.2%}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {e}")
        return False


def test_self_detection():
    """测试自我检测引擎"""
    print("\n" + "=" * 60)
    print("测试: 自我检测引擎")
    print("=" * 60)
    
    try:
        from self_detection.self_detection_engine import create_self_detection_engine
        
        engine = create_self_detection_engine()
        print(f"✓ 自我检测引擎初始化成功")
        
        # 执行检测
        result = engine.full_scan('all', [
            {
                'type': 'web',
                'url': 'https://example.com',
                'sqli_vulnerable': True,
                'xss_vulnerable': True
            }
        ])
        
        print(f"✓ 检测完成:")
        print(f"  - 发现问题: {len(result.findings)}项")
        print(f"  - 风险评分: {result.risk_score:.2%}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_protection_modules():
    """测试防护模块"""
    print("\n" + "=" * 60)
    print("测试: 防护模块")
    print("=" * 60)
    
    try:
        from protection_system.boundary.firewall import FirewallModule
        from protection_system.network.ids import IDSModule
        from protection_system.boundary.waf import WAFModule
        
        # 防火墙测试
        fw = FirewallModule(None, None)
        result = fw.check({'source_ip': '10.0.0.1', 'port': 445})
        print(f"✓ 防火墙检测: {'拦截' if result['blocked'] else '放行'}")
        
        # IDS测试
        ids = IDSModule(None, None)
        result = ids.check({'data': "admin' OR 1=1--", 'source_ip': '192.168.1.1'})
        print(f"✓ IDS检测: {'发现攻击' if result['detected'] else '正常'}")
        
        # WAF测试
        waf = WAFModule(None, None)
        result = waf.check({'url': '/search', 'params': {'q': "admin' OR 1=1--"}})
        print(f"✓ WAF检测: {'发现攻击' if result['detected'] else '正常'}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {e}")
        return False


def test_compatibility_engine():
    """测试兼容引擎"""
    print("\n" + "=" * 60)
    print("测试: 兼容引擎")
    print("=" * 60)
    
    try:
        from compatibility_engine.compatibility_engine import CompatibilityEngine
        
        engine = CompatibilityEngine(None, None)
        print(f"✓ 兼容引擎初始化成功")
        
        # 测试数据格式转换
        result = engine.data.convert_format({'name': '测试'}, 'json', 'xml')
        print(f"✓ 数据格式转换: {'成功' if result.success else '失败'}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {e}")
        return False


def test_linkage_engine():
    """测试联动引擎"""
    print("\n" + "=" * 60)
    print("测试: 联动引擎")
    print("=" * 60)
    
    try:
        from linkage_engine.linkage_engine import LinkageEngine, EventType, LinkageEvent
        
        engine = LinkageEngine(None, None)
        print(f"✓ 联动引擎初始化成功")
        
        # 测试事件发布
        event = LinkageEvent(
            event_type=EventType.SECURITY_ALERT,
            source='firewall',
            data={'alert': '检测到威胁'}
        )
        engine.event_bus.publish(event)
        print(f"✓ 事件发布: 成功")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {e}")
        return False


def run_all_tests():
    """运行所有测试"""
    print("\n" + "=" * 80)
    print("企业级综合安全引擎 v3.0.0 - 集成测试")
    print("=" * 80)
    
    tests = [
        ("核心引擎", test_core_engine),
        ("钓鱼检测", test_phishing_detector),
        ("垃圾邮件过滤", test_spam_filter),
        ("防护模块", test_protection_modules),
        ("自我检测", test_self_detection),
        ("兼容引擎", test_compatibility_engine),
        ("联动引擎", test_linkage_engine),
    ]
    
    results = []
    
    for name, test_func in tests:
        try:
            passed = test_func()
            results.append((name, passed))
        except Exception as e:
            print(f"\n✗ {name}测试异常: {e}")
            results.append((name, False))
    
    # 汇总结果
    print("\n" + "=" * 80)
    print("测试结果汇总")
    print("=" * 80)
    
    passed_count = sum(1 for _, passed in results if passed)
    total_count = len(results)
    
    for name, passed in results:
        status = "✓ 通过" if passed else "✗ 失败"
        print(f"  {status}: {name}")
    
    print(f"\n总计: {passed_count}/{total_count} 通过")
    print("=" * 80)
    
    return passed_count == total_count


if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
