"""
授权管理模块
Authorization Module

提供反击授权管理功能
"""

from .counterattack_authorization import CounterattackAuthorization

__version__ = "v3.0.0"
__all__ = [
    'CounterattackAuthorization'
]
