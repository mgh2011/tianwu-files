# ========== 测试套件 v3.0.4 ==========
# 文件: scripts/tests.py
# 版本: 3.0.4
# 优化: 版本统一、测试用例完善、边界测试增强

"""
邮件安全守门员测试套件
包含: 单元测试、集成测试、性能测试
"""

import unittest
import asyncio
import os
import sys
from datetime import datetime
from typing import List, Dict

# 添加脚本路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ========== 单元测试 ==========

class TestPhishingDetector(unittest.TestCase):
    """钓鱼检测器测试"""
    
    @classmethod
    def setUpClass(cls):
        """测试前准备"""
        from scripts.email_gatekeeper_core import PhishingDetector
        cls.detector = PhishingDetector()
    
    def test_paypa1_homograph_detection(self):
        """测试: paypa1.com 冒充 paypal 同形字攻击检测"""
        domain = "paypa1.com"  # 数字1冒充字母l
        result = self.detector._check_domain_spoofing(
            type('obj', (object,), {'sender_domain': domain})()
        )
        
        self.assertTrue(result['is_spoofed'], "应该检测到paypa1同形字攻击")
        self.assertGreaterEqual(result['confidence'], 80, "置信度应该>=80")
    
    def test_bank0fchina_homograph_detection(self):
        """测试: bank0fchina.com 冒充 bank-of-china"""
        domain = "bank0fchina.com"  # 数字0冒充字母o
        result = self.detector._check_domain_spoofing(
            type('obj', (object,), {'sender_domain': domain})()
        )
        
        self.assertTrue(result['is_spoofed'], "应该检测到bank0fchina同形字攻击")
    
    def test_legitimate_domain(self):
        """测试: 正常域名应该通过"""
        domain = "paypal.com"
        result = self.detector._check_domain_spoofing(
            type('obj', (object,), {'sender_domain': domain})()
        )
        
        self.assertFalse(result['is_spoofed'], "正常域名不应该被标记")
    
    def test_suspicious_tld(self):
        """测试: 可疑TLD检测"""
        domain = "paypal.xyz"
        result = self.detector._check_domain_spoofing(
            type('obj', (object,), {'sender_domain': domain})()
        )
        
        # 可疑TLD应该增加置信度
        self.assertGreater(result['confidence'], 0, "可疑TLD应该增加风险")


class TestAttackPatternDetector(unittest.TestCase):
    """攻击模式检测器测试"""
    
    @classmethod
    def setUpClass(cls):
        from scripts.email_gatekeeper_core import AttackPatternDetector, Email
        cls.detector = AttackPatternDetector()
        cls.Email = Email
    
    def test_phishing_email_detection(self):
        """测试: 钓鱼邮件检测"""
        email = self.Email(
            message_id="test_001",
            sender="security@paypa1.com",
            recipients=["user@example.com"],
            subject="【紧急】您的账户已被锁定",
            body="请立即点击链接验证您的身份，否则账户将被冻结！"
        )
        
        phishing_result = self.detector.phishing_detector.detect_phishing(email)
        
        self.assertTrue(phishing_result['is_phishing'], "应该检测为钓鱼邮件")
        self.assertGreaterEqual(phishing_result['confidence'], 40, "置信度应该>=40")
    
    def test_urgent_pressure_detection(self):
        """测试: 紧急施压检测"""
        email = self.Email(
            message_id="test_002",
            sender="support@legitimate.com",
            recipients=["user@example.com"],
            subject="紧急通知",
            body="您的账户将在24小时内被冻结，请立即处理！"
        )
        
        score, rules, features, _ = self.detector.detect(email)
        
        self.assertGreater(score, 0, "应该检测到紧急施压")
        self.assertTrue(any('urgent' in r.lower() for r in rules), "应该触发紧急施压规则")
    
    def test_credential_request_detection(self):
        """测试: 权限索取检测"""
        email = self.Email(
            message_id="test_003",
            sender="bank@secure.com",
            recipients=["user@example.com"],
            subject="验证您的密码",
            body="请提供您的密码和验证码以验证身份"
        )
        
        score, rules, features, _ = self.detector.detect(email)
        
        self.assertGreater(score, 0, "应该检测到权限索取")
        self.assertTrue(any('credential' in r.lower() for r in rules), "应该触发权限索取规则")


class TestSenderTrustScorer(unittest.TestCase):
    """发件人信任度评分器测试"""
    
    @classmethod
    def setUpClass(cls):
        from scripts.email_gatekeeper_core import SenderTrustScorer, Email
        cls.scorer = SenderTrustScorer(
            whitelist=["trusted@example.com"],
            blacklist=["blocked@spam.com"]
        )
        cls.Email = Email
    
    def test_whitelist_trust(self):
        """测试: 白名单发件人"""
        email = self.Email(
            message_id="test_001",
            sender="trusted@example.com",
            recipients=["user@example.com"],
            subject="Test",
            body="Test body"
        )
        
        score, rating, details = self.scorer.calculate_trust_score(email)
        
        self.assertEqual(score, 100, "白名单发件人应该得100分")
        self.assertEqual(rating, "极高", "评级应该是极高")
    
    def test_blacklist_trust(self):
        """测试: 黑名单发件人"""
        email = self.Email(
            message_id="test_002",
            sender="blocked@spam.com",
            recipients=["user@example.com"],
            subject="Test",
            body="Test body"
        )
        
        score, rating, details = self.scorer.calculate_trust_score(email)
        
        self.assertEqual(score, 0, "黑名单发件人应该得0分")
        self.assertEqual(rating, "极低", "评级应该是极低")
    
    def test_unknown_sender(self):
        """测试: 未知发件人"""
        email = self.Email(
            message_id="test_003",
            sender="unknown@unknown.com",
            recipients=["user@example.com"],
            subject="Test",
            body="Test body"
        )
        
        score, rating, details = self.scorer.calculate_trust_score(email)
        
        self.assertGreater(score, 0, "未知发件人应该有一些基础分")
        self.assertLess(score, 100, "未知发件人不应该得满分")


class TestEmailSecurityGatekeeper(unittest.TestCase):
    """邮件安全守门员主类测试"""
    
    @classmethod
    def setUpClass(cls):
        from scripts.email_gatekeeper_core import EmailSecurityGatekeeper, Email
        cls.gatekeeper = EmailSecurityGatekeeper(
            whitelist=["trusted@example.com"],
            blacklist=["blocked@spam.com"]
        )
        cls.Email = Email
    
    @pytest.mark.asyncio
    async def test_phishing_email_full_analysis(self):
        """测试: 钓鱼邮件完整分析"""
        email = self.Email(
            message_id="test_phishing_001",
            sender="security@paypa1.com",
            recipients=["user@example.com"],
            subject="【紧急】您的PayPal账户已被锁定",
            body="""
            Dear Customer,
            
            Your PayPal account has been limited.
            Please verify your identity immediately.
            
            Click here to verify: http://paypa1-secure.com/verify
            
            Sincerely,
            PayPal Security Team
            """
        )
        
        result, status = await self.gatekeeper.process_email(email)
        
        # 验证结果
        self.assertGreaterEqual(result.risk_score, 50, "钓鱼邮件风险分应该>=50")
        self.assertTrue(result.phishing_check.get('is_phishing'), "应该检测为钓鱼")
        self.assertGreater(result.confidence, 0.5, "置信度应该>50%")
        
        # 验证处理动作
        self.assertIn(status, ["已隔离", "已删除并加入黑名单"], "应该隔离或删除钓鱼邮件")
    
    @pytest.mark.asyncio
    async def test_normal_email_full_analysis(self):
        """测试: 正常邮件完整分析"""
        email = self.Email(
            message_id="test_normal_001",
            sender="newsletter@amazon.com",
            recipients=["user@example.com"],
            subject="您的订单已发货",
            body="您好，您的订单已于今日发货，请注意查收。"
        )
        
        result, status = await self.gatekeeper.process_email(email)
        
        # 验证结果
        self.assertLess(result.risk_score, 30, "正常邮件风险分应该<30")
        self.assertFalse(result.phishing_check.get('is_phishing'), "正常邮件不应该被标记为钓鱼")
        
        # 验证处理动作
        self.assertEqual(status, "已放行", "正常邮件应该直接放行")


class TestSecurityModules(unittest.TestCase):
    """安全模块测试"""
    
    def test_encryption(self):
        """测试: 加密模块"""
        from scripts.security_modules import DataEncryption
        
        encryptor = DataEncryption()
        
        test_data = "这是一段机密信息"
        
        encrypted = encryptor.encrypt(test_data)
        self.assertIn("encrypted_data", encrypted, "加密结果应包含encrypted_data字段")
        
        decrypted = encryptor.decrypt(encrypted)
        self.assertEqual(decrypted.decode(), test_data, "解密后应得到原始数据")
    
    def test_data_hash(self):
        """测试: 数据哈希"""
        from scripts.security_modules import DataEncryption
        
        encryptor = DataEncryption()
        
        data = "test data"
        hash1 = encryptor.hash_data(data)
        hash2 = encryptor.hash_data(data)
        
        self.assertEqual(hash1, hash2, "相同数据应产生相同哈希")
        
        hash3 = encryptor.hash_data(data + "x")
        self.assertNotEqual(hash1, hash3, "不同数据应产生不同哈希")


class TestSecuritySelfCheck(unittest.TestCase):
    """安全自检测试"""
    
    def test_run_self_check(self):
        """测试: 运行安全自检"""
        from scripts.security_modules import SecuritySelfCheck
        
        checker = SecuritySelfCheck()
        report = checker.run_all_checks()
        
        self.assertIn("summary", report, "报告应包含摘要")
        self.assertIn("checks", report, "报告应包含检查项")
        self.assertIn("passed", report["summary"], "摘要应包含通过数")
        self.assertIn("failed", report["summary"], "摘要应包含失败数")


# ========== 集成测试 ==========

class TestIntegration(unittest.TestCase):
    """集成测试"""
    
    @pytest.mark.asyncio
    async def test_full_email_processing_flow(self):
        """测试: 完整邮件处理流程"""
        from scripts.email_gatekeeper_core import EmailSecurityGatekeeper, Email
        
        gatekeeper = EmailSecurityGatekeeper()
        
        # 测试用例
        test_cases = [
            {
                "name": "paypa1钓鱼",
                "email": Email(
                    message_id="int_001",
                    sender="security@paypa1.com",
                    recipients=["user@example.com"],
                    subject="紧急：账户验证",
                    body="请立即验证您的PayPal账户..."
                ),
                "expected_phishing": True
            },
            {
                "name": "正常企业邮件",
                "email": Email(
                    message_id="int_002",
                    sender="support@microsoft.com",
                    recipients=["user@example.com"],
                    subject="欢迎使用Office 365",
                    body="感谢您使用我们的服务。"
                ),
                "expected_phishing": False
            }
        ]
        
        for case in test_cases:
            result, _ = await gatekeeper.process_email(case["email"])
            
            actual_phishing = result.phishing_check.get("is_phishing", False)
            
            self.assertEqual(
                actual_phishing, 
                case["expected_phishing"],
                f"测试用例 '{case['name']}' 失败: 期望钓鱼={case['expected_phishing']}, 实际={actual_phishing}"
            )


# ========== pytest配置 ==========

try:
    import pytest
    
    # pytest配置
    def pytest_configure(config):
        config.addinivalue_line("markers", "asyncio: mark test as asyncio test")
    
    # 跳过asyncio测试如果不支持
    pytestmark = pytest.mark.asyncio
    
except ImportError:
    # 如果没有pytest，使用替代方案
    pass


# ========== 测试运行器 ==========

def run_tests():
    """运行所有测试"""
    import unittest
    
    # 创建测试套件
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # 添加测试类
    test_classes = [
        TestPhishingDetector,
        TestAttackPatternDetector,
        TestSenderTrustScorer,
        TestEmailSecurityGatekeeper,
        TestSecurityModules,
        TestSecuritySelfCheck,
        TestIntegration
    ]
    
    for test_class in test_classes:
        suite.addTests(loader.loadTestsFromTestCase(test_class))
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # 返回结果
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
