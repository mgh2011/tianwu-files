"""
效果监控模块
Effect Monitoring Module

提供反击效果实时监控功能
"""

__version__ = "v3.0.0"
__all__ = []
