# dialog_engine/memory/long_term_memory.py
"""
长期记忆管理
持久化存储，支持跨会话记忆
"""

import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from uuid import uuid4

from ..models.data_models import Memory


logger = logging.getLogger(__name__)


class LongTermMemory:
    """
    长期记忆管理
    持久化存储,支持跨会话记忆
    实际使用时需要接入数据库
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.max_memories = self.config.get("max_memories_per_user", 1000)
        self.importance_threshold = self.config.get("importance_threshold", 0.5)
        self.auto_summarize = self.config.get("auto_summarize", True)
        self.summarize_threshold = self.config.get("summarize_threshold", 100)
        self.retention_days = self.config.get("retention_days", 365)
        
        # 模拟存储
        self._storage: Dict[str, List[Memory]] = {}
        self._index: Dict[str, List[str]] = {}  # user_id -> memory_ids
        
    async def store(self, user_id: str, memory: Memory) -> str:
        """
        存储记忆
        
        Args:
            user_id: 用户ID
            memory: 记忆对象
            
        Returns:
            memory_id: 记忆ID
        """
        # 生成ID
        if not memory.memory_id:
            memory.memory_id = f"mem_{uuid4().hex[:12]}"
        
        memory.created_at = datetime.now()
        memory.last_accessed_at = datetime.now()
        
        # 初始化用户存储
        if user_id not in self._storage:
            self._storage[user_id] = []
            self._index[user_id] = []
        
        # 检查容量
        if len(self._storage[user_id]) >= self.max_memories:
            await self._prune_memories(user_id)
        
        # 存储
        self._storage[user_id].append(memory)
        self._index[user_id].append(memory.memory_id)
        
        logger.debug(f"Stored memory {memory.memory_id} for user {user_id}")
        return memory.memory_id
    
    async def retrieve(self, user_id: str, query: str,
                      limit: int = 10) -> List[Memory]:
        """
        检索记忆
        
        Args:
            user_id: 用户ID
            query: 查询关键词
            limit: 返回数量限制
            
        Returns:
            相关记忆列表
        """
        if user_id not in self._storage:
            return []
        
        memories = self._storage[user_id]
        
        # 简单的关键词匹配
        query_lower = query.lower()
        scored_memories = []
        
        for memory in memories:
            # 更新访问时间
            memory.last_accessed_at = datetime.now()
            
            # 计算相关性分数
            score = 0
            content_lower = memory.content.lower()
            
            if query_lower in content_lower:
                score += 1
            
            # 检查标签匹配
            for tag in memory.tags:
                if query_lower in tag.lower():
                    score += 0.5
            
            # 重要程度加权
            score *= memory.importance
            
            if score > 0:
                scored_memories.append((memory, score))
        
        # 排序并返回
        scored_memories.sort(key=lambda x: x[1], reverse=True)
        
        return [m[0] for m in scored_memories[:limit]]
    
    async def update(self, user_id: str, memory_id: str, content: str) -> bool:
        """
        更新记忆内容
        
        Args:
            user_id: 用户ID
            memory_id: 记忆ID
            content: 新内容
            
        Returns:
            是否更新成功
        """
        memories = self._storage.get(user_id, [])
        
        for memory in memories:
            if memory.memory_id == memory_id:
                memory.content = content
                memory.last_accessed_at = datetime.now()
                logger.debug(f"Updated memory {memory_id}")
                return True
        
        return False
    
    async def delete(self, user_id: str, memory_id: str) -> bool:
        """
        删除记忆
        
        Args:
            user_id: 用户ID
            memory_id: 记忆ID
            
        Returns:
            是否删除成功
        """
        if user_id not in self._storage:
            return False
        
        memories = self._storage[user_id]
        
        for i, memory in enumerate(memories):
            if memory.memory_id == memory_id:
                memories.pop(i)
                if memory_id in self._index[user_id]:
                    self._index[user_id].remove(memory_id)
                logger.debug(f"Deleted memory {memory_id}")
                return True
        
        return False
    
    async def get_all(self, user_id: str) -> List[Memory]:
        """获取用户所有记忆"""
        return self._storage.get(user_id, [])
    
    async def get_recent(self, user_id: str, count: int = 10) -> List[Memory]:
        """获取最近的记忆"""
        memories = self._storage.get(user_id, [])
        sorted_memories = sorted(
            memories,
            key=lambda m: m.last_accessed_at,
            reverse=True
        )
        return sorted_memories[:count]
    
    async def add_tag(self, user_id: str, memory_id: str, tag: str) -> bool:
        """添加标签"""
        memories = self._storage.get(user_id, [])
        
        for memory in memories:
            if memory.memory_id == memory_id:
                if tag not in memory.tags:
                    memory.tags.append(tag)
                return True
        
        return False
    
    async def remove_tag(self, user_id: str, memory_id: str, tag: str) -> bool:
        """移除标签"""
        memories = self._storage.get(user_id, [])
        
        for memory in memories:
            if memory.memory_id == memory_id:
                if tag in memory.tags:
                    memory.tags.remove(tag)
                return True
        
        return False
    
    async def search_by_tags(self, user_id: str, tags: List[str],
                           match_all: bool = False) -> List[Memory]:
        """按标签搜索"""
        memories = self._storage.get(user_id, [])
        results = []
        
        for memory in memories:
            if match_all:
                if all(tag in memory.tags for tag in tags):
                    results.append(memory)
            else:
                if any(tag in memory.tags for tag in tags):
                    results.append(memory)
        
        return results
    
    async def get_memory_count(self, user_id: str) -> int:
        """获取记忆数量"""
        return len(self._storage.get(user_id, []))
    
    async def _prune_memories(self, user_id: str) -> int:
        """
        清理低重要性的记忆
        
        Returns:
            清理的记忆数量
        """
        memories = self._storage.get(user_id, [])
        
        # 按重要性和时间排序
        sorted_memories = sorted(
            memories,
            key=lambda m: (m.importance, m.last_accessed_at),
            reverse=False
        )
        
        # 删除最低优先级的记忆
        prune_count = len(memories) - self.max_memories + 10  # 保留一些余量
        
        if prune_count > 0:
            to_remove = sorted_memories[:prune_count]
            for memory in to_remove:
                await self.delete(user_id, memory.memory_id)
            
            logger.info(f"Pruned {prune_count} memories for user {user_id}")
        
        return prune_count
    
    async def cleanup_old_memories(self, days: Optional[int] = None) -> int:
        """
        清理过期记忆
        
        Args:
            days: 保留天数,None使用默认配置
            
        Returns:
            清理的记忆数量
        """
        days = days or self.retention_days
        cutoff = datetime.now() - timedelta(days=days)
        total_cleaned = 0
        
        for user_id, memories in list(self._storage.items()):
            to_remove = []
            
            for memory in memories:
                if memory.last_accessed_at < cutoff:
                    to_remove.append(memory.memory_id)
            
            for memory_id in to_remove:
                if await self.delete(user_id, memory_id):
                    total_cleaned += 1
        
        if total_cleaned > 0:
            logger.info(f"Cleaned up {total_cleaned} old memories")
        
        return total_cleaned
    
    async def summarize(self, user_id: str) -> str:
        """
        生成用户记忆摘要
        
        Returns:
            摘要文本
        """
        memories = await self.get_recent(user_id, self.summarize_threshold)
        
        if not memories:
            return "暂无相关记忆。"
        
        # 简单摘要:按标签分组
        tags_count: Dict[str, int] = {}
        
        for memory in memories:
            for tag in memory.tags:
                tags_count[tag] = tags_count.get(tag, 0) + 1
        
        # 生成摘要
        top_tags = sorted(tags_count.items(), key=lambda x: x[1], reverse=True)[:5]
        
        summary_parts = [f"共有 {len(memories)} 条相关记忆"]
        
        if top_tags:
            tag_str = ", ".join([f"{tag}({count})" for tag, count in top_tags])
            summary_parts.append(f"主要涉及: {tag_str}")
        
        return " | ".join(summary_parts)
