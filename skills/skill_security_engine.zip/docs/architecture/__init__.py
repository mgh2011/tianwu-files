"""
架构文档模块
Architecture Documentation Module

提供架构设计文档
"""

__version__ = "v3.0.0"
__all__ = []
