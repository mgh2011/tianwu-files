# 邮件安全守门员 v3.0.3 (Email Security Gatekeeper)

> 帮助Agent识别可疑邮件、判断授权边界，自动化处理威胁邮件
> **版本：v3.0.3 精简实用版** - 精简描述，新增域名验证和威胁情报

---

## 核心功能

| 功能 | 描述 |
|------|------|
| **邮件分类** | 工具类、社交类、事务类、可疑类 |
| **钓鱼检测** | 域名伪造检测（仿冒品牌）、同形字攻击、内容分析、链接检测 |
| **威胁识别** | 六类攻击模式：身份伪造型、紧急施压型、利益诱惑型、技术恐吓型、情感操纵型、组合攻击型 |
| **授权边界** | 自主处理、需确认、禁止执行 三级判断 |
| **域名验证** | SPF/DKIM/DMARC检查、MX记录验证 |
| **威胁情报** | VirusTotal/PhishTank/Google Safe Browsing集成 |
| **法律合规** | 中国法规(网安法/数安法/PIPL)、国际法规(GDPR/CAN-SPAM/CCPA) |
| **安全自检** | 敏感数据泄露、API密钥安全、文件完整性检查 |

---

## 文件结构

```
email-gatekeeper/
├── SKILL.md                           # 本文件
├── __init__.py                        # 模块初始化
├── config/gatekeeper.yaml             # 配置文件
├── scripts/
│   ├── email_gatekeeper_core.py       # 核心引擎（钓鱼检测、邮件分类）
│   ├── security_modules.py             # 安全模块（加密、备份、自检）
│   ├── offense_defense.py             # 反击与威胁情报
│   ├── compliance_checker.py           # 法律合规检查
│   ├── api_server.py                   # REST API服务
│   └── tests.py                        # 测试套件
└── data/                               # 数据目录（运行时创建）
```

---

## 快速开始

### 1. 基础使用

```python
from scripts.email_gatekeeper_core import EmailSecurityGatekeeper, Email

# 初始化
gatekeeper = EmailSecurityGatekeeper(
    whitelist=["trusted@example.com"],
    blacklist=["blocked@spam.com"]
)

# 分析邮件
email = Email(
    message_id="test_001",
    sender="security@paypa1.com",  # 仿冒paypal（数字1替代l）
    recipients=["user@example.com"],
    subject="【紧急】您的账户存在风险",
    body="请立即点击链接验证..."
)

result, status = await gatekeeper.process_email(email)
print(f"风险等级: {result.risk_level.label}")
print(f"建议操作: {result.recommended_action}")
```

### 2. 域名验证

```python
from scripts.email_gatekeeper_core import EmailSecurityGatekeeper

gatekeeper = EmailSecurityGatekeeper()

# 验证发件人域名
email_data = {
    "sender": "boss@company.com",
    "from_header": "CEO <ceo@company.com>"
}

result = await gatekeeper.verify_sender_domain(email_data)
print(f"SPF: {result.get('spf_result')}")
print(f"DKIM: {result.get('dkim_result')}")
print(f"DMARC: {result.get('dmarc_result')}")
```

### 3. 威胁情报查询

```python
from scripts.offense_defense import ThreatIntelManager

threat_intel = ThreatIntelManager()

# 检查IP信誉
ip_result = await threat_intel.check_ip("192.168.1.1")

# 检查域名
domain_result = await threat_intel.check_domain("malicious.com")

# 检查URL安全性
url_result = await threat_intel.check_url("http://example.com")
```

### 4. 合规检查

```python
from scripts.compliance_checker import ComplianceChecker

checker = ComplianceChecker({'log_retention_days': 200})

# 日志留存检查
result = checker.check_log_retention(180)

# 用户同意检查
email_data = {'user_consent': True, 'consent_time': '2026-01-01'}
result = checker.check_consent(email_data)

# 生成HTML报告
html_report = checker.generate_html_report()
```

### 5. 启动API服务

```bash
python -m scripts.api_server --port 8443
```

### 6. 安全自检

```bash
python -m scripts.security_self_check
```

---

## 检测方法

| 方法 | 检查内容 |
|------|----------|
| `process_email(email)` | 综合邮件分析 |
| `verify_sender_domain(email)` | 域名验证(SPF/DKIM/DMARC) |
| `check_ip_reputation(ip)` | IP信誉查询 |
| `check_url_safety(url)` | URL安全检查 |

---

## 风险等级

| 等级 | 分数范围 | 建议操作 |
|------|----------|----------|
| 🟢 极低 | 0-20 | 直接放行 |
| 🟡 低 | 21-40 | 放行但记录 |
| 🟠 中 | 41-60 | 需确认 |
| 🔴 高 | 61-80 | 隔离审查 |
| ⚫ 极高 | 81-100 | 拦截并告警 |

---

## 版本历史

- **v3.0.3 (2026-04-11)**：精简实用版
  - 精简SKILL.md描述，与实际代码一致
  - 新增域名验证功能(SPF/DKIM/DMARC)
  - 新增威胁情报API集成
  - 新增商务邮件诈骗(BEC)检测
  - 新增勒索邮件检测

- **v3.0.2 (2026-04-10)**：法律合规增强版
  - 新增完整法律合规模块
  - 支持中国/国际主要法规

- **v3.0 (2026-04-10)**：企业级超级版
  - 新增钓鱼检测修复
  - 新增域名伪造检测

- v2.1-v1.0：早期版本
