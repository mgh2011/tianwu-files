"""
诱骗措施模块
Deception Module

提供蜜罐和虚假信息诱骗功能
"""

from .fake_response_deceiver import FakeResponseDeceiver

__version__ = "v3.0.0"
__all__ = [
    'FakeResponseDeceiver'
]
