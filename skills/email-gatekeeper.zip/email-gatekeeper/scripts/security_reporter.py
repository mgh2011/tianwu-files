# ========== 安全报告生成器 v3.2.0 ==========
# 文件: scripts/security_reporter.py
# 版本: 3.2.0
# 功能: 生成多格式安全检测报告

"""
安全报告生成器 v3.2.0
====================

核心能力：
1. Markdown报告生成 - 结构化Markdown格式
2. HTML报告生成 - 可视化HTML页面
3. JSON报告生成 - 程序化处理
4. 统计摘要生成 - 可视化统计图表
5. 合规报告生成 - 符合法规要求的报告

合规说明：
- 报告中不含敏感邮件内容
- 仅包含安全检测结果
- 支持数据脱敏
- 合规存档
"""

import json
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ReportFormat(Enum):
    """报告格式"""
    MARKDOWN = "markdown"
    HTML = "html"
    JSON = "json"
    TEXT = "text"


class RiskLevel(Enum):
    """风险等级"""
    VERY_LOW = "极低"
    LOW = "低"
    MEDIUM = "中"
    HIGH = "高"
    VERY_HIGH = "极高"


@dataclass
class DetectionRecord:
    """检测记录"""
    timestamp: str
    sender: str
    subject: str
    risk_score: int
    risk_level: str
    category: str
    threats_detected: List[str] = field(default_factory=list)
    indicators: List[str] = field(default_factory=list)
    action_taken: str = ""


@dataclass
class ReportSummary:
    """报告摘要"""
    total_emails: int = 0
    malicious_emails: int = 0
    suspicious_emails: int = 0
    safe_emails: int = 0
    avg_risk_score: float = 0.0
    top_threats: List[str] = field(default_factory=list)
    threat_breakdown: Dict[str, int] = field(default_factory=dict)


class SecurityReporter:
    """
    安全报告生成器 v3.2.0
    
    合规处理：
    - 不存储原始邮件内容
    - 支持数据脱敏
    - 合规存档
    """
    
    VERSION = "3.2.0"
    
    def __init__(self, config: Dict = None):
        """初始化报告生成器"""
        self.config = config or {}
        self._init_templates()
        
        logger.info("✅ 安全报告生成器初始化完成 (v3.2.0)")
    
    def _init_templates(self):
        """初始化模板"""
        # HTML模板
        self.html_template = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .header h1 {{
            margin: 0 0 10px 0;
        }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .stat-card h3 {{
            margin: 0 0 10px 0;
            color: #666;
            font-size: 14px;
        }}
        .stat-card .value {{
            font-size: 32px;
            font-weight: bold;
            color: #333;
        }}
        .stat-card.danger .value {{ color: #e74c3c; }}
        .stat-card.warning .value {{ color: #f39c12; }}
        .stat-card.success .value {{ color: #27ae60; }}
        .section {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .section h2 {{
            margin-top: 0;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
        }}
        th, td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }}
        th {{
            background: #f8f9fa;
            font-weight: 600;
        }}
        .risk-badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }}
        .risk-very-low {{ background: #d4edda; color: #155724; }}
        .risk-low {{ background: #fff3cd; color: #856404; }}
        .risk-medium {{ background: #ffeaa7; color: #d63031; }}
        .risk-high {{ background: #fab1a0; color: #d63031; }}
        .risk-very-high {{ background: #ff7675; color: #fff; }}
        .footer {{
            text-align: center;
            color: #666;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{title}</h1>
        <p>生成时间: {timestamp}</p>
        <p>版本: {version}</p>
    </div>
    
    <div class="stats">
        <div class="stat-card">
            <h3>总检测量</h3>
            <div class="value">{total_emails}</div>
        </div>
        <div class="stat-card danger">
            <h3>恶意邮件</h3>
            <div class="value">{malicious_count}</div>
        </div>
        <div class="stat-card warning">
            <h3>可疑邮件</h3>
            <div class="value">{suspicious_count}</div>
        </div>
        <div class="stat-card success">
            <h3>安全邮件</h3>
            <div class="value">{safe_count}</div>
        </div>
    </div>
    
    <div class="section">
        <h2>风险分布</h2>
        {risk_distribution}
    </div>
    
    <div class="section">
        <h2>威胁类型统计</h2>
        {threat_breakdown}
    </div>
    
    <div class="section">
        <h2>检测详情</h2>
        {detection_table}
    </div>
    
    <div class="footer">
        <p>邮件安全守门员 v{version} - 自动化安全检测报告</p>
        <p>本报告仅用于安全参考，不作为法律证据</p>
    </div>
</body>
</html>
"""
    
    def generate_report(
        self,
        records: List[DetectionRecord],
        format: ReportFormat = ReportFormat.MARKDOWN,
        title: str = "邮件安全检测报告",
        include_details: bool = True,
    ) -> str:
        """
        生成安全报告
        
        Args:
            records: 检测记录列表
            format: 报告格式
            title: 报告标题
            include_details: 是否包含详情
        
        Returns:
            str: 报告内容
        """
        # 生成摘要
        summary = self._generate_summary(records)
        
        if format == ReportFormat.MARKDOWN:
            return self._generate_markdown(title, summary, records, include_details)
        elif format == ReportFormat.HTML:
            return self._generate_html(title, summary, records, include_details)
        elif format == ReportFormat.JSON:
            return self._generate_json(title, summary, records)
        else:
            return self._generate_text(title, summary, records)
    
    def _generate_summary(self, records: List[DetectionRecord]) -> ReportSummary:
        """生成摘要"""
        summary = ReportSummary()
        
        if not records:
            return summary
        
        summary.total_emails = len(records)
        
        threat_counts: Dict[str, int] = {}
        all_threats: List[str] = []
        
        for record in records:
            # 统计风险等级
            if record.risk_level in ["极高", "高"]:
                summary.malicious_emails += 1
            elif record.risk_level == "中":
                summary.suspicious_emails += 1
            else:
                summary.safe_emails += 1
            
            # 统计威胁
            for threat in record.threats_detected:
                threat_counts[threat] = threat_counts.get(threat, 0) + 1
                all_threats.append(threat)
            
            # 累计风险分数
            summary.avg_risk_score += record.risk_score
        
        # 计算平均风险
        summary.avg_risk_score = round(summary.avg_risk_score / len(records), 2)
        
        # 排名前5威胁
        sorted_threats = sorted(threat_counts.items(), key=lambda x: x[1], reverse=True)
        summary.top_threats = [t[0] for t in sorted_threats[:5]]
        summary.threat_breakdown = dict(sorted_threats[:10])
        
        return summary
    
    def _generate_markdown(
        self,
        title: str,
        summary: ReportSummary,
        records: List[DetectionRecord],
        include_details: bool
    ) -> str:
        """生成Markdown报告"""
        lines = []
        
        # 标题
        lines.append(f"# {title}")
        lines.append("")
        lines.append(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"**版本**: {self.VERSION}")
        lines.append("")
        
        # 摘要
        lines.append("## 📊 检测摘要")
        lines.append("")
        lines.append("| 指标 | 数值 |")
        lines.append("|------|------|")
        lines.append(f"| 总检测量 | {summary.total_emails} |")
        lines.append(f"| 恶意邮件 | {summary.malicious_emails} |")
        lines.append(f"| 可疑邮件 | {summary.suspicious_emails} |")
        lines.append(f"| 安全邮件 | {summary.safe_emails} |")
        lines.append(f"| 平均风险分数 | {summary.avg_risk_score} |")
        lines.append("")
        
        # 威胁排名
        if summary.top_threats:
            lines.append("## 🔍 威胁排名")
            lines.append("")
            for i, threat in enumerate(summary.top_threats, 1):
                count = summary.threat_breakdown.get(threat, 0)
                lines.append(f"{i}. **{threat}** ({count}次)")
            lines.append("")
        
        # 威胁类型分布
        if summary.threat_breakdown:
            lines.append("## 📈 威胁类型分布")
            lines.append("")
            for threat, count in summary.threat_breakdown.items():
                percentage = count / summary.total_emails * 100
                bar = "█" * int(percentage / 5)
                lines.append(f"- {threat}: {bar} {count} ({percentage:.1f}%)")
            lines.append("")
        
        # 检测详情
        if include_details and records:
            lines.append("## 📋 检测详情")
            lines.append("")
            lines.append("| 时间 | 发件人 | 主题 | 风险 | 威胁 |")
            lines.append("|------|--------|------|------|------|")
            
            for record in records[:50]:  # 限制显示数量
                risk_badge = self._get_risk_badge(record.risk_level)
                threats = ", ".join(record.threats_detected[:2])
                if len(record.threats_detected) > 2:
                    threats += "..."
                lines.append(
                    f"| {record.timestamp[:10]} | "
                    f"{self._anonymize(record.sender)} | "
                    f"{record.subject[:20]}... | "
                    f"{risk_badge} | "
                    f"{threats} |"
                )
            lines.append("")
        
        # 页脚
        lines.append("---")
        lines.append("")
        lines.append("*本报告由邮件安全守门员自动生成*")
        
        return "\n".join(lines)
    
    def _generate_html(
        self,
        title: str,
        summary: ReportSummary,
        records: List[DetectionRecord],
        include_details: bool
    ) -> str:
        """生成HTML报告"""
        # 风险分布
        risk_distribution = "<ul>"
        for level in ["极高", "高", "中", "低", "极低"]:
            count = sum(1 for r in records if r.risk_level == level)
            percentage = count / summary.total_emails * 100 if summary.total_emails > 0 else 0
            risk_distribution += f"<li>{level}: {count} ({percentage:.1f}%)</li>"
        risk_distribution += "</ul>"
        
        # 威胁分布
        threat_breakdown = "<ul>"
        for threat, count in summary.threat_breakdown.items():
            threat_breakdown += f"<li>{threat}: {count}次</li>"
        threat_breakdown += "</ul>"
        
        # 检测表格
        detection_rows = ""
        for record in records[:50]:
            risk_class = f"risk-{record.risk_level}"
            detection_rows += f"""
            <tr>
                <td>{record.timestamp[:10]}</td>
                <td>{self._anonymize(record.sender)}</td>
                <td>{record.subject[:30]}...</td>
                <td><span class="risk-badge {risk_class}">{record.risk_level}</span></td>
                <td>{', '.join(record.threats_detected[:2])}</td>
            </tr>
            """
        
        return self.html_template.format(
            title=title,
            timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            version=self.VERSION,
            total_emails=summary.total_emails,
            malicious_count=summary.malicious_emails,
            suspicious_count=summary.suspicious_emails,
            safe_count=summary.safe_emails,
            risk_distribution=risk_distribution,
            threat_breakdown=threat_breakdown,
            detection_table=f"<table><thead><tr><th>时间</th><th>发件人</th><th>主题</th><th>风险</th><th>威胁</th></tr></thead><tbody>{detection_rows}</tbody></table>" if include_details else "<p>详情已禁用</p>",
        )
    
    def _generate_json(
        self,
        title: str,
        summary: ReportSummary,
        records: List[DetectionRecord]
    ) -> str:
        """生成JSON报告"""
        report = {
            "report": {
                "title": title,
                "timestamp": datetime.now().isoformat(),
                "version": self.VERSION,
            },
            "summary": asdict(summary),
            "records": [
                {
                    **asdict(r),
                    "sender_anonymized": self._anonymize(r.sender),
                }
                for r in records
            ]
        }
        return json.dumps(report, ensure_ascii=False, indent=2)
    
    def _generate_text(
        self,
        title: str,
        summary: ReportSummary,
        records: List[DetectionRecord]
    ) -> str:
        """生成纯文本报告"""
        lines = []
        
        lines.append("=" * 60)
        lines.append(title.center(60))
        lines.append("=" * 60)
        lines.append("")
        lines.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"版本: {self.VERSION}")
        lines.append("")
        
        lines.append("【检测摘要】")
        lines.append(f"  总检测量: {summary.total_emails}")
        lines.append(f"  恶意邮件: {summary.malicious_emails}")
        lines.append(f"  可疑邮件: {summary.suspicious_emails}")
        lines.append(f"  安全邮件: {summary.safe_emails}")
        lines.append(f"  平均风险分数: {summary.avg_risk_score}")
        lines.append("")
        
        if summary.top_threats:
            lines.append("【威胁排名】")
            for i, threat in enumerate(summary.top_threats, 1):
                lines.append(f"  {i}. {threat}")
            lines.append("")
        
        lines.append("=" * 60)
        
        return "\n".join(lines)
    
    def _get_risk_badge(self, level: str) -> str:
        """获取风险徽章"""
        badges = {
            "极低": "🟢极低",
            "低": "🟡低",
            "中": "🟠中",
            "高": "🔴高",
            "极高": "⚫极高",
        }
        return badges.get(level, level)
    
    def _anonymize(self, email: str) -> str:
        """脱敏处理"""
        if not email or '@' not in email:
            return "***"
        
        local, domain = email.split('@', 1)
        
        # 只显示第一个和最后一个字符
        if len(local) <= 2:
            masked_local = local[0] + "*"
        else:
            masked_local = local[0] + "*" * (len(local) - 2) + local[-1]
        
        return f"{masked_local}@{domain}"
    
    def generate_compliance_report(
        self,
        records: List[DetectionRecord],
        format: ReportFormat = ReportFormat.MARKDOWN
    ) -> str:
        """生成合规报告"""
        title = "邮件安全合规报告"
        
        # 按月统计
        monthly_stats: Dict[str, Dict] = {}
        for record in records:
            month = record.timestamp[:7]  # YYYY-MM
            if month not in monthly_stats:
                monthly_stats[month] = {
                    'total': 0,
                    'malicious': 0,
                    'suspicious': 0,
                    'safe': 0,
                }
            
            monthly_stats[month]['total'] += 1
            if record.risk_level in ["极高", "高"]:
                monthly_stats[month]['malicious'] += 1
            elif record.risk_level == "中":
                monthly_stats[month]['suspicious'] += 1
            else:
                monthly_stats[month]['safe'] += 1
        
        if format == ReportFormat.MARKDOWN:
            lines = []
            lines.append(f"# {title}")
            lines.append("")
            lines.append(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            lines.append("")
            
            lines.append("## 📅 月度统计")
            lines.append("")
            lines.append("| 月份 | 总计 | 恶意 | 可疑 | 安全 |")
            lines.append("|------|------|------|------|------|")
            
            for month in sorted(monthly_stats.keys()):
                stats = monthly_stats[month]
                lines.append(
                    f"| {month} | {stats['total']} | "
                    f"{stats['malicious']} | {stats['suspicious']} | {stats['safe']} |"
                )
            
            lines.append("")
            lines.append("---")
            lines.append("*本报告用于合规存档*")
            
            return "\n".join(lines)
        
        return self.generate_report(records, format, title, False)
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        return {
            'version': self.VERSION,
            'supported_formats': [f.value for f in ReportFormat],
        }
