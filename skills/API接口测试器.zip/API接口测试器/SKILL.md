# API接口测试器

## 技能信息
- **技能ID**: `tianwu-api-tester`
- **版本**: 1.0.0
- **作者**: 天武团队
- **分类**: 测试工具
- **价格**: 11积分
- **依赖**: `tianwu-core-engine` (天武综合引擎)

## ⚠️ 前置要求
**必须先安装「天武综合引擎」才能使用此技能！**

## 简介
专业API接口测试工具，支持接口调试、自动化测试、性能测试、文档生成。

## 核心功能

### 1. 接口调试
```python
class 接口调试器:
    def 发送请求(方法, URL, 参数):
        """支持GET、POST、PUT、DELETE等"""
        pass
    
    def 环境切换(环境名):
        """切换测试/预发/生产环境"""
        pass
    
    def 变量管理(变量列表):
        pass
    
    def 请求历史():
        pass
```

### 2. 自动化测试
```python
class 自动化测试器:
    def 创建用例(用例信息):
        pass
    
    def 批量执行(用例列表):
        pass
    
    def 断言验证(响应, 预期):
        pass
    
    def 测试报告(执行结果):
        pass
```

### 3. 性能测试
```python
class 性能测试器:
    def 压力测试(配置):
        """并发压力测试"""
        pass
    
    def 渐进测试(配置):
        """逐步增加并发"""
        pass
    
    def 持续测试(时长):
        """持续一段时间测试"""
        pass
    
    def 性能报告(测试结果):
        pass
```

### 4. 文档生成
```python
class 文档生成器:
    def 从用例生成文档(用例列表):
        pass
    
    def 导出OpenAPI(接口列表):
        pass
    
    def 导出Markdown(接口列表):
        pass
    
    def Mock服务(接口定义):
        """生成Mock服务器"""
        pass
```

## 使用示例

```python
# 接口调试
响应 = 引擎.执行("API接口测试器.发送请求",
               方法="POST",
               URL="https://api.example.com/users",
               参数={"name": "测试用户"})

# 批量测试
引擎.执行("API接口测试器.批量执行", 用例列表=测试用例)

# 性能测试
报告 = 引擎.执行("API接口测试器.压力测试",
               配置={
                   "URL": "https://api.example.com",
                   "并发数": 100,
                   "持续时间": 60
               })
```

## 支持的特性
- RESTful API
- GraphQL
- WebSocket
- 认证：Bearer、Basic、OAuth2
- 数据格式：JSON、XML、Form

## 价格说明
- 购买价格: 11积分
- 无接口数量限制
- 支持CI/CD集成
