"""
干扰措施模块
Interference Module

提供干扰攻击者的功能
"""

__version__ = "v3.0.0"
__all__ = []
