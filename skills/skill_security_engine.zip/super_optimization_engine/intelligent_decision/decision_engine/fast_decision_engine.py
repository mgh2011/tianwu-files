"""
超级优化引擎 - 快速决策引擎
Fast Decision Engine - 毫秒级决策响应引擎
"""

from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json
import time
import threading
from collections import deque
import hashlib


class DecisionType(Enum):
    """决策类型"""
    SECURITY = "security"
    OPTIMIZATION = "optimization"
    AUTOMATION = "automation"
    EMERGENCY = "emergency"


class DecisionPriority(Enum):
    """决策优先级"""
    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4


@dataclass
class DecisionRequest:
    """决策请求"""
    request_id: str
    decision_type: DecisionType
    context: Dict
    priority: DecisionPriority
    deadline: Optional[str] = None
    callback: Optional[str] = None


@dataclass
class DecisionResult:
    """决策结果"""
    request_id: str
    decision: Any
    confidence: float
    execution_time: float
    timestamp: str
    cached: bool = False


@dataclass
class DecisionMetrics:
    """决策指标"""
    total_decisions: int = 0
    avg_execution_time: float = 0.0
    p99_latency: float = 0.0
    cache_hit_rate: float = 0.0
    error_rate: float = 0.0


class FastDecisionEngine:
    """快速决策引擎"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化快速决策引擎

        Args:
            config: 配置字典
        """
        self.config = config or {}

        # 性能配置
        self.target_latency_ms = self.config.get('target_latency_ms', 10)  # 目标延迟10ms
        self.max_latency_ms = self.config.get('max_latency_ms', 100)  # 最大延迟100ms
        self.cache_size = self.config.get('cache_size', 10000)
        self.parallel_threshold = self.config.get('parallel_threshold', 5)

        # 决策缓存
        self.decision_cache: Dict[str, DecisionResult] = {}
        self.cache_access_order = deque(maxlen=self.cache_size)

        # 决策策略
        self.decision_strategies: Dict[DecisionType, Callable] = {}
        self._register_default_strategies()

        # 指标
        self.metrics = DecisionMetrics()
        self.latency_history: deque = deque(maxlen=1000)
        self._lock = threading.Lock()

        # 预计算决策
        self.precomputed_decisions: Dict[str, Any] = {}
        self.enable_precomputation = self.config.get('enable_precomputation', True)

    def make_decision(self, request: DecisionRequest) -> DecisionResult:
        """
        做出决策

        Args:
            request: 决策请求

        Returns:
            决策结果
        """
        start_time = time.time()

        # 检查缓存
        cache_key = self._generate_cache_key(request)
        cached_result = self._get_from_cache(cache_key)
        if cached_result:
            cached_result.cached = True
            self._update_cache_hit_metrics()
            return cached_result

        # 执行决策
        try:
            strategy = self.decision_strategies.get(request.decision_type)
            if not strategy:
                # 默认策略
                decision = self._default_strategy(request)
            else:
                decision = strategy(request.context)

            execution_time = (time.time() - start_time) * 1000  # 转换为毫秒

            result = DecisionResult(
                request_id=request.request_id,
                decision=decision,
                confidence=0.95,
                execution_time=execution_time,
                timestamp=datetime.now().isoformat(),
                cached=False
            )

            # 更新缓存
            self._add_to_cache(cache_key, result)

            # 更新指标
            self._update_metrics(execution_time, success=True)

            return result

        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            self._update_metrics(execution_time, success=False)

            return DecisionResult(
                request_id=request.request_id,
                decision=None,
                confidence=0.0,
                execution_time=execution_time,
                timestamp=datetime.now().isoformat(),
                cached=False
            )

    def make_decision_batch(self, requests: List[DecisionRequest]) -> List[DecisionResult]:
        """
        批量决策

        Args:
            requests: 决策请求列表

        Returns:
            决策结果列表
        """
        # 按优先级排序
        sorted_requests = sorted(
            requests,
            key=lambda r: r.priority.value
        )

        # 检查是否并行处理
        if len(sorted_requests) >= self.parallel_threshold:
            return self._parallel_decision(sorted_requests)
        else:
            return [self.make_decision(r) for r in sorted_requests]

    def precompute_decisions(self, scenarios: List[Dict]):
        """
        预计算决策

        Args:
            scenarios: 场景列表
        """
        if not self.enable_precomputation:
            return

        for scenario in scenarios:
            request = DecisionRequest(
                request_id=self._generate_id(),
                decision_type=DecisionType(scenario.get('type', 'security')),
                context=scenario.get('context', {}),
                priority=DecisionPriority(scenario.get('priority', 3))
            )

            cache_key = self._generate_cache_key(request)
            result = self.make_decision(request)
            self.precomputed_decisions[cache_key] = result

    def register_strategy(self, decision_type: DecisionType, strategy: Callable):
        """
        注册决策策略

        Args:
            decision_type: 决策类型
            strategy: 策略函数
        """
        self.decision_strategies[decision_type] = strategy

    def get_metrics(self) -> DecisionMetrics:
        """获取决策指标"""
        return self.metrics

    def _register_default_strategies(self):
        """注册默认策略"""
        self.decision_strategies = {
            DecisionType.SECURITY: self._security_strategy,
            DecisionType.OPTIMIZATION: self._optimization_strategy,
            DecisionType.AUTOMATION: self._automation_strategy,
            DecisionType.EMERGENCY: self._emergency_strategy,
        }

    def _security_strategy(self, context: Dict) -> Dict:
        """安全决策策略"""
        threat_level = context.get('threat_level', 5)
        threat_type = context.get('threat_type', 'unknown')

        if threat_level >= 8:
            action = 'block'
        elif threat_level >= 5:
            action = 'monitor'
        else:
            action = 'log'

        return {
            'action': action,
            'threat_level': threat_level,
            'threat_type': threat_type,
            'recommended_response': self._get_response_action(action)
        }

    def _optimization_strategy(self, context: Dict) -> Dict:
        """优化决策策略"""
        current_metrics = context.get('metrics', {})
        target_metrics = context.get('target_metrics', {})

        optimizations = []
        for key in target_metrics:
            current = current_metrics.get(key, 0)
            target = target_metrics[key]
            if current < target:
                optimizations.append({
                    'parameter': key,
                    'current': current,
                    'target': target,
                    'adjustment': (target - current) * 1.2
                })

        return {
            'optimizations': optimizations,
            'estimated_improvement': sum(o['adjustment'] for o in optimizations)
        }

    def _automation_strategy(self, context: Dict) -> Dict:
        """自动化决策策略"""
        task_type = context.get('task_type', 'unknown')
        task_priority = context.get('priority', 'medium')

        automation_level = 'full' if task_priority == 'high' else 'partial'

        return {
            'automation_level': automation_level,
            'task_type': task_type,
            'estimated_time': context.get('estimated_time', 60)
        }

    def _emergency_strategy(self, context: Dict) -> Dict:
        """紧急决策策略"""
        emergency_type = context.get('emergency_type', 'unknown')

        return {
            'action': 'emergency_response',
            'emergency_type': emergency_type,
            'immediate_actions': ['isolate', 'notify', 'escalate'],
            'response_team': 'ERT'
        }

    def _default_strategy(self, request: DecisionRequest) -> Dict:
        """默认策略"""
        return {
            'action': 'process',
            'type': request.decision_type.value,
            'priority': request.priority.name
        }

    def _get_response_action(self, action: str) -> Dict:
        """获取响应动作"""
        response_map = {
            'block': ['add_firewall_rule', 'notify_admin', 'log_incident'],
            'monitor': ['increase_logging', 'alert_team', 'track_pattern'],
            'log': ['record_event', 'update_metrics']
        }
        return response_map.get(action, ['log'])

    def _parallel_decision(self, requests: List[DecisionRequest]) -> List[DecisionResult]:
        """并行决策"""
        results = [None] * len(requests)
        threads = []

        def process(index, request):
            results[index] = self.make_decision(request)

        for i, request in enumerate(requests):
            thread = threading.Thread(target=process, args=(i, request))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        return results

    def _generate_cache_key(self, request: DecisionRequest) -> str:
        """生成缓存键"""
        content = json.dumps({
            'type': request.decision_type.value,
            'context': request.context,
            'priority': request.priority.value
        }, sort_keys=True)
        return hashlib.md5(content.encode()).hexdigest()

    def _generate_id(self) -> str:
        """生成ID"""
        return f"DEC-{hashlib.md5(str(datetime.now()).encode()).hexdigest()[:12].upper()}"

    def _get_from_cache(self, cache_key: str) -> Optional[DecisionResult]:
        """从缓存获取"""
        return self.decision_cache.get(cache_key)

    def _add_to_cache(self, cache_key: str, result: DecisionResult):
        """添加到缓存"""
        with self._lock:
            if len(self.decision_cache) >= self.cache_size:
                # 移除最旧的
                oldest_key = self.cache_access_order.popleft()
                if oldest_key in self.decision_cache:
                    del self.decision_cache[oldest_key]

            self.decision_cache[cache_key] = result
            self.cache_access_order.append(cache_key)

    def _update_cache_hit_metrics(self):
        """更新缓存命中指标"""
        with self._lock:
            self.metrics.cache_hit_rate = min(1.0, self.metrics.cache_hit_rate + 0.01)

    def _update_metrics(self, execution_time: float, success: bool):
        """更新指标"""
        with self._lock:
            self.metrics.total_decisions += 1

            # 更新平均执行时间
            n = self.metrics.total_decisions
            self.metrics.avg_execution_time = (
                (self.metrics.avg_execution_time * (n - 1) + execution_time) / n
            )

            # 更新P99延迟
            self.latency_history.append(execution_time)
            if len(self.latency_history) >= 100:
                sorted_latencies = sorted(self.latency_history)
                self.metrics.p99_latency = sorted_latencies[int(len(sorted_latencies) * 0.99)]

            # 更新错误率
            if not success:
                errors = self.metrics.error_rate * (n - 1) + 1
                self.metrics.error_rate = errors / n


# 独立运行测试
if __name__ == "__main__":
    engine = FastDecisionEngine({
        'target_latency_ms': 10,
        'max_latency_ms': 100,
        'cache_size': 1000,
        'enable_precomputation': True
    })

    print("=" * 60)
    print("快速决策引擎测试")
    print("=" * 60)

    # 预计算决策
    print("\n1. 预计算决策...")
    scenarios = [
        {'type': 'security', 'context': {'threat_level': 9, 'threat_type': 'ddos'}},
        {'type': 'security', 'context': {'threat_level': 5, 'threat_type': 'scan'}},
        {'type': 'optimization', 'context': {'metrics': {'cpu': 80}, 'target_metrics': {'cpu': 60}}}
    ]
    engine.precompute_decisions(scenarios)
    print(f"   预计算完成: {len(engine.precomputed_decisions)} 个决策")

    # 单个决策测试
    print("\n2. 单个决策测试...")
    for i in range(5):
        request = DecisionRequest(
            request_id=f"REQ-{i:03d}",
            decision_type=DecisionType.SECURITY,
            context={'threat_level': 7, 'threat_type': 'intrusion'},
            priority=DecisionPriority.HIGH
        )

        result = engine.make_decision(request)
        status = "缓存" if result.cached else "计算"
        print(f"   [{status}] 请求{request.request_id}: "
              f"执行时间={result.execution_time:.2f}ms, "
              f"动作={result.decision.get('action') if result.decision else 'None'}")

    # 批量决策测试
    print("\n3. 批量决策测试...")
    batch_requests = [
        DecisionRequest(
            request_id=f"REQ-BATCH-{i:02d}",
            decision_type=DecisionType.OPTIMIZATION,
            context={'metrics': {'mem': 90}, 'target_metrics': {'mem': 70}},
            priority=DecisionPriority(i % 4 + 1)
        )
        for i in range(10)
    ]

    start = time.time()
    results = engine.make_decision_batch(batch_requests)
    total_time = (time.time() - start) * 1000

    print(f"   批量处理: {len(results)} 个决策")
    print(f"   总耗时: {total_time:.2f}ms")
    print(f"   平均耗时: {total_time/len(results):.2f}ms")

    # 获取指标
    print("\n4. 决策指标:")
    metrics = engine.get_metrics()
    print(f"   总决策数: {metrics.total_decisions}")
    print(f"   平均延迟: {metrics.avg_execution_time:.2f}ms")
    print(f"   P99延迟: {metrics.p99_latency:.2f}ms")
    print(f"   缓存命中率: {metrics.cache_hit_rate:.1%}")
    print(f"   错误率: {metrics.error_rate:.2%}")

    print("\n" + "=" * 60)
    print("快速决策引擎测试完成")
    print("=" * 60)
