# 数据库管理专家

## 技能信息
- **技能ID**: `tianwu-database-manager`
- **版本**: 1.0.0
- **作者**: 天武团队
- **分类**: 数据管理
- **价格**: 16积分
- **依赖**: `tianwu-core-engine` (天武综合引擎)

## ⚠️ 前置要求
**必须先安装「天武综合引擎」才能使用此技能！**

## 简介
专业数据库管理工具，支持多数据库类型、SQL优化、数据迁移、备份恢复。

## 核心功能

### 1. 连接管理
```python
class 数据库连接器:
    def 连接(数据库类型, 连接配置):
        """支持MySQL、PostgreSQL、MongoDB等"""
        pass
    
    def 连接池管理(配置):
        pass
    
    def 健康检查():
        pass
    
    def 断线重连():
        pass
```

### 2. SQL工具
```python
class SQL工具:
    def 格式化(SQL语句):
        pass
    
    def 优化建议(SQL语句):
        """分析SQL并给出优化建议"""
        pass
    
    def 执行计划分析(SQL语句):
        pass
    
    def 慢查询分析(时间范围):
        pass
```

### 3. 数据操作
```python
class 数据操作器:
    def 智能查询(表名, 条件):
        pass
    
    def 批量插入(数据列表):
        pass
    
    def 数据导出(查询, 格式):
        """导出为CSV、JSON、Excel"""
        pass
    
    def 数据导入(文件, 表名):
        pass
```

### 4. 备份恢复
```python
class 备份恢复器:
    def 创建备份(数据库, 备份路径):
        pass
    
    def 定时备份(计划):
        pass
    
    def 恢复数据(备份文件):
        pass
    
    def 增量备份(上次备份时间):
        pass
```

### 5. 数据迁移
```python
class 数据迁移器:
    def 迁移向导(源库, 目标库):
        pass
    
    def 表结构同步():
        pass
    
    def 数据校验():
        pass
    
    def 迁移回滚():
        pass
```

## 使用示例

```python
# 连接数据库
引擎.执行("数据库管理专家.连接",
          数据库类型="MySQL",
          连接配置={"host": "localhost", "port": 3306})

# SQL优化
建议 = 引擎.执行("数据库管理专家.优化建议",
               SQL语句="SELECT * FROM users WHERE name LIKE '%test%'")

# 数据备份
引擎.执行("数据库管理专家.创建备份",
          数据库="mydb",
          备份路径="./backup/")

# 数据迁移
引擎.执行("数据库管理专家.迁移向导",
          源库=源配置,
          目标库=目标配置)
```

## 支持的数据库
- MySQL / MariaDB
- PostgreSQL
- MongoDB
- SQLite
- Redis
- Oracle
- SQL Server

## 价格说明
- 购买价格: 16积分
- 支持所有主流数据库
- 支持数据安全加密
