"""
反击风险分析模块
Counterattack Risk Analyzer - 分析反击行动的潜在风险
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class RiskCategory(Enum):
    """风险类别"""
    TECHNICAL_RISK = "technical_risk"  # 技术风险
    LEGAL_RISK = "legal_risk"  # 法律风险
    OPERATIONAL_RISK = "operational_risk"  # 运营风险
    REPUTATIONAL_RISK = "reputational_risk"  # 声誉风险
    ESCALATION_RISK = "escalation_risk"  # 升级风险
    COLLATERAL_RISK = "collateral_risk"  # 附带损害风险
    ATTRIBUTION_RISK = "attribution_risk"  # 归因风险
    RESOURCE_RISK = "resource_risk"  # 资源风险


class RiskSeverity(Enum):
    """风险严重程度"""
    NEGLIGIBLE = 1
    LOW = 2
    MEDIUM = 3
    HIGH = 4
    CRITICAL = 5


@dataclass
class RiskItem:
    """风险项目"""
    category: RiskCategory
    name: str
    description: str
    severity: RiskSeverity
    likelihood: float  # 发生可能性 (0-1)
    impact: float  # 影响程度 (0-1)
    risk_score: float
    mitigation: str
    contingency: str
    evidence: List[str] = field(default_factory=list)


@dataclass
class RiskAnalysis:
    """风险分析结果"""
    overall_risk_score: float
    risk_level: str
    risks: List[RiskItem]
    breakdown: Dict[str, float]
    high_risks: List[RiskItem]
    mitigations: List[str]
    recommendations: List[str]
    can_proceed: bool
    conditions: List[str]


class CounterattackRiskAnalyzer:
    """反击风险分析器"""

    # 风险评分权重
    SEVERITY_WEIGHTS = {
        RiskSeverity.NEGLIGIBLE: 1,
        RiskSeverity.LOW: 2,
        RiskSeverity.MEDIUM: 3,
        RiskSeverity.HIGH: 4,
        RiskSeverity.CRITICAL: 5,
    }

    # 风险等级阈值
    RISK_THRESHOLDS = {
        'low': (0, 30),
        'medium': (30, 50),
        'high': (50, 70),
        'critical': (70, 100),
    }

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化反击风险分析器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.legal_jurisdiction = self.config.get('legal_jurisdiction', 'CN')
        self.analysis_history = []

    def analyze(self, counterattack_plan: Dict) -> RiskAnalysis:
        """
        分析反击风险

        Args:
            counterattack_plan: 反击计划，包含：
                - action_type: 反击动作类型
                - target: 目标信息
                - attack_info: 攻击信息
                - legal_context: 法律背景
                - operational_context: 运营背景

        Returns:
            风险分析结果
        """
        action_type = counterattack_plan.get('action_type', 'unknown')
        target = counterattack_plan.get('target', {})
        attack_info = counterattack_plan.get('attack_info', {})
        legal_context = counterattack_plan.get('legal_context', {})
        operational_context = counterattack_plan.get('operational_context', {})

        risks = []

        # 1. 技术风险
        technical_risk = self._analyze_technical_risk(
            action_type, target, attack_info
        )
        risks.append(technical_risk)

        # 2. 法律风险
        legal_risk = self._analyze_legal_risk(
            action_type, target, attack_info, legal_context
        )
        risks.append(legal_risk)

        # 3. 运营风险
        operational_risk = self._analyze_operational_risk(
            action_type, target, operational_context
        )
        risks.append(operational_risk)

        # 4. 声誉风险
        reputational_risk = self._analyze_reputational_risk(
            action_type, target, legal_context
        )
        risks.append(reputational_risk)

        # 5. 升级风险
        escalation_risk = self._analyze_escalation_risk(
            action_type, attack_info
        )
        risks.append(escalation_risk)

        # 6. 附带损害风险
        collateral_risk = self._analyze_collateral_risk(
            action_type, target
        )
        risks.append(collateral_risk)

        # 7. 归因风险
        attribution_risk = self._analyze_attribution_risk(
            action_type, attack_info
        )
        risks.append(attribution_risk)

        # 8. 资源风险
        resource_risk = self._analyze_resource_risk(
            action_type, operational_context
        )
        risks.append(resource_risk)

        # 计算总体风险评分
        breakdown = {}
        for risk in risks:
            breakdown[risk.category.value] = risk.risk_score

        overall_score = sum(r.risk_score * r.likelihood for r in risks)

        # 确定风险等级
        risk_level = self._determine_risk_level(overall_score)

        # 识别高风险项
        high_risks = [r for r in risks if r.severity in [
            RiskSeverity.HIGH, RiskSeverity.CRITICAL
        ]]

        # 汇总缓解措施
        mitigations = self._aggregate_mitigations(risks)

        # 生成建议
        recommendations = self._generate_recommendations(
            risks, high_risks, risk_level, action_type
        )

        # 评估是否可以继续
        can_proceed, conditions = self._assess_proceed_decision(
            high_risks, risk_level, legal_risk
        )

        # 构建分析结果
        analysis = RiskAnalysis(
            overall_risk_score=round(overall_score, 2),
            risk_level=risk_level,
            risks=risks,
            breakdown=breakdown,
            high_risks=high_risks,
            mitigations=mitigations,
            recommendations=recommendations,
            can_proceed=can_proceed,
            conditions=conditions
        )

        # 更新历史
        self._update_history(analysis, counterattack_plan)

        return analysis

    def _analyze_technical_risk(self, action_type: str,
                               target: Dict,
                               attack_info: Dict) -> RiskItem:
        """分析技术风险"""
        risk_score = 30.0
        evidence = []

        # 反击动作技术复杂性
        complex_actions = ['counterattack', 'reverse_penetration', 'exploit']
        if action_type in complex_actions:
            risk_score += 20
            evidence.append("高技术复杂性反击动作")

        # 目标防御能力
        target_defense = target.get('defense_level', 'medium')
        if target_defense == 'high':
            risk_score += 15
            evidence.append("目标具有强防御能力")

        # 行动失败风险
        failure_probability = target.get('estimated_failure_rate', 0.3)
        if failure_probability > 0.5:
            risk_score += 10
            evidence.append(f"高失败概率({failure_probability:.0%})")

        # 误操作风险
        if action_type in ['block', 'terminate']:
            risk_score += 10
            evidence.append("破坏性操作存在误操作风险")

        risk_score = min(100, risk_score)

        return RiskItem(
            category=RiskCategory.TECHNICAL_RISK,
            name="技术实施风险",
            description="反击行动在技术层面可能失败或产生意外结果的风险",
            severity=self._score_to_severity(risk_score),
            likelihood=min(1.0, risk_score / 100),
            impact=risk_score / 100,
            risk_score=risk_score,
            mitigation="充分的测试和演练，确保技术可行性",
            contingency="准备回滚方案，准备替代技术方案",
            evidence=evidence
        )

    def _analyze_legal_risk(self, action_type: str,
                           target: Dict,
                           attack_info: Dict,
                           legal_context: Dict) -> RiskItem:
        """分析法律风险"""
        risk_score = 50.0  # 法律风险通常较高
        evidence = []

        # 法律管辖区
        jurisdiction = legal_context.get('jurisdiction', self.legal_jurisdiction)
        if jurisdiction not in ['CN', 'US', 'EU']:
            risk_score += 20
            evidence.append(f"法律管辖区:{jurisdiction}可能存在法律空白")

        # 跨境行动
        if attack_info.get('cross_border', False):
            risk_score += 25
            evidence.append("跨境攻击增加法律复杂性")

        # 攻击者身份
        if not attack_info.get('attacker_confirmed', False):
            risk_score += 15
            evidence.append("攻击者身份未确认")

        # 反击动作类型
        prohibited_actions = ['counterattack', 'reverse_penetration', 'exploit']
        if action_type in prohibited_actions:
            risk_score += 30
            evidence.append(f"动作{action_type}可能违反法律")

        # 法律授权
        if not legal_context.get('authorized', False):
            risk_score += 20
            evidence.append("未经法律授权")

        risk_score = min(100, risk_score)

        return RiskItem(
            category=RiskCategory.LEGAL_RISK,
            name="法律合规风险",
            description="反击行动可能违反法律或法规的风险",
            severity=self._score_to_severity(risk_score),
            likelihood=min(1.0, risk_score / 100),
            impact=risk_score / 100,
            risk_score=risk_score,
            mitigation="确保法律授权，在法律框架内行动",
            contingency="准备法律辩护材料，寻求法律援助",
            evidence=evidence
        )

    def _analyze_operational_risk(self, action_type: str,
                                  target: Dict,
                                  context: Dict) -> RiskItem:
        """分析运营风险"""
        risk_score = 20.0
        evidence = []

        # 资源可用性
        resource_availability = context.get('resource_availability', 0.8)
        if resource_availability < 0.5:
            risk_score += 20
            evidence.append("资源可用性低")

        # 人员能力
        staff_capability = context.get('staff_capability', 'adequate')
        if staff_capability == 'inadequate':
            risk_score += 15
            evidence.append("人员能力不足")

        # 时间压力
        if context.get('time_pressure', False):
            risk_score += 10
            evidence.append("时间紧迫")

        # 系统影响
        if target.get('affects_production', False):
            risk_score += 15
            evidence.append("影响生产系统")

        risk_score = min(100, risk_score)

        return RiskItem(
            category=RiskCategory.OPERATIONAL_RISK,
            name="运营中断风险",
            description="反击行动可能影响正常运营的风险",
            severity=self._score_to_severity(risk_score),
            likelihood=min(1.0, risk_score / 100),
            impact=risk_score / 100,
            risk_score=risk_score,
            mitigation="选择低影响时间执行，准备运营恢复方案",
            contingency="快速恢复运营，启动业务连续性计划",
            evidence=evidence
        )

    def _analyze_reputational_risk(self, action_type: str,
                                   target: Dict,
                                   legal_context: Dict) -> RiskItem:
        """分析声誉风险"""
        risk_score = 25.0
        evidence = []

        # 公众可见度
        if legal_context.get('high_public_visibility', False):
            risk_score += 15
            evidence.append("高公众可见度")

        # 动作类型
        if action_type in ['counterattack', 'deception']:
            risk_score += 20
            evidence.append("主动反击可能引发争议")

        # 目标类型
        if target.get('is_government', False):
            risk_score += 10
            evidence.append("政府目标敏感")

        risk_score = min(100, risk_score)

        return RiskItem(
            category=RiskCategory.REPUTATIONAL_RISK,
            name="声誉损害风险",
            description="反击行动可能损害组织声誉的风险",
            severity=self._score_to_severity(risk_score),
            likelihood=min(1.0, risk_score / 100),
            impact=risk_score / 100,
            risk_score=risk_score,
            mitigation="谨慎选择行动时机，准备公关应对方案",
            contingency="发布声明，透明沟通",
            evidence=evidence
        )

    def _analyze_escalation_risk(self, action_type: str,
                                 attack_info: Dict) -> RiskItem:
        """分析升级风险"""
        risk_score = 40.0
        evidence = []

        # 主动攻击
        if action_type in ['counterattack', 'reverse_penetration']:
            risk_score += 30
            evidence.append("主动攻击可能导致报复")

        # 攻击者背景
        attacker_background = attack_info.get('attacker_background', 'unknown')
        if attacker_background in ['nation_state', 'apt']:
            risk_score += 25
            evidence.append("高级威胁行为者可能导致升级")

        # 攻击规模
        if attack_info.get('attack_scale', 'small') == 'large':
            risk_score += 15
            evidence.append("大规模攻击可能引发更大报复")

        risk_score = min(100, risk_score)

        return RiskItem(
            category=RiskCategory.ESCALATION_RISK,
            name="冲突升级风险",
            description="反击行动可能导致冲突升级的风险",
            severity=self._score_to_severity(risk_score),
            likelihood=min(1.0, risk_score / 100),
            impact=risk_score / 100,
            risk_score=risk_score,
            mitigation="限制反击强度，避免针对性攻击",
            contingency="准备危机应对方案，寻求外交解决",
            evidence=evidence
        )

    def _analyze_collateral_risk(self, action_type: str,
                                target: Dict) -> RiskItem:
        """分析附带损害风险"""
        risk_score = 30.0
        evidence = []

        # 动作类型
        if action_type in ['block', 'flood', 'disrupt']:
            risk_score += 20
            evidence.append("阻断类动作可能影响无辜方")

        # 目标位置
        if target.get('shared_infrastructure', False):
            risk_score += 25
            evidence.append("共享基础设施增加附带损害风险")

        # 目标精确度
        if not target.get('precise_targeting', True):
            risk_score += 15
            evidence.append("目标定位不精确")

        risk_score = min(100, risk_score)

        return RiskItem(
            category=RiskCategory.COLLATERAL_RISK,
            name="附带损害风险",
            description="反击行动可能伤害无辜第三方的风险",
            severity=self._score_to_severity(risk_score),
            likelihood=min(1.0, risk_score / 100),
            impact=risk_score / 100,
            risk_score=risk_score,
            mitigation="精确打击，选择性攻击",
            contingency="道歉和赔偿，准备第三方声明",
            evidence=evidence
        )

    def _analyze_attribution_risk(self, action_type: str,
                                 attack_info: Dict) -> RiskItem:
        """分析归因风险"""
        risk_score = 20.0
        evidence = []

        # 匿名性
        if attack_info.get('attacker_anonymous', True):
            risk_score += 15
            evidence.append("攻击者使用匿名手段")

        # 反追踪能力
        if attack_info.get('attacker_counterintel', False):
            risk_score += 20
            evidence.append("攻击者具有反情报能力")

        risk_score = min(100, risk_score)

        return RiskItem(
            category=RiskCategory.ATTRIBUTION_RISK,
            name="身份暴露风险",
            description="反击行动可能暴露自身身份的风险",
            severity=self._score_to_severity(risk_score),
            likelihood=min(1.0, risk_score / 100),
            impact=risk_score / 100,
            risk_score=risk_score,
            mitigation="使用匿名化技术，隐藏行动痕迹",
            contingency="否认关联，准备身份保护方案",
            evidence=evidence
        )

    def _analyze_resource_risk(self, action_type: str,
                               context: Dict) -> RiskItem:
        """分析资源风险"""
        risk_score = 15.0
        evidence = []

        # 资源充足性
        required = context.get('resources_required', 100)
        available = context.get('resources_available', 100)
        ratio = available / required if required > 0 else 1.0

        if ratio < 0.5:
            risk_score += 30
            evidence.append("资源严重不足")
        elif ratio < 0.8:
            risk_score += 15
            evidence.append("资源略有不足")

        # 预算限制
        if context.get('budget_limited', False):
            risk_score += 10
            evidence.append("预算受限")

        risk_score = min(100, risk_score)

        return RiskItem(
            category=RiskCategory.RESOURCE_RISK,
            name="资源耗尽风险",
            description="反击行动可能耗尽资源的风险",
            severity=self._score_to_severity(risk_score),
            likelihood=min(1.0, risk_score / 100),
            impact=risk_score / 100,
            risk_score=risk_score,
            mitigation="合理配置资源，准备备用资源",
            contingency="优先保障关键行动，寻求额外资源",
            evidence=evidence
        )

    def _score_to_severity(self, score: float) -> RiskSeverity:
        """分数转严重程度"""
        if score < 20:
            return RiskSeverity.NEGLIGIBLE
        elif score < 40:
            return RiskSeverity.LOW
        elif score < 60:
            return RiskSeverity.MEDIUM
        elif score < 80:
            return RiskSeverity.HIGH
        else:
            return RiskSeverity.CRITICAL

    def _determine_risk_level(self, score: float) -> str:
        """确定风险等级"""
        if score < 30:
            return "低风险"
        elif score < 50:
            return "中风险"
        elif score < 70:
            return "高风险"
        else:
            return "极高风险"

    def _aggregate_mitigations(self, risks: List[RiskItem]) -> List[str]:
        """汇总缓解措施"""
        mitigations = list(set(r.mitigation for r in risks))
        return mitigations

    def _generate_recommendations(self, risks: List[RiskItem],
                                  high_risks: List[RiskItem],
                                  risk_level: str,
                                  action_type: str) -> List[str]:
        """生成建议"""
        recommendations = []

        # 基于风险等级的建议
        if "极高" in risk_level or "高" in risk_level:
            recommendations.append("建议暂缓执行，等待风险降低")
            recommendations.append("增加审批层级")
        else:
            recommendations.append("可在监控下执行")

        # 基于高风险类别的建议
        high_risk_categories = {r.category for r in high_risks}

        if RiskCategory.LEGAL_RISK in high_risk_categories:
            recommendations.append("必须获得法律授权和意见")
            recommendations.append("准备法律应对方案")

        if RiskCategory.ESCALATION_RISK in high_risk_categories:
            recommendations.append("限制反击烈度")
            recommendations.append("准备危机沟通方案")

        if RiskCategory.COLLATERAL_RISK in high_risk_categories:
            recommendations.append("提高目标精确度")
            recommendations.append("避免使用广域攻击手段")

        # 通用建议
        recommendations.append("执行前进行桌面演练")
        recommendations.append("准备完整的回滚方案")
        recommendations.append("确保实时监控")

        return recommendations

    def _assess_proceed_decision(self, high_risks: List[RiskItem],
                                risk_level: str,
                                legal_risk: RiskItem) -> Tuple[bool, List[str]]:
        """评估是否可继续"""
        conditions = []

        # 法律风险检查
        if legal_risk.severity in [RiskSeverity.HIGH, RiskSeverity.CRITICAL]:
            return False, ["法律风险过高，必须获得明确法律授权"]

        # 极高风险
        if "极高" in risk_level:
            return False, ["风险等级过高，不建议执行"]

        # 高风险项检查
        if len(high_risks) > 3:
            return False, ["高风险项过多，需要进一步评估"]

        # 条件通过
        if high_risks:
            for risk in high_risks:
                conditions.append(f"需满足条件: {risk.mitigation}")

        return True, conditions if conditions else ["可在严格监控下执行"]

    def _update_history(self, analysis: RiskAnalysis, plan: Dict):
        """更新历史记录"""
        self.analysis_history.append({
            'overall_risk_score': analysis.overall_risk_score,
            'risk_level': analysis.risk_level,
            'can_proceed': analysis.can_proceed,
            'plan': plan,
            'timestamp': datetime.now().isoformat()
        })

        if len(self.analysis_history) > 500:
            self.analysis_history = self.analysis_history[-400:]


# 独立运行测试
if __name__ == "__main__":
    analyzer = CounterattackRiskAnalyzer()

    # 测试反击计划风险分析
    counterattack_plan = {
        'action_type': 'honeypot',
        'target': {
            'defense_level': 'high',
            'shared_infrastructure': False,
            'affects_production': False,
            'precise_targeting': True
        },
        'attack_info': {
            'cross_border': True,
            'attacker_confirmed': True,
            'attacker_background': 'criminal',
            'attack_scale': 'medium'
        },
        'legal_context': {
            'jurisdiction': 'CN',
            'authorized': False,
            'high_public_visibility': False
        },
        'operational_context': {
            'resource_availability': 0.9,
            'staff_capability': 'adequate',
            'time_pressure': False,
            'budget_limited': False
        }
    }

    analysis = analyzer.analyze(counterattack_plan)
    print("反击风险分析结果:")
    print(f"总体风险评分: {analysis.overall_risk_score}")
    print(f"风险等级: {analysis.risk_level}")
    print(f"可以继续: {analysis.can_proceed}")
    print(f"\n风险分布:")
    for category, score in analysis.breakdown.items():
        print(f"  {category}: {score}")
    print(f"\n高风险项:")
    for risk in analysis.high_risks:
        print(f"  - {risk.name} ({risk.severity.name})")
    print(f"\n条件:")
    for cond in analysis.conditions:
        print(f"  - {cond}")
    print(f"\n建议:")
    for rec in analysis.recommendations:
        print(f"  - {rec}")
