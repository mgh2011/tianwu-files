"""
行为捕获模块
Behavior Capture Module

提供蜜罐行为捕获功能
"""

__version__ = "v3.0.0"
__all__ = []
