"""
定时测评引擎模块
Scheduled Assessment Engine Module

提供周期性能力测评功能
"""

__version__ = "v3.0.0"
__all__ = []
