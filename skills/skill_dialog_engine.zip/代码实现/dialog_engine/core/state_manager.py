# dialog_engine/core/state_manager.py
"""
对话状态管理器
负责管理对话状态的转换、持久化和历史记录
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable
from collections import defaultdict

from ..models.data_models import DialogState, Session, DialogContext


logger = logging.getLogger(__name__)


class StateTransition:
    """状态转换定义"""
    
    def __init__(self, from_state: DialogState, to_state: DialogState, 
                 event: str, condition: Optional[Callable] = None,
                 action: Optional[Callable] = None):
        self.from_state = from_state
        self.to_state = to_state
        self.event = event
        self.condition = condition
        self.action = action
    
    def can_transition(self) -> bool:
        """检查是否满足转换条件"""
        if self.condition is None:
            return True
        return self.condition()


class StateMachine:
    """状态机"""
    
    def __init__(self, initial_state: DialogState):
        self.current_state = initial_state
        self.transitions: Dict[str, List[StateTransition]] = defaultdict(list)
        self.state_history: List[Dict] = []
        
    def add_transition(self, transition: StateTransition):
        """添加状态转换"""
        key = f"{transition.from_state.value}_{transition.event}"
        self.transitions[key].append(transition)
    
    def trigger(self, event: str) -> bool:
        """触发状态转换"""
        key = f"{self.current_state.value}_{event}"
        possible_transitions = self.transitions.get(key, [])
        
        for transition in possible_transitions:
            if transition.can_transition():
                old_state = self.current_state
                self.current_state = transition.to_state
                
                # 记录历史
                self.state_history.append({
                    "from_state": old_state.value,
                    "to_state": transition.to_state.value,
                    "event": event,
                    "timestamp": datetime.now().isoformat()
                })
                
                # 执行动作
                if transition.action:
                    try:
                        transition.action()
                    except Exception as e:
                        logger.error(f"State transition action error: {e}")
                
                logger.info(f"State transition: {old_state.value} -> {transition.to_state.value} (event: {event})")
                return True
        
        logger.warning(f"No valid transition for event '{event}' from state '{self.current_state.value}'")
        return False


class DialogStateManager:
    """
    对话状态管理器
    管理对话状态转换、状态持久化和状态历史
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.sessions: Dict[str, Session] = {}
        self.state_machines: Dict[str, StateMachine] = {}
        self.state_history: Dict[str, List[Dict]] = defaultdict(list)
        self.state_listeners: List[Callable] = []
        self.max_history = self.config.get("max_state_history", 100)
        
        # 初始化状态转换规则
        self._init_transitions()
        
    def _init_transitions(self):
        """初始化默认状态转换规则"""
        self.transition_rules = {
            (DialogState.INIT, "start"): DialogState.WAITING_INTENT,
            (DialogState.INIT, "message"): DialogState.WAITING_INTENT,
            (DialogState.WAITING_INTENT, "intent_recognized"): DialogState.INTENT_CONFIRMED,
            (DialogState.WAITING_INTENT, "timeout"): DialogState.ERROR,
            (DialogState.INTENT_CONFIRMED, "slots_incomplete"): DialogState.COLLECTING_SLOTS,
            (DialogState.INTENT_CONFIRMED, "slots_complete"): DialogState.EXECUTING,
            (DialogState.COLLECTING_SLOTS, "slot_filled"): DialogState.CONFIRMING,
            (DialogState.COLLECTING_SLOTS, "cancel"): DialogState.COMPLETED,
            (DialogState.CONFIRMING, "confirmed"): DialogState.EXECUTING,
            (DialogState.CONFIRMING, "denied"): DialogState.COMPLETED,
            (DialogState.EXECUTING, "success"): DialogState.RESPONDING,
            (DialogState.EXECUTING, "failure"): DialogState.ERROR,
            (DialogState.RESPONDING, "complete"): DialogState.ACTIVE,
            (DialogState.ERROR, "retry"): DialogState.WAITING_INTENT,
            (DialogState.ERROR, "abort"): DialogState.COMPLETED,
            (DialogState.ACTIVE, "message"): DialogState.WAITING_INTENT,
            (DialogState.ACTIVE, "end"): DialogState.COMPLETED,
            (DialogState.ACTIVE, "timeout"): DialogState.EXPIRED,
            (DialogState.EXPIRED, "resume"): DialogState.ACTIVE,
        }
    
    def create_session(self, session_id: str, user_id: str, 
                       initial_state: DialogState = None,
                       timeout: int = 1800) -> Session:
        """
        创建新会话
        
        Args:
            session_id: 会话ID
            user_id: 用户ID
            initial_state: 初始状态
            timeout: 超时时间(秒)
            
        Returns:
            Session: 创建的会话对象
        """
        if session_id in self.sessions:
            logger.warning(f"Session {session_id} already exists, returning existing session")
            return self.sessions[session_id]
        
        state = initial_state or DialogState.INIT
        session = Session(
            session_id=session_id,
            user_id=user_id,
            state=state,
            expires_at=datetime.now() + timedelta(seconds=timeout)
        )
        
        # 创建状态机
        self.state_machines[session_id] = StateMachine(state)
        self._setup_default_transitions(session_id)
        
        # 初始化槽位状态历史
        self.state_history[session_id] = []
        
        self.sessions[session_id] = session
        logger.info(f"Created session: {session_id} for user: {user_id}")
        
        self._notify_listeners(session_id, "session_created", session)
        
        return session
    
    def _setup_default_transitions(self, session_id: str):
        """设置默认状态转换"""
        machine = self.state_machines[session_id]
        
        for (from_state, event), to_state in self.transition_rules.items():
            transition = StateTransition(
                from_state=from_state,
                to_state=to_state,
                event=event
            )
            machine.add_transition(transition)
    
    def get_session(self, session_id: str) -> Optional[Session]:
        """获取会话"""
        return self.sessions.get(session_id)
    
    def get_state(self, session_id: str) -> Optional[DialogState]:
        """获取当前状态"""
        session = self.sessions.get(session_id)
        if session:
            return session.state
        return None
    
    def transition(self, session_id: str, event: str) -> bool:
        """
        触发状态转换
        
        Args:
            session_id: 会话ID
            event: 触发事件
            
        Returns:
            bool: 是否转换成功
        """
        session = self.sessions.get(session_id)
        if not session:
            logger.error(f"Session {session_id} not found")
            return False
        
        machine = self.state_machines.get(session_id)
        if not machine:
            logger.error(f"State machine for session {session_id} not found")
            return False
        
        old_state = session.state
        success = machine.trigger(event)
        
        if success:
            session.state = machine.current_state
            session.last_active_at = datetime.now()
            
            # 记录状态历史
            self._record_state_history(session_id, old_state, session.state, event)
            
            self._notify_listeners(session_id, "state_changed", {
                "old_state": old_state,
                "new_state": session.state,
                "event": event
            })
        
        return success
    
    def _record_state_history(self, session_id: str, old_state: DialogState,
                               new_state: DialogState, event: str):
        """记录状态历史"""
        record = {
            "from_state": old_state.value,
            "to_state": new_state.value,
            "event": event,
            "timestamp": datetime.now().isoformat()
        }
        
        history = self.state_history[session_id]
        history.append(record)
        
        # 限制历史记录长度
        if len(history) > self.max_history:
            history.pop(0)
    
    def get_state_history(self, session_id: str) -> List[Dict]:
        """获取状态历史"""
        return self.state_history.get(session_id, [])
    
    def update_state_metadata(self, session_id: str, key: str, value: any):
        """更新状态元数据"""
        session = self.sessions.get(session_id)
        if session:
            session.metadata[key] = value
            session.last_active_at = datetime.now()
    
    def extend_session(self, session_id: str, additional_seconds: int) -> bool:
        """延长会话超时"""
        session = self.sessions.get(session_id)
        if session and session.expires_at:
            session.expires_at += timedelta(seconds=additional_seconds)
            return True
        return False
    
    def end_session(self, session_id: str) -> bool:
        """结束会话"""
        session = self.sessions.get(session_id)
        if session:
            self.transition(session_id, "end")
            session.state = DialogState.COMPLETED
            self._notify_listeners(session_id, "session_ended", session)
            logger.info(f"Ended session: {session_id}")
            return True
        return False
    
    def cleanup_expired_sessions(self) -> List[str]:
        """清理过期会话"""
        now = datetime.now()
        expired_ids = []
        
        for session_id, session in list(self.sessions.items()):
            if session.expires_at and session.expires_at < now:
                self.end_session(session_id)
                expired_ids.append(session_id)
        
        if expired_ids:
            logger.info(f"Cleaned up {len(expired_ids)} expired sessions")
        
        return expired_ids
    
    def add_state_listener(self, listener: Callable):
        """添加状态监听器"""
        if listener not in self.state_listeners:
            self.state_listeners.append(listener)
    
    def remove_state_listener(self, listener: Callable):
        """移除状态监听器"""
        if listener in self.state_listeners:
            self.state_listeners.remove(listener)
    
    def _notify_listeners(self, session_id: str, event: str, data: any):
        """通知监听器"""
        for listener in self.state_listeners:
            try:
                listener(session_id, event, data)
            except Exception as e:
                logger.error(f"State listener error: {e}")
    
    def get_all_sessions(self) -> List[Session]:
        """获取所有会话"""
        return list(self.sessions.values())
    
    def get_active_session_count(self) -> int:
        """获取活跃会话数"""
        return sum(1 for s in self.sessions.values() 
                   if s.state not in [DialogState.COMPLETED, DialogState.EXPIRED])
    
    def is_valid_transition(self, from_state: DialogState, event: str) -> bool:
        """检查是否为有效转换"""
        return (from_state, event) in self.transition_rules
