"""
防护系统 - WAF Web应用防火墙
Web Application Firewall
"""

import re
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


class WAFModule:
    """
    Web应用防火墙
    
    检测和阻断Web攻击
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # WAF规则
        self._waf_rules = {
            'sqli': {
                'patterns': [
                    r"('\"|(\''))",
                    r"union\s+select",
                    r"load_file\(",
                    r"into\s+outfile",
                ],
                'severity': 'HIGH'
            },
            'xss': {
                'patterns': [
                    r"<script",
                    r"javascript:",
                    r"on\w+\s*=",
                    r"<iframe",
                ],
                'severity': 'MEDIUM'
            },
            'lfi': {
                'patterns': [
                    r"\.\./",
                    r"/etc/passwd",
                    r"c:\\windows",
                ],
                'severity': 'HIGH'
            },
            'rce': {
                'patterns': [
                    r"system\(",
                    r"exec\(",
                    r"passthru\(",
                    r"shell_exec\(",
                ],
                'severity': 'CRITICAL'
            }
        }
    
    def check(self, request: Dict) -> Dict:
        """检查Web攻击"""
        url = request.get('url', '')
        params = request.get('params', {})
        headers = request.get('headers', {})
        body = request.get('body', '')
        
        detections = []
        threat_score = 0.0
        
        # 检查URL和参数
        all_data = url + '?' + '&'.join(f"{k}={v}" for k, v in params.items()) + body
        
        for attack_type, rule in self._waf_rules.items():
            for pattern in rule['patterns']:
                if re.search(pattern, all_data, re.IGNORECASE):
                    detections.append(attack_type)
                    severity_weight = {'CRITICAL': 1.0, 'HIGH': 0.8, 'MEDIUM': 0.5}.get(rule['severity'], 0.3)
                    threat_score = max(threat_score, severity_weight)
                    break
        
        return {
            'detected': len(detections) > 0,
            'threat_score': threat_score,
            'attack_types': detections,
            'blocked': threat_score >= 0.8
        }


if __name__ == '__main__':
    print("WAF模块测试")
    
    waf = WAFModule(None, None)
    
    result = waf.check({
        'url': '/search',
        'params': {'q': "admin' OR 1=1--"},
        'body': ''
    })
    
    print(f"攻击检测: {'是' if result['detected'] else '否'}")
    print(f"攻击类型: {result['attack_types']}")
