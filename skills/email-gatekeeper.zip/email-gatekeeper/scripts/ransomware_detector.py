# ========== 勒索邮件检测器 v3.3.0 ==========
# 文件: scripts/ransomware_detector.py
# 版本: 3.3.0 (2024-2025全面优化版)
# 功能: 勒索软件和勒索邮件深度检测

"""
勒索邮件/软件检测器 v3.3.0
==========================

核心能力：
1. 加密货币勒索检测 - 比特币钱包地址、交易所要求
2. 文件威胁检测 - 声称已加密/将删除文件
3. 隐私威胁检测 - 摄像头录像、密码泄露威胁
4. 色情勒索(Sextortion)检测 - 声称有私密照片/视频
5. 商务威胁检测 - 威胁公开信息、散布谣言
6. 恐吓攻击检测 - 冒充执法机构、法律威胁
7. 新型勒索手段检测 (v3.3.0新增)
8. 邮件头深度分析 (v3.3.0新增)

v3.3.0 数据库扩展：
- 勒索关键词库: 150+
- 加密货币勒索模式: 50+
- 色情勒索模式: 60+
- 新型勒索手段: 40+

合规说明：
- 本地检测，不传输勒索内容
- 严格隐私保护，不存储敏感信息
- 合规审计日志
- 建议联系执法机构
"""

import re
import logging
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from datetime import datetime

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ========== 数据结构定义 ==========

@dataclass
class RansomwareCheckResult:
    """勒索检测结果"""
    is_ransomware: bool = False
    ransomware_type: str = ""  # crypto_ransom/sextortion/business_threat/fake_legal/malware_threat
    confidence: int = 0
    indicators: List[str] = field(default_factory=list)
    threat_details: Dict = field(default_factory=dict)
    payment_info: Dict = field(default_factory=dict)  # 检测到的支付信息
    recommended_action: str = "report_to_authorities"


# ========== 勒索关键词库 v3.3.0 (扩展到150+) ==========

RANSOMWARE_KEYWORDS = {
    # ============ 加密货币勒索 (50+) ============
    "bitcoin": 85, "btc": 82, "ethereum": 80, "eth": 78, "cryptocurrency": 82,
    "bitcoin address": 90, "wallet address": 88, "crypto wallet": 85, "send bitcoin": 95,
    "比特币": 85, "以太坊": 82, "加密货币": 80, "虚拟币": 78,
    "钱包地址": 88, "收款地址": 85, "转账地址": 82, "区块链地址": 80,
    "打币": 88, "充币": 82, "提币": 78, "数字货币钱包": 85,
    "usdt": 80, "tether": 78, "ripple": 75, "xrp": 75,
    "litecoin": 78, "dogecoin": 80, "bnb": 75, "solana": 75,
    "钱包": 70, "转入": 75, "转出": 70, "充值地址": 82,
    "区块链": 65, "链上": 60, "交易所": 70,
    
    # ============ 文件威胁 (40+) ============
    "encrypted": 80, "encrypt": 78, "ransomware": 92, "decryption key": 90,
    "all your files": 88, "every file": 85, "all data": 82, "delete your files": 95,
    "格式化": 85, "删除所有": 90, "文件丢失": 82, "数据损坏": 85,
    "锁定文件": 92, "无法打开": 80, "文件已损坏": 85, "永久删除": 90,
    "解密": 82, "密钥": 78, "密码": 65, "解锁密码": 85,
    "file encryption": 88, "data encryption": 85, "locked files": 90,
    "文件加密": 88, "数据锁定": 85, "无法访问": 78,
    "恢复文件": 75, "解密工具": 80, "解锁工具": 78,
    "your data": 75, "your files": 72, "your documents": 70,
    
    # ============ 色情勒索/隐私威胁 (60+) ============
    "webcam": 80, "camera": 75, "recorded": 82, "recording you": 88,
    "naked": 90, "compromising": 85, "adult video": 88, "porn": 82,
    "私密": 78, "裸照": 90, "艳照": 92, "不雅照": 90,
    "摄像头": 80, "录像": 82, "偷拍": 88, "监控录像": 85,
    "私密视频": 90, "成人视频": 88, "黄色视频": 85, "色情照片": 90,
    "私密时刻": 92, "偷情": 95, "出轨": 95, "不忠": 90,
    "compromising footage": 92, "private moments": 90, "intimate photos": 95,
    "sexual content": 88, "adult content": 85, "xxx": 80,
    "screen record": 82, "screen capture": 80, "screen shot": 78,
    "聊天记录": 88, "通话录音": 85, "视频通话": 82,
    
    # ============ 恐吓威胁 (30+) ============
    "arrest": 75, "prosecute": 78, "lawsuit": 72, "legal action": 70,
    "fbi": 85, "police": 78, "irs": 82, "government": 70,
    "逮捕": 80, "起诉": 78, "法律": 65, "警察": 72,
    "FBI": 85, "国安": 78, "网警": 82, "经侦": 75,
    "send to prison": 88, "jail time": 85, "prison sentence": 82,
    "执法部门": 80, "检察机关": 78, "公安机关": 82,
    "国家安全": 75, "泄露机密": 80, "危害国家安全": 88,
    
    # ============ 商务威胁 (25+) ============
    "expose": 80, "leak": 82, "reveal": 78, "disclose": 75,
    "曝光": 85, "泄露": 82, "公开": 78, "散布": 80,
    "trade secret": 88, "confidential": 85, "proprietary": 82,
    "商业秘密": 88, "机密文件": 85, "内部资料": 82,
    "damage reputation": 85, "ruin business": 88, "destroy company": 90,
    "毁坏名誉": 85, "搞垮公司": 88, "让公司倒闭": 90,
    "competitor": 75, "sell to rival": 82, "give to enemy": 85,
    "竞争对手": 75, "敌对势力": 82, "商业间谍": 85,
    
    # ============ 新型勒索手段 (40+) (v3.3.0新增) ============
    "password reset": 78, "reset your password": 80, "password compromised": 85,
    "账号密码": 82, "密码泄露": 85, "密码被破解": 88,
    "data breach": 88, "data leak": 85, "information leaked": 82,
    "数据泄露": 88, "信息泄露": 85, "隐私曝光": 90,
    "account hacked": 85, "account compromised": 88, "hacked your": 90,
    "入侵": 82, "被黑": 85, "黑客攻击": 88, "渗透": 80,
    "social media": 75, "post online": 78, "share with friends": 82,
    "社交媒体": 75, "发到网上": 78, "群发": 80, "公开处刑": 88,
    "doxxing": 92, "dox": 90, "personal information": 82,
    "社工库": 88, "人肉搜索": 90, "开盒": 92,
    "malware": 80, "trojan": 82, "keylogger": 85, "spyware": 85,
    "木马": 82, "病毒": 78, "键盘记录": 88, "间谍软件": 85,
    
    # ============ 时间压力 (25+) ============
    "48 hours": 88, "72 hours": 90, "24 hours": 85,
    "within 24": 85, "within 48": 88, "within 72": 90,
    "48小时": 88, "72小时": 90, "24小时": 85,
    "限时": 82, "截止": 80, "过期": 75, "倒计时": 85,
    "time is running": 82, "running out": 80, "urgent": 78,
    "今天": 75, "今日": 72, "立刻": 80, "马上": 78,
    "deadline": 80, "expires": 78, "last chance": 85,
}


# ========== 加密货币地址模式库 v3.3.0 (扩展) ==========

CRYPTO_ADDRESS_PATTERNS = {
    "bitcoin": {
        "patterns": [
            r'\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b',  # P2PKH
            r'\b[bc1][a-zA-HJ-NP-Z1-9]{25,89}\b',   # Bech32
            r'\b[0-9a-zA-Z]{34}\b',                   # 通用34位
        ],
        "weight": 95,
        "description": "Bitcoin地址"
    },
    "ethereum": {
        "patterns": [
            r'\b0x[a-fA-F0-9]{40}\b',
            r'\b0x[a-fA-F0-9]{64}\b',  # 某些合约
        ],
        "weight": 92,
        "description": "Ethereum地址"
    },
    "litecoin": {
        "patterns": [
            r'\bL[a-km-zA-HJ-NP-Z1-9]{32,33}\b',
            r'\bltc1[a-zA-HJ-NP-Z1-9]{39,59}\b',
        ],
        "weight": 88,
        "description": "Litecoin地址"
    },
    "ripple": {
        "patterns": [
            r'\bX[a-zA-Z0-9]{33}\b',
            r'\br[a-zA-Z0-9]{24,34}\b',
        ],
        "weight": 85,
        "description": "Ripple地址"
    },
    "dogecoin": {
        "patterns": [
            r'\bD[5-9A-HJ-NP-U][1-9A-HJ-NP-Za-km-z]{32}\b',
        ],
        "weight": 82,
        "description": "Dogecoin地址"
    },
    "usdt": {
        "patterns": [
            r'\b0x[a-fA-F0-9]{40}\b.*USDT',
            r'\bUSDT.*\b0x[a-fA-F0-9]{40}\b',
        ],
        "weight": 88,
        "description": "USDT (TRC20)"
    },
}


# ========== 勒索软件名称库 v3.3.0 (扩展) ==========

RANSOMWARE_NAMES = {
    # 知名勒索软件家族
    "WannaCry": 98, "WannaDecrypt": 98,
    "Locky": 95, "Cerber": 92, "Ryuk": 95,
    "REvil": 95, "Sodinokibi": 95, "DarkSide": 92,
    "Conti": 92, "BlackMatter": 90, "ALPHV": 90,
    "Hive": 90, "BlackCat": 88, "Clop": 90,
    "Avaddon": 88, "Babuk": 88, "Egregor": 88,
    "Phobos": 88, "Ironscale": 85, "Magniber": 85,
    "Medusa": 85, "AvosLocker": 88, "Hive": 88,
    # 勒索软件通用词
    "ransom": 80, "ransomware": 92, "decryptor": 85,
    "赎金": 90, "勒索": 85, "解密": 78,
}


# ========== 勒索检测器主类 ==========

class RansomwareDetector:
    """
    勒索邮件/软件检测器 v3.3.0
    
    勒索攻击类型：
    1. 加密货币勒索 - 要求BTC/ETH支付赎金
    2. Sextortion色情勒索 - 声称有私密照片/视频
    3. 商务威胁 - 威胁公开信息、散布谣言
    4. 假冒执法 - 冒充FBI/警察/税务局
    5. 恶意软件威胁 - 声称已控制电脑
    6. 新型勒索 - 密码泄露/数据泄露威胁 (v3.3.0新增)
    
    合规处理：
    - 建议用户联系执法机构
    - 不与攻击者互动
    - 记录检测日志
    """
    
    VERSION = "3.3.0"
    
    def __init__(self, config: Dict = None):
        """初始化勒索检测器"""
        self.config = config or {}
        self._init_databases()
        
        logger.info(f"✅ 勒索检测器初始化完成 (v{self.VERSION})")
    
    def _init_databases(self):
        """初始化所有数据库"""
        # 勒索关键词库
        self.ransomware_keywords = RANSOMWARE_KEYWORDS
        
        # 加密货币地址模式
        self.crypto_patterns = CRYPTO_ADDRESS_PATTERNS
        
        # 勒索软件名称
        self.ransomware_names = RANSOMWARE_NAMES
        
        # 勒索子类型
        self.ransomware_subtypes = {
            "crypto_ransom": [
                "bitcoin", "wallet", "crypto", "比特币", "钱包",
                "加密货币", "转账地址", "usdt",
            ],
            "sextortion": [
                "webcam", "camera", "naked", "compromising",
                "私密", "裸照", "偷拍", "成人",
            ],
            "business_threat": [
                "expose", "leak", "trade secret", "business",
                "曝光", "泄露", "商业秘密", "公司",
            ],
            "fake_legal": [
                "fbi", "police", "irs", "arrest", "lawsuit",
                "FBI", "警察", "税务局", "逮捕", "起诉",
            ],
            "malware_threat": [
                "ransomware", "encrypted", "ransom",
                "勒索软件", "加密", "解密",
            ],
            "new_ransom": [
                "password", "data breach", "account hacked",
                "密码泄露", "数据泄露", "入侵", "doxxing",
            ],
        }
        
        # 威胁公开模式
        self.exposure_patterns = [
            (r"(send|share|post|publish|expose)\s+(to|on|in)", "威胁公开"),
            (r"(your\s+)?(friends?|family|contacts?|colleagues?)", "威胁散布"),
            (r"(all\s+)?(contacts?|address\s+book|emails?)", "威胁群发"),
            (r"(youtube|facebook|instagram|tiktok|twitter)", "威胁发布到社交媒体"),
        ]
    
    def detect(self, email_data: Dict) -> RansomwareCheckResult:
        """
        检测勒索邮件
        
        Args:
            email_data: 邮件数据字典
        
        Returns:
            RansomwareCheckResult: 检测结果
        """
        result = RansomwareCheckResult()
        
        sender = email_data.get('sender', '')
        subject = email_data.get('subject', '')
        body = email_data.get('body', '')
        headers = email_data.get('headers', {})
        
        combined = f"{subject} {body}".lower()
        
        # 1. 勒索关键词检测
        keyword_result = self._check_keywords(combined)
        if keyword_result['detected']:
            result.indicators.extend(keyword_result['indicators'])
            result.confidence += keyword_result['confidence']
        
        # 2. 加密货币地址检测
        crypto_result = self._check_crypto_addresses(combined)
        if crypto_result['detected']:
            result.payment_info = crypto_result['payment_info']
            result.confidence += crypto_result['confidence']
            result.indicators.extend(crypto_result['indicators'])
        
        # 3. 勒索软件名称检测
        ransomware_result = self._check_ransomware_names(combined)
        if ransomware_result['detected']:
            result.confidence += ransomware_result['confidence']
            result.indicators.extend(ransomware_result['indicators'])
        
        # 4. 威胁公开模式检测
        exposure_result = self._check_exposure_threats(combined)
        if exposure_result['detected']:
            result.confidence += exposure_result['confidence']
            result.indicators.extend(exposure_result['indicators'])
        
        # 5. 时间压力检测
        time_result = self._check_time_pressure(combined)
        if time_result['detected']:
            result.confidence += time_result['confidence']
            result.indicators.extend(time_result['indicators'])
        
        # 6. 发件人分析
        sender_result = self._analyze_sender(sender)
        if sender_result['detected']:
            result.confidence += sender_result['confidence']
            result.indicators.extend(sender_result['indicators'])
        
        # 确保置信度在有效范围
        result.confidence = min(100, result.confidence)
        
        # 判断是否为勒索
        if result.confidence >= 50:
            result.is_ransomware = True
            result.ransomware_type = self._determine_ransomware_type(result, combined)
        
        # 威胁详情
        result.threat_details = {
            'total_indicators': len(result.indicators),
            'payment_demands': len(result.payment_info),
            'urgency_level': 'high' if any(x in combined for x in ['24', '48', '72', '小时']) else 'medium',
        }
        
        # 推荐操作
        result.recommended_action = self._determine_action(result)
        
        return result
    
    def _check_keywords(self, text: str) -> Dict:
        """检测勒索关键词"""
        result = {
            'detected': False,
            'confidence': 0,
            'indicators': [],
        }
        
        matched = []
        for keyword, weight in self.ransomware_keywords.items():
            if keyword.lower() in text:
                matched.append((keyword, weight))
                result['detected'] = True
        
        # 按权重排序，取前15个
        matched.sort(key=lambda x: x[1], reverse=True)
        for keyword, weight in matched[:15]:
            result['confidence'] += weight // 8
            result['indicators'].append(f"勒索关键词: {keyword}")
        
        return result
    
    def _check_crypto_addresses(self, text: str) -> Dict:
        """检测加密货币地址"""
        result = {
            'detected': False,
            'confidence': 0,
            'indicators': [],
            'payment_info': {},
        }
        
        for crypto_name, info in self.crypto_patterns.items():
            for pattern in info['patterns']:
                matches = re.findall(pattern, text)
                if matches:
                    result['detected'] = True
                    result['confidence'] += info['weight']
                    result['indicators'].append(f"检测到{crypto_name}地址: {matches[0][:10]}...")
                    result['payment_info'][crypto_name] = len(matches)
        
        # 检测赎金金额描述
        amount_patterns = [
            r'\$\d+', r'USD\s*\d+', r'\d+\s*(dollars?|usd)',
            r'¥\d+', r'\d+\s*(人民币|元)', r'\d+\s*(bitcoin|btc)',
            r'\d+\s*(ethereum|eth)', r'\d+\s*(个)?(比特币|以太)',
        ]
        
        for pattern in amount_patterns:
            match = re.search(pattern, text)
            if match:
                result['detected'] = True
                result['confidence'] += 30
                result['indicators'].append(f"检测到赎金金额描述: {match.group()}")
        
        return result
    
    def _check_ransomware_names(self, text: str) -> Dict:
        """检测勒索软件名称"""
        result = {
            'detected': False,
            'confidence': 0,
            'indicators': [],
        }
        
        for name, weight in self.ransomware_names.items():
            if name.lower() in text:
                result['detected'] = True
                result['confidence'] += weight
                result['indicators'].append(f"提及勒索软件: {name}")
        
        return result
    
    def _check_exposure_threats(self, text: str) -> Dict:
        """检测威胁公开模式"""
        result = {
            'detected': False,
            'confidence': 0,
            'indicators': [],
        }
        
        for pattern, description in self.exposure_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                result['detected'] = True
                result['confidence'] += 20
                result['indicators'].append(description)
        
        return result
    
    def _check_time_pressure(self, text: str) -> Dict:
        """检测时间压力"""
        result = {
            'detected': False,
            'confidence': 0,
            'indicators': [],
        }
        
        time_patterns = [
            (r'48\s*hours?', 40),
            (r'72\s*hours?', 45),
            (r'24\s*hours?', 35),
            (r'within\s+\d+', 30),
            (r'(today|tonight)', 25),
            (r'(expires?|deadline)', 30),
            (r'48小时', 40),
            (r'72小时', 45),
            (r'24小时', 35),
            (r'限时', 30),
        ]
        
        for pattern, weight in time_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                result['detected'] = True
                result['confidence'] += weight
                result['indicators'].append("存在时间压力")
        
        return result
    
    def _analyze_sender(self, sender: str) -> Dict:
        """分析发件人"""
        result = {
            'detected': False,
            'confidence': 0,
            'indicators': [],
        }
        
        if not sender:
            return result
        
        # 检查发件人域名是否可疑
        suspicious_domains = ['.tk', '.ml', '.ga', '.xyz', '.top']
        
        if '@' in sender:
            domain = sender.split('@')[-1]
            tld = '.' + domain.split('.')[-1] if '.' in domain else ''
            
            if tld in suspicious_domains:
                result['detected'] = True
                result['confidence'] += 15
                result['indicators'].append(f"发件人使用可疑域名: {domain}")
        
        # 检查发件人名称是否可疑
        suspicious_names = ['hacker', 'attacker', 'darkweb', 'anonymous', 'h4ck']
        for name in suspicious_names:
            if name in sender.lower():
                result['detected'] = True
                result['confidence'] += 30
                result['indicators'].append(f"发件人名称可疑: {name}")
        
        return result
    
    def _determine_ransomware_type(self, result: RansomwareCheckResult, text: str) -> str:
        """确定勒索攻击类型"""
        indicators_text = ' '.join(result.indicators).lower()
        
        # 按优先级判断
        if 'bitcoin' in indicators_text or '加密货币' in indicators_text:
            return "crypto_ransom"
        if '私密' in text or '裸照' in text or 'naked' in text:
            return "sextortion"
        if any(word in text for word in ['expose', 'leak', '曝光', '泄露']):
            return "business_threat"
        if any(word in text for word in ['fbi', 'police', '警察', 'FBI']):
            return "fake_legal"
        if 'ransomware' in text or '加密' in text:
            return "malware_threat"
        
        # 检查付款信息
        if result.payment_info:
            return "crypto_ransom"
        
        return "general_ransomware"
    
    def _determine_action(self, result: RansomwareCheckResult) -> str:
        """确定推荐操作"""
        if result.confidence >= 80:
            return "block_and_report"
        elif result.confidence >= 60:
            return "quarantine_and_report"
        else:
            return "manual_review"


# ========== 便捷函数 ==========

def detect_ransomware(email_data: Dict) -> RansomwareCheckResult:
    """
    便捷函数：检测勒索邮件
    
    Args:
        email_data: 邮件数据字典
    
    Returns:
        RansomwareCheckResult: 检测结果
    """
    detector = RansomwareDetector()
    return detector.detect(email_data)


# ========== 入口点 ==========

if __name__ == "__main__":
    # 示例用法
    email = {
        'sender': 'hacker@darkweb.com',
        'subject': '你的电脑已被控制',
        'body': '''
        We have full control of your computer.
        We recorded you through your webcam while you were visiting adult websites.
        All your files have been encrypted.
        Pay 0.5 BTC to this address within 48 hours or all your data will be deleted.
        ''',
    }
    
    result = detect_ransomware(email)
    
    print(f"勒索攻击: {result.is_ransomware}")
    print(f"类型: {result.ransomware_type}")
    print(f"置信度: {result.confidence}%")
    print(f"支付信息: {result.payment_info}")
    print(f"指标: {result.indicators}")
    print(f"建议操作: {result.recommended_action}")
