# dialog_engine/nlu/intent_classifier.py
"""
意图分类器
支持规则匹配、机器学习、深度学习多种方式
"""

import re
import logging
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime

from ..models.data_models import IntentResult, IntentType, DialogContext
from ..config.default_config import config


logger = logging.getLogger(__name__)


class IntentClassifier:
    """
    多策略意图分类器
    支持规则匹配、机器学习、深度学习多种方式
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        self.config = config_dict or config.INTENT_CLASSIFIER
        self.intent_rules = self.config.get("intent_rules", {})
        self.confidence_threshold = self.config.get("default_confidence_threshold", 0.7)
        self.fallback_intent = self.config.get("fallback_intent", "UNKNOWN")
        self.model_type = self.config.get("model_type", "rule_ml_hybrid")
        
        # 意图-槽位映射
        self.intent_slot_mapping = self._build_intent_slot_mapping()
        
        # 意图策略映射
        self.intent_policy_mapping = self._build_intent_policy_mapping()
        
        # ML模型引用(可选)
        self.ml_model = None
        
    def _build_intent_slot_mapping(self) -> Dict[str, List[str]]:
        """构建意图-槽位映射"""
        return {
            "booking": ["service_type", "date", "time", "location", "contact"],
            "query": ["query_type", "keywords"],
            "payment": ["amount", "payment_method"],
            "refund": ["order_id", "reason"],
            "modification": ["field", "new_value"],
            "cancellation": ["order_id", "reason"],
        }
    
    def _build_intent_policy_mapping(self) -> Dict[str, str]:
        """构建意图-策略映射"""
        return {
            "greeting": "greeting",
            "goodbye": "goodbye",
            "help": "help",
            "query": "query",
            "booking": "booking",
            "payment": "payment",
            "refund": "refund",
            "modification": "modification",
            "cancellation": "cancellation",
            "confirmation": "confirmation",
            "denial": "confirmation",
        }
    
    async def classify(self, text: str, 
                      context: Optional[DialogContext] = None) -> IntentResult:
        """
        意图分类
        
        Args:
            text: 用户输入文本
            context: 对话上下文
            
        Returns:
            IntentResult: 意图识别结果
        """
        text = text.strip().lower()
        
        if self.model_type == "rule":
            return await self.classify_with_rules(text)
        elif self.model_type == "ml":
            return await self.classify_with_ml(text)
        elif self.model_type == "hybrid":
            return await self.hybrid_classify(text)
        elif self.model_type == "rule_ml_hybrid":
            return await self.ensemble_classify(text, context)
        else:
            return await self.classify_with_rules(text)
    
    async def classify_with_rules(self, text: str) -> Optional[IntentResult]:
        """基于规则的意图分类"""
        scores = {}
        
        for intent_name, keywords in self.intent_rules.items():
            score = 0
            for keyword in keywords:
                if keyword.lower() in text:
                    score += 1
            if score > 0:
                scores[intent_name] = score / len(keywords)
        
        if not scores:
            return self._create_unknown_result()
        
        # 选择得分最高的意图
        best_intent = max(scores.items(), key=lambda x: x[1])
        
        return IntentResult(
            intent=IntentType(best_intent[0]),
            confidence=min(best_intent[1] * 1.2, 1.0),  # 加权提升置信度
            requires_slots=self.intent_slot_mapping.get(best_intent[0], []),
            policy_name=self.intent_policy_mapping.get(best_intent[0])
        )
    
    async def classify_with_ml(self, text: str) -> Optional[IntentResult]:
        """
        基于机器学习模型的意图分类
        需要外部接入ML模型服务
        """
        if self.ml_model is None:
            logger.warning("ML model not loaded, falling back to rule-based")
            return await self.classify_with_rules(text)
        
        try:
            # 调用ML模型
            prediction = await self.ml_model.predict(text)
            
            return IntentResult(
                intent=IntentType(prediction["intent"]),
                confidence=prediction["confidence"],
                alternatives=prediction.get("alternatives", []),
                requires_slots=self.intent_slot_mapping.get(prediction["intent"], []),
                policy_name=self.intent_policy_mapping.get(prediction["intent"])
            )
        except Exception as e:
            logger.error(f"ML classification error: {e}")
            return await self.classify_with_rules(text)
    
    async def hybrid_classify(self, text: str) -> IntentResult:
        """
        混合分类
        规则优先，ML辅助
        """
        rule_result = await self.classify_with_rules(text)
        
        if rule_result and rule_result.confidence >= 0.9:
            return rule_result
        
        ml_result = await self.classify_with_ml(text)
        
        if ml_result and ml_result.confidence > rule_result.confidence:
            return ml_result
        
        return rule_result or self._create_unknown_result()
    
    async def ensemble_classify(self, text: str,
                               context: Optional[DialogContext] = None) -> IntentResult:
        """
        集成分类
        结合规则、ML和上下文信息
        """
        results = []
        
        # 1. 规则分类
        rule_result = await self.classify_with_rules(text)
        if rule_result:
            results.append(("rule", rule_result))
        
        # 2. ML分类
        ml_result = await self.classify_with_ml(text)
        if ml_result:
            results.append(("ml", ml_result))
        
        # 3. 上下文推断
        context_intent = self._infer_from_context(context)
        if context_intent:
            results.append(("context", context_intent))
        
        if not results:
            return self._create_unknown_result()
        
        # 4. 综合评分
        final_intent, final_confidence, alternatives = self._ensemble_vote(results)
        
        return IntentResult(
            intent=IntentType(final_intent),
            confidence=final_confidence,
            alternatives=alternatives,
            requires_slots=self.intent_slot_mapping.get(final_intent, []),
            policy_name=self.intent_policy_mapping.get(final_intent)
        )
    
    def _infer_from_context(self, context: Optional[DialogContext]) -> Optional[IntentResult]:
        """从上下文推断意图"""
        if not context or not context.intent:
            return None
        
        # 如果上一轮意图是查询，且当前轮次简短，可能是在追问
        if context.intent.intent == IntentType.QUERY:
            return IntentResult(
                intent=IntentType.CLASSIFICATION,
                confidence=0.5,
                metadata={"inferred_from": "context"}
            )
        
        return None
    
    def _ensemble_vote(self, results: List[Tuple[str, IntentResult]]) -> Tuple[str, float, List[Tuple]]:
        """
        集成投票
        
        Returns:
            (final_intent, final_confidence, alternatives)
        """
        intent_scores: Dict[str, float] = {}
        intent_counts: Dict[str, int] = {}
        
        for source, result in results:
            intent_name = result.intent.value
            weight = self._get_source_weight(source)
            
            if intent_name not in intent_scores:
                intent_scores[intent_name] = 0
                intent_counts[intent_name] = 0
            
            intent_scores[intent_name] += result.confidence * weight
            intent_counts[intent_name] += 1
        
        # 选择加权得分最高的意图
        best_intent = max(intent_scores.items(), key=lambda x: x[1])
        
        # 构建备选列表
        alternatives = sorted(
            [(k, v) for k, v in intent_scores.items() if k != best_intent[0]],
            key=lambda x: x[1],
            reverse=True
        )[:3]
        
        # 调整置信度
        confidence = min(best_intent[1], 1.0)
        
        return best_intent[0], confidence, alternatives
    
    def _get_source_weight(self, source: str) -> float:
        """获取不同来源的权重"""
        weights = {
            "rule": 0.3,
            "ml": 0.5,
            "context": 0.2
        }
        return weights.get(source, 0.2)
    
    def _create_unknown_result(self) -> IntentResult:
        """创建未知意图结果"""
        return IntentResult(
            intent=IntentType.UNKNOWN,
            confidence=0.0,
            requires_slots=[],
            policy_name="fallback"
        )
    
    def set_ml_model(self, model):
        """设置ML模型"""
        self.ml_model = model
    
    def add_intent_rule(self, intent: str, keywords: List[str]):
        """添加意图规则"""
        if intent not in self.intent_rules:
            self.intent_rules[intent] = []
        self.intent_rules[intent].extend(keywords)
        logger.info(f"Added rules for intent: {intent}")
    
    def remove_intent_rule(self, intent: str):
        """移除意图规则"""
        if intent in self.intent_rules:
            del self.intent_rules[intent]
            logger.info(f"Removed rules for intent: {intent}")
    
    def get_intent_keywords(self, intent: str) -> List[str]:
        """获取意图关键词"""
        return self.intent_rules.get(intent, [])
    
    def get_all_intents(self) -> List[str]:
        """获取所有支持的意图"""
        return list(self.intent_rules.keys())
    
    async def batch_classify(self, texts: List[str]) -> List[IntentResult]:
        """批量意图分类"""
        return [await self.classify(text) for text in texts]
