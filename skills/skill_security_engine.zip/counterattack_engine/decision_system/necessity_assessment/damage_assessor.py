"""
损失评估引擎
Damage Assessor - 评估攻击造成的损失
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class DamageCategory(Enum):
    """损失类别"""
    DIRECT_FINANCIAL = "direct_financial"  # 直接经济损失
    INDIRECT_FINANCIAL = "indirect_financial"  # 间接经济损失
    DATA_LOSS = "data_loss"  # 数据损失
    SERVICE_LOSS = "service_loss"  # 服务损失
    REPUTATION_LOSS = "reputation_loss"  # 声誉损失
    COMPLIANCE_LOSS = "compliance_loss"  # 合规损失
    PRODUCTIVITY_LOSS = "productivity_loss"  # 生产力损失
    LEGAL_LOSS = "legal_loss"  # 法律损失


@dataclass
class DamageItem:
    """损失项目"""
    category: DamageCategory
    description: str
    estimated_value: float
    currency: str = "USD"
    confidence: float = 1.0  # 估值置信度
    evidence: List[str] = field(default_factory=list)


@dataclass
class DamageReport:
    """损失报告"""
    total_damage: float
    currency: str
    breakdown: Dict[str, float]
    damage_items: List[DamageItem]
    severity: str
    recovery_cost: float
    business_impact: str
    recommendations: List[str]


class DamageAssessor:
    """损失评估引擎"""

    # 单位成本估算（USD/单位）
    UNIT_COSTS = {
        'per_record_breach': 150,  # 每条泄露记录成本
        'per_hour_downtime': 10000,  # 每小时停机成本
        'per_malware_incident': 2500000,  # 勒索软件平均成本
        'per_ddos_hour': 50000,  # DDoS攻击每小时成本
        'per_credential_compromised': 100,  # 每条凭据泄露成本
        'per_ip_theft': 5000,  # 知识产权盗窃成本
    }

    # 停机成本系数
    DOWNTIME_COST_MULTIPLIERS = {
        'critical': 5.0,  # 关键业务
        'high': 2.5,
        'medium': 1.5,
        'low': 1.0
    }

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化损失评估引擎

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.unit_costs = self.UNIT_COSTS.copy()
        self.assessment_history = []

    def assess(self, incident_data: Dict) -> DamageReport:
        """
        评估损失

        Args:
            incident_data: 事件数据，包含：
                - incident_type: 事件类型
                - duration: 持续时间（秒）
                - data_compromised: 泄露数据量
                - systems_affected: 受影响系统
                - services_affected: 受影响服务
                - credentials_compromised: 泄露凭据数
                - intellectual_property: 是否涉及知识产权
                - compliance_violations: 合规违规情况
                - customer_impact: 客户影响
                - recovery_time: 恢复时间
                - investigation_cost: 调查成本

        Returns:
            损失报告
        """
        incident_type = incident_data.get('incident_type', 'unknown')
        duration = incident_data.get('duration', 0)
        data_compromised = incident_data.get('data_compromised', 0)
        systems_affected = incident_data.get('systems_affected', [])
        services_affected = incident_data.get('services_affected', [])
        credentials_compromised = incident_data.get('credentials_compromised', 0)
        intellectual_property = incident_data.get('intellectual_property', False)
        compliance_violations = incident_data.get('compliance_violations', [])
        customer_impact = incident_data.get('customer_impact', 0)
        recovery_time = incident_data.get('recovery_time', 0)
        investigation_cost = incident_data.get('investigation_cost', 0)

        damage_items = []
        breakdown = {}

        # 1. 直接经济损失
        direct_financial = self._assess_direct_financial(
            incident_type, investigation_cost, data_compromised
        )
        damage_items.append(direct_financial)
        breakdown['direct_financial'] = direct_financial.estimated_value

        # 2. 数据损失
        data_loss = self._assess_data_loss(data_compromised, intellectual_property)
        damage_items.append(data_loss)
        breakdown['data_loss'] = data_loss.estimated_value

        # 3. 服务损失
        service_loss = self._assess_service_loss(
            duration, services_affected, customer_impact
        )
        damage_items.append(service_loss)
        breakdown['service_loss'] = service_loss.estimated_value

        # 4. 凭据泄露损失
        if credentials_compromised > 0:
            credential_loss = self._assess_credential_loss(credentials_compromised)
            damage_items.append(credential_loss)
            breakdown['credential_loss'] = credential_loss.estimated_value

        # 5. 合规损失
        compliance_loss = self._assess_compliance_loss(compliance_violations)
        damage_items.append(compliance_loss)
        breakdown['compliance_loss'] = compliance_loss.estimated_value

        # 6. 声誉损失
        reputation_loss = self._assess_reputation_loss(
            incident_type, customer_impact, data_compromised
        )
        damage_items.append(reputation_loss)
        breakdown['reputation_loss'] = reputation_loss.estimated_value

        # 7. 间接经济损失（基于其他损失估算）
        indirect_financial = self._assess_indirect_financial(breakdown)
        damage_items.append(indirect_financial)
        breakdown['indirect_financial'] = indirect_financial.estimated_value

        # 计算总损失
        total_damage = sum(d.estimated_value * d.confidence for d in damage_items)

        # 计算恢复成本
        recovery_cost = self._estimate_recovery_cost(
            incident_type, systems_affected, recovery_time
        )

        # 确定严重程度
        severity = self._determine_severity(total_damage, incident_type)

        # 评估业务影响
        business_impact = self._assess_business_impact(
            services_affected, customer_impact, incident_type
        )

        # 生成建议
        recommendations = self._generate_recommendations(
            incident_type, damage_items, severity
        )

        # 构建报告
        report = DamageReport(
            total_damage=round(total_damage, 2),
            currency="USD",
            breakdown=breakdown,
            damage_items=damage_items,
            severity=severity,
            recovery_cost=recovery_cost,
            business_impact=business_impact,
            recommendations=recommendations
        )

        # 更新历史
        self._update_history(report, incident_data)

        return report

    def _assess_direct_financial(self, incident_type: str,
                                  investigation_cost: float,
                                  data_compromised: int) -> DamageItem:
        """评估直接经济损失"""
        base_cost = investigation_cost

        # 根据事件类型添加基础成本
        type_costs = {
            'ransomware': 2500000,
            'data_breach': 500000,
            'ddos': 100000,
            'phishing': 50000,
            'insider_threat': 300000,
            'apt': 2000000,
        }

        base_cost += type_costs.get(incident_type, 100000)

        # 数据泄露额外成本
        if data_compromised > 0:
            base_cost += data_compromised * self.unit_costs['per_record_breach']

        return DamageItem(
            category=DamageCategory.DIRECT_FINANCIAL,
            description=f"直接经济损失（{incident_type}）",
            estimated_value=base_cost,
            confidence=0.85,
            evidence=["调查成本记录", "事件类型评估"]
        )

    def _assess_data_loss(self, data_compromised: int,
                          intellectual_property: bool) -> DamageItem:
        """评估数据损失"""
        value = 0.0
        evidence = []

        # 个人数据泄露成本
        if data_compromised > 0:
            value += data_compromised * self.unit_costs['per_record_breach']
            evidence.append(f"{data_compromised}条记录泄露")

        # 知识产权损失
        if intellectual_property:
            value += self.unit_costs['per_ip_theft'] * 10  # 假设IP价值较高
            evidence.append("知识产权盗窃")

        return DamageItem(
            category=DamageCategory.DATA_LOSS,
            description="数据资产损失",
            estimated_value=max(value, 10000),  # 最低估值
            confidence=0.7,
            evidence=evidence
        )

    def _assess_service_loss(self, duration: float,
                            services_affected: List[str],
                            customer_impact: int) -> DamageItem:
        """评估服务损失"""
        hours = duration / 3600
        value = 0.0
        evidence = []

        # 计算停机损失
        for service in services_affected:
            # 假设每服务每小时10000美元
            service_cost = 10000 * hours
            value += service_cost
            evidence.append(f"{service}: {hours:.1f}小时")

        # 客户影响
        if customer_impact > 0:
            customer_cost = customer_impact * 100 * hours  # 每个客户每小时100美元
            value += customer_cost
            evidence.append(f"客户影响: {customer_impact}个客户")

        return DamageItem(
            category=DamageCategory.SERVICE_LOSS,
            description="服务中断损失",
            estimated_value=max(value, 1000),
            confidence=0.75,
            evidence=evidence
        )

    def _assess_credential_loss(self, credentials_compromised: int) -> DamageItem:
        """评估凭据泄露损失"""
        value = credentials_compromised * self.unit_costs['per_credential_compromised']

        return DamageItem(
            category=DamageCategory.DIRECT_FINANCIAL,
            description="凭据泄露损失",
            estimated_value=value,
            confidence=0.8,
            evidence=[f"{credentials_compromised}个凭据泄露"]
        )

    def _assess_compliance_loss(self, compliance_violations: List[str]) -> DamageItem:
        """评估合规损失"""
        # 模拟GDPR、PCI-DSS等罚款
        fine_per_violation = 2000000  # 假设平均罚款
        value = len(compliance_violations) * fine_per_violation

        evidence = [f"违反{len(compliance_violations)}项合规要求"]

        return DamageItem(
            category=DamageCategory.COMPLIANCE_LOSS,
            description="合规违规罚款及处理成本",
            estimated_value=max(value, 50000),
            confidence=0.6,
            evidence=evidence
        )

    def _assess_reputation_loss(self, incident_type: str,
                                customer_impact: int,
                                data_compromised: int) -> DamageItem:
        """评估声誉损失"""
        # 声誉损失通常难以量化，使用行业平均倍数
        base_reputation_cost = 1000000

        # 根据事件类型调整
        type_multipliers = {
            'ransomware': 5.0,
            'data_breach': 3.0,
            'ddos': 1.5,
            'phishing': 1.0,
            'insider_threat': 2.0,
        }
        multiplier = type_multipliers.get(incident_type, 1.0)

        value = base_reputation_cost * multiplier

        # 根据客户影响调整
        if customer_impact > 1000:
            value *= 2.0
        elif customer_impact > 100:
            value *= 1.5

        return DamageItem(
            category=DamageCategory.REPUTATION_LOSS,
            description="品牌声誉损失（难以精确量化）",
            estimated_value=value,
            confidence=0.4,  # 声誉损失置信度较低
            evidence=[f"事件类型: {incident_type}", f"客户影响: {customer_impact}"]
        )

    def _assess_indirect_financial(self, breakdown: Dict[str, float]) -> DamageItem:
        """评估间接经济损失"""
        # 通常为其他损失的10-30%
        direct_total = sum(v for k, v in breakdown.items()
                          if k != 'indirect_financial')
        value = direct_total * 0.15  # 假设15%

        return DamageItem(
            category=DamageCategory.INDIRECT_FINANCIAL,
            description="间接经济损失（业务中断、客户流失等）",
            estimated_value=value,
            confidence=0.5,
            evidence=["基于直接损失估算"]
        )

    def _estimate_recovery_cost(self, incident_type: str,
                               systems_affected: List[str],
                               recovery_time: float) -> float:
        """估算恢复成本"""
        base_cost = 50000  # 基础恢复成本

        # 系统数量
        system_cost = len(systems_affected) * 10000

        # 恢复时间
        hour_cost = (recovery_time / 3600) * 5000

        # 类型调整
        type_multipliers = {
            'ransomware': 3.0,
            'apt': 2.5,
            'data_breach': 1.5,
            'ddos': 1.2,
        }
        multiplier = type_multipliers.get(incident_type, 1.0)

        return (base_cost + system_cost + hour_cost) * multiplier

    def _determine_severity(self, total_damage: float,
                            incident_type: str) -> str:
        """确定严重程度"""
        # 基于金额分级
        if total_damage > 10000000:
            return "critical"
        elif total_damage > 1000000:
            return "high"
        elif total_damage > 100000:
            return "medium"
        elif total_damage > 10000:
            return "low"
        else:
            return "negligible"

    def _assess_business_impact(self, services_affected: List[str],
                                customer_impact: int,
                                incident_type: str) -> str:
        """评估业务影响"""
        if customer_impact > 10000:
            return "严重业务影响：大量客户受影响，可能导致客户流失和收入大幅下降"
        elif customer_impact > 1000:
            return "显著业务影响：部分客户受影响，需要启动客户通知和补救程序"
        elif customer_impact > 100:
            return "中等业务影响：有限客户受影响，需要监控客户反馈"
        elif len(services_affected) > 3:
            return "系统层面影响：多个核心系统受影响，需要优先恢复"
        else:
            return "轻微业务影响：影响范围有限，业务可继续运行"

    def _generate_recommendations(self, incident_type: str,
                                  damage_items: List[DamageItem],
                                  severity: str) -> List[str]:
        """生成建议"""
        recommendations = []

        # 基于严重程度的建议
        if severity in ['critical', 'high']:
            recommendations.append("立即启动紧急预算应对损失")
            recommendations.append("启动法律程序追究责任")
            recommendations.append("通知相关监管机构和受影响客户")

        # 基于损失类别的建议
        categories = {item.category for item in damage_items}

        if DamageCategory.DATA_LOSS in categories:
            recommendations.append("强化数据保护措施，增加加密级别")
            recommendations.append("审查数据访问权限")

        if DamageCategory.SERVICE_LOSS in categories:
            recommendations.append("建立更完善的业务连续性计划")
            recommendations.append("增加冗余系统和备份机制")

        if DamageCategory.COMPLIANCE_LOSS in categories:
            recommendations.append("全面审查合规状态")
            recommendations.append("聘请合规顾问进行评估")

        if DamageCategory.REPUTATION_LOSS in categories:
            recommendations.append("制定公关策略，控制舆论")
            recommendations.append("加强客户沟通和透明度")

        # 通用建议
        recommendations.append("进行根本原因分析(RCA)")
        recommendations.append("更新安全事件响应计划")
        recommendations.append("加强员工安全意识培训")

        return recommendations

    def _update_history(self, report: DamageReport, incident_data: Dict):
        """更新历史记录"""
        self.assessment_history.append({
            'report': {
                'total_damage': report.total_damage,
                'severity': report.severity,
                'breakdown': report.breakdown,
            },
            'incident': incident_data,
            'timestamp': datetime.now().isoformat()
        })

        if len(self.assessment_history) > 500:
            self.assessment_history = self.assessment_history[-400:]

    def get_average_damage(self) -> Dict:
        """获取平均损失统计"""
        if not self.assessment_history:
            return {'count': 0}

        totals = [h['report']['total_damage'] for h in self.assessment_history]
        severities = [h['report']['severity'] for h in self.assessment_history]

        severity_counts = {}
        for s in severities:
            severity_counts[s] = severity_counts.get(s, 0) + 1

        return {
            'count': len(totals),
            'average': sum(totals) / len(totals) if totals else 0,
            'total': sum(totals),
            'max': max(totals) if totals else 0,
            'min': min(totals) if totals else 0,
            'by_severity': severity_counts
        }


# 独立运行测试
if __name__ == "__main__":
    assessor = DamageAssessor()

    # 测试数据泄露事件
    incident = {
        'incident_type': 'data_breach',
        'duration': 7200,  # 2小时
        'data_compromised': 10000,
        'systems_affected': ['web_server', 'database', 'auth_service'],
        'services_affected': ['web_portal', 'api'],
        'credentials_compromised': 500,
        'intellectual_property': False,
        'compliance_violations': ['GDPR', 'PCI-DSS'],
        'customer_impact': 10000,
        'recovery_time': 86400,  # 24小时
        'investigation_cost': 50000,
    }

    report = assessor.assess(incident)
    print("损失评估报告:")
    print(f"总损失: ${report.total_damage:,.2f}")
    print(f"严重程度: {report.severity}")
    print(f"恢复成本: ${report.recovery_cost:,.2f}")
    print(f"\n损失分布:")
    for category, value in report.breakdown.items():
        print(f"  {category}: ${value:,.2f}")
    print(f"\n业务影响: {report.business_impact}")
    print(f"\n建议:")
    for rec in report.recommendations:
        print(f"  - {rec}")

    print(f"\n\n历史统计:")
    print(json.dumps(assessor.get_average_damage(), indent=2))
