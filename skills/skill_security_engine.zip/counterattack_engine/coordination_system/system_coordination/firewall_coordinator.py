"""
反击协调系统 - 防火墙联动模块
Firewall Coordinator - 与防火墙系统联动
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class FirewallVendor(Enum):
    """防火墙厂商"""
    CISCO = "cisco"
    PaloAlto = "palo_alto"
    Fortinet = "fortinet"
    CHECKPOINT = "checkpoint"
    AWS = "aws_security_group"
    AZURE = "azure_firewall"
    GCP = "gcp_firewall"
    IPTABLES = "iptables"


class RuleAction(Enum):
    """规则动作"""
    ALLOW = "allow"
    DENY = "deny"
    DROP = "drop"
    LOG = "log"


@dataclass
class FirewallRule:
    """防火墙规则"""
    rule_id: str
    name: str
    action: RuleAction
    source: str  # IP/CIDR
    destination: str
    protocol: str
    port: str
    direction: str = "ingress"  # ingress/egress
    enabled: bool = True
    priority: int = 100
    description: str = ""
    created_at: str = ""
    expires_at: Optional[str] = None


@dataclass
class CoordinationResult:
    """联动结果"""
    success: bool
    action: str
    target: str
    message: str
    rule_id: Optional[str] = None
    details: Dict = field(default_factory=dict)


class FirewallCoordinator:
    """防火墙协调器"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化防火墙协调器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.vendor = FirewallVendor(self.config.get('vendor', 'CISCO'))
        self.api_endpoint = self.config.get('api_endpoint', '')
        self.api_key = self.config.get('api_key', '')
        self.rules: Dict[str, FirewallRule] = {}
        self.sync_history = []

    def add_block_rule(self, ip: str, duration: int = 3600,
                       reason: str = "") -> CoordinationResult:
        """
        添加阻断规则

        Args:
            ip: IP地址
            duration: 持续时间（秒）
            reason: 原因

        Returns:
            联动结果
        """
        rule_id = self._generate_rule_id(ip)

        rule = FirewallRule(
            rule_id=rule_id,
            name=f"Block {ip}",
            action=RuleAction.DROP,
            source=ip,
            destination="any",
            protocol="any",
            port="any",
            description=reason or "Auto-blocked by security system",
            created_at=datetime.now().isoformat(),
            expires_at=(datetime.now().timestamp() + duration) if duration > 0 else None
        )

        # 实际应用中会调用防火墙API
        success = self._push_rule(rule)

        if success:
            self.rules[rule_id] = rule

        self._record_sync('add_rule', ip, success)

        return CoordinationResult(
            success=success,
            action='add_block_rule',
            target=ip,
            message="规则已添加" if success else "规则添加失败",
            rule_id=rule_id if success else None,
            details={'duration': duration, 'reason': reason}
        )

    def remove_block_rule(self, ip: str) -> CoordinationResult:
        """
        移除阻断规则

        Args:
            ip: IP地址

        Returns:
            联动结果
        """
        rule_id = self._find_rule_by_ip(ip)

        if not rule_id:
            return CoordinationResult(
                success=False,
                action='remove_block_rule',
                target=ip,
                message="未找到对应规则"
            )

        # 实际应用中会调用防火墙API删除规则
        success = self._delete_rule(rule_id)

        if success:
            del self.rules[rule_id]

        self._record_sync('remove_rule', ip, success)

        return CoordinationResult(
            success=success,
            action='remove_block_rule',
            target=ip,
            message="规则已移除" if success else "规则移除失败",
            rule_id=rule_id
        )

    def add_rate_limit_rule(self, ip: str, rate: int,
                            duration: int = 3600) -> CoordinationResult:
        """
        添加限速规则

        Args:
            ip: IP地址
            rate: 限速值
            duration: 持续时间

        Returns:
            联动结果
        """
        rule_id = self._generate_rule_id(f"{ip}-ratelimit")

        rule = FirewallRule(
            rule_id=rule_id,
            name=f"Rate Limit {ip}",
            action=RuleAction.ALLOW,  # 限速通常是allow但带限速
            source=ip,
            destination="any",
            protocol="tcp",
            port="any",
            description=f"Rate limit: {rate} connections/sec",
            created_at=datetime.now().isoformat(),
            expires_at=(datetime.now().timestamp() + duration) if duration > 0 else None
        )

        success = self._push_rule(rule)

        if success:
            self.rules[rule_id] = rule

        return CoordinationResult(
            success=success,
            action='add_rate_limit',
            target=ip,
            message="限速规则已添加",
            rule_id=rule_id if success else None,
            details={'rate': rate, 'duration': duration}
        )

    def bulk_block(self, ips: List[str], duration: int = 3600) -> Dict:
        """
        批量阻断

        Args:
            ips: IP列表
            duration: 持续时间

        Returns:
            批量结果
        """
        results = []
        success_count = 0

        for ip in ips:
            result = self.add_block_rule(ip, duration)
            results.append({
                'ip': ip,
                'success': result.success,
                'rule_id': result.rule_id
            })
            if result.success:
                success_count += 1

        return {
            'total': len(ips),
            'success': success_count,
            'failed': len(ips) - success_count,
            'results': results
        }

    def sync_rules(self) -> CoordinationResult:
        """
        同步防火墙规则

        Returns:
            同步结果
        """
        try:
            # 实际应用中会从防火墙拉取当前规则
            # 模拟同步
            synced_count = len(self.rules)

            # 清理过期规则
            expired = self._cleanup_expired_rules()

            self._record_sync('sync', 'all', True)

            return CoordinationResult(
                success=True,
                action='sync_rules',
                target='firewall',
                message=f"同步完成，{synced_count}条规则，清理{expired}条过期规则",
                details={'synced': synced_count, 'expired': expired}
            )

        except Exception as e:
            return CoordinationResult(
                success=False,
                action='sync_rules',
                target='firewall',
                message=f"同步失败: {str(e)}"
            )

    def get_rule(self, rule_id: str) -> Optional[FirewallRule]:
        """获取规则"""
        return self.rules.get(rule_id)

    def list_rules(self, filters: Dict = None) -> List[FirewallRule]:
        """
        列出规则

        Args:
            filters: 筛选条件

        Returns:
            规则列表
        """
        filters = filters or {}
        rules = list(self.rules.values())

        if 'action' in filters:
            rules = [r for r in rules if r.action == filters['action']]

        if 'source' in filters:
            rules = [r for r in rules if filters['source'] in r.source]

        if 'enabled_only' in filters and filters['enabled_only']:
            rules = [r for r in rules if r.enabled]

        return rules

    def _generate_rule_id(self, target: str) -> str:
        """生成规则ID"""
        import hashlib
        content = f"{target}:{datetime.now().isoformat()}"
        return f"FW-{self.vendor.value.upper()[:3]}-{hashlib.md5(content.encode()).hexdigest()[:8].upper()}"

    def _find_rule_by_ip(self, ip: str) -> Optional[str]:
        """查找IP对应的规则"""
        for rule_id, rule in self.rules.items():
            if rule.source == ip:
                return rule_id
        return None

    def _push_rule(self, rule: FirewallRule) -> bool:
        """推送规则到防火墙"""
        # 实际应用中会调用防火墙API
        # 模拟成功
        return True

    def _delete_rule(self, rule_id: str) -> bool:
        """从防火墙删除规则"""
        # 实际应用中会调用防火墙API
        # 模拟成功
        return True

    def _cleanup_expired_rules(self) -> int:
        """清理过期规则"""
        now = datetime.now().timestamp()
        expired_ids = []

        for rule_id, rule in self.rules.items():
            if rule.expires_at and rule.expires_at < now:
                expired_ids.append(rule_id)

        for rule_id in expired_ids:
            del self.rules[rule_id]

        return len(expired_ids)

    def _record_sync(self, action: str, target: str, success: bool):
        """记录同步历史"""
        self.sync_history.append({
            'action': action,
            'target': target,
            'success': success,
            'timestamp': datetime.now().isoformat()
        })

        if len(self.sync_history) > 1000:
            self.sync_history = self.sync_history[-800:]

    def get_statistics(self) -> Dict:
        """获取统计"""
        total = len(self.rules)
        by_action = {}

        for rule in self.rules.values():
            action = rule.action.value
            by_action[action] = by_action.get(action, 0) + 1

        return {
            'total_rules': total,
            'by_action': by_action,
            'vendor': self.vendor.value,
            'sync_history_count': len(self.sync_history)
        }


# 独立运行测试
if __name__ == "__main__":
    coordinator = FirewallCoordinator({
        'vendor': 'CISCO',
        'api_endpoint': 'https://firewall.example.com/api'
    })

    # 阻断单个IP
    result = coordinator.add_block_rule('192.168.1.100', duration=7200, reason='DDoS攻击')
    print(f"阻断IP: {result.message}, Rule ID: {result.rule_id}")

    # 批量阻断
    bulk_result = coordinator.bulk_block(['10.0.0.1', '10.0.0.2', '10.0.0.3'], duration=3600)
    print(f"\n批量阻断: 成功{bulk_result['success']}/{bulk_result['total']}")

    # 添加限速规则
    rate_result = coordinator.add_rate_limit_rule('172.16.0.0/16', rate=100)
    print(f"\n限速规则: {rate_result.message}")

    # 列出所有阻断规则
    block_rules = coordinator.list_rules({'action': RuleAction.DROP})
    print(f"\n当前阻断规则: {len(block_rules)}条")
    for rule in block_rules:
        print(f"  - {rule.rule_id}: {rule.source}")

    # 同步防火墙
    sync_result = coordinator.sync_rules()
    print(f"\n防火墙同步: {sync_result.message}")

    # 获取统计
    stats = coordinator.get_statistics()
    print(f"\n防火墙联动统计:")
    print(json.dumps(stats, indent=2))
