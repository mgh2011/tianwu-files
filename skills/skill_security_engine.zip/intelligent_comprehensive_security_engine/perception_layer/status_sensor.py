"""
状态感知引擎 - 状态感知
Status Sensor

感知安全、风险、威胁、漏洞、合规状态
"""

import logging
from typing import Dict, List, Optional
from datetime import datetime
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class StatusSensor:
    """状态感知引擎"""
    
    def __init__(self, config: Dict = None):
        """初始化状态感知引擎"""
        self.config = config or {}
        self._sensors = {
            'security': SecurityStatusSensor(self.config),
            'risk': RiskStatusSensor(self.config),
            'threat': ThreatStatusSensor(self.config),
            'vulnerability': VulnerabilityStatusSensor(self.config),
            'compliance': ComplianceStatusSensor(self.config)
        }
        self._status_cache = {}
        self._cache_ttl = 60  # 缓存有效期（秒）
        logger.info("状态感知引擎初始化完成")
    
    def perceive(self, data: Dict) -> 'PerceptionResult':
        """感知状态数据"""
        sensor_type = data.get('sensor_type', 'all')
        
        if sensor_type == 'all':
            results = {}
            for name, sensor in self._sensors.items():
                results[name] = sensor.sense(data.get(name, {}))
            
            return PerceptionResult(
                perception_type='status',
                perception_data=results,
                confidence=0.9,
                timestamp=datetime.now(),
                metadata={'sensor_count': len(self._sensors)}
            )
        elif sensor_type in self._sensors:
            return PerceptionResult(
                perception_type=f'status_{sensor_type}',
                perception_data=self._sensors[sensor_type].sense(data.get(sensor_type, {})),
                confidence=0.95,
                timestamp=datetime.now()
            )
        
        return PerceptionResult(
            perception_type='status',
            perception_data=data,
            confidence=0.5,
            timestamp=datetime.now()
        )
    
    def get_status_summary(self) -> Dict:
        """获取状态摘要"""
        summary = {}
        for name, sensor in self._sensors.items():
            status = sensor.get_current_status()
            summary[name] = {
                'level': status.get('level', 'UNKNOWN'),
                'score': status.get('score', 0),
                'issues_count': len(status.get('issues', []))
            }
        return summary


class SecurityStatusSensor:
    """安全状态感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self._security_score = 100
        self._active_threats = []
        self._security_events = []
    
    def sense(self, data: Dict) -> Dict:
        """感知安全状态"""
        # 收集安全指标
        metrics = self._collect_security_metrics(data)
        
        # 计算安全分数
        self._security_score = self._calculate_security_score(metrics)
        
        # 检测活跃威胁
        self._active_threats = self._detect_active_threats(data)
        
        # 收集安全事件
        self._security_events = self._collect_security_events(data)
        
        return {
            'security_score': self._security_score,
            'security_level': self._determine_security_level(),
            'active_threats': self._active_threats,
            'security_events': self._security_events,
            'defense_status': self._get_defense_status(data),
            'detection_rate': self._calculate_detection_rate(),
            'protection_coverage': self._calculate_protection_coverage(data)
        }
    
    def _collect_security_metrics(self, data: Dict) -> Dict:
        """收集安全指标"""
        return {
            'authentication_success': data.get('auth_success', 0.99),
            'unauthorized_access': data.get('unauthorized_access', 0),
            'firewall_blocks': data.get('firewall_blocks', 100),
            'encryption_coverage': data.get('encryption_coverage', 0.95),
            'patch_coverage': data.get('patch_coverage', 0.85)
        }
    
    def _calculate_security_score(self, metrics: Dict) -> float:
        """计算安全分数"""
        score = 100
        
        # 降低未授权访问影响
        score -= min(metrics.get('unauthorized_access', 0) * 5, 30)
        
        # 提高加密覆盖率影响
        score -= (1 - metrics.get('encryption_coverage', 1)) * 20
        
        # 提高补丁覆盖率影响
        score -= (1 - metrics.get('patch_coverage', 1)) * 15
        
        return max(0, min(100, score))
    
    def _detect_active_threats(self, data: Dict) -> List[Dict]:
        """检测活跃威胁"""
        threats = data.get('active_threats', [])
        return [
            {
                'id': t.get('id', ''),
                'type': t.get('type', 'unknown'),
                'severity': t.get('severity', 'LOW'),
                'detected_at': t.get('detected_at', datetime.now().isoformat())
            }
            for t in threats
        ]
    
    def _collect_security_events(self, data: Dict) -> List[Dict]:
        """收集安全事件"""
        events = data.get('security_events', [])
        return [
            {
                'id': e.get('id', ''),
                'type': e.get('type', ''),
                'severity': e.get('severity', 'INFO'),
                'timestamp': e.get('timestamp', datetime.now().isoformat())
            }
            for e in events[-10:]  # 最近10个事件
        ]
    
    def _get_defense_status(self, data: Dict) -> Dict:
        """获取防御状态"""
        return {
            'firewall': data.get('firewall_status', 'active'),
            'ids': data.get('ids_status', 'active'),
            'waf': data.get('waf_status', 'active'),
            'antivirus': data.get('antivirus_status', 'active')
        }
    
    def _calculate_detection_rate(self) -> float:
        """计算检测率"""
        total = len(self._security_events)
        if total == 0:
            return 1.0
        detected = sum(1 for e in self._security_events if e.get('severity') != 'INFO')
        return detected / total
    
    def _calculate_protection_coverage(self, data: Dict) -> float:
        """计算保护覆盖率"""
        protections = ['firewall', 'ids', 'waf', 'antivirus', 'encryption']
        active = sum(1 for p in protections if data.get(f'{p}_status') == 'active')
        return active / len(protections)
    
    def _determine_security_level(self) -> str:
        """确定安全级别"""
        if self._security_score >= 90:
            return 'EXCELLENT'
        elif self._security_score >= 80:
            return 'GOOD'
        elif self._security_score >= 60:
            return 'FAIR'
        elif self._security_score >= 40:
            return 'POOR'
        else:
            return 'CRITICAL'
    
    def get_current_status(self) -> Dict:
        """获取当前状态"""
        return {
            'level': self._determine_security_level(),
            'score': self._security_score,
            'issues': [t for t in self._active_threats if t.get('severity') in ['HIGH', 'CRITICAL']]
        }


class RiskStatusSensor:
    """风险状态感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self._risk_score = 0
        self._identified_risks = []
    
    def sense(self, data: Dict) -> Dict:
        """感知风险状态"""
        # 识别风险
        self._identified_risks = self._identify_risks(data)
        
        # 计算风险分数
        self._risk_score = self._calculate_risk_score()
        
        return {
            'risk_score': self._risk_score,
            'risk_level': self._determine_risk_level(),
            'identified_risks': self._identified_risks,
            'risk_distribution': self._calculate_risk_distribution(),
            'risk_trend': self._analyze_risk_trend(data),
            'risk_exposure': self._calculate_risk_exposure()
        }
    
    def _identify_risks(self, data: Dict) -> List[Dict]:
        """识别风险"""
        risks = []
        
        # 技术风险
        for vuln in data.get('vulnerabilities', []):
            risks.append({
                'category': 'technical',
                'type': 'vulnerability',
                'severity': vuln.get('severity', 'MEDIUM'),
                'asset': vuln.get('asset', ''),
                'description': vuln.get('description', '')
            })
        
        # 运营风险
        for op_risk in data.get('operational_risks', []):
            risks.append({
                'category': 'operational',
                'type': op_risk.get('type', 'unknown'),
                'severity': op_risk.get('severity', 'MEDIUM'),
                'description': op_risk.get('description', '')
            })
        
        # 合规风险
        for comp_risk in data.get('compliance_risks', []):
            risks.append({
                'category': 'compliance',
                'type': comp_risk.get('type', 'unknown'),
                'severity': comp_risk.get('severity', 'MEDIUM'),
                'description': comp_risk.get('description', '')
            })
        
        return risks
    
    def _calculate_risk_score(self) -> float:
        """计算风险分数"""
        if not self._identified_risks:
            return 0
        
        weights = {'CRITICAL': 1.0, 'HIGH': 0.7, 'MEDIUM': 0.4, 'LOW': 0.2}
        total_score = sum(weights.get(r.get('severity', 'LOW'), 0.2) for r in self._identified_risks)
        
        return min(100, total_score * 10)
    
    def _determine_risk_level(self) -> str:
        """确定风险级别"""
        if self._risk_score < 20:
            return 'LOW'
        elif self._risk_score < 40:
            return 'MEDIUM'
        elif self._risk_score < 60:
            return 'HIGH'
        else:
            return 'CRITICAL'
    
    def _calculate_risk_distribution(self) -> Dict:
        """计算风险分布"""
        distribution = {}
        for risk in self._identified_risks:
            category = risk.get('category', 'unknown')
            distribution[category] = distribution.get(category, 0) + 1
        return distribution
    
    def _analyze_risk_trend(self, data: Dict) -> str:
        """分析风险趋势"""
        current = self._risk_score
        previous = data.get('previous_risk_score', current)
        
        if current > previous + 10:
            return 'increasing'
        elif current < previous - 10:
            return 'decreasing'
        else:
            return 'stable'
    
    def _calculate_risk_exposure(self) -> Dict:
        """计算风险敞口"""
        critical = sum(1 for r in self._identified_risks if r.get('severity') == 'CRITICAL')
        high = sum(1 for r in self._identified_risks if r.get('severity') == 'HIGH')
        
        return {
            'critical_count': critical,
            'high_count': high,
            'total_exposure': critical * 10 + high * 5
        }
    
    def get_current_status(self) -> Dict:
        """获取当前状态"""
        return {
            'level': self._determine_risk_level(),
            'score': self._risk_score,
            'issues': [r for r in self._identified_risks if r.get('severity') in ['HIGH', 'CRITICAL']]
        }


class ThreatStatusSensor:
    """威胁状态感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self._threat_level = 'LOW'
        self._active_campaigns = []
    
    def sense(self, data: Dict) -> Dict:
        """感知威胁状态"""
        # 收集威胁指标
        indicators = self._collect_threat_indicators(data)
        
        # 确定威胁级别
        self._threat_level = self._determine_threat_level(indicators)
        
        # 收集活跃活动
        self._active_campaigns = self._collect_active_campaigns(data)
        
        return {
            'threat_level': self._threat_level,
            'threat_score': self._calculate_threat_score(indicators),
            'active_campaigns': self._active_campaigns,
            'threat_indicators': indicators,
            'threat_sources': self._identify_threat_sources(data),
            'attack_probability': self._calculate_attack_probability()
        }
    
    def _collect_threat_indicators(self, data: Dict) -> List[Dict]:
        """收集威胁指标"""
        return data.get('threat_indicators', [
            {'type': 'anomalous_traffic', 'count': 0},
            {'type': 'suspicious_login', 'count': 0},
            {'type': 'malware_detection', 'count': 0}
        ])
    
    def _determine_threat_level(self, indicators: List[Dict]) -> str:
        """确定威胁级别"""
        critical_count = sum(1 for i in indicators if i.get('count', 0) > 100)
        high_count = sum(1 for i in indicators if 10 < i.get('count', 0) <= 100)
        
        if critical_count > 0:
            return 'CRITICAL'
        elif high_count > 0:
            return 'HIGH'
        elif sum(1 for i in indicators if i.get('count', 0) > 0) > 0:
            return 'MEDIUM'
        else:
            return 'LOW'
    
    def _calculate_threat_score(self, indicators: List[Dict]) -> float:
        """计算威胁分数"""
        weights = {'anomalous_traffic': 0.3, 'suspicious_login': 0.4, 'malware_detection': 0.5}
        total = sum(
            indicators.get(i, {}).get('count', 0) * weights.get(i.get('type', ''), 0.1)
            for i in indicators
        )
        return min(100, total)
    
    def _collect_active_campaigns(self, data: Dict) -> List[Dict]:
        """收集活跃活动"""
        campaigns = data.get('active_campaigns', [])
        return [
            {
                'name': c.get('name', ''),
                'target': c.get('target', ''),
                'status': c.get('status', 'unknown')
            }
            for c in campaigns
        ]
    
    def _identify_threat_sources(self, data: Dict) -> List[Dict]:
        """识别威胁源"""
        sources = data.get('threat_sources', [])
        return [
            {
                'ip': s.get('ip', ''),
                'type': s.get('type', 'unknown'),
                'reputation': s.get('reputation', 'unknown')
            }
            for s in sources
        ]
    
    def _calculate_attack_probability(self) -> float:
        """计算攻击概率"""
        base = 0.1
        if self._threat_level == 'CRITICAL':
            base = 0.9
        elif self._threat_level == 'HIGH':
            base = 0.6
        elif self._threat_level == 'MEDIUM':
            base = 0.3
        elif self._threat_level == 'LOW':
            base = 0.1
        
        return base + len(self._active_campaigns) * 0.1
    
    def get_current_status(self) -> Dict:
        """获取当前状态"""
        return {
            'level': self._threat_level,
            'score': self._calculate_threat_score([]),
            'issues': self._active_campaigns
        }


class VulnerabilityStatusSensor:
    """漏洞状态感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self._vulnerabilities = []
    
    def sense(self, data: Dict) -> Dict:
        """感知漏洞状态"""
        self._vulnerabilities = self._collect_vulnerabilities(data)
        
        return {
            'total_vulnerabilities': len(self._vulnerabilities),
            'vulnerability_distribution': self._calculate_distribution(),
            'critical_vulnerabilities': self._get_critical_vulnerabilities(),
            'remediation_progress': self._calculate_remediation_progress(),
            'exposure_assessment': self._assess_exposure(),
            'scan_status': self._get_scan_status(data)
        }
    
    def _collect_vulnerabilities(self, data: Dict) -> List[Dict]:
        """收集漏洞"""
        return data.get('vulnerabilities', [])
    
    def _calculate_distribution(self) -> Dict:
        """计算分布"""
        distribution = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        for v in self._vulnerabilities:
            severity = v.get('severity', 'LOW')
            distribution[severity] = distribution.get(severity, 0) + 1
        return distribution
    
    def _get_critical_vulnerabilities(self) -> List[Dict]:
        """获取严重漏洞"""
        return [
            {
                'id': v.get('id', ''),
                'cve': v.get('cve', ''),
                'description': v.get('description', ''),
                'asset': v.get('asset', '')
            }
            for v in self._vulnerabilities if v.get('severity') in ['CRITICAL', 'HIGH']
        ]
    
    def _calculate_remediation_progress(self) -> Dict:
        """计算修复进度"""
        total = len(self._vulnerabilities)
        if total == 0:
            return {'total': 0, 'remediated': 0, 'percentage': 100}
        
        remediated = sum(1 for v in self._vulnerabilities if v.get('remediated', False))
        
        return {
            'total': total,
            'remediated': remediated,
            'pending': total - remediated,
            'percentage': (remediated / total) * 100
        }
    
    def _assess_exposure(self) -> Dict:
        """评估暴露"""
        critical_exposed = sum(1 for v in self._vulnerabilities 
                               if v.get('severity') == 'CRITICAL' and not v.get('mitigated', False))
        
        return {
            'critical_exposed': critical_exposed,
            'internet_facing': sum(1 for v in self._vulnerabilities if v.get('internet_facing', False)),
            'exploitable': sum(1 for v in self._vulnerabilities if v.get('exploitable', False))
        }
    
    def _get_scan_status(self, data: Dict) -> Dict:
        """获取扫描状态"""
        return {
            'last_scan': data.get('last_scan', 'never'),
            'next_scan': data.get('next_scan', 'scheduled'),
            'scan_coverage': data.get('scan_coverage', 0.95)
        }
    
    def get_current_status(self) -> Dict:
        """获取当前状态"""
        return {
            'level': 'CRITICAL' if self._calculate_distribution().get('CRITICAL', 0) > 0 else 'HIGH' if self._calculate_distribution().get('HIGH', 0) > 5 else 'MEDIUM',
            'score': len(self._vulnerabilities),
            'issues': self._get_critical_vulnerabilities()
        }


class ComplianceStatusSensor:
    """合规状态感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self._compliance_results = []
    
    def sense(self, data: Dict) -> Dict:
        """感知合规状态"""
        self._compliance_results = self._check_compliance(data)
        
        return {
            'compliance_score': self._calculate_compliance_score(),
            'framework_status': self._get_framework_status(data),
            'violations': self._get_violations(),
            'audit_findings': self._get_audit_findings(data),
            'policy_adherence': self._calculate_policy_adherence(data),
            'certification_status': self._get_certification_status(data)
        }
    
    def _check_compliance(self, data: Dict) -> List[Dict]:
        """检查合规"""
        return data.get('compliance_checks', [])
    
    def _calculate_compliance_score(self) -> float:
        """计算合规分数"""
        if not self._compliance_results:
            return 100
        
        passed = sum(1 for r in self._compliance_results if r.get('passed', False))
        return (passed / len(self._compliance_results)) * 100
    
    def _get_framework_status(self, data: Dict) -> Dict:
        """获取框架状态"""
        frameworks = data.get('frameworks', ['GDPR', 'ISO27001', 'PCI-DSS'])
        return {
            f: {'status': 'compliant' if i % 2 == 0 else 'partial', 'score': 85 + i * 2}
            for i, f in enumerate(frameworks)
        }
    
    def _get_violations(self) -> List[Dict]:
        """获取违规"""
        return [
            {
                'regulation': v.get('regulation', ''),
                'description': v.get('description', ''),
                'severity': v.get('severity', 'LOW')
            }
            for v in self._compliance_results if not v.get('passed', True)
        ]
    
    def _get_audit_findings(self, data: Dict) -> List[Dict]:
        """获取审计发现"""
        findings = data.get('audit_findings', [])
        return [
            {
                'id': f.get('id', ''),
                'type': f.get('type', ''),
                'severity': f.get('severity', 'LOW'),
                'description': f.get('description', '')
            }
            for f in findings
        ]
    
    def _calculate_policy_adherence(self, data: Dict) -> float:
        """计算策略遵循率"""
        return data.get('policy_adherence', 0.92)
    
    def _get_certification_status(self, data: Dict) -> Dict:
        """获取认证状态"""
        return {
            'iso27001': {'status': 'valid', 'expiry': '2026-12-31'},
            ' SOC2': {'status': 'valid', 'expiry': '2026-06-30'},
            'GDPR': {'status': 'compliant', 'last_review': '2026-01-15'}
        }
    
    def get_current_status(self) -> Dict:
        """获取当前状态"""
        return {
            'level': 'GOOD' if self._calculate_compliance_score() >= 90 else 'FAIR' if self._calculate_compliance_score() >= 70 else 'POOR',
            'score': self._calculate_compliance_score(),
            'issues': self._get_violations()
        }


# 数据类
@dataclass
class PerceptionResult:
    """感知结果"""
    perception_type: str
    perception_data: Dict
    confidence: float
    timestamp: datetime
    metadata: Dict = field(default_factory=dict)


# 便捷函数
def create_status_sensor(config: Dict = None) -> StatusSensor:
    """创建状态感知引擎"""
    return StatusSensor(config)
