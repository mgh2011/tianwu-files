# dialog_engine/security/privacy_guard.py
"""
隐私保护模块
PII检测和脱敏
"""

import re
import logging
from typing import Dict, List, Optional, Match, Callable
from datetime import datetime

from ..models.data_models import ContentCheckResult, SensitiveLevel
from ..config.default_config import config


logger = logging.getLogger(__name__)


class PrivacyGuard:
    """
    隐私保护模块
    检测和脱敏个人身份信息(PII)
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        self.config = config_dict or config.SECURITY
        self.enable_detection = self.config.get("pii_detection", True)
        self.enable_masking = self.config.get("pii_masking", True)
        self.masking_patterns = self.config.get("masking_patterns", {})
        
        # PII类型
        self.pii_types = {
            "phone": {
                "name": "手机号",
                "pattern": r"1[3-9]\d{9}",
                "mask_type": "partial",  # partial | full | last4
                "mask_char": "*"
            },
            "id_card": {
                "name": "身份证号",
                "pattern": r"\d{17}[\dXx]",
                "mask_type": "partial",
                "mask_char": "*"
            },
            "bank_card": {
                "name": "银行卡号",
                "pattern": r"\d{16,19}",
                "mask_type": "last4",
                "mask_char": "*"
            },
            "email": {
                "name": "邮箱",
                "pattern": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
                "mask_type": "domain",
                "mask_char": "*"
            },
            "address": {
                "name": "详细地址",
                "pattern": r"(?:省|市|区|县|路|街|号)[^\s]{5,50}",
                "mask_type": "full",
                "mask_char": "*"
            }
        }
        
        # 加载自定义模式
        self._load_custom_patterns()
        
        # 编译所有模式
        self._compile_patterns()
        
        # 脱敏回调
        self.mask_callbacks: Dict[str, Callable] = {}
    
    def _load_custom_patterns(self):
        """加载自定义模式"""
        for pii_type, pattern in self.masking_patterns.items():
            if pii_type not in self.pii_types:
                self.pii_types[pii_type] = {
                    "name": pii_type,
                    "pattern": pattern,
                    "mask_type": "partial",
                    "mask_char": "*"
                }
    
    def _compile_patterns(self):
        """编译所有正则模式"""
        self.compiled_patterns: Dict[str, re.Pattern] = {}
        
        for pii_type, config in self.pii_types.items():
            try:
                self.compiled_patterns[pii_type] = re.compile(config["pattern"])
            except re.error as e:
                logger.error(f"Failed to compile pattern for {pii_type}: {e}")
    
    async def protect(self, text: str) -> str:
        """
        隐私保护(脱敏)
        
        Args:
            text: 原始文本
            
        Returns:
            str: 脱敏后的文本
        """
        if not text or not self.enable_masking:
            return text
        
        result = text
        
        for pii_type, pattern in self.compiled_patterns.items():
            config = self.pii_types.get(pii_type, {})
            
            def replacer(match: Match) -> str:
                original = match.group()
                
                # 使用回调进行脱敏
                if pii_type in self.mask_callbacks:
                    return self.mask_callbacks[pii_type](original)
                
                return self._mask_value(original, config.get("mask_type", "partial"), config.get("mask_char", "*"))
            
            result = pattern.sub(replacer, result)
        
        return result
    
    def _mask_value(self, value: str, mask_type: str, mask_char: str) -> str:
        """
        脱敏值
        
        Args:
            value: 原始值
            mask_type: 脱敏类型
            mask_char: 脱敏字符
            
        Returns:
            脱敏后的值
        """
        if mask_type == "full":
            # 全脱敏
            return mask_char * min(len(value), 10)
        
        elif mask_type == "partial":
            # 部分脱敏:保留首尾各1位
            if len(value) <= 2:
                return mask_char * len(value)
            return value[0] + mask_char * (len(value) - 2) + value[-1]
        
        elif mask_type == "last4":
            # 只显示后4位
            if len(value) <= 4:
                return mask_char * len(value)
            return mask_char * (len(value) - 4) + value[-4:]
        
        elif mask_type == "domain":
            # 邮箱脱敏
            if "@" in value:
                local, domain = value.split("@", 1)
                if len(local) <= 2:
                    masked_local = mask_char * len(local)
                else:
                    masked_local = local[0] + mask_char * (len(local) - 1)
                return f"{masked_local}@{domain}"
            return mask_char * len(value)
        
        else:
            return value
    
    async def detect(self, text: str) -> List[Dict]:
        """
        检测PII
        
        Args:
            text: 待检测文本
            
        Returns:
            检测到的PII列表
        """
        if not text or not self.enable_detection:
            return []
        
        detected = []
        
        for pii_type, pattern in self.compiled_patterns.items():
            matches = pattern.finditer(text)
            
            for match in matches:
                config = self.pii_types.get(pii_type, {})
                
                detected.append({
                    "type": pii_type,
                    "name": config.get("name", pii_type),
                    "value": match.group(),
                    "start": match.start(),
                    "end": match.end(),
                    "masked": await self.protect(match.group())
                })
        
        return detected
    
    async def check(self, text: str) -> ContentCheckResult:
        """
        隐私检查
        
        Args:
            text: 待检查文本
            
        Returns:
            ContentCheckResult: 检查结果
        """
        detected = await self.detect(text)
        
        if detected:
            pii_types = [d["type"] for d in detected]
            return ContentCheckResult(
                is_safe=False,
                sensitive_level=SensitiveLevel.MEDIUM,
                sensitive_words=pii_types,
                suggestion="检测到个人信息,请注意保护隐私"
            )
        
        return ContentCheckResult(
            is_safe=True,
            sensitive_level=SensitiveLevel.SAFE,
            sensitive_words=[]
        )
    
    def register_mask_callback(self, pii_type: str, callback: Callable[[str], str]):
        """
        注册自定义脱敏回调
        
        Args:
            pii_type: PII类型
            callback: 脱敏函数
        """
        self.mask_callbacks[pii_type] = callback
        logger.info(f"Registered mask callback for {pii_type}")
    
    def add_pattern(self, pii_type: str, pattern: str, 
                   name: str = None, mask_type: str = "partial"):
        """
        添加PII模式
        
        Args:
            pii_type: PII类型
            pattern: 正则模式
            name: 显示名称
            mask_type: 脱敏类型
        """
        self.pii_types[pii_type] = {
            "name": name or pii_type,
            "pattern": pattern,
            "mask_type": mask_type,
            "mask_char": "*"
        }
        
        try:
            self.compiled_patterns[pii_type] = re.compile(pattern)
            logger.info(f"Added PII pattern for {pii_type}")
        except re.error as e:
            logger.error(f"Invalid pattern for {pii_type}: {e}")
    
    def remove_pattern(self, pii_type: str) -> bool:
        """移除PII模式"""
        if pii_type in self.pii_types:
            del self.pii_types[pii_type]
        
        if pii_type in self.compiled_patterns:
            del self.compiled_patterns[pii_type]
            return True
        
        return False
    
    def get_supported_types(self) -> List[str]:
        """获取支持的PII类型"""
        return list(self.pii_types.keys())
