"""
主机防护模块
Host Protection Module

提供主机安全防护和病毒查杀功能
"""

from .antivirus import AntivirusModule

__version__ = "v3.0.0"
__all__ = [
    'AntivirusModule'
]
