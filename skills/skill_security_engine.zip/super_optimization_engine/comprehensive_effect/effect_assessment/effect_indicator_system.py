"""
超级优化引擎 - 综合效果评估引擎
Comprehensive Effect Assessment Engine - 全方位效果评估
"""

from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import json
import time
import threading
from collections import deque


class MetricCategory(Enum):
    """指标类别"""
    PERFORMANCE = "performance"  # 性能指标
    QUALITY = "quality"  # 质量指标
    EFFICIENCY = "efficiency"  # 效率指标
    RELIABILITY = "reliability"  # 可靠性指标
    SECURITY = "security"  # 安全性指标
    USER = "user"  # 用户体验指标


@dataclass
class MetricValue:
    """指标值"""
    name: str
    value: float
    unit: str
    timestamp: str
    category: MetricCategory


@dataclass
class AssessmentScore:
    """评估分数"""
    category: MetricCategory
    score: float  # 0-100
    weight: float  # 权重
    metrics: List[MetricValue]
    trend: str  # improving/declining/stable
    details: Dict


@dataclass
class EffectReport:
    """效果报告"""
    report_id: str
    generated_at: str
    period_start: str
    period_end: str
    overall_score: float
    category_scores: Dict[str, AssessmentScore]
    key_findings: List[str]
    recommendations: List[str]
    trend_analysis: Dict


class ComprehensiveEffectAssessmentEngine:
    """综合效果评估引擎"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化综合效果评估引擎

        Args:
            config: 配置字典
        """
        self.config = config or {}

        # 指标配置
        self.metric_weights = {
            MetricCategory.PERFORMANCE: 0.25,
            MetricCategory.QUALITY: 0.20,
            MetricCategory.EFFICIENCY: 0.15,
            MetricCategory.RELIABILITY: 0.15,
            MetricCategory.SECURITY: 0.15,
            MetricCategory.USER: 0.10,
        }

        # 指标收集
        self.collected_metrics: Dict[str, deque] = {}
        self._metrics_lock = threading.Lock()

        # 阈值配置
        self.thresholds = {
            'critical': 60,  # 临界阈值
            'warning': 75,  # 警告阈值
            'good': 85,  # 良好阈值
            'excellent': 95,  # 优秀阈值
        }

        # 历史数据保留
        self.retention_days = self.config.get('retention_days', 90)
        self.max_samples = self.config.get('max_samples', 10000)

    def record_metric(self, name: str, value: float, unit: str = "",
                     category: MetricCategory = MetricCategory.PERFORMANCE,
                     metadata: Dict = None):
        """
        记录指标

        Args:
            name: 指标名称
            value: 指标值
            unit: 单位
            category: 指标类别
            metadata: 元数据
        """
        with self._metrics_lock:
            metric = MetricValue(
                name=name,
                value=value,
                unit=unit,
                timestamp=datetime.now().isoformat(),
                category=category
            )

            if name not in self.collected_metrics:
                self.collected_metrics[name] = deque(maxlen=self.max_samples)

            self.collected_metrics[name].append(metric)

    def assess(self, period_hours: int = 24) -> EffectReport:
        """
        执行评估

        Args:
            period_hours: 评估周期（小时）

        Returns:
            效果报告
        """
        import hashlib

        now = datetime.now()
        period_start = (now - timedelta(hours=period_hours)).isoformat()

        # 按类别分组评估
        category_scores = {}
        all_metrics = []

        for category in MetricCategory:
            metrics = self._get_category_metrics(category, period_start)
            score = self._calculate_category_score(category, metrics)
            trend = self._calculate_trend(category, metrics)
            details = self._analyze_metrics(metrics)

            category_scores[category.value] = AssessmentScore(
                category=category,
                score=score,
                weight=self.metric_weights[category],
                metrics=metrics,
                trend=trend,
                details=details
            )

            all_metrics.extend(metrics)

        # 计算综合分数
        overall_score = sum(
            s.score * s.weight
            for s in category_scores.values()
        )

        # 生成关键发现
        findings = self._generate_findings(category_scores)

        # 生成建议
        recommendations = self._generate_recommendations(category_scores)

        # 趋势分析
        trend_analysis = self._generate_trend_analysis(category_scores)

        return EffectReport(
            report_id=f"RPT-{hashlib.md5(str(now).encode()).hexdigest()[:12].upper()}",
            generated_at=now.isoformat(),
            period_start=period_start,
            period_end=now.isoformat(),
            overall_score=round(overall_score, 2),
            category_scores=category_scores,
            key_findings=findings,
            recommendations=recommendations,
            trend_analysis=trend_analysis
        )

    def compare_periods(self, current_hours: int = 24,
                       previous_hours: int = 48) -> Dict:
        """
        周期对比

        Args:
            current_hours: 当前周期
            previous_hours: 之前周期

        Returns:
            对比结果
        """
        now = datetime.now()
        current_start = (now - timedelta(hours=current_hours)).isoformat()
        previous_start = (now - timedelta(hours=current_hours + previous_hours)).isoformat()
        previous_end = current_start

        # 当前周期评估
        current_report = self.assess(current_hours)

        # 收集之前周期的指标
        previous_metrics = {}
        cutoff = datetime.fromisoformat(previous_start)

        with self._metrics_lock:
            for name, samples in self.collected_metrics.items():
                prev_samples = [
                    m for m in samples
                    if datetime.fromisoformat(m.timestamp) >= cutoff
                    and datetime.fromisoformat(m.timestamp) < datetime.fromisoformat(previous_end)
                ]
                if prev_samples:
                    previous_metrics[name] = prev_samples

        # 计算对比
        comparison = {
            'current_period': {
                'start': current_start,
                'end': now.isoformat(),
                'overall_score': current_report.overall_score
            },
            'previous_period': {
                'start': previous_start,
                'end': previous_end,
                'overall_score': self._calculate_overall_from_metrics(previous_metrics)
            },
            'category_comparison': {},
            'improvements': [],
            'declines': []
        }

        # 分类对比
        for cat_value, current_score in current_report.category_scores.items():
            category = MetricCategory(cat_value)
            if category.name in previous_metrics:
                prev_score = self._calculate_category_score(
                    category, previous_metrics[category.name]
                )
            else:
                prev_score = 0

            change = current_score.score - prev_score
            comparison['category_comparison'][cat_value] = {
                'current': round(current_score.score, 2),
                'previous': round(prev_score, 2),
                'change': round(change, 2),
                'trend': 'up' if change > 2 else ('down' if change < -2 else 'stable')
            }

            if change > 2:
                comparison['improvements'].append(cat_value)
            elif change < -2:
                comparison['declines'].append(cat_value)

        return comparison

    def get_current_status(self) -> Dict:
        """获取当前状态"""
        recent_hours = 1  # 最近1小时
        return self.assess(recent_hours)

    def get_metric_history(self, metric_name: str,
                         hours: int = 24) -> List[MetricValue]:
        """获取指标历史"""
        cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

        with self._metrics_lock:
            if metric_name not in self.collected_metrics:
                return []

            return [
                m for m in self.collected_metrics[metric_name]
                if m.timestamp >= cutoff
            ]

    def get_trending_metrics(self, limit: int = 10) -> List[Dict]:
        """获取趋势指标"""
        trending = []

        with self._metrics_lock:
            for name, samples in self.collected_metrics.items():
                if len(samples) < 10:
                    continue

                values = [m.value for m in samples]
                recent_avg = sum(values[-10:]) / min(10, len(values))
                older_avg = sum(values[-20:-10]) / min(10, len(values) - 10) if len(values) > 10 else recent_avg

                if older_avg != 0:
                    change_pct = ((recent_avg - older_avg) / older_avg) * 100
                else:
                    change_pct = 0

                trending.append({
                    'name': name,
                    'recent_value': recent_avg,
                    'change_percent': change_pct,
                    'trend': 'up' if change_pct > 5 else ('down' if change_pct < -5 else 'stable'),
                    'sample_count': len(samples)
                })

        trending.sort(key=lambda x: abs(x['change_percent']), reverse=True)
        return trending[:limit]

    def _get_category_metrics(self, category: MetricCategory,
                             start_time: str) -> List[MetricValue]:
        """获取类别指标"""
        metrics = []
        cutoff = datetime.fromisoformat(start_time)

        with self._metrics_lock:
            for name, samples in self.collected_metrics.items():
                category_samples = [
                    m for m in samples
                    if m.category == category and datetime.fromisoformat(m.timestamp) >= cutoff
                ]
                metrics.extend(category_samples)

        return metrics

    def _calculate_category_score(self, category: MetricCategory,
                                  metrics: List[MetricValue]) -> float:
        """计算类别分数"""
        if not metrics:
            return 0.0

        values = [m.value for m in metrics]

        # 特殊处理某些指标
        if category == MetricCategory.PERFORMANCE:
            # 性能指标：值越低越好
            avg_value = sum(values) / len(values)
            if avg_value <= 10:
                return 100
            elif avg_value <= 50:
                return 90
            elif avg_value <= 100:
                return 80
            elif avg_value <= 500:
                return 60
            else:
                return max(0, 50 - (avg_value - 500) / 20)

        elif category == MetricCategory.QUALITY:
            # 质量指标：值越高越好
            return min(100, sum(values) / len(values))

        elif category == MetricCategory.RELIABILITY:
            # 可靠性指标：成功率
            return min(100, sum(values) / len(values))

        elif category == MetricCategory.SECURITY:
            # 安全指标：风险分数
            return max(0, 100 - sum(values) / len(values))

        else:
            return sum(values) / len(values)

    def _calculate_trend(self, category: MetricCategory,
                        metrics: List[MetricValue]) -> str:
        """计算趋势"""
        if len(metrics) < 10:
            return "insufficient_data"

        values = [m.value for m in metrics]
        recent_half = values[len(values)//2:]
        older_half = values[:len(values)//2]

        if not older_half:
            return "stable"

        recent_avg = sum(recent_half) / len(recent_half)
        older_avg = sum(older_half) / len(older_half)

        if older_avg == 0:
            return "stable"

        change_pct = ((recent_avg - older_avg) / older_avg) * 100

        if change_pct > 5:
            return "improving"
        elif change_pct < -5:
            return "declining"
        else:
            return "stable"

    def _analyze_metrics(self, metrics: List[MetricValue]) -> Dict:
        """分析指标"""
        if not metrics:
            return {}

        values = [m.value for m in metrics]
        return {
            'count': len(metrics),
            'avg': sum(values) / len(values),
            'min': min(values),
            'max': max(values),
            'latest': values[-1] if values else None,
        }

    def _generate_findings(self, category_scores: Dict[str, AssessmentScore]) -> List[str]:
        """生成关键发现"""
        findings = []

        # 整体分数分析
        overall = sum(s.score * s.weight for s in category_scores.values())
        if overall >= 90:
            findings.append("整体效果优秀，所有指标均达到预期")
        elif overall >= 80:
            findings.append("整体效果良好，有小幅提升空间")
        elif overall >= 70:
            findings.append("整体效果一般，需要重点关注")
        else:
            findings.append("整体效果较差，需要紧急改进")

        # 分类分析
        for cat_value, score in category_scores.items():
            if score.score < self.thresholds['critical']:
                findings.append(f"{cat_value}指标低于临界值，需要立即改进")
            elif score.trend == 'declining':
                findings.append(f"{cat_value}指标呈下降趋势，需要关注")

        return findings

    def _generate_recommendations(self, category_scores: Dict[str, AssessmentScore]) -> List[str]:
        """生成建议"""
        recommendations = []

        for cat_value, score in category_scores.items():
            if score.score < self.thresholds['warning']:
                recommendations.append(
                    f"建议优化{cat_value}指标，当前分数{score.score:.1f}，目标{self.thresholds['good']}"
                )

            if score.trend == 'declining':
                recommendations.append(
                    f"关注{cat_value}指标下降趋势，分析原因并采取改进措施"
                )

        # 优先级排序
        recommendations.sort(key=lambda x: (
            'critical' in x.lower(),
            'warning' in x.lower(),
            'declining' in x.lower()
        ), reverse=True)

        return recommendations[:10]  # 最多10条建议

    def _generate_trend_analysis(self, category_scores: Dict[str, AssessmentScore]) -> Dict:
        """生成趋势分析"""
        trends = {}
        improving = []
        declining = []
        stable = []

        for cat_value, score in category_scores.items():
            trends[cat_value] = score.trend
            if score.trend == 'improving':
                improving.append(cat_value)
            elif score.trend == 'declining':
                declining.append(cat_value)
            else:
                stable.append(cat_value)

        return {
            'trends': trends,
            'improving': improving,
            'declining': declining,
            'stable': stable,
            'summary': f"{len(improving)}项改善，{len(declining)}项下降，{len(stable)}项稳定"
        }

    def _calculate_overall_from_metrics(self, metrics: Dict) -> float:
        """从指标计算整体分数"""
        if not metrics:
            return 0.0

        category_scores = {}
        for category in MetricCategory:
            cat_metrics = metrics.get(category.value, [])
            if cat_metrics:
                category_scores[category.value] = self._calculate_category_score(
                    category, cat_metrics
                )

        return sum(
            s * self.metric_weights[MetricCategory(k)]
            for k, s in category_scores.items()
        ) / sum(
            self.metric_weights[MetricCategory(k)]
            for k in category_scores.keys()
        ) if category_scores else 0.0


# 独立运行测试
if __name__ == "__main__":
    engine = ComprehensiveEffectAssessmentEngine()

    print("=" * 60)
    print("综合效果评估引擎测试")
    print("=" * 60)

    # 记录模拟指标
    print("\n1. 记录模拟指标...")

    # 性能指标
    for i in range(100):
        engine.record_metric(
            'response_time_ms',
            50 + (i % 20) - 10,  # 波动
            'ms',
            MetricCategory.PERFORMANCE
        )

    # 质量指标
    for i in range(100):
        engine.record_metric(
            'accuracy_percent',
            95 + (i % 5),  # 稳定偏高
            '%',
            MetricCategory.QUALITY
        )

    # 可靠性指标
    for i in range(100):
        engine.record_metric(
            'uptime_percent',
            99.5 + (i % 3) * 0.1,  # 缓慢上升
            '%',
            MetricCategory.RELIABILITY
        )

    # 效率指标
    for i in range(100):
        engine.record_metric(
            'throughput_rps',
            1000 + (50 - i % 100),  # 略有下降
            'rps',
            MetricCategory.EFFICIENCY
        )

    # 安全指标
    for i in range(100):
        engine.record_metric(
            'incident_count',
            max(0, 5 - i % 10),  # 逐渐减少
            'count',
            MetricCategory.SECURITY
        )

    print(f"   已记录 {sum(len(v) for v in engine.collected_metrics.values())} 条指标")

    # 执行评估
    print("\n2. 执行综合评估...")
    report = engine.assess(period_hours=24)

    print(f"\n   报告ID: {report.report_id}")
    print(f"   评估周期: {report.period_start[:19]} 至 {report.period_end[:19]}")
    print(f"   整体分数: {report.overall_score:.2f}/100")

    print("\n   分类评分:")
    for cat_value, score in report.category_scores.items():
        trend_icon = {'improving': '↑', 'declining': '↓', 'stable': '→'}.get(score.trend, '?')
        print(f"     {cat_value:15s}: {score.score:5.1f} (权重{score.weight:.0%}) {trend_icon}")

    print("\n   关键发现:")
    for finding in report.key_findings:
        print(f"     • {finding}")

    print("\n   建议:")
    for rec in report.recommendations:
        print(f"     • {rec}")

    print("\n   趋势分析:")
    ta = report.trend_analysis
    print(f"     改善: {', '.join(ta['improving']) or '无'}")
    print(f"     下降: {', '.join(ta['declining']) or '无'}")
    print(f"     稳定: {', '.join(ta['stable']) or '无'}")

    # 周期对比
    print("\n3. 周期对比分析...")
    comparison = engine.compare_periods(current_hours=24, previous_hours=24)

    print(f"   当前周期分数: {comparison['current_period']['overall_score']:.2f}")
    print(f"   上周期分数: {comparison['previous_period']['overall_score']:.2f}")

    print("\n   分类变化:")
    for cat, comp in comparison['category_comparison'].items():
        change_icon = {'up': '↑', 'down': '↓', 'stable': '→'}.get(comp['trend'], '?')
        print(f"     {cat:15s}: {comp['current']:5.1f} vs {comp['previous']:5.1f} ({comp['change']:+5.1f}) {change_icon}")

    if comparison['improvements']:
        print(f"   改善指标: {', '.join(comparison['improvements'])}")
    if comparison['declines']:
        print(f"   下降指标: {', '.join(comparison['declines'])}")

    # 趋势指标
    print("\n4. 趋势指标 TOP 10:")
    trending = engine.get_trending_metrics(10)
    for t in trending:
        trend_icon = {'up': '↑', 'down': '↓', 'stable': '→'}.get(t['trend'], '?')
        print(f"     {t['name']:20s}: {t['recent_value']:8.2f} ({t['change_percent']:+6.1f}%) {trend_icon}")

    # 当前状态
    print("\n5. 当前状态(最近1小时):")
    status = engine.get_current_status()
    print(f"   整体分数: {status.overall_score:.2f}/100")

    print("\n" + "=" * 60)
    print("综合效果评估引擎测试完成")
    print("=" * 60)
