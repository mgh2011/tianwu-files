# dialog_engine/nlu/entity_extractor.py
"""
实体抽取器
支持正则、词典、NER模型多种方式
"""

import re
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import re

from ..models.data_models import Entity, EntityType
from ..config.default_config import config


logger = logging.getLogger(__name__)


class EntityExtractor:
    """
    多策略实体抽取器
    支持正则、词典、NER模型多种方式
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        self.config = config_dict or config.ENTITY_EXTRACTOR
        self.patterns = self.config.get("entity_patterns", {})
        self.time_rules = self.config.get("time_normalization_rules", {})
        self.confidence_threshold = self.config.get("confidence_threshold", 0.6)
        
        # 词典
        self.dictionaries: Dict[EntityType, List[str]] = {}
        
        # NER模型引用(可选)
        self.ner_model = None
        
        # 编译正则表达式
        self._compile_patterns()
        
    def _compile_patterns(self):
        """编译正则表达式"""
        self.compiled_patterns: Dict[str, re.Pattern] = {}
        for entity_type, patterns in self.patterns.items():
            for pattern in patterns:
                try:
                    self.compiled_patterns[f"{entity_type}_{pattern}"] = re.compile(pattern)
                except re.error as e:
                    logger.error(f"Invalid regex pattern: {pattern}, error: {e}")
    
    async def extract(self, text: str,
                     entity_types: Optional[List[EntityType]] = None) -> List[Entity]:
        """
        实体抽取
        
        Args:
            text: 输入文本
            entity_types: 指定要抽取的实体类型列表, None表示抽取所有类型
            
        Returns:
            List[Entity]: 实体列表
        """
        entities = []
        
        # 确定要抽取的类型
        if entity_types is None:
            entity_types = [EntityType(t) for t in self.patterns.keys()]
        
        # 1. 正则抽取
        regex_entities = await self._extract_by_regex(text, entity_types)
        entities.extend(regex_entities)
        
        # 2. 词典匹配
        dict_entities = await self._extract_by_dict(text, entity_types)
        entities.extend(dict_entities)
        
        # 3. NER模型抽取
        if self.ner_model:
            ner_entities = await self._extract_by_ner(text)
            entities.extend(ner_entities)
        
        # 4. 去重和合并
        entities = self._merge_entities(entities)
        
        # 5. 归一化
        entities = [self._normalize_entity(e) for e in entities]
        
        return entities
    
    async def _extract_by_regex(self, text: str,
                                 entity_types: List[EntityType]) -> List[Entity]:
        """基于正则表达式的实体抽取"""
        entities = []
        
        for entity_type in entity_types:
            type_str = entity_type.value
            
            if type_str not in self.patterns:
                continue
            
            for pattern in self.patterns[type_str]:
                try:
                    regex = self.compiled_patterns.get(f"{type_str}_{pattern}")
                    if not regex:
                        regex = re.compile(pattern)
                    
                    for match in regex.finditer(text):
                        entity = Entity(
                            type=entity_type,
                            value=match.group(),
                            start_pos=match.start(),
                            end_pos=match.end(),
                            confidence=0.9,
                            metadata={"source": "regex", "pattern": pattern}
                        )
                        entities.append(entity)
                        
                except Exception as e:
                    logger.error(f"Regex extraction error for {type_str}: {e}")
        
        return entities
    
    async def _extract_by_dict(self, text: str,
                              entity_types: List[EntityType]) -> List[Entity]:
        """基于词典的实体抽取"""
        entities = []
        
        for entity_type in entity_types:
            if entity_type not in self.dictionaries:
                continue
            
            dict_words = self.dictionaries[entity_type]
            
            for word in dict_words:
                # 精确匹配
                pattern = re.escape(word)
                for match in re.finditer(pattern, text):
                    entity = Entity(
                        type=entity_type,
                        value=word,
                        start_pos=match.start(),
                        end_pos=match.end(),
                        confidence=0.85,
                        metadata={"source": "dictionary"}
                    )
                    entities.append(entity)
                
                # 模糊匹配(包含)
                if word in text:
                    start = text.find(word)
                    entity = Entity(
                        type=entity_type,
                        value=word,
                        start_pos=start,
                        end_pos=start + len(word),
                        confidence=0.7,
                        metadata={"source": "dictionary_fuzzy"}
                    )
                    entities.append(entity)
        
        return entities
    
    async def _extract_by_ner(self, text: str) -> List[Entity]:
        """基于NER模型的实体抽取"""
        if not self.ner_model:
            return []
        
        try:
            predictions = await self.ner_model.predict(text)
            
            entities = []
            for pred in predictions:
                entity = Entity(
                    type=EntityType(pred["type"]),
                    value=pred["text"],
                    start_pos=pred.get("start", 0),
                    end_pos=pred.get("end", 0),
                    confidence=pred.get("confidence", 0.9),
                    metadata={"source": "ner_model"}
                )
                entities.append(entity)
            
            return entities
            
        except Exception as e:
            logger.error(f"NER extraction error: {e}")
            return []
    
    def _merge_entities(self, entities: List[Entity]) -> List[Entity]:
        """合并重复和重叠的实体"""
        if not entities:
            return []
        
        # 按起始位置排序
        entities = sorted(entities, key=lambda e: (e.start_pos, -e.confidence))
        
        merged = []
        for entity in entities:
            # 检查是否与已选实体重叠
            is_duplicate = False
            for existing in merged:
                if (entity.start_pos < existing.end_pos and 
                    entity.end_pos > existing.start_pos):
                    # 重叠：保留置信度高的
                    if entity.confidence > existing.confidence:
                        merged.remove(existing)
                    else:
                        is_duplicate = True
                    break
            
            if not is_duplicate:
                merged.append(entity)
        
        return merged
    
    def _normalize_entity(self, entity: Entity) -> Entity:
        """归一化实体"""
        if entity.type == EntityType.TIME:
            entity.normalized_value = self._normalize_time(entity.value)
        elif entity.type == EntityType.DATE:
            entity.normalized_value = self._normalize_date(entity.value)
        elif entity.type == EntityType.MONEY:
            entity.normalized_value = self._normalize_money(entity.value)
        elif entity.type == EntityType.PHONE:
            entity.normalized_value = self._normalize_phone(entity.value)
        
        return entity
    
    def _normalize_time(self, time_str: str) -> str:
        """归一化时间"""
        # 处理相对时间
        now = datetime.now()
        
        if "早上" in time_str or "早晨" in time_str:
            return "morning"
        elif "下午" in time_str:
            return "afternoon"
        elif "晚上" in time_str or "傍晚" in time_str:
            return "evening"
        elif "中午" in time_str:
            return "noon"
        
        # 处理具体时间
        time_match = re.search(r"(\d{1,2})[:：]?(\d{2})?", time_str)
        if time_match:
            hour = int(time_match.group(1))
            minute = int(time_match.group(2) or "0")
            return f"{hour:02d}:{minute:02d}"
        
        return time_str
    
    def _normalize_date(self, date_str: str) -> str:
        """归一化日期"""
        now = datetime.now()
        
        if "今天" in date_str:
            return now.strftime("%Y-%m-%d")
        elif "明天" in date_str:
            return (now + timedelta(days=1)).strftime("%Y-%m-%d")
        elif "后天" in date_str:
            return (now + timedelta(days=2)).strftime("%Y-%m-%d")
        elif "昨天" in date_str:
            return (now - timedelta(days=1)).strftime("%Y-%m-%d")
        elif "大后天" in date_str:
            return (now + timedelta(days=3)).strftime("%Y-%m-%d")
        
        # 处理具体日期格式
        date_patterns = [
            (r"(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})[日]?", r"\1-\2-\3"),
            (r"(\d{1,2})[-/月](\d{1,2})[日]?", rf"{now.year}-\1-\2"),
        ]
        
        for pattern, replacement in date_patterns:
            match = re.search(pattern, date_str)
            if match:
                return re.sub(pattern, replacement, match.group())
        
        return date_str
    
    def _normalize_money(self, money_str: str) -> str:
        """归一化金额"""
        # 提取数字
        amount_match = re.search(r"(\d+(?:\.\d+)?)", money_str)
        if not amount_match:
            return money_str
        
        amount = amount_match.group(1)
        
        # 确定货币单位
        if "美元" in money_str or "$" in money_str:
            return f"USD:{amount}"
        elif "欧元" in money_str or "€" in money_str:
            return f"EUR:{amount}"
        else:
            return f"CNY:{amount}"
    
    def _normalize_phone(self, phone_str: str) -> str:
        """归一化手机号"""
        # 移除空格和连字符
        phone = re.sub(r"[\s\-]", "", phone_str)
        return phone
    
    def add_dictionary(self, entity_type: EntityType, words: List[str]):
        """添加词典"""
        if entity_type not in self.dictionaries:
            self.dictionaries[entity_type] = []
        self.dictionaries[entity_type].extend(words)
        logger.info(f"Added {len(words)} words to dictionary for {entity_type.value}")
    
    def remove_dictionary(self, entity_type: EntityType, words: List[str]):
        """移除词典词"""
        if entity_type in self.dictionaries:
            for word in words:
                if word in self.dictionaries[entity_type]:
                    self.dictionaries[entity_type].remove(word)
    
    def set_ner_model(self, model):
        """设置NER模型"""
        self.ner_model = model
    
    def add_entity_pattern(self, entity_type: str, patterns: List[str]):
        """添加实体模式"""
        if entity_type not in self.patterns:
            self.patterns[entity_type] = []
        self.patterns[entity_type].extend(patterns)
        
        # 编译新模式
        for pattern in patterns:
            try:
                self.compiled_patterns[f"{entity_type}_{pattern}"] = re.compile(pattern)
            except re.error as e:
                logger.error(f"Invalid regex pattern: {pattern}")
        
        logger.info(f"Added {len(patterns)} patterns for {entity_type}")
    
    async def batch_extract(self, texts: List[str],
                           entity_types: Optional[List[EntityType]] = None) -> List[List[Entity]]:
        """批量实体抽取"""
        return [await self.extract(text, entity_types) for text in texts]
