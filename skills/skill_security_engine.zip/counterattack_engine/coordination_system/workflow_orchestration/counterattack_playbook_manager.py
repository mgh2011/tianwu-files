"""
反击协调系统 - Playbook管理模块
Counterattack Playbook Manager - 管理反击剧本
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
import json


@dataclass
class PlaybookStep:
    """剧本步骤"""
    step_id: str
    name: str
    action: str
    target: Dict
    conditions: List[str]
    timeout: int
    rollback_action: str


@dataclass
class Playbook:
    """反击剧本"""
    playbook_id: str
    name: str
    description: str
    trigger_conditions: List[str]
    steps: List[PlaybookStep]
    version: str
    enabled: bool
    created_at: str
    updated_at: str


class CounterattackPlaybookManager:
    """反击剧本管理器"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.playbooks: Dict[str, Playbook] = {}
        self.execution_history = []

    def create_playbook(self, name: str, description: str,
                       steps: List[Dict]) -> Playbook:
        """创建剧本"""
        import hashlib

        playbook_id = f"PB-{hashlib.md5(f'{name}:{datetime.now().isoformat()}'.encode()).hexdigest()[:12].upper()}"

        playbook_steps = []
        for i, step_data in enumerate(steps):
            step = PlaybookStep(
                step_id=f"{playbook_id}-STEP-{i+1}",
                name=step_data['name'],
                action=step_data['action'],
                target=step_data.get('target', {}),
                conditions=step_data.get('conditions', []),
                timeout=step_data.get('timeout', 300),
                rollback_action=step_data.get('rollback_action', '')
            )
            playbook_steps.append(step)

        playbook = Playbook(
            playbook_id=playbook_id,
            name=name,
            description=description,
            trigger_conditions=[],
            steps=playbook_steps,
            version='1.0.0',
            enabled=True,
            created_at=datetime.now().isoformat(),
            updated_at=datetime.now().isoformat()
        )

        self.playbooks[playbook_id] = playbook
        return playbook

    def get_playbook(self, playbook_id: str) -> Optional[Playbook]:
        """获取剧本"""
        return self.playbooks.get(playbook_id)

    def list_playbooks(self, enabled_only: bool = False) -> List[Playbook]:
        """列出剧本"""
        playbooks = list(self.playbooks.values())
        if enabled_only:
            playbooks = [p for p in playbooks if p.enabled]
        return playbooks

    def execute_playbook(self, playbook_id: str, context: Dict) -> Dict:
        """执行剧本"""
        playbook = self.get_playbook(playbook_id)
        if not playbook:
            return {'success': False, 'error': 'Playbook not found'}

        executed_steps = []
        for step in playbook.steps:
            executed_steps.append({
                'step_id': step.step_id,
                'action': step.action,
                'status': 'executed'
            })

        return {
            'success': True,
            'playbook_id': playbook_id,
            'executed_steps': executed_steps,
            'timestamp': datetime.now().isoformat()
        }


# 独立运行测试
if __name__ == "__main__":
    manager = CounterattackPlaybookManager()

    # 创建剧本
    steps = [
        {'name': '阻断IP', 'action': 'block', 'timeout': 60},
        {'name': '部署蜜罐', 'action': 'honeypot', 'timeout': 120}
    ]

    pb = manager.create_playbook('DDoS响应剧本', '应对DDoS攻击', steps)
    print(f"剧本已创建: {pb.playbook_id}")
    print(f"步骤数: {len(pb.steps)}")

    # 执行剧本
    result = manager.execute_playbook(pb.playbook_id, {})
    print(f"执行结果: {result}")
