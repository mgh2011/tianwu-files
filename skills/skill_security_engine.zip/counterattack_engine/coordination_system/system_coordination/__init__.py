"""
系统协调模块
System Coordination Module

提供系统间的协调联动功能
"""

from .firewall_coordinator import FirewallCoordinator

__version__ = "v3.0.0"
__all__ = [
    'FirewallCoordinator'
]
