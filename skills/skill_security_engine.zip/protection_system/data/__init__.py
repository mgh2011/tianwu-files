"""
数据防护模块
Data Protection Module

提供数据安全保护功能
"""

__version__ = "v3.0.0"
__all__ = []
