"""
反击策略选择模块
Counterattack Strategy Selector - 选择最佳的反击策略
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class StrategyType(Enum):
    """策略类型"""
    PASSIVE_DEFENSE = "passive_defense"  # 被动防御
    ACTIVE_DEFENSE = "active_defense"  # 主动防御
    COUNTER_ATTACK = "counter_attack"  # 反制攻击
    HONEYPOT_TRAP = "honeypot_trap"  # 蜜罐诱捕
    DECEPTION = "deception"  # 欺骗防御
    HYBRID = "hybrid"  # 混合策略


class StrategyPriority(Enum):
    """策略优先级"""
    CRITICAL = 1  # 关键
    HIGH = 2  # 高
    MEDIUM = 3  # 中
    LOW = 4  # 低


@dataclass
class StrategyOption:
    """策略选项"""
    strategy_type: StrategyType
    name: str
    description: str
    priority: StrategyPriority
    effectiveness: float  # 有效性评分
    risk_score: float  # 风险评分
    cost: float  # 成本
    duration: int  # 预计时长（分钟）
    requirements: List[str] = field(default_factory=list)
    contraindications: List[str] = field(default_factory=list)


@dataclass
class StrategySelection:
    """策略选择结果"""
    recommended_strategy: StrategyOption
    alternatives: List[StrategyOption]
    reasoning: List[str]
    conditions: List[str]
    warnings: List[str]
    combined_strategy: Optional[Dict] = None


class CounterattackStrategySelector:
    """反击策略选择器"""

    # 策略配置
    STRATEGIES = {
        StrategyType.PASSIVE_DEFENSE: {
            'name': '被动防御策略',
            'description': '强化防御，阻断攻击但不主动出击',
            'effectiveness_range': (0.6, 0.8),
            'risk_range': (0.1, 0.3),
            'cost_range': (1, 3),
            'duration_range': (30, 120),
            'typical_actions': ['block', 'rate_limit', 'filter', 'isolate']
        },
        StrategyType.ACTIVE_DEFENSE: {
            'name': '主动防御策略',
            'description': '主动分析、追踪、干扰攻击者',
            'effectiveness_range': (0.7, 0.9),
            'risk_range': (0.2, 0.4),
            'cost_range': (3, 6),
            'duration_range': (60, 240),
            'typical_actions': ['trace', 'analyze', 'disrupt', 'deceive']
        },
        StrategyType.COUNTER_ATTACK: {
            'name': '反制攻击策略',
            'description': '对攻击者进行主动反击',
            'effectiveness_range': (0.5, 0.8),
            'risk_range': (0.5, 0.8),
            'cost_range': (5, 9),
            'duration_range': (120, 480),
            'typical_actions': ['counterattack', 'exploit', 'disrupt_attacker']
        },
        StrategyType.HONEYPOT_TRAP: {
            'name': '蜜罐诱捕策略',
            'description': '部署蜜罐诱捕攻击者收集情报',
            'effectiveness_range': (0.6, 0.85),
            'risk_range': (0.15, 0.35),
            'cost_range': (2, 5),
            'duration_range': (60, 1440),
            'typical_actions': ['deploy_honeypot', 'decoy_service', 'trap']
        },
        StrategyType.DECEPTION: {
            'name': '欺骗防御策略',
            'description': '使用虚假信息欺骗攻击者',
            'effectiveness_range': (0.55, 0.75),
            'risk_range': (0.1, 0.25),
            'cost_range': (2, 4),
            'duration_range': (30, 180),
            'typical_actions': ['fake_data', 'fake_vulnerability', 'mislead']
        },
    }

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化策略选择器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.strategies = self.STRATEGIES.copy()
        self.selection_history = []

    def select_strategy(self, context: Dict) -> StrategySelection:
        """
        选择最佳策略

        Args:
            context: 上下文信息，包含：
                - threat_info: 威胁信息
                - attack_info: 攻击信息
                - target_info: 目标信息
                - resource_info: 资源信息
                - legal_context: 法律背景
                - authorization_level: 授权级别

        Returns:
            策略选择结果
        """
        threat_info = context.get('threat_info', {})
        attack_info = context.get('attack_info', {})
        target_info = context.get('target_info', {})
        resource_info = context.get('resource_info', {})
        legal_context = context.get('legal_context', {})
        auth_level = context.get('authorization_level', 1)

        # 生成所有可能的策略
        strategies = self._generate_strategies(
            threat_info, attack_info, target_info, resource_info, legal_context
        )

        # 过滤不可用策略
        available_strategies = self._filter_strategies(
            strategies, auth_level, resource_info, legal_context
        )

        # 评分和排序
        scored_strategies = self._score_strategies(
            available_strategies, threat_info, attack_info, target_info
        )

        # 选择最佳策略
        if not scored_strategies:
            return self._create_no_strategy_result()

        best_strategy = scored_strategies[0]
        alternatives = scored_strategies[1:4]  # 前3个备选

        # 生成理由
        reasoning = self._generate_reasoning(
            best_strategy, threat_info, attack_info, alternatives
        )

        # 确定条件
        conditions = self._determine_conditions(best_strategy, legal_context)

        # 生成警告
        warnings = self._generate_warnings(
            best_strategy, threat_info, legal_context
        )

        # 检查是否需要混合策略
        combined = self._check_combined_strategy(
            best_strategy, alternatives, threat_info
        )

        # 构建结果
        selection = StrategySelection(
            recommended_strategy=best_strategy,
            alternatives=alternatives,
            reasoning=reasoning,
            conditions=conditions,
            warnings=warnings,
            combined_strategy=combined
        )

        # 更新历史
        self._update_history(selection, context)

        return selection

    def _generate_strategies(self, threat_info: Dict, attack_info: Dict,
                           target_info: Dict, resource_info: Dict,
                           legal_context: Dict) -> List[StrategyOption]:
        """生成策略选项"""
        strategies = []

        for strategy_type, config in self.strategies.items():
            option = StrategyOption(
                strategy_type=strategy_type,
                name=config['name'],
                description=config['description'],
                priority=StrategyPriority.MEDIUM,
                effectiveness=sum(config['effectiveness_range']) / 2,
                risk_score=sum(config['risk_range']) / 2,
                cost=sum(config['cost_range']) / 2,
                duration=sum(config['duration_range']) // 2,
                requirements=self._get_requirements(strategy_type, resource_info),
                contraindications=self._get_contraindications(strategy_type, legal_context)
            )
            strategies.append(option)

        return strategies

    def _filter_strategies(self, strategies: List[StrategyOption],
                          auth_level: int,
                          resource_info: Dict,
                          legal_context: Dict) -> List[StrategyOption]:
        """过滤不可用策略"""
        filtered = []

        for strategy in strategies:
            # 检查授权级别
            required_level = self._get_required_auth_level(strategy.strategy_type)
            if auth_level < required_level:
                continue

            # 检查禁忌症
            if strategy.contraindications:
                continue

            # 检查资源
            available_resources = resource_info.get('available', [])
            if not all(req in available_resources for req in strategy.requirements):
                continue

            filtered.append(strategy)

        return filtered

    def _score_strategies(self, strategies: List[StrategyOption],
                         threat_info: Dict,
                         attack_info: Dict,
                         target_info: Dict) -> List[StrategyOption]:
        """评分策略"""
        threat_level = threat_info.get('level', 50)
        attack_type = attack_info.get('type', 'unknown')
        target_critical = target_info.get('criticality', 'medium')

        scored = []

        for strategy in strategies:
            score = 0.0

            # 有效性评分
            score += strategy.effectiveness * 40

            # 风险评分（反转，越低越好）
            score += (1 - strategy.risk_score) * 30

            # 威胁匹配度
            threat_match = self._calculate_threat_match(
                strategy, threat_level, attack_type
            )
            score += threat_match * 20

            # 目标匹配度
            target_match = self._calculate_target_match(
                strategy, target_critical
            )
            score += target_match * 10

            # 排序
            strategy.effectiveness = score
            scored.append(strategy)

        # 按评分排序
        scored.sort(key=lambda x: x.effectiveness, reverse=True)

        return scored

    def _calculate_threat_match(self, strategy: StrategyOption,
                                threat_level: float,
                                attack_type: str) -> float:
        """计算威胁匹配度"""
        # 高威胁需要更主动的策略
        if threat_level >= 70:
            if strategy.strategy_type in [
                StrategyType.ACTIVE_DEFENSE,
                StrategyType.COUNTER_ATTACK,
                StrategyType.HYBRID
            ]:
                return 1.0
            elif strategy.strategy_type == StrategyType.HONEYPOT_TRAP:
                return 0.7
            else:
                return 0.5
        elif threat_level >= 50:
            if strategy.strategy_type in [
                StrategyType.ACTIVE_DEFENSE,
                StrategyType.HONEYPOT_TRAP
            ]:
                return 1.0
            else:
                return 0.6
        else:
            if strategy.strategy_type in [
                StrategyType.PASSIVE_DEFENSE,
                StrategyType.DECEPTION
            ]:
                return 1.0
            else:
                return 0.5

    def _calculate_target_match(self, strategy: StrategyOption,
                               target_critical: str) -> float:
        """计算目标匹配度"""
        if target_critical == 'critical':
            if strategy.risk_score < 0.3:
                return 1.0
            else:
                return 0.5
        elif target_critical == 'high':
            if strategy.risk_score < 0.4:
                return 1.0
            else:
                return 0.6
        else:
            return 0.8

    def _get_required_auth_level(self, strategy_type: StrategyType) -> int:
        """获取所需授权级别"""
        level_map = {
            StrategyType.PASSIVE_DEFENSE: 1,
            StrategyType.DECEPTION: 2,
            StrategyType.ACTIVE_DEFENSE: 2,
            StrategyType.HONEYPOT_TRAP: 2,
            StrategyType.COUNTER_ATTACK: 4,
            StrategyType.HYBRID: 3,
        }
        return level_map.get(strategy_type, 1)

    def _get_requirements(self, strategy_type: StrategyType,
                         resource_info: Dict) -> List[str]:
        """获取策略需求"""
        requirements_map = {
            StrategyType.PASSIVE_DEFENSE: ['firewall', 'ids'],
            StrategyType.ACTIVE_DEFENSE: ['siem', 'analysis_tool'],
            StrategyType.COUNTER_ATTACK: ['counter_tool', 'legal_approval'],
            StrategyType.HONEYPOT_TRAP: ['honeypot_server'],
            StrategyType.DECEPTION: ['deception_platform'],
        }
        return requirements_map.get(strategy_type, [])

    def _get_contraindications(self, strategy_type: StrategyType,
                               legal_context: Dict) -> List[str]:
        """获取禁忌症"""
        contraindications = []

        # 法律限制
        if not legal_context.get('counterattack_allowed', False):
            if strategy_type == StrategyType.COUNTER_ATTACK:
                contraindications.append("法律不允许主动反击")

        # 跨境限制
        if legal_context.get('cross_border_restriction', False):
            if strategy_type == StrategyType.COUNTER_ATTACK:
                contraindications.append("跨境行动受限")

        return contraindications

    def _generate_reasoning(self, best: StrategyOption,
                           threat_info: Dict,
                           attack_info: Dict,
                           alternatives: List[StrategyOption]) -> List[str]:
        """生成理由"""
        reasoning = []

        reasoning.append(
            f"推荐策略: {best.name}（评分: {best.effectiveness:.1f}）"
        )

        reasoning.append(
            f"策略描述: {best.description}"
        )

        if threat_info:
            reasoning.append(
                f"威胁等级: {threat_info.get('level', 'N/A')}，"
                f"攻击类型: {attack_info.get('type', 'N/A')}"
            )

        reasoning.append(
            f"预期有效性: {best.effectiveness:.0%}，"
            f"风险评分: {best.risk_score:.0%}，"
            f"成本: {best.cost:.1f}"
        )

        if alternatives:
            alt_names = [a.name for a in alternatives]
            reasoning.append(f"备选策略: {', '.join(alt_names)}")

        return reasoning

    def _determine_conditions(self, strategy: StrategyOption,
                             legal_context: Dict) -> List[str]:
        """确定条件"""
        conditions = []

        if strategy.risk_score > 0.5:
            conditions.append("必须持续监控执行效果")

        if legal_context.get('requires_reporting', False):
            conditions.append("需要向管理层报告进展")

        if strategy.strategy_type == StrategyType.COUNTER_ATTACK:
            conditions.append("必须在法律顾问监督下执行")

        return conditions

    def _generate_warnings(self, strategy: StrategyOption,
                          threat_info: Dict,
                          legal_context: Dict) -> List[str]:
        """生成警告"""
        warnings = []

        if strategy.risk_score > 0.6:
            warnings.append(f"警告: 该策略风险较高({strategy.risk_score:.0%})")

        if strategy.strategy_type == StrategyType.COUNTER_ATTACK:
            warnings.append("警告: 主动反击可能导致冲突升级")
            warnings.append("警告: 需要确保法律授权")

        if threat_info.get('apt_suspected', False):
            warnings.append("警告: 可能涉及高级持续性威胁(APT)")

        if legal_context.get('uncertainty', False):
            warnings.append("警告: 法律环境存在不确定性")

        return warnings

    def _check_combined_strategy(self, best: StrategyOption,
                                 alternatives: List[StrategyOption],
                                 threat_info: Dict) -> Optional[Dict]:
        """检查是否需要混合策略"""
        threat_level = threat_info.get('level', 50)

        # 高威胁且有多个可用策略时，考虑混合
        if threat_level >= 70 and len(alternatives) >= 2:
            return {
                'type': 'hybrid',
                'primary': best.strategy_type.value,
                'secondary': alternatives[0].strategy_type.value if alternatives else None,
                'phases': ['containment', 'investigation', 'response'],
                'rationale': '高威胁场景需要多层次防御'
            }

        return None

    def _create_no_strategy_result(self) -> StrategySelection:
        """创建无策略结果"""
        return StrategySelection(
            recommended_strategy=None,
            alternatives=[],
            reasoning=["当前条件下无可用策略"],
            conditions=["请提升授权级别或等待资源就绪"],
            warnings=["无合适策略可用"],
            combined_strategy=None
        )

    def _update_history(self, selection: StrategySelection, context: Dict):
        """更新历史"""
        self.selection_history.append({
            'selected_strategy': selection.recommended_strategy.strategy_type.value if selection.recommended_strategy else None,
            'score': selection.recommended_strategy.effectiveness if selection.recommended_strategy else 0,
            'context': context,
            'timestamp': datetime.now().isoformat()
        })

        if len(self.selection_history) > 500:
            self.selection_history = self.selection_history[-400:]


# 独立运行测试
if __name__ == "__main__":
    selector = CounterattackStrategySelector()

    # 测试策略选择
    context = {
        'threat_info': {
            'level': 75,
            'category': 'ddos'
        },
        'attack_info': {
            'type': 'ddos',
            'source_count': 1000,
            'intensity': 'high'
        },
        'target_info': {
            'criticality': 'critical',
            'system': 'web_application'
        },
        'resource_info': {
            'available': ['firewall', 'ids', 'honeypot_server', 'siem']
        },
        'legal_context': {
            'counterattack_allowed': True,
            'cross_border_restriction': True
        },
        'authorization_level': 3
    }

    selection = selector.select_strategy(context)

    print("策略选择结果:")
    print(f"推荐策略: {selection.recommended_strategy.name}")
    print(f"评分: {selection.recommended_strategy.effectiveness:.1f}")
    print(f"风险: {selection.recommended_strategy.risk_score:.0%}")
    print(f"\n理由:")
    for r in selection.reasoning:
        print(f"  - {r}")
    if selection.conditions:
        print(f"\n条件:")
        for c in selection.conditions:
            print(f"  - {c}")
    if selection.warnings:
        print(f"\n警告:")
        for w in selection.warnings:
            print(f"  - {w}")
    if selection.combined_strategy:
        print(f"\n混合策略: {selection.combined_strategy}")
