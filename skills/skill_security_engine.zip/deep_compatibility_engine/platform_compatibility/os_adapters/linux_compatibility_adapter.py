"""
深度兼容性引擎 - Linux操作系统兼容适配器
Linux Compatibility Adapter - 提供Linux平台的系统级兼容性支持
"""

from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json
import os
import subprocess
import platform


class LinuxDistribution(Enum):
    """Linux发行版"""
    UBUNTU = "ubuntu"
    DEBIAN = "debian"
    CENTOS = "centos"
    RHEL = "rhel"
    FEDORA = "fedora"
    KYLIN = "kylin"  # 麒麟
    NEOKYLIN = "neokylin"  # 中标麒麟
    DEEPIN = "deepin"  # 深度
    STARTOS = "startos"  # 统信UOS
    OTHER = "other"


@dataclass
class LinuxSystemInfo:
    """Linux系统信息"""
    distribution: LinuxDistribution
    version: str
    kernel_version: str
    arch: str
    hostname: str
    cpu_count: int
    memory_total: int
    disk_total: int
    features: List[str]


@dataclass
class CompatibilityResult:
    """兼容性结果"""
    compatible: bool
    distribution: str
    features_supported: List[str]
    features_unsupported: List[str]
    workarounds: List[str]
    warnings: List[str]


class LinuxCompatibilityAdapter:
    """Linux兼容适配器"""

    # 各发行版特性支持
    DISTRO_FEATURES = {
        LinuxDistribution.UBUNTU: ['apt', 'systemd', 'netplan', 'snap', 'ufw'],
        LinuxDistribution.DEBIAN: ['apt', 'systemd', 'iptables', 'sudo'],
        LinuxDistribution.CENTOS: ['yum', 'dnf', 'firewalld', 'selinux'],
        LinuxDistribution.RHEL: ['yum', 'dnf', 'firewalld', 'selinux'],
        LinuxDistribution.FEDORA: ['dnf', 'firewalld', 'selinux'],
        LinuxDistribution.KYLIN: ['yum', 'kylin-firewall', 'kmail'],
        LinuxDistribution.NEOKYLIN: ['yum', 'neo-firewall'],
        LinuxDistribution.DEEPIN: ['apt', 'deepin-desktop', 'DDE'],
        LinuxDistribution.STARTOS: ['apt', 'uos-desktop', 'UOS桌面'],
    }

    # 国产系统标识
    DOMESTIC_DISTROS = {LinuxDistribution.KYLIN, LinuxDistribution.NEOKYLIN,
                       LinuxDistribution.DEEPIN, LinuxDistribution.STARTOS}

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化Linux兼容适配器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.system_info = self._detect_system()
        self.is_domestic = self.system_info.distribution in self.DOMESTIC_DISTROS

    def check_compatibility(self, requirements: Dict) -> CompatibilityResult:
        """
        检查兼容性

        Args:
            requirements: 需求字典，包含：
                - features: 需要的特性列表
                - min_kernel_version: 最低内核版本
                - min_disk_space: 最小磁盘空间(MB)
                - min_memory: 最小内存(MB)

        Returns:
            兼容性结果
        """
        features_supported = []
        features_unsupported = []
        workarounds = []
        warnings = []

        required_features = requirements.get('features', [])
        for feature in required_features:
            if self._is_feature_supported(feature):
                features_supported.append(feature)
            else:
                features_unsupported.append(feature)
                workaround = self._get_workaround(feature)
                if workaround:
                    workarounds.append(workaround)

        # 检查内核版本
        min_kernel = requirements.get('min_kernel_version', '0.0.0')
        if self._compare_kernel_version(min_kernel) < 0:
            warnings.append(f"内核版本过低: 需要{min_kernel}, 当前{self.system_info.kernel_version}")

        # 检查磁盘空间
        min_disk = requirements.get('min_disk_space', 0)
        if self.system_info.disk_total < min_disk:
            warnings.append(f"磁盘空间不足: 需要{min_disk}MB, 当前{self.system_info.disk_total}MB")

        # 检查内存
        min_mem = requirements.get('min_memory', 0)
        if self.system_info.memory_total < min_mem:
            warnings.append(f"内存不足: 需要{min_mem}MB, 当前{self.system_info.memory_total}MB")

        compatible = len(features_unsupported) == 0 and len(warnings) == 0

        return CompatibilityResult(
            compatible=compatible,
            distribution=self.system_info.distribution.value,
            features_supported=features_supported,
            features_unsupported=features_unsupported,
            workarounds=workarounds,
            warnings=warnings
        )

    def get_package_manager(self) -> str:
        """获取包管理器"""
        distro = self.system_info.distribution
        if distro in [LinuxDistribution.UBUNTU, LinuxDistribution.DEBIAN,
                      LinuxDistribution.DEEPIN, LinuxDistribution.STARTOS]:
            return 'apt'
        elif distro in [LinuxDistribution.CENTOS, LinuxDistribution.RHEL,
                       LinuxDistribution.KYLIN, LinuxDistribution.NEOKYLIN]:
            return 'yum'
        elif distro == LinuxDistribution.FEDORA:
            return 'dnf'
        else:
            return 'unknown'

    def install_package(self, package_name: str) -> Dict:
        """
        安装软件包

        Args:
            package_name: 包名

        Returns:
            安装结果
        """
        pm = self.get_package_manager()
        if pm == 'unknown':
            return {'success': False, 'error': 'Unknown package manager'}

        try:
            if pm == 'apt':
                cmd = ['apt-get', 'install', '-y', package_name]
            elif pm in ['yum', 'dnf']:
                cmd = [pm, 'install', '-y', package_name]
            else:
                return {'success': False, 'error': f'Unsupported package manager: {pm}'}

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            return {
                'success': result.returncode == 0,
                'output': result.stdout,
                'error': result.stderr if result.returncode != 0 else None
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def configure_firewall(self, rules: List[Dict], action: str = 'add') -> Dict:
        """
        配置防火墙

        Args:
            rules: 规则列表
            action: 操作(add/remove)

        Returns:
            配置结果
        """
        distro = self.system_info.distribution
        results = []

        # 检测防火墙类型
        if distro in [LinuxDistribution.CENTOS, LinuxDistribution.RHEL,
                      LinuxDistribution.FEDORA]:
            firewall_type = 'firewalld'
        elif distro in [LinuxDistribution.KYLIN]:
            firewall_type = 'kylin-firewall'
        elif distro in [LinuxDistribution.UBUNTU, LinuxDistribution.DEBian]:
            firewall_type = 'ufw'
        else:
            firewall_type = 'iptables'

        for rule in rules:
            port = rule.get('port')
            protocol = rule.get('protocol', 'tcp')
            result = self._configure_firewall_rule(
                firewall_type, port, protocol, action
            )
            results.append(result)

        return {
            'firewall_type': firewall_type,
            'results': results,
            'all_success': all(r.get('success', False) for r in results)
        }

    def get_system_limits(self) -> Dict:
        """获取系统限制"""
        limits = {}
        try:
            with open('/etc/security/limits.conf', 'r') as f:
                limits['limits_conf'] = f.read()
        except:
            pass

        try:
            result = subprocess.run(
                ['sysctl', '-a'], capture_output=True, text=True, timeout=10
            )
            limits['sysctl'] = result.stdout
        except:
            pass

        return limits

    def adjust_system_limits(self, settings: Dict) -> Dict:
        """
        调整系统限制

        Args:
            settings: 设置字典

        Returns:
            调整结果
        """
        results = []

        for key, value in settings.items():
            try:
                result = subprocess.run(
                    ['sysctl', '-w', f'{key}={value}'],
                    capture_output=True, text=True
                )
                results.append({
                    'key': key,
                    'value': value,
                    'success': result.returncode == 0
                })
            except Exception as e:
                results.append({
                    'key': key,
                    'value': value,
                    'success': False,
                    'error': str(e)
                })

        return {
            'settings_applied': len([r for r in results if r['success']]),
            'results': results
        }

    def _detect_system(self) -> LinuxSystemInfo:
        """检测Linux系统"""
        try:
            # 获取发行版信息
            if os.path.exists('/etc/os-release'):
                with open('/etc/os-release', 'r') as f:
                    os_info = {}
                    for line in f:
                        if '=' in line:
                            key, value = line.strip().split('=', 1)
                            os_info[key] = value.strip('"')

                distro_name = os_info.get('ID', '').lower()
                version = os_info.get('VERSION_ID', '')

                # 匹配发行版
                distribution = LinuxDistribution.OTHER
                for distro in LinuxDistribution:
                    if distro.value in distro_name:
                        distribution = distro
                        break
            else:
                distribution = LinuxDistribution.OTHER
                version = 'unknown'

            # 获取内核版本
            kernel_version = platform.release()

            # 获取架构
            arch = platform.machine()

            # 获取主机名
            hostname = platform.node()

            # 获取CPU数量
            cpu_count = os.cpu_count() or 1

            # 获取内存总量
            try:
                with open('/proc/meminfo', 'r') as f:
                    for line in f:
                        if line.startswith('MemTotal:'):
                            memory_kb = int(line.split()[1])
                            memory_mb = memory_kb // 1024
                            break
            except:
                memory_mb = 0

            # 获取磁盘总量
            try:
                result = subprocess.run(
                    ['df', '-BG', '--total'],
                    capture_output=True, text=True, timeout=10
                )
                disk_gb = 0
                for line in result.stdout.split('\n'):
                    if 'total' in line:
                        parts = line.split()
                        for part in parts:
                            if part.endswith('G'):
                                disk_gb = int(part[:-1])
            except:
                disk_gb = 0

            # 获取支持的功能
            features = self.DISTRO_FEATURES.get(distribution, [])

            return LinuxSystemInfo(
                distribution=distribution,
                version=version,
                kernel_version=kernel_version,
                arch=arch,
                hostname=hostname,
                cpu_count=cpu_count,
                memory_total=memory_mb,
                disk_total=disk_gb * 1024,  # 转换为MB
                features=features
            )

        except Exception as e:
            return LinuxSystemInfo(
                distribution=LinuxDistribution.OTHER,
                version='unknown',
                kernel_version='unknown',
                arch='unknown',
                hostname='unknown',
                cpu_count=1,
                memory_total=0,
                disk_total=0,
                features=[]
            )

    def _is_feature_supported(self, feature: str) -> bool:
        """检查功能是否支持"""
        supported_features = self.system_info.features

        # 基础功能映射
        feature_map = {
            'firewall': ['firewalld', 'kylin-firewall', 'ufw', 'iptables'],
            'package_manager': ['apt', 'yum', 'dnf'],
            'systemd': ['systemd'],
            'selinux': ['selinux'],
            'container': ['docker', 'podman'],
        }

        if feature in feature_map:
            required = feature_map[feature]
            return any(f in supported_features for f in required)

        return feature in supported_features

    def _get_workaround(self, feature: str) -> Optional[str]:
        """获取变通方案"""
        workarounds = {
            'firewall': '可使用iptables作为替代方案',
            'systemd': '可使用init.d脚本或SysVinit',
            'selinux': '可暂时设置为permissive模式',
            'snap': '可使用apt或其他包管理器',
        }
        return workarounds.get(feature)

    def _compare_kernel_version(self, min_version: str) -> int:
        """比较内核版本"""
        try:
            current = self._parse_version(self.system_info.kernel_version)
            minimum = self._parse_version(min_version)

            if current >= minimum:
                return 1
            elif current < minimum:
                return -1
            else:
                return 0
        except:
            return 0

    def _parse_version(self, version: str) -> tuple:
        """解析版本号"""
        import re
        match = re.match(r'(\d+)\.(\d+)\.(\d+)', version)
        if match:
            return tuple(int(x) for x in match.groups())
        return (0, 0, 0)

    def _configure_firewall_rule(self, firewall_type: str, port: int,
                                protocol: str, action: str) -> Dict:
        """配置防火墙规则"""
        try:
            if firewall_type == 'firewalld':
                cmd = ['firewall-cmd']
                if action == 'add':
                    cmd.extend(['--add-port', f'{port}/{protocol}'])
                else:
                    cmd.extend(['--remove-port', f'{port}/{protocol}'])
                cmd.extend(['--permanent'])

            elif firewall_type == 'ufw':
                cmd = ['ufw']
                if action == 'add':
                    cmd.extend(['allow', f'{port}/{protocol}'])
                else:
                    cmd.extend(['deny', f'{port}/{protocol}'])

            elif firewall_type == 'iptables':
                if action == 'add':
                    cmd = ['iptables', '-A', 'INPUT', '-p', protocol,
                          '--dport', str(port), '-j', 'ACCEPT']
                else:
                    cmd = ['iptables', '-D', 'INPUT', '-p', protocol,
                          '--dport', str(port), '-j', 'ACCEPT']
            else:
                return {'success': False, 'error': f'Unknown firewall: {firewall_type}'}

            result = subprocess.run(cmd, capture_output=True, text=True)
            return {
                'success': result.returncode == 0,
                'port': port,
                'protocol': protocol,
                'action': action,
                'error': result.stderr if result.returncode != 0 else None
            }

        except Exception as e:
            return {'success': False, 'error': str(e)}


# 独立运行测试
if __name__ == "__main__":
    adapter = LinuxCompatibilityAdapter()

    print("=" * 60)
    print("Linux 兼容适配器测试")
    print("=" * 60)

    print(f"\n检测到的系统:")
    print(f"  发行版: {adapter.system_info.distribution.value}")
    print(f"  版本: {adapter.system_info.version}")
    print(f"  内核: {adapter.system_info.kernel_version}")
    print(f"  架构: {adapter.system_info.arch}")
    print(f"  CPU: {adapter.system_info.cpu_count}核")
    print(f"  内存: {adapter.system_info.memory_total}MB")
    print(f"  磁盘: {adapter.system_info.disk_total}MB")
    print(f"  功能: {adapter.system_info.features}")
    print(f"  国产系统: {'是' if adapter.is_domestic else '否'}")

    print(f"\n包管理器: {adapter.get_package_manager()}")

    # 检查兼容性
    print("\n兼容性检查:")
    requirements = {
        'features': ['firewall', 'systemd', 'apt'],
        'min_kernel_version': '4.0.0',
        'min_memory': 512
    }
    result = adapter.check_compatibility(requirements)
    print(f"  兼容: {'是' if result.compatible else '否'}")
    print(f"  支持的特性: {result.features_supported}")
    print(f"  不支持的特性: {result.features_unsupported}")
    if result.warnings:
        print(f"  警告: {result.warnings}")
    if result.workarounds:
        print(f"  变通方案: {result.workarounds}")
