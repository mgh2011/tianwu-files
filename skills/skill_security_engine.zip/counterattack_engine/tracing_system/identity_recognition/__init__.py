"""
身份识别模块
Identity Recognition Module

提供攻击者身份识别功能
"""

__version__ = "v3.0.0"
__all__ = []
