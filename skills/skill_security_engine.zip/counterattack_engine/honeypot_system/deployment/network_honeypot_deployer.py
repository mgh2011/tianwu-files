"""
蜜罐部署引擎 - 网络蜜罐部署模块
Network Honeypot Deployer - 部署网络层蜜罐服务
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class HoneypotType(Enum):
    """蜜罐类型"""
    TCP_LOW = "tcp_low"  # 低交互TCP蜜罐
    TCP_MEDIUM = "tcp_medium"  # 中交互TCP蜜罐
    HTTP = "http"  # HTTP蜜罐
    SSH = "ssh"  # SSH蜜罐
    FTP = "ftp"  # FTP蜜罐
    SMTP = "smtp"  # SMTP蜜罐
    DNS = "dns"  # DNS蜜罐
    RDP = "rdp"  # RDP蜜罐
    DATABASE = "database"  # 数据库蜜罐


class DeploymentStatus(Enum):
    """部署状态"""
    PENDING = "pending"
    DEPLOYING = "deploying"
    ACTIVE = "active"
    TRIGGERED = "triggered"
    ERROR = "error"
    STOPPED = "stopped"


@dataclass
class HoneypotConfig:
    """蜜罐配置"""
    name: str
    type: HoneypotType
    port: int
    banner: str
    responses: Dict[str, str] = field(default_factory=dict)
    allow_connections: bool = True
    max_connections: int = 100
    logging_enabled: bool = True


@dataclass
class HoneypotInstance:
    """蜜罐实例"""
    instance_id: str
    config: HoneypotConfig
    status: DeploymentStatus
    created_at: str
    triggered_count: int = 0
    total_connections: int = 0
    captured_data: List[Dict] = field(default_factory=list)


class NetworkHoneypotDeployer:
    """网络蜜罐部署器"""

    # 预定义蜜罐配置模板
    HONEYPOT_TEMPLATES = {
        HoneypotType.SSH: HoneypotConfig(
            name="SSH Honeypot",
            type=HoneypotType.SSH,
            port=22,
            banner="SSH-2.0-OpenSSH_7.4",
            responses={
                'password': 'Login incorrect',
                'auth_attempt': 'authentication failure'
            }
        ),
        HoneypotType.FTP: HoneypotConfig(
            name="FTP Honeypot",
            type=HoneypotType.FTP,
            port=21,
            banner="220 FTP Server ready",
            responses={
                'login': '530 Login incorrect',
                'user': '331 Password required'
            }
        ),
        HoneypotType.HTTP: HoneypotConfig(
            name="HTTP Honeypot",
            type=HoneypotType.HTTP,
            port=80,
            banner="HTTP/1.1 200 OK",
            responses={
                'admin': '<html><body><h1>Admin Panel</h1></body></html>',
                'login': '<html><body><form>Login</form></body></html>'
            }
        ),
        HoneypotType.TELNET: HoneypotConfig(
            name="Telnet Honeypot",
            type=HoneypotType.TCP_LOW,
            port=23,
            banner="Welcome to Ubuntu 20.04",
            responses={}
        ),
        HoneypotType.RDP: HoneypotConfig(
            name="RDP Honeypot",
            type=HoneypotType.RDP,
            port=3389,
            banner="",
            responses={}
        ),
    }

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化网络蜜罐部署器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.instances: Dict[str, HoneypotInstance] = {}
        self.network_range = self.config.get('network_range', '192.168.1.0/24')
        self.deployment_history = []

    def deploy(self, hp_type: HoneypotType, custom_config: Dict = None) -> HoneypotInstance:
        """
        部署蜜罐

        Args:
            hp_type: 蜜罐类型
            custom_config: 自定义配置

        Returns:
            蜜罐实例
        """
        # 获取模板配置
        template = self.HONEYPOT_TEMPLATES.get(hp_type)
        if not template:
            raise ValueError(f"不支持的蜜罐类型: {hp_type}")

        # 合并自定义配置
        if custom_config:
            config = HoneypotConfig(
                name=custom_config.get('name', template.name),
                type=hp_type,
                port=custom_config.get('port', template.port),
                banner=custom_config.get('banner', template.banner),
                responses=custom_config.get('responses', template.responses),
                allow_connections=custom_config.get('allow_connections', True),
                max_connections=custom_config.get('max_connections', template.max_connections),
                logging_enabled=custom_config.get('logging_enabled', True)
            )
        else:
            config = template

        # 生成实例ID
        instance_id = self._generate_instance_id(hp_type)

        # 创建实例
        instance = HoneypotInstance(
            instance_id=instance_id,
            config=config,
            status=DeploymentStatus.DEPLOYING,
            created_at=datetime.now().isoformat()
        )

        # 模拟部署过程
        instance.status = DeploymentStatus.ACTIVE

        # 保存实例
        self.instances[instance_id] = instance

        # 记录历史
        self._record_deployment(instance)

        return instance

    def deploy_multiple(self, hp_types: List[HoneypotType]) -> List[HoneypotInstance]:
        """批量部署蜜罐"""
        instances = []
        for hp_type in hp_types:
            try:
                instance = self.deploy(hp_type)
                instances.append(instance)
            except Exception as e:
                print(f"部署{hp_type}失败: {e}")
        return instances

    def undeploy(self, instance_id: str) -> bool:
        """
        卸载蜜罐

        Args:
            instance_id: 实例ID

        Returns:
            是否成功
        """
        if instance_id not in self.instances:
            return False

        instance = self.instances[instance_id]
        instance.status = DeploymentStatus.STOPPED

        return True

    def get_instance(self, instance_id: str) -> Optional[HoneypotInstance]:
        """获取蜜罐实例"""
        return self.instances.get(instance_id)

    def list_instances(self, status: DeploymentStatus = None) -> List[HoneypotInstance]:
        """
        列出蜜罐实例

        Args:
            status: 筛选状态

        Returns:
            实例列表
        """
        instances = list(self.instances.values())
        if status:
            instances = [i for i in instances if i.status == status]
        return instances

    def record_connection(self, instance_id: str, connection_info: Dict):
        """
        记录连接

        Args:
            instance_id: 实例ID
            connection_info: 连接信息
        """
        if instance_id not in self.instances:
            return

        instance = self.instances[instance_id]
        instance.total_connections += 1

        # 捕获的数据
        captured = {
            'timestamp': datetime.now().isoformat(),
            'source_ip': connection_info.get('source_ip'),
            'source_port': connection_info.get('source_port'),
            'data': connection_info.get('data', ''),
            'commands': connection_info.get('commands', [])
        }
        instance.captured_data.append(captured)

        # 触发计数
        if connection_info.get('is_malicious', False):
            instance.triggered_count += 1
            instance.status = DeploymentStatus.TRIGGERED

        # 限制捕获数据大小
        if len(instance.captured_data) > 10000:
            instance.captured_data = instance.captured_data[-8000:]

    def get_captured_data(self, instance_id: str,
                          limit: int = 100) -> List[Dict]:
        """获取捕获的数据"""
        instance = self.instances.get(instance_id)
        if not instance:
            return []

        return instance.captured_data[-limit:]

    def get_statistics(self) -> Dict:
        """获取统计信息"""
        total = len(self.instances)
        active = len([i for i in self.instances.values()
                     if i.status == DeploymentStatus.ACTIVE])
        triggered = len([i for i in self.instances.values()
                        if i.status == DeploymentStatus.TRIGGERED])

        total_connections = sum(i.total_connections for i in self.instances.values())
        total_triggered = sum(i.triggered_count for i in self.instances.values())

        by_type = {}
        for instance in self.instances.values():
            hp_type = instance.config.type.value
            if hp_type not in by_type:
                by_type[hp_type] = {'count': 0, 'connections': 0, 'triggered': 0}
            by_type[hp_type]['count'] += 1
            by_type[hp_type]['connections'] += instance.total_connections
            by_type[hp_type]['triggered'] += instance.triggered_count

        return {
            'total_instances': total,
            'active_instances': active,
            'triggered_instances': triggered,
            'total_connections': total_connections,
            'total_triggered': total_triggered,
            'by_type': by_type
        }

    def _generate_instance_id(self, hp_type: HoneypotType) -> str:
        """生成实例ID"""
        import hashlib
        timestamp = datetime.now().isoformat()
        content = f"{hp_type.value}:{timestamp}"
        return f"HP-{hp_type.value.upper()}-{hashlib.md5(content.encode()).hexdigest()[:8]}"

    def _record_deployment(self, instance: HoneypotInstance):
        """记录部署历史"""
        self.deployment_history.append({
            'instance_id': instance.instance_id,
            'type': instance.config.type.value,
            'port': instance.config.port,
            'timestamp': instance.created_at,
            'status': instance.status.value
        })

        if len(self.deployment_history) > 1000:
            self.deployment_history = self.deployment_history[-800:]


# 独立运行测试
if __name__ == "__main__":
    deployer = NetworkHoneypotDeployer()

    # 部署SSH蜜罐
    ssh_hp = deployer.deploy(HoneypotType.SSH)
    print(f"SSH蜜罐已部署: {ssh_hp.instance_id}")

    # 部署HTTP蜜罐
    http_hp = deployer.deploy(HoneypotType.HTTP, {
        'port': 8080,
        'banner': 'Apache/2.4.41'
    })
    print(f"HTTP蜜罐已部署: {http_hp.instance_id}")

    # 批量部署
    hp_types = [HoneypotType.FTP, HoneypotType.TELNET, HoneypotType.RDP]
    instances = deployer.deploy_multiple(hp_types)
    print(f"批量部署完成: {len(instances)}个蜜罐")

    # 模拟记录连接
    deployer.record_connection(ssh_hp.instance_id, {
        'source_ip': '192.168.1.100',
        'source_port': 54321,
        'data': 'root\npassword123\n',
        'commands': ['root', 'password123'],
        'is_malicious': True
    })

    # 获取统计
    stats = deployer.get_statistics()
    print(f"\n蜜罐统计:")
    print(json.dumps(stats, indent=2))

    # 获取实例列表
    active = deployer.list_instances(DeploymentStatus.ACTIVE)
    print(f"\n活跃蜜罐: {len(active)}个")
