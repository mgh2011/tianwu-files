# 对话引擎测试用例

import pytest
import asyncio
from datetime import datetime
from dialog_engine import (
    DialogEngine, DialogStateManager, ContextManager,
    IntentClassifier, EntityExtractor, SlotFiller,
    PolicyRouter, ResponseGenerator,
    ShortTermMemory, LongTermMemory, UserProfileManager,
    ContentFilter, PrivacyGuard, AuditLogger
)
from dialog_engine.models.data_models import (
    DialogRequest, IntentResult, IntentType, Entity, EntityType,
    Slot, SlotType, SlotStatus, DialogState, MessageType
)


# ============== 测试夹具 ==============

@pytest.fixture
def event_loop():
    """创建事件循环"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def dialog_engine():
    """创建对话引擎实例"""
    engine = DialogEngine()
    
    # 注册组件
    engine.register_component("intent_classifier", IntentClassifier())
    engine.register_component("entity_extractor", EntityExtractor())
    engine.register_component("slot_filler", SlotFiller())
    engine.register_component("policy_router", PolicyRouter())
    engine.register_component("response_generator", ResponseGenerator())
    engine.register_component("content_filter", ContentFilter())
    engine.register_component("privacy_guard", PrivacyGuard())
    engine.register_component("audit_logger", AuditLogger())
    
    return engine


@pytest.fixture
def sample_request():
    """创建示例请求"""
    return DialogRequest(
        session_id="test_session_001",
        user_id="test_user_001",
        message="你好，我想查询明天的天气",
        message_type=MessageType.TEXT
    )


# ============== 对话引擎测试 ==============

class TestDialogEngine:
    """对话引擎测试"""
    
    @pytest.mark.asyncio
    async def test_start_session(self, dialog_engine):
        """测试会话开始"""
        session = await dialog_engine.start_session(
            "test_session",
            "test_user"
        )
        
        assert session is not None
        assert session.session_id == "test_session"
        assert session.user_id == "test_user"
        assert session.state == DialogState.INIT
    
    @pytest.mark.asyncio
    async def test_end_session(self, dialog_engine):
        """测试会话结束"""
        await dialog_engine.start_session("test_session", "test_user")
        result = await dialog_engine.end_session("test_session")
        
        assert result is True
    
    @pytest.mark.asyncio
    async def test_process_message(self, dialog_engine, sample_request):
        """测试消息处理"""
        response = await dialog_engine.process_message(sample_request)
        
        assert response is not None
        assert response.response_id is not None
        assert response.session_id == sample_request.session_id
    
    @pytest.mark.asyncio
    async def test_get_session_state(self, dialog_engine):
        """测试获取会话状态"""
        await dialog_engine.start_session("test_session", "test_user")
        state = await dialog_engine.get_session_state("test_session")
        
        assert state is not None
        assert state["session_id"] == "test_session"
    
    def test_health_check(self, dialog_engine):
        """测试健康检查"""
        health = dialog_engine.health_check()
        
        assert health["status"] == "healthy"
        assert "components" in health
        assert "metrics" in health
    
    def test_get_metrics(self, dialog_engine):
        """测试获取指标"""
        metrics = dialog_engine.get_metrics()
        
        assert "total_requests" in metrics
        assert "successful_requests" in metrics


# ============== 状态管理器测试 ==============

class TestStateManager:
    """状态管理器测试"""
    
    def test_create_session(self):
        """测试创建会话"""
        manager = DialogStateManager()
        session = manager.create_session("sess_001", "user_001")
        
        assert session.session_id == "sess_001"
        assert session.user_id == "user_001"
        assert session.state == DialogState.INIT
    
    def test_get_session(self):
        """测试获取会话"""
        manager = DialogStateManager()
        manager.create_session("sess_001", "user_001")
        
        session = manager.get_session("sess_001")
        assert session is not None
        assert session.session_id == "sess_001"
    
    def test_transition(self):
        """测试状态转换"""
        manager = DialogStateManager()
        manager.create_session("sess_001", "user_001")
        
        success = manager.transition("sess_001", "message")
        assert success is True
        
        state = manager.get_state("sess_001")
        assert state == DialogState.WAITING_INTENT
    
    def test_end_session(self):
        """测试结束会话"""
        manager = DialogStateManager()
        manager.create_session("sess_001", "user_001")
        
        result = manager.end_session("sess_001")
        assert result is True
        
        session = manager.get_session("sess_001")
        assert session.state == DialogState.COMPLETED


# ============== 上下文管理器测试 ==============

class TestContextManager:
    """上下文管理器测试"""
    
    def test_create_context(self):
        """测试创建上下文"""
        manager = ContextManager()
        context = manager.create_context("sess_001", "user_001")
        
        assert context.session_id == "sess_001"
        assert context.user_id == "user_001"
        assert context.current_turn == 0
    
    def test_add_turn(self):
        """测试添加轮次"""
        manager = ContextManager()
        manager.create_context("sess_001", "user_001")
        
        turn = manager.add_turn(
            "sess_001",
            "你好",
            "您好！"
        )
        
        assert turn is not None
        assert turn.user_message == "你好"
        assert turn.bot_response == "您好！"
    
    def test_update_slots(self):
        """测试更新槽位"""
        manager = ContextManager()
        manager.create_context("sess_001", "user_001")
        
        slot = Slot(
            name="location",
            type=SlotType.REQUIRED,
            value="北京",
            status=SlotStatus.FILLED
        )
        
        result = manager.update_slots("sess_001", {"location": slot})
        assert result is True
        
        retrieved_slot = manager.get_slot("sess_001", "location")
        assert retrieved_slot.value == "北京"


# ============== 意图分类器测试 ==============

class TestIntentClassifier:
    """意图分类器测试"""
    
    @pytest.mark.asyncio
    async def test_greeting_intent(self):
        """测试问候意图"""
        classifier = IntentClassifier()
        result = await classifier.classify("你好")
        
        assert result is not None
        assert result.intent == IntentType.GREETING
        assert result.confidence > 0
    
    @pytest.mark.asyncio
    async def test_query_intent(self):
        """测试查询意图"""
        classifier = IntentClassifier()
        result = await classifier.classify("帮我查询天气")
        
        assert result is not None
        assert result.intent == IntentType.QUERY
    
    @pytest.mark.asyncio
    async def test_unknown_intent(self):
        """测试未知意图"""
        classifier = IntentClassifier()
        result = await classifier.classify("asdfghjkl")
        
        assert result is not None
        # 可能识别为UNKNOWN
    
    def test_add_intent_rule(self):
        """测试添加意图规则"""
        classifier = IntentClassifier()
        classifier.add_intent_rule("custom_intent", ["自定义关键词"])
        
        assert "custom_intent" in classifier.intent_rules


# ============== 实体抽取器测试 ==============

class TestEntityExtractor:
    """实体抽取器测试"""
    
    @pytest.mark.asyncio
    async def test_extract_phone(self):
        """测试手机号抽取"""
        extractor = EntityExtractor()
        entities = await extractor.extract("我的电话是13812345678")
        
        phone_entities = [e for e in entities if e.type == EntityType.PHONE]
        assert len(phone_entities) > 0
        assert phone_entities[0].value == "13812345678"
    
    @pytest.mark.asyncio
    async def test_extract_email(self):
        """测试邮箱抽取"""
        extractor = EntityExtractor()
        entities = await extractor.extract("邮箱test@example.com")
        
        email_entities = [e for e in entities if e.type == EntityType.EMAIL]
        assert len(email_entities) > 0
    
    @pytest.mark.asyncio
    async def test_extract_date(self):
        """测试日期抽取"""
        extractor = EntityExtractor()
        entities = await extractor.extract("明天的天气")
        
        date_entities = [e for e in entities if e.type == EntityType.DATE]
        assert len(date_entities) > 0
    
    def test_add_dictionary(self):
        """测试添加词典"""
        extractor = EntityExtractor()
        extractor.add_dictionary(EntityType.CUSTOM, ["自定义实体"])
        
        assert EntityType.CUSTOM in extractor.dictionaries


# ============== 槽位填充器测试 ==============

class TestSlotFiller:
    """槽位填充器测试"""
    
    @pytest.mark.asyncio
    async def test_fill_slots(self):
        """测试槽位填充"""
        filler = SlotFiller()
        
        intent = IntentResult(
            intent=IntentType.QUERY,
            confidence=0.9
        )
        
        entities = [
            Entity(type=EntityType.DATE, value="明天", confidence=0.9)
        ]
        
        result = await filler.fill_slots(intent, entities, None)
        
        assert result is not None
        assert "date" in result.filled_slots or len(result.missing_slots) >= 0
    
    @pytest.mark.asyncio
    async def test_validate_phone(self):
        """测试手机号验证"""
        filler = SlotFiller()
        
        valid = await filler.validate_slot("phone", "13812345678")
        invalid = await filler.validate_slot("phone", "12345")
        
        assert valid is True
        assert invalid is False
    
    @pytest.mark.asyncio
    async def test_validate_email(self):
        """测试邮箱验证"""
        filler = SlotFiller()
        
        valid = await filler.validate_slot("email", "test@example.com")
        invalid = await filler.validate_slot("email", "invalid-email")
        
        assert valid is True
        assert invalid is False


# ============== 策略路由器测试 ==============

class TestPolicyRouter:
    """策略路由器测试"""
    
    @pytest.mark.asyncio
    async def test_route_greeting(self):
        """测试问候策略路由"""
        router = PolicyRouter()
        
        intent = IntentResult(
            intent=IntentType.GREETING,
            confidence=0.9
        )
        
        policy = await router.route(intent, None)
        
        assert policy is not None
        assert policy.name == "greeting"
    
    @pytest.mark.asyncio
    async def test_route_unknown(self):
        """测试未知意图路由"""
        router = PolicyRouter()
        
        intent = IntentResult(
            intent=IntentType.UNKNOWN,
            confidence=0.0
        )
        
        policy = await router.route(intent, None)
        
        assert policy is not None
        assert policy.name == "fallback"
    
    def test_register_policy(self):
        """测试注册策略"""
        from dialog_engine.models.data_models import DialogPolicy
        
        router = PolicyRouter()
        
        policy = DialogPolicy(
            name="custom_policy",
            intent=IntentType.UNKNOWN,
            response_templates={"default": "Custom response"}
        )
        
        router.register_policy(policy)
        
        assert "custom_policy" in router.policies


# ============== 回复生成器测试 ==============

class TestResponseGenerator:
    """回复生成器测试"""
    
    @pytest.mark.asyncio
    async def test_generate_greeting(self):
        """测试生成问候回复"""
        generator = ResponseGenerator()
        
        response = await generator.generate(
            "resp_001",
            DialogRequest(
                session_id="sess_001",
                user_id="user_001",
                message="你好"
            ),
            IntentResult(intent=IntentType.GREETING, confidence=0.9),
            [],
            None,
            None,
            None
        )
        
        assert response is not None
        assert response.message.content is not None
        assert len(response.message.content) > 0


# ============== 短期记忆测试 ==============

class TestShortTermMemory:
    """短期记忆测试"""
    
    @pytest.mark.asyncio
    async def test_remember_recall(self):
        """测试记忆存取"""
        memory = ShortTermMemory("test_session")
        await memory.start()
        
        await memory.remember("key1", "value1")
        value = await memory.recall("key1")
        
        assert value == "value1"
        
        await memory.stop()
    
    @pytest.mark.asyncio
    async def test_forget(self):
        """测试遗忘"""
        memory = ShortTermMemory("test_session")
        await memory.start()
        
        await memory.remember("key1", "value1")
        await memory.forget("key1")
        value = await memory.recall("key1")
        
        assert value is None
        
        await memory.stop()
    
    @pytest.mark.asyncio
    async def test_clear(self):
        """测试清空"""
        memory = ShortTermMemory("test_session")
        await memory.start()
        
        await memory.remember("key1", "value1")
        await memory.remember("key2", "value2")
        await memory.clear()
        
        size = await memory.size()
        assert size == 0
        
        await memory.stop()


# ============== 长期记忆测试 ==============

class TestLongTermMemory:
    """长期记忆测试"""
    
    @pytest.mark.asyncio
    async def test_store_retrieve(self):
        """测试存储和检索"""
        from dialog_engine.models.data_models import Memory
        
        memory = LongTermMemory()
        
        mem = Memory(
            memory_id="mem_001",
            user_id="user_001",
            content="用户喜欢查询天气",
            memory_type="preference"
        )
        
        memory_id = await memory.store("user_001", mem)
        results = await memory.retrieve("user_001", "天气")
        
        assert len(results) > 0
        assert any(r.memory_id == memory_id for r in results)
    
    @pytest.mark.asyncio
    async def test_delete(self):
        """测试删除记忆"""
        from dialog_engine.models.data_models import Memory
        
        memory = LongTermMemory()
        
        mem = Memory(
            memory_id="mem_001",
            user_id="user_001",
            content="测试记忆",
            memory_type="test"
        )
        
        memory_id = await memory.store("user_001", mem)
        result = await memory.delete("user_001", memory_id)
        
        assert result is True


# ============== 用户画像测试 ==============

class TestUserProfile:
    """用户画像测试"""
    
    @pytest.mark.asyncio
    async def test_get_profile(self):
        """测试获取画像"""
        manager = UserProfileManager()
        
        profile = await manager.get_profile("user_001")
        
        assert profile is not None
        assert profile.user_id == "user_001"
    
    @pytest.mark.asyncio
    async def test_add_interaction(self):
        """测试添加交互"""
        manager = UserProfileManager()
        
        await manager.add_interaction("user_001", {
            "message": "你好",
            "intent": "greeting"
        })
        
        profile = await manager.get_profile("user_001")
        assert profile.interaction_count == 1


# ============== 内容过滤测试 ==============

class TestContentFilter:
    """内容过滤测试"""
    
    @pytest.mark.asyncio
    async def test_safe_content(self):
        """测试安全内容"""
        filter = ContentFilter()
        
        result = await filter.check("今天天气很好")
        
        assert result.is_safe is True
        assert result.sensitive_level.value == "safe"
    
    @pytest.mark.asyncio
    async def test_custom_word(self):
        """测试自定义敏感词"""
        filter = ContentFilter()
        filter.add_word("测试敏感词", "custom")
        
        result = await filter.check("这是一个测试敏感词")
        
        assert result.is_safe is False
        assert "测试敏感词" in result.sensitive_words


# ============== 隐私保护测试 ==============

class TestPrivacyGuard:
    """隐私保护测试"""
    
    @pytest.mark.asyncio
    async def test_mask_phone(self):
        """测试手机号脱敏"""
        guard = PrivacyGuard()
        
        masked = await guard.protect("我的电话是13812345678")
        
        assert "13812345678" not in masked
        assert "****" in masked or "*" in masked
    
    @pytest.mark.asyncio
    async def test_mask_email(self):
        """测试邮箱脱敏"""
        guard = PrivacyGuard()
        
        masked = await guard.protect("邮箱test@example.com")
        
        assert "test@example.com" not in masked
    
    @pytest.mark.asyncio
    async def test_detect_pii(self):
        """测试PII检测"""
        guard = PrivacyGuard()
        
        detected = await guard.detect("电话13812345678")
        
        assert len(detected) > 0
        assert detected[0]["type"] == "phone"


# ============== 审计日志测试 ==============

class TestAuditLogger:
    """审计日志测试"""
    
    @pytest.mark.asyncio
    async def test_log_action(self):
        """测试记录操作"""
        logger = AuditLogger()
        
        log_id = await logger.log(
            "sess_001",
            "user_001",
            "message_sent",
            "测试消息",
            "success"
        )
        
        assert log_id is not None
    
    @pytest.mark.asyncio
    async def test_get_logs(self):
        """测试获取日志"""
        logger = AuditLogger()
        
        await logger.log("sess_001", "user_001", "message_sent", "msg1", "success")
        await logger.log("sess_001", "user_001", "message_sent", "msg2", "success")
        
        logs = await logger.get_session_logs("sess_001")
        
        assert len(logs) >= 2


# ============== 运行测试 ==============

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
