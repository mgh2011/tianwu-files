# dialog_engine/memory/user_profile.py
"""
用户画像管理
维护用户特征、偏好、历史交互
"""

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional
from dataclasses import asdict

from ..models.data_models import (
    UserProfile, UserPreferences, 
    DialogContext, IntentResult
)


logger = logging.getLogger(__name__)


class UserProfileManager:
    """
    用户画像管理器
    维护用户特征、偏好、历史交互
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.enable_auto_update = self.config.get("enable_auto_update", True)
        self.update_interval = self.config.get("update_interval", 86400)
        self.min_interactions = self.config.get("min_interactions_for_profile", 5)
        
        # 用户画像存储
        self._profiles: Dict[str, UserProfile] = {}
        
        # 交互历史
        self._interactions: Dict[str, List[Dict]] = {}
        
        # 行为模式分析
        self._behavior_patterns: Dict[str, Dict] = {}
        
    async def get_profile(self, user_id: str) -> UserProfile:
        """
        获取用户画像
        
        Args:
            user_id: 用户ID
            
        Returns:
            UserProfile: 用户画像
        """
        if user_id not in self._profiles:
            # 创建新画像
            self._profiles[user_id] = UserProfile(
                user_id=user_id,
                preferences=UserPreferences(),
                tags=[],
                interaction_count=0
            )
            self._interactions[user_id] = []
        
        return self._profiles[user_id]
    
    async def update_profile(self, user_id: str, 
                           updates: Dict[str, Any]) -> bool:
        """
        更新用户画像
        
        Args:
            user_id: 用户ID
            updates: 更新内容
            
        Returns:
            是否更新成功
        """
        profile = await self.get_profile(user_id)
        
        # 更新基本字段
        for key, value in updates.items():
            if hasattr(profile, key):
                setattr(profile, key, value)
        
        profile.updated_at = datetime.now()
        logger.debug(f"Updated profile for user {user_id}")
        return True
    
    async def add_interaction(self, user_id: str, 
                             interaction: Dict[str, Any]) -> None:
        """
        添加交互记录
        
        Args:
            user_id: 用户ID
            interaction: 交互记录
        """
        if user_id not in self._interactions:
            self._interactions[user_id] = []
        
        # 添加时间戳
        interaction["timestamp"] = datetime.now().isoformat()
        
        self._interactions[user_id].append(interaction)
        
        # 更新画像统计
        profile = await self.get_profile(user_id)
        profile.interaction_count += 1
        profile.last_interaction_at = datetime.now()
        
        # 自动分析行为模式
        if self.enable_auto_update and len(self._interactions[user_id]) >= self.min_interactions:
            await self._analyze_behavior(user_id)
        
        # 提取偏好
        if self.config.get("extract_preferences", True):
            await self._extract_preferences(user_id, interaction)
    
    async def _analyze_behavior(self, user_id: str) -> None:
        """分析用户行为模式"""
        interactions = self._interactions.get(user_id, [])
        
        if len(interactions) < self.min_interactions:
            return
        
        # 分析常见意图
        intent_counts: Dict[str, int] = {}
        time_patterns = {"morning": 0, "afternoon": 0, "evening": 0}
        
        for interaction in interactions:
            # 意图统计
            intent = interaction.get("intent")
            if intent:
                intent_counts[intent] = intent_counts.get(intent, 0) + 1
            
            # 时间模式
            timestamp = interaction.get("timestamp")
            if timestamp:
                try:
                    dt = datetime.fromisoformat(timestamp)
                    hour = dt.hour
                    if 6 <= hour < 12:
                        time_patterns["morning"] += 1
                    elif 12 <= hour < 18:
                        time_patterns["afternoon"] += 1
                    else:
                        time_patterns["evening"] += 1
                except:
                    pass
        
        # 保存行为模式
        self._behavior_patterns[user_id] = {
            "top_intents": sorted(intent_counts.items(), 
                                  key=lambda x: x[1], reverse=True)[:5],
            "time_preference": max(time_patterns.items(), 
                                   key=lambda x: x[1])[0] if any(time_patterns.values()) else "evening",
            "total_interactions": len(interactions)
        }
        
        logger.debug(f"Analyzed behavior for user {user_id}")
    
    async def _extract_preferences(self, user_id: str,
                                   interaction: Dict[str, Any]) -> None:
        """提取用户偏好"""
        profile = await self.get_profile(user_id)
        
        # 从交互中提取偏好
        message = interaction.get("message", "")
        intent = interaction.get("intent", "")
        
        # 简单的关键词偏好提取
        preference_keywords = {
            "详细": ["详细", "具体", "全面"],
            "简洁": ["简单", "简洁", "简要"],
            "快捷": ["快", "速度", "迅速"],
        }
        
        for pref, keywords in preference_keywords.items():
            if any(kw in message for kw in keywords):
                if pref not in profile.tags:
                    profile.tags.append(pref)
    
    async def get_preferences(self, user_id: str) -> UserPreferences:
        """获取用户偏好"""
        profile = await self.get_profile(user_id)
        return profile.preferences
    
    async def set_preference(self, user_id: str, 
                            key: str, value: Any) -> bool:
        """设置用户偏好"""
        profile = await self.get_profile(user_id)
        
        if hasattr(profile.preferences, key):
            setattr(profile.preferences, key, value)
            return True
        
        # 自定义偏好
        profile.preferences.custom_preferences[key] = value
        return True
    
    async def get_interaction_history(self, user_id: str,
                                     limit: int = 50) -> List[Dict]:
        """获取交互历史"""
        interactions = self._interactions.get(user_id, [])
        return interactions[-limit:]
    
    async def get_behavior_patterns(self, user_id: str) -> Dict:
        """获取行为模式"""
        if user_id not in self._behavior_patterns:
            await self._analyze_behavior(user_id)
        
        return self._behavior_patterns.get(user_id, {})
    
    async def get_top_intents(self, user_id: str, 
                             limit: int = 5) -> List[tuple]:
        """获取最常用的意图"""
        patterns = await self.get_behavior_patterns(user_id)
        return patterns.get("top_intents", [])[:limit]
    
    async def add_tag(self, user_id: str, tag: str) -> bool:
        """添加用户标签"""
        profile = await self.get_profile(user_id)
        
        if tag not in profile.tags:
            profile.tags.append(tag)
            logger.debug(f"Added tag '{tag}' to user {user_id}")
            return True
        
        return False
    
    async def remove_tag(self, user_id: str, tag: str) -> bool:
        """移除用户标签"""
        profile = await self.get_profile(user_id)
        
        if tag in profile.tags:
            profile.tags.remove(tag)
            return True
        
        return False
    
    async def get_user_summary(self, user_id: str) -> Dict:
        """获取用户摘要"""
        profile = await self.get_profile(user_id)
        patterns = await self.get_behavior_patterns(user_id)
        
        return {
            "user_id": user_id,
            "name": profile.name,
            "interaction_count": profile.interaction_count,
            "last_interaction": profile.last_interaction_at.isoformat() if profile.last_interaction_at else None,
            "top_intents": [i[0] for i in patterns.get("top_intents", [])[:3]],
            "time_preference": patterns.get("time_preference", "evening"),
            "tags": profile.tags,
            "language": profile.preferences.language,
        }
    
    async def delete_profile(self, user_id: str) -> bool:
        """删除用户画像"""
        if user_id in self._profiles:
            del self._profiles[user_id]
        
        if user_id in self._interactions:
            del self._interactions[user_id]
        
        if user_id in self._behavior_patterns:
            del self._behavior_patterns[user_id]
        
        logger.info(f"Deleted profile for user {user_id}")
        return True
    
    async def export_profile(self, user_id: str) -> Optional[Dict]:
        """导出用户画像"""
        profile = await self.get_profile(user_id)
        return asdict(profile)
    
    async def import_profile(self, data: Dict) -> str:
        """导入用户画像"""
        user_id = data.get("user_id")
        
        if not user_id:
            return None
        
        profile = UserProfile(
            user_id=user_id,
            name=data.get("name"),
            preferences=UserPreferences(**data.get("preferences", {})),
            tags=data.get("tags", []),
            interaction_count=data.get("interaction_count", 0)
        )
        
        self._profiles[user_id] = profile
        
        logger.info(f"Imported profile for user {user_id}")
        return user_id
