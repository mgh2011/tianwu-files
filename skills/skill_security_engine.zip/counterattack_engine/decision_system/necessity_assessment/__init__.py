"""
必要性评估模块
Necessity Assessment Module

提供反击必要性、利益、风险等评估功能
"""

from .counterattack_benefit_analyzer import CounterattackBenefitAnalyzer
from .counterattack_decision_tree import CounterattackDecisionTree
from .counterattack_risk_analyzer import CounterattackRiskAnalyzer
from .damage_assessor import DamageAssessor
from .threat_level_assessor import ThreatLevelAssessor

__version__ = "v3.0.0"
__all__ = [
    'CounterattackBenefitAnalyzer',
    'CounterattackDecisionTree',
    'CounterattackRiskAnalyzer',
    'DamageAssessor',
    'ThreatLevelAssessor'
]
