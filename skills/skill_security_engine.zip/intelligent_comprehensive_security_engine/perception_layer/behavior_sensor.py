"""
行为感知引擎 - 行为感知
Behavior Sensor

感知用户、实体、网络、应用、数据行为
"""

import logging
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class BehaviorSensor:
    """行为感知引擎"""
    
    def __init__(self, config: Dict = None):
        """初始化行为感知引擎"""
        self.config = config or {}
        self._sensors = {
            'user': UserBehaviorSensor(self.config),
            'entity': EntityBehaviorSensor(self.config),
            'network': NetworkBehaviorSensor(self.config),
            'application': ApplicationBehaviorSensor(self.config),
            'data': DataBehaviorSensor(self.config)
        }
        self._baseline_profiles = {}
        self._anomaly_thresholds = {
            'user': 0.7,
            'entity': 0.6,
            'network': 0.5,
            'application': 0.6,
            'data': 0.7
        }
        logger.info("行为感知引擎初始化完成")
    
    def perceive(self, data: Dict) -> 'PerceptionResult':
        """感知行为数据"""
        sensor_type = data.get('sensor_type', 'all')
        
        if sensor_type == 'all':
            results = {}
            for name, sensor in self._sensors.items():
                results[name] = sensor.sense(data.get(name, {}))
            
            return PerceptionResult(
                perception_type='behavior',
                perception_data=results,
                confidence=0.85,
                timestamp=datetime.now(),
                metadata={'sensor_count': len(self._sensors)}
            )
        elif sensor_type in self._sensors:
            return PerceptionResult(
                perception_type=f'behavior_{sensor_type}',
                perception_data=self._sensors[sensor_type].sense(data.get(sensor_type, {})),
                confidence=0.9,
                timestamp=datetime.now()
            )
        
        return PerceptionResult(
            perception_type='behavior',
            perception_data=data,
            confidence=0.5,
            timestamp=datetime.now()
        )
    
    def update_baseline(self, entity_type: str, entity_id: str, behavior_data: Dict):
        """更新行为基线"""
        key = f"{entity_type}:{entity_id}"
        if key not in self._baseline_profiles:
            self._baseline_profiles[key] = []
        
        self._baseline_profiles[key].append(behavior_data)
        
        # 保持最近100个样本
        if len(self._baseline_profiles[key]) > 100:
            self._baseline_profiles[key] = self._baseline_profiles[key][-100:]
    
    def detect_anomaly(self, entity_type: str, entity_id: str, current_behavior: Dict) -> Dict:
        """检测异常行为"""
        key = f"{entity_type}:{entity_id}"
        baseline = self._baseline_profiles.get(key, [])
        
        if not baseline:
            return {
                'is_anomaly': False,
                'anomaly_score': 0.0,
                'deviation': {}
            }
        
        # 计算偏差
        deviation = self._calculate_deviation(baseline, current_behavior)
        anomaly_score = sum(deviation.values()) / len(deviation) if deviation else 0.0
        
        threshold = self._anomaly_thresholds.get(entity_type, 0.6)
        
        return {
            'is_anomaly': anomaly_score > threshold,
            'anomaly_score': anomaly_score,
            'threshold': threshold,
            'deviation': deviation
        }
    
    def _calculate_deviation(self, baseline: List[Dict], current: Dict) -> Dict:
        """计算偏差"""
        deviation = {}
        
        for key in current.keys():
            if isinstance(current[key], (int, float)):
                baseline_values = [b.get(key, 0) for b in baseline if isinstance(b.get(key), (int, float))]
                if baseline_values:
                    avg = sum(baseline_values) / len(baseline_values)
                    if avg > 0:
                        deviation[key] = abs(current[key] - avg) / avg
        
        return deviation


class UserBehaviorSensor:
    """用户行为感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知用户行为"""
        return {
            'login_behavior': self._sense_login(data),
            'access_behavior': self._sense_access(data),
            'operation_behavior': self._sense_operations(data),
            'communication_behavior': self._sense_communication(data),
            'collaboration_behavior': self._sense_collaboration(data),
            'risk_indicators': self._sense_risk_indicators(data)
        }
    
    def _sense_login(self, data: Dict) -> Dict:
        """感知登录行为"""
        return {
            'login_count': data.get('login_count', 0),
            'login_locations': data.get('login_locations', []),
            'login_devices': data.get('login_devices', []),
            'login_times': data.get('login_times', []),
            'failed_attempts': data.get('failed_attempts', 0),
            'unusual_hours': data.get('unusual_hours', False)
        }
    
    def _sense_access(self, data: Dict) -> Dict:
        """感知访问行为"""
        return {
            'resources_accessed': data.get('resources_accessed', []),
            'sensitive_access': data.get('sensitive_access', []),
            'access_frequency': data.get('access_frequency', {}),
            'access_pattern': data.get('access_pattern', 'normal')
        }
    
    def _sense_operations(self, data: Dict) -> Dict:
        """感知操作行为"""
        return {
            'file_operations': data.get('file_ops', []),
            'system_commands': data.get('commands', []),
            'config_changes': data.get('config_changes', []),
            'data_exports': data.get('data_exports', [])
        }
    
    def _sense_communication(self, data: Dict) -> Dict:
        """感知通信行为"""
        return {
            'email_count': data.get('email_count', 0),
            'external_contacts': data.get('external_contacts', []),
            'attachment_ratio': data.get('attachment_ratio', 0.0)
        }
    
    def _sense_collaboration(self, data: Dict) -> Dict:
        """感知协作行为"""
        return {
            'team_interactions': data.get('team_interactions', 0),
            'shared_resources': data.get('shared_resources', []),
            'delegation_count': data.get('delegation_count', 0)
        }
    
    def _sense_risk_indicators(self, data: Dict) -> List[Dict]:
        """感知风险指标"""
        indicators = data.get('risk_indicators', [])
        return [
            {
                'indicator': i.get('type', ''),
                'severity': i.get('severity', 'LOW'),
                'description': i.get('description', '')
            }
            for i in indicators
        ]


class EntityBehaviorSensor:
    """实体行为感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知实体行为"""
        return {
            'processes': self._sense_processes(data),
            'connections': self._sense_connections(data),
            'resource_usage': self._sense_resource_usage(data),
            'service_calls': self._sense_service_calls(data),
            'anomalies': self._sense_anomalies(data)
        }
    
    def _sense_processes(self, data: Dict) -> List[Dict]:
        """感知进程行为"""
        processes = data.get('processes', [])
        return [
            {
                'pid': p.get('pid', 0),
                'name': p.get('name', ''),
                'parent': p.get('parent', 0),
                'cpu': p.get('cpu', 0),
                'memory': p.get('memory', 0),
                'network_connections': p.get('net_conns', 0)
            }
            for p in processes
        ]
    
    def _sense_connections(self, data: Dict) -> List[Dict]:
        """感知连接行为"""
        connections = data.get('connections', [])
        return [
            {
                'local': c.get('local', ''),
                'remote': c.get('remote', ''),
                'state': c.get('state', ''),
                'bytes_sent': c.get('bytes_sent', 0),
                'bytes_recv': c.get('bytes_recv', 0)
            }
            for c in connections
        ]
    
    def _sense_resource_usage(self, data: Dict) -> Dict:
        """感知资源使用"""
        return {
            'cpu_usage': data.get('cpu_usage', 0),
            'memory_usage': data.get('memory_usage', 0),
            'disk_io': data.get('disk_io', {}),
            'network_io': data.get('network_io', {})
        }
    
    def _sense_service_calls(self, data: Dict) -> List[Dict]:
        """感知服务调用"""
        calls = data.get('service_calls', [])
        return [
            {
                'service': c.get('service', ''),
                'method': c.get('method', ''),
                'frequency': c.get('frequency', 0),
                'response_time': c.get('response_time', 0)
            }
            for c in calls
        ]
    
    def _sense_anomalies(self, data: Dict) -> List[Dict]:
        """感知异常"""
        anomalies = data.get('anomalies', [])
        return [
            {
                'type': a.get('type', ''),
                'severity': a.get('severity', 'LOW'),
                'description': a.get('description', '')
            }
            for a in anomalies
        ]


class NetworkBehaviorSensor:
    """网络行为感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知网络行为"""
        return {
            'traffic_pattern': self._sense_traffic_pattern(data),
            'connection_pattern': self._sense_connection_pattern(data),
            'protocol_usage': self._sense_protocol_usage(data),
            'bandwidth_usage': self._sense_bandwidth(data),
            'security_events': self._sense_security_events(data)
        }
    
    def _sense_traffic_pattern(self, data: Dict) -> Dict:
        """感知流量模式"""
        return {
            'total_bytes': data.get('total_bytes', 0),
            'total_packets': data.get('total_packets', 0),
            'avg_packet_size': data.get('avg_packet_size', 0),
            'burst_ratio': data.get('burst_ratio', 1.0)
        }
    
    def _sense_connection_pattern(self, data: Dict) -> Dict:
        """感知连接模式"""
        return {
            'unique_sources': data.get('unique_sources', 0),
            'unique_destinations': data.get('unique_destinations', 0),
            'connection_frequency': data.get('connection_frequency', 0),
            'persistent_connections': data.get('persistent_conns', 0)
        }
    
    def _sense_protocol_usage(self, data: Dict) -> Dict:
        """感知协议使用"""
        protocols = data.get('protocol_usage', {})
        return {
            'tcp_ratio': protocols.get('tcp', 0),
            'udp_ratio': protocols.get('udp', 0),
            'icmp_ratio': protocols.get('icmp', 0),
            'other_ratio': protocols.get('other', 0)
        }
    
    def _sense_bandwidth(self, data: Dict) -> Dict:
        """感知带宽使用"""
        return {
            'inbound': data.get('inbound_bw', 0),
            'outbound': data.get('outbound_bw', 0),
            'peak_inbound': data.get('peak_inbound', 0),
            'peak_outbound': data.get('peak_outbound', 0)
        }
    
    def _sense_security_events(self, data: Dict) -> List[Dict]:
        """感知安全事件"""
        events = data.get('security_events', [])
        return [
            {
                'type': e.get('type', ''),
                'source': e.get('source', ''),
                'severity': e.get('severity', 'LOW')
            }
            for e in events
        ]


class ApplicationBehaviorSensor:
    """应用行为感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知应用行为"""
        return {
            'api_calls': self._sense_api_calls(data),
            'data_processing': self._sense_data_processing(data),
            'error_rates': self._sense_error_rates(data),
            'performance': self._sense_performance(data),
            'dependencies': self._sense_dependencies(data)
        }
    
    def _sense_api_calls(self, data: Dict) -> List[Dict]:
        """感知API调用"""
        calls = data.get('api_calls', [])
        return [
            {
                'endpoint': c.get('endpoint', ''),
                'method': c.get('method', ''),
                'frequency': c.get('frequency', 0),
                'success_rate': c.get('success_rate', 1.0)
            }
            for c in calls
        ]
    
    def _sense_data_processing(self, data: Dict) -> Dict:
        """感知数据处理"""
        return {
            'queries_executed': data.get('queries', 0),
            'data_volume': data.get('data_volume', 0),
            'processing_time': data.get('processing_time', 0),
            'transformations': data.get('transformations', [])
        }
    
    def _sense_error_rates(self, data: Dict) -> Dict:
        """感知错误率"""
        return {
            'http_errors': data.get('http_errors', 0),
            'database_errors': data.get('db_errors', 0),
            'timeout_errors': data.get('timeouts', 0),
            'total_requests': data.get('total_requests', 1)
        }
    
    def _sense_performance(self, data: Dict) -> Dict:
        """感知性能"""
        return {
            'response_time': data.get('response_time', 0),
            'throughput': data.get('throughput', 0),
            'availability': data.get('availability', 1.0)
        }
    
    def _sense_dependencies(self, data: Dict) -> List[Dict]:
        """感知依赖"""
        deps = data.get('dependencies', [])
        return [
            {
                'name': d.get('name', ''),
                'status': d.get('status', 'unknown'),
                'latency': d.get('latency', 0)
            }
            for d in deps
        ]


class DataBehaviorSensor:
    """数据行为感知"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
    
    def sense(self, data: Dict) -> Dict:
        """感知数据行为"""
        return {
            'access_pattern': self._sense_access_pattern(data),
            'modification_pattern': self._sense_modification(data),
            'transfer_pattern': self._sense_transfer(data),
            'storage_pattern': self._sense_storage(data),
            'compliance': self._sense_compliance(data)
        }
    
    def _sense_access_pattern(self, data: Dict) -> Dict:
        """感知访问模式"""
        return {
            'read_count': data.get('read_count', 0),
            'write_count': data.get('write_count', 0),
            'delete_count': data.get('delete_count', 0),
            'access_times': data.get('access_times', [])
        }
    
    def _sense_modification(self, data: Dict) -> Dict:
        """感知修改模式"""
        return {
            'insertions': data.get('insertions', 0),
            'updates': data.get('updates', 0),
            'deletions': data.get('deletions', 0),
            'bulk_operations': data.get('bulk_ops', 0)
        }
    
    def _sense_transfer(self, data: Dict) -> Dict:
        """感知传输模式"""
        return {
            'upload_size': data.get('upload_size', 0),
            'download_size': data.get('download_size', 0),
            'external_transfers': data.get('external_transfers', 0),
            'encryption_used': data.get('encryption_used', False)
        }
    
    def _sense_storage(self, data: Dict) -> Dict:
        """感知存储模式"""
        return {
            'total_size': data.get('total_size', 0),
            'growth_rate': data.get('growth_rate', 0),
            'retention_period': data.get('retention', 0)
        }
    
    def _sense_compliance(self, data: Dict) -> Dict:
        """感知合规"""
        return {
            'classification': data.get('classification', 'public'),
            'retention_policy': data.get('retention_policy', ''),
            'encryption_status': data.get('encryption_status', 'unknown')
        }


# 数据类
@dataclass
class PerceptionResult:
    """感知结果"""
    perception_type: str
    perception_data: Dict
    confidence: float
    timestamp: datetime
    metadata: Dict = field(default_factory=dict)


# 便捷函数
def create_behavior_sensor(config: Dict = None) -> BehaviorSensor:
    """创建行为感知引擎"""
    return BehaviorSensor(config)
