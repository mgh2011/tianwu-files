"""
攻击溯源系统 - IP地址追踪模块
IP Tracer - 追踪攻击来源IP地址
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
import json
import re


@dataclass
class TraceResult:
    """追踪结果"""
    ip: str
    hops: List[Dict]
    origin: Dict
    isp_info: Dict
    geolocation: Dict
    confidence: float
    threats: List[str]
    recommendations: List[str]


class IPTracer:
    """IP地址追踪器"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化IP追踪器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.max_hops = self.config.get('max_hops', 30)
        self.trace_history = {}

    def trace(self, ip_address: str, options: Dict = None) -> TraceResult:
        """
        追踪IP地址

        Args:
            ip_address: 要追踪的IP地址
            options: 选项，包含：
                - include_reverse_dns: 是否包含反向DNS
                - include_geolocation: 是否包含地理位置
                - include_isp: 是否包含ISP信息

        Returns:
            追踪结果
        """
        options = options or {}

        # 验证IP地址格式
        if not self._validate_ip(ip_address):
            raise ValueError(f"无效的IP地址: {ip_address}")

        # 执行追踪
        hops = self._perform_trace(ip_address)
        origin = self._resolve_origin(ip_address)
        isp_info = self._get_isp_info(ip_address) if options.get('include_isp', True) else {}
        geolocation = self._get_geolocation(ip_address) if options.get('include_geolocation', True) else {}

        # 分析威胁
        threats = self._analyze_threats(ip_address, hops)

        # 计算置信度
        confidence = self._calculate_confidence(hops, origin)

        # 生成建议
        recommendations = self._generate_recommendations(ip_address, hops, threats)

        # 构建结果
        result = TraceResult(
            ip=ip_address,
            hops=hops,
            origin=origin,
            isp_info=isp_info,
            geolocation=geolocation,
            confidence=confidence,
            threats=threats,
            recommendations=recommendations
        )

        # 记录历史
        self._update_history(ip_address, result)

        return result

    def _validate_ip(self, ip: str) -> bool:
        """验证IP地址"""
        ipv4_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        if re.match(ipv4_pattern, ip):
            parts = ip.split('.')
            return all(0 <= int(p) <= 255 for p in parts)
        return False

    def _perform_trace(self, ip_address: str) -> List[Dict]:
        """
        执行路由追踪
        实际应用中会调用traceroute或其他工具
        """
        # 模拟追踪结果
        hops = []

        # 添加中间跳
        sample_hops = [
            {'hop': 1, 'ip': '192.168.1.1', 'hostname': 'gateway.local', 'rtt': 1.2},
            {'hop': 2, 'ip': '10.0.0.1', 'hostname': 'isp-gateway.isp.net', 'rtt': 5.5},
            {'hop': 3, 'ip': '172.16.0.1', 'hostname': 'core-router.isp.net', 'rtt': 10.2},
            {'hop': 4, 'ip': '192.168.100.1', 'hostname': 'border-router.net', 'rtt': 15.8},
            {'hop': 5, 'ip': ip_address, 'hostname': 'target.host', 'rtt': 25.3},
        ]

        for hop in sample_hops:
            if hop['hop'] <= self.max_hops:
                hops.append(hop)

        return hops

    def _resolve_origin(self, ip_address: str) -> Dict:
        """解析IP来源"""
        # 模拟来源解析
        if ip_address.startswith('192.168.'):
            origin = {
                'type': 'private',
                'description': '私有网络地址',
                'real_ip': None,
                'source': 'internal'
            }
        elif ip_address.startswith('10.'):
            origin = {
                'type': 'private',
                'description': '私有网络地址',
                'real_ip': None,
                'source': 'internal'
            }
        else:
            origin = {
                'type': 'public',
                'description': '公共网络地址',
                'real_ip': ip_address,
                'source': 'external'
            }

        return origin

    def _get_isp_info(self, ip_address: str) -> Dict:
        """获取ISP信息"""
        # 模拟ISP信息查询
        return {
            'isp': 'Example ISP',
            'as_number': 'AS12345',
            'as_name': 'EXAMPLE-ISP',
            'registration_date': '2020-01-01',
            'abuse_contact': 'abuse@example-isp.net',
            'rir': 'ARIN'
        }

    def _get_geolocation(self, ip_address: str) -> Dict:
        """获取地理位置"""
        # 模拟地理位置查询
        if ip_address.startswith('192.168.'):
            return {
                'country': 'Private',
                'country_code': 'XX',
                'region': 'Local',
                'city': 'Local Network',
                'latitude': 0.0,
                'longitude': 0.0,
                'timezone': 'UTC',
                'accuracy': 0
            }
        else:
            return {
                'country': 'United States',
                'country_code': 'US',
                'region': 'California',
                'city': 'San Francisco',
                'latitude': 37.7749,
                'longitude': -122.4194,
                'timezone': 'America/Los_Angeles',
                'accuracy': 100
            }

    def _analyze_threats(self, ip_address: str, hops: List[Dict]) -> List[str]:
        """分析威胁"""
        threats = []

        # 检查是否为已知恶意IP
        if ip_address.startswith('10.255.'):
            threats.append("已知恶意IP范围")

        # 检查匿名化服务
        for hop in hops:
            hostname = hop.get('hostname', '').lower()
            if 'vpn' in hostname or 'proxy' in hostname or 'tor' in hostname:
                threats.append("检测到匿名化服务")
                break

        # 检查路由异常
        if len(hops) < 3:
            threats.append("路由路径异常短")

        if len(hops) > 20:
            threats.append("路由路径异常长，可能经过多重跳转")

        # 检查RTT异常
        rtts = [hop.get('rtt', 0) for hop in hops]
        if rtts:
            max_rtt = max(rtts)
            if max_rtt > 500:
                threats.append("存在高延迟跳，可能影响追踪准确性")

        return threats

    def _calculate_confidence(self, hops: List[Dict], origin: Dict) -> float:
        """计算追踪置信度"""
        confidence = 0.5  # 基础置信度

        # 跳数影响
        if 5 <= len(hops) <= 15:
            confidence += 0.2
        elif len(hops) < 3:
            confidence -= 0.2
        elif len(hops) > 25:
            confidence -= 0.1

        # 来源类型影响
        if origin['type'] == 'public':
            confidence += 0.2
        else:
            confidence += 0.1

        # RTT稳定性
        rtts = [hop.get('rtt', 0) for hop in hops]
        if rtts:
            avg_rtt = sum(rtts) / len(rtts)
            if avg_rtt < 100:
                confidence += 0.1
            elif avg_rtt > 300:
                confidence -= 0.1

        return max(0.0, min(1.0, confidence))

    def _generate_recommendations(self, ip_address: str,
                                  hops: List[Dict],
                                  threats: List[str]) -> List[str]:
        """生成建议"""
        recommendations = []

        if threats:
            recommendations.append("建议将该IP加入监控列表")
            if "匿名化服务" in threats:
                recommendations.append("检测到VPN/代理，建议追踪真实IP")
        else:
            recommendations.append("IP来源相对清晰，持续监控即可")

        if origin := [h for h in hops if h.get('hostname')]:
            recommendations.append(f"可通过hostname {origin[0].get('hostname', '')} 进行进一步调查")

        recommendations.append("建议保存完整追踪日志作为证据")

        return recommendations

    def _update_history(self, ip_address: str, result: TraceResult):
        """更新历史"""
        if ip_address not in self.trace_history:
            self.trace_history[ip_address] = []

        self.trace_history[ip_address].append({
            'timestamp': datetime.now().isoformat(),
            'confidence': result.confidence,
            'origin_type': result.origin.get('type'),
            'threats': result.threats
        })

        # 限制历史大小
        if len(self.trace_history[ip_address]) > 100:
            self.trace_history[ip_address] = self.trace_history[ip_address][-80:]

    def batch_trace(self, ip_addresses: List[str]) -> Dict[str, TraceResult]:
        """批量追踪"""
        return {ip: self.trace(ip) for ip in ip_addresses}


# 独立运行测试
if __name__ == "__main__":
    tracer = IPTracer()

    # 测试追踪
    result = tracer.trace('8.8.8.8')
    print(f"追踪 {result.ip}:")
    print(f"置信度: {result.confidence:.0%}")
    print(f"地理: {result.geolocation.get('city')}, {result.geolocation.get('country')}")
    print(f"ISP: {result.isp_info.get('isp')}")
    print(f"威胁: {result.threats}")
    print(f"\n路由跳数: {len(result.hops)}")
    for hop in result.hops:
        print(f"  {hop['hop']}: {hop['ip']} ({hop['hostname']}) - {hop['rtt']}ms")
    print(f"\n建议:")
    for rec in result.recommendations:
        print(f"  - {rec}")
