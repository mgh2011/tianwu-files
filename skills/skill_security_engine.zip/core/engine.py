"""
企业级综合安全引擎 - 核心引擎 v3.0.0
Enterprise Security Engine Core

【设计理念】
- 完全自主可控，无外部依赖
- 模块化架构，灵活扩展
- 本地化运行，数据不出域
- 企业级架构，稳定可靠

【五大独立系统】
1. 企业级独立安全系统 - 决策、策略、规则、分析、评估
2. 独立数据安全系统 - 采集、存储、处理、传输、使用、销毁、备份
3. 企业级独立防护系统 - 边界、网络、主机、应用、数据、身份
4. 企业级独立自我实现系统 - 感知、诊断、修复、优化、学习、保护、演进
5. 企业级自动化引擎 - 编排、检测、响应、运维、决策、集成

【版本】v3.0.0 (2026-04-10)
"""

import os
import sys
import json
import time
import uuid
import hashlib
import logging
import threading
import asyncio
import importlib
from typing import Dict, List, Optional, Any, Callable, Type
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
import re

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('security_engine.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)


# ========== 枚举定义 ==========

class ThreatLevel(Enum):
    """威胁等级"""
    SAFE = (0, "安全", "🟢")
    LOW = (1, "低危", "🟡")
    MEDIUM = (2, "中危", "🟠")
    HIGH = (3, "高危", "🔴")
    CRITICAL = (4, "极高危", "⚫")
    
    def __init__(self, level: int, label: str, emoji: str):
        self.level = level
        self.label = label
        self.emoji = emoji
    
    @classmethod
    def from_score(cls, score: float) -> 'ThreatLevel':
        if score < 0.2: return cls.SAFE
        elif score < 0.4: return cls.LOW
        elif score < 0.6: return cls.MEDIUM
        elif score < 0.8: return cls.HIGH
        return cls.CRITICAL


class ActionType(Enum):
    """处理动作"""
    ALLOW = "allow"
    BLOCK = "block"
    QUARANTINE = "quarantine"
    ALERT = "alert"
    MONITOR = "monitor"
    INVESTIGATE = "investigate"


class SystemType(Enum):
    """系统类型"""
    INDEPENDENT_SECURITY = "independent_security"    # 独立安全系统
    DATA_SECURITY = "data_security"                # 数据安全系统
    PROTECTION_SYSTEM = "protection_system"        # 防护系统
    SELF_IMPLEMENTATION = "self_implementation"      # 自我实现系统
    AUTOMATION_ENGINE = "automation_engine"         # 自动化引擎
    MAIL_MANAGEMENT = "mail_management"             # 邮件管理系统


class ModuleCategory(Enum):
    """模块类别"""
    CORE = "core"
    SECURITY = "security"
    DATA = "data"
    PROTECTION = "protection"
    AUTOMATION = "automation"
    MANAGEMENT = "management"


# ========== 数据结构 ==========

@dataclass
class SecurityEvent:
    """安全事件"""
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    event_type: str = ""
    severity: str = "INFO"
    source: str = ""
    target: str = ""
    description: str = ""
    raw_data: Dict = field(default_factory=dict)
    indicators: List[str] = field(default_factory=list)
    actions_taken: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class SecurityResult:
    """安全检查结果"""
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    threat_score: float = 0.0
    threat_level: str = "SAFE"
    threat_level_emoji: str = "🟢"
    action: str = "allow"
    confidence: float = 0.0
    detections: Dict[str, Any] = field(default_factory=dict)
    triggered_rules: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    processing_time_ms: float = 0.0
    modules_executed: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @property
    def is_safe(self) -> bool:
        return self.threat_level in ["SAFE", "LOW"] and self.action != "block"
    
    @property
    def is_critical(self) -> bool:
        return self.threat_level in ["HIGH", "CRITICAL"]


@dataclass
class ModuleInfo:
    """模块信息"""
    module_id: str
    module_name: str
    module_type: str
    system_type: str
    category: str
    enabled: bool
    priority: int
    description: str
    version: str
    dependencies: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class AutomationTask:
    """自动化任务"""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_name: str = ""
    task_type: str = ""
    target_module: str = ""
    schedule: str = ""  # cron表达式
    trigger: str = ""   # manual, scheduled, event
    parameters: Dict = field(default_factory=dict)
    status: str = "pending"
    last_run: Optional[str] = None
    next_run: Optional[str] = None
    result: Optional[Dict] = None
    
    def to_dict(self) -> Dict:
        return asdict(self)


# ========== 配置管理器 ==========

class ConfigManager:
    """配置管理器 - 本地化存储，完全自主可控"""
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._config_dir = Path(__file__).parent.parent / "config"
        self._config_dir.mkdir(parents=True, exist_ok=True)
        
        self._config = self._load_config()
        self._module_configs: Dict[str, Dict] = {}
        self._load_module_configs()
        
        self._initialized = True
        logger.info(f"配置管理器初始化完成，配置目录: {self._config_dir}")
    
    def _load_config(self) -> Dict:
        """加载主配置"""
        config_file = self._config_dir / "engine_config.yaml"
        
        if config_file.exists():
            try:
                import yaml
                with open(config_file, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f) or {}
            except Exception as e:
                logger.warning(f"加载配置文件失败: {e}")
        
        return self._get_default_config()
    
    def _load_module_configs(self):
        """加载所有模块配置"""
        for subdir in ['policies', 'rules']:
            subdir_path = self._config_dir / subdir
            if subdir_path.exists():
                for config_file in subdir_path.glob("*.yaml"):
                    try:
                        import yaml
                        with open(config_file, 'r', encoding='utf-8') as f:
                            self._module_configs[config_file.stem] = yaml.safe_load(f)
                    except Exception as e:
                        logger.warning(f"加载模块配置失败 {config_file}: {e}")
    
    def _get_default_config(self) -> Dict:
        """获取默认配置"""
        return {
            'engine': {
                'name': 'Enterprise Security Engine',
                'version': '3.0.0',
                'mode': 'active',  # active, passive, audit_only
                'offline_mode': True,
                'log_level': 'INFO',
            },
            'thresholds': {
                'block': 0.7,
                'quarantine': 0.4,
                'alert': 0.2,
                'monitor': 0.1,
            },
            'modules': {
                # 独立安全系统
                'security_decision': {'enabled': True, 'priority': 100},
                'security_policy': {'enabled': True, 'priority': 95},
                'security_rules': {'enabled': True, 'priority': 90},
                'security_analysis': {'enabled': True, 'priority': 85},
                'security_assessment': {'enabled': True, 'priority': 80},
                
                # 数据安全系统
                'encryption_engine': {'enabled': True, 'priority': 90},
                'key_management': {'enabled': True, 'priority': 95},
                'data_masking': {'enabled': True, 'priority': 85},
                'data_lineage': {'enabled': True, 'priority': 80},
                
                # 防护系统
                'firewall': {'enabled': True, 'priority': 90},
                'ids': {'enabled': True, 'priority': 85},
                'waf': {'enabled': True, 'priority': 85},
                'anti_ddos': {'enabled': True, 'priority': 80},
                'antivirus': {'enabled': True, 'priority': 85},
                'dlp': {'enabled': True, 'priority': 85},
                
                # 邮件安全
                'phishing_detector': {'enabled': True, 'priority': 95},
                'domain_spoof_detector': {'enabled': True, 'priority': 95},
                'spam_filter': {'enabled': True, 'priority': 85},
                
                # 自动化引擎
                'automation_orchestrator': {'enabled': True, 'priority': 100},
                'auto_detector': {'enabled': True, 'priority': 90},
                'auto_responder': {'enabled': True, 'priority': 90},
                
                # 自我实现系统
                'self_monitor': {'enabled': True, 'priority': 80},
                'self_healer': {'enabled': True, 'priority': 80},
                'self_optimizer': {'enabled': True, 'priority': 75},
            },
            'storage': {
                'type': 'local',
                'path': './data',
                'retention_days': 90,
            },
            'automation': {
                'enabled': True,
                'max_concurrent_tasks': 10,
                'retry_count': 3,
                'retry_interval': 60,
            }
        }
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值"""
        keys = key.split('.')
        value = self._config
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        return value
    
    def set(self, key: str, value: Any):
        """设置配置值"""
        keys = key.split('.')
        config = self._config
        for k in keys[:-1]:
            config = config.setdefault(k, {})
        config[keys[-1]] = value
    
    def get_module_config(self, module_name: str) -> Dict:
        """获取模块配置"""
        return self._module_configs.get(module_name, {})
    
    def save_config(self):
        """保存配置"""
        config_file = self._config_dir / "engine_config.yaml"
        try:
            import yaml
            with open(config_file, 'w', encoding='utf-8') as f:
                yaml.dump(self._config, f, allow_unicode=True, default_flow_style=False)
        except Exception as e:
            logger.error(f"保存配置失败: {e}")


# ========== 本地存储 ==========

class LocalStorage:
    """本地安全存储 - 完全自主可控"""
    
    def __init__(self, base_path: str = "./data"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        
        # 各类存储文件
        self._event_file = self.base_path / "security_events.jsonl"
        self._threat_file = self.base_path / "threat_intel.json"
        self._audit_file = self.base_path / "audit_log.jsonl"
        self._config_file = self.base_path / "system_config.json"
        self._backup_dir = self.base_path / "backups"
        self._backup_dir.mkdir(exist_ok=True)
        
        # 内存缓存
        self._threat_cache: Dict[str, Dict] = {}
        self._event_cache: List[SecurityEvent] = []
        self._config_cache: Dict[str, Any] = {}
        
        self._load_caches()
    
    def _load_caches(self):
        """加载缓存"""
        # 加载威胁情报
        if self._threat_file.exists():
            try:
                with open(self._threat_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self._threat_cache = {t['value']: t for t in data.get('indicators', [])}
            except:
                pass
        
        # 加载配置
        if self._config_file.exists():
            try:
                with open(self._config_file, 'r', encoding='utf-8') as f:
                    self._config_cache = json.load(f)
            except:
                pass
    
    def _save_threat_cache(self):
        """保存威胁缓存"""
        try:
            with open(self._threat_file, 'w', encoding='utf-8') as f:
                json.dump({
                    'updated_at': datetime.now().isoformat(),
                    'indicators': list(self._threat_cache.values())
                }, f, ensure_ascii=False, indent=2)
        except:
            pass
    
    def log_event(self, event: SecurityEvent):
        """记录安全事件"""
        self._event_cache.append(event)
        
        # 保留最近1000条
        if len(self._event_cache) > 1000:
            self._event_cache = self._event_cache[-500:]
        
        try:
            with open(self._event_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(event.to_dict(), ensure_ascii=False) + '\n')
        except:
            pass
    
    def log_audit(self, action: str, user: str, resource: str, result: str, details: Dict = None):
        """记录审计日志"""
        entry = {
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'user': user,
            'resource': resource,
            'result': result,
            'details': details or {},
        }
        try:
            with open(self._audit_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(entry, ensure_ascii=False) + '\n')
        except:
            pass
    
    def add_threat(self, indicator_type: str, value: str, threat_type: str, confidence: float = 1.0, metadata: Dict = None):
        """添加威胁指标"""
        self._threat_cache[value] = {
            'type': indicator_type,
            'value': value,
            'threat_type': threat_type,
            'confidence': confidence,
            'added_at': datetime.now().isoformat(),
            'metadata': metadata or {}
        }
        self._save_threat_cache()
    
    def check_threat(self, value: str) -> Optional[Dict]:
        """检查威胁"""
        return self._threat_cache.get(value)
    
    def get_all_threats(self) -> List[Dict]:
        """获取所有威胁"""
        return list(self._threat_cache.values())
    
    def save_config(self, key: str, value: Any):
        """保存配置"""
        self._config_cache[key] = value
        try:
            with open(self._config_file, 'w', encoding='utf-8') as f:
                json.dump(self._config_cache, f, ensure_ascii=False, indent=2)
        except:
            pass
    
    def get_config(self, key: str, default: Any = None) -> Any:
        """获取配置"""
        return self._config_cache.get(key, default)
    
    def backup(self, data: Dict, name: str = None) -> str:
        """创建备份"""
        if name is None:
            name = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        backup_path = self._backup_dir / f"{name}.json"
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return str(backup_path)
    
    def restore(self, name: str) -> Optional[Dict]:
        """恢复备份"""
        backup_path = self._backup_dir / f"{name}.json"
        if backup_path.exists():
            with open(backup_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None
    
    def list_backups(self) -> List[str]:
        """列出备份"""
        return [f.stem for f in self._backup_dir.glob("*.json")]


# ========== 核心引擎 ==========

class SecurityEngineCore:
    """
    企业级综合安全引擎 - 核心
    
    【五大独立系统集成】
    1. 独立安全系统 - 决策、策略、规则、分析、评估引擎
    2. 数据安全系统 - 加密、脱敏、备份、溯源
    3. 防护系统 - 防火墙、入侵检测、WAF、防病毒
    4. 自我实现系统 - 感知、诊断、修复、优化、学习
    5. 自动化引擎 - 编排、检测、响应、运维
    
    特性：
    - 完全本地化运行，无外部依赖
    - 模块化设计，灵活配置
    - 数据不出域，保护隐私
    - 支持离线模式
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls, config: Dict = None):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self, config: Dict = None):
        if self._initialized:
            return
        
        self._config = ConfigManager()
        self._storage = LocalStorage(self._config.get('storage.path', './data'))
        
        # 模块注册表
        self._modules: Dict[str, Any] = {}
        self._module_infos: Dict[str, ModuleInfo] = {}
        
        # 自动化任务调度器
        self._automation_scheduler: Optional['AutomationScheduler'] = None
        
        # 事件处理器
        self._event_handlers: Dict[str, List[Callable]] = {}
        
        # 统计信息
        self._stats = {
            'total_requests': 0,
            'threats_blocked': 0,
            'threats_detected': 0,
            'alerts_generated': 0,
            'automation_tasks_executed': 0,
            'start_time': datetime.now().isoformat(),
            'modules_initialized': []
        }
        
        # 初始化所有系统
        self._initialize_all_systems()
        
        self._initialized = True
        logger.info("=" * 80)
        logger.info("企业级综合安全引擎 v3.0.0 初始化完成")
        logger.info("【五大独立系统】全部就绪")
        logger.info(f"总计模块数: {len(self._modules)}")
        logger.info("模式: 完全自主可控 - 本地化运行 - 数据不出域")
        logger.info("=" * 80)
    
    def _initialize_all_systems(self):
        """初始化所有系统"""
        # 1. 独立安全系统
        self._init_independent_security_system()
        
        # 2. 数据安全系统
        self._init_data_security_system()
        
        # 3. 防护系统
        self._init_protection_system()
        
        # 4. 邮件管理
        self._init_mail_management()
        
        # 5. 自动化引擎
        self._init_automation_engine()
        
        # 6. 自我实现系统
        self._init_self_implementation_system()
    
    def _init_independent_security_system(self):
        """初始化独立安全系统"""
        try:
            # 安全决策引擎
            from independent_security.security_decision import SecurityDecisionEngine
            self._modules['security_decision'] = SecurityDecisionEngine(self._config, self._storage)
            self._register_module_info('security_decision', '安全决策引擎', 
                                       SystemType.INDEPENDENT_SECURITY.value)
            
            # 安全策略引擎
            from independent_security.security_policy import SecurityPolicyEngine
            self._modules['security_policy'] = SecurityPolicyEngine(self._config, self._storage)
            self._register_module_info('security_policy', '安全策略引擎',
                                       SystemType.INDEPENDENT_SECURITY.value)
            
            # 安全规则引擎
            from independent_security.security_rules import SecurityRulesEngine
            self._modules['security_rules'] = SecurityRulesEngine(self._config, self._storage)
            self._register_module_info('security_rules', '安全规则引擎',
                                       SystemType.INDEPENDENT_SECURITY.value)
            
            # 安全分析引擎
            from independent_security.security_analysis import SecurityAnalysisEngine
            self._modules['security_analysis'] = SecurityAnalysisEngine(self._config, self._storage)
            self._register_module_info('security_analysis', '安全分析引擎',
                                       SystemType.INDEPENDENT_SECURITY.value)
            
            # 安全评估引擎
            from independent_security.security_assessment import SecurityAssessmentEngine
            self._modules['security_assessment'] = SecurityAssessmentEngine(self._config, self._storage)
            self._register_module_info('security_assessment', '安全评估引擎',
                                       SystemType.INDEPENDENT_SECURITY.value)
            
            logger.info("✓ 独立安全系统初始化完成: 决策、策略、规则、分析、评估引擎")
        except ImportError as e:
            logger.warning(f"独立安全系统模块导入失败: {e}")
            self._init_independent_security_fallback()
    
    def _init_independent_security_fallback(self):
        """独立安全系统降级实现"""
        from independent_security.security_decision import SecurityDecisionEngine
        from independent_security.security_policy import SecurityPolicyEngine
        from independent_security.security_rules import SecurityRulesEngine
        from independent_security.security_analysis import SecurityAnalysisEngine
        from independent_security.security_assessment import SecurityAssessmentEngine
        
        self._modules['security_decision'] = SecurityDecisionEngine(self._config, self._storage)
        self._modules['security_policy'] = SecurityPolicyEngine(self._config, self._storage)
        self._modules['security_rules'] = SecurityRulesEngine(self._config, self._storage)
        self._modules['security_analysis'] = SecurityAnalysisEngine(self._config, self._storage)
        self._modules['security_assessment'] = SecurityAssessmentEngine(self._config, self._storage)
        
        for name in ['security_decision', 'security_policy', 'security_rules', 
                     'security_analysis', 'security_assessment']:
            self._register_module_info(name, name.replace('_', ' ').title(),
                                       SystemType.INDEPENDENT_SECURITY.value)
        
        logger.info("✓ 独立安全系统(降级)初始化完成")
    
    def _init_data_security_system(self):
        """初始化数据安全系统"""
        try:
            # 数据加密引擎
            from data_security.encryption_engine import DataEncryptionEngine
            self._modules['encryption_engine'] = DataEncryptionEngine(self._config, self._storage)
            self._register_module_info('encryption_engine', '数据加密引擎',
                                       SystemType.DATA_SECURITY.value)
            
            # 密钥管理
            from data_security.key_management import KeyManagement
            self._modules['key_management'] = KeyManagement(self._config, self._storage)
            self._register_module_info('key_management', '密钥管理系统',
                                       SystemType.DATA_SECURITY.value)
            
            # 数据脱敏
            from data_security.data_masking import DataMaskingEngine
            self._modules['data_masking'] = DataMaskingEngine(self._config, self._storage)
            self._register_module_info('data_masking', '数据脱敏引擎',
                                       SystemType.DATA_SECURITY.value)
            
            # 数据血缘追踪
            from data_security.data_lineage import DataLineageTracker
            self._modules['data_lineage'] = DataLineageTracker(self._config, self._storage)
            self._register_module_info('data_lineage', '数据血缘追踪',
                                       SystemType.DATA_SECURITY.value)
            
            # 数据备份恢复
            from data_security.backup_recovery import BackupRecoverySystem
            self._modules['backup_recovery'] = BackupRecoverySystem(self._config, self._storage)
            self._register_module_info('backup_recovery', '备份恢复系统',
                                       SystemType.DATA_SECURITY.value)
            
            logger.info("✓ 数据安全系统初始化完成: 加密、脱敏、备份、溯源")
        except ImportError as e:
            logger.warning(f"数据安全系统模块导入失败: {e}")
    
    def _init_protection_system(self):
        """初始化防护系统"""
        try:
            # 防火墙
            from protection_system.boundary.firewall import FirewallModule
            self._modules['firewall'] = FirewallModule(self._config, self._storage)
            self._register_module_info('firewall', '智能防火墙',
                                       SystemType.PROTECTION_SYSTEM.value)
            
            # 入侵检测
            from protection_system.network.ids import IDSModule
            self._modules['ids'] = IDSModule(self._config, self._storage)
            self._register_module_info('ids', '入侵检测系统',
                                       SystemType.PROTECTION_SYSTEM.value)
            
            # WAF
            from protection_system.boundary.waf import WAFModule
            self._modules['waf'] = WAFModule(self._config, self._storage)
            self._register_module_info('waf', 'Web应用防火墙',
                                       SystemType.PROTECTION_SYSTEM.value)
            
            # 抗DDoS
            from protection_system.boundary.anti_ddos import AntiDDoSModule
            self._modules['anti_ddos'] = AntiDDoSModule(self._config, self._storage)
            self._register_module_info('anti_ddos', '抗DDoS系统',
                                       SystemType.PROTECTION_SYSTEM.value)
            
            # 防病毒
            from protection_system.host.antivirus import AntivirusModule
            self._modules['antivirus'] = AntivirusModule(self._config, self._storage)
            self._register_module_info('antivirus', '终端防病毒',
                                       SystemType.PROTECTION_SYSTEM.value)
            
            # DLP
            from protection_system.data.dlp import DLPModule
            self._modules['dlp'] = DLPModule(self._config, self._storage)
            self._register_module_info('dlp', '数据防泄漏',
                                       SystemType.PROTECTION_SYSTEM.value)
            
            # 身份认证
            from protection_system.identity.authentication import AuthenticationModule
            self._modules['authentication'] = AuthenticationModule(self._config, self._storage)
            self._register_module_info('authentication', '身份认证系统',
                                       SystemType.PROTECTION_SYSTEM.value)
            
            logger.info("✓ 防护系统初始化完成: 防火墙、IDS、WAF、抗D、杀软、DLP、认证")
        except ImportError as e:
            logger.warning(f"防护系统模块导入失败: {e}")
    
    def _init_mail_management(self):
        """初始化邮件管理"""
        try:
            # 钓鱼检测
            from mail_management.phishing_detector import PhishingDetector
            self._modules['phishing_detector'] = PhishingDetector(self._config, self._storage)
            self._register_module_info('phishing_detector', '钓鱼邮件检测',
                                       SystemType.MAIL_MANAGEMENT.value)
            
            # 域名伪造检测
            from mail_management.domain_spoof_detector import DomainSpoofDetector
            self._modules['domain_spoof_detector'] = DomainSpoofDetector(self._config, self._storage)
            self._register_module_info('domain_spoof_detector', '域名伪造检测',
                                       SystemType.MAIL_MANAGEMENT.value)
            
            # 垃圾邮件过滤
            from mail_management.spam_filter import SpamFilter
            self._modules['spam_filter'] = SpamFilter(self._config, self._storage)
            self._register_module_info('spam_filter', '垃圾邮件过滤',
                                       SystemType.MAIL_MANAGEMENT.value)
            
            # 邮件分类器
            from mail_management.classifier.mail_classifier import MailClassifier
            self._modules['mail_classifier'] = MailClassifier(self._config, self._storage)
            self._register_module_info('mail_classifier', '邮件分类器',
                                       SystemType.MAIL_MANAGEMENT.value)
            
            # 邮件处理器
            from mail_management.processor.mail_processor import MailProcessor
            self._modules['mail_processor'] = MailProcessor(self._config, self._storage)
            self._register_module_info('mail_processor', '邮件处理器',
                                       SystemType.MAIL_MANAGEMENT.value)
            
            logger.info("✓ 邮件管理初始化完成: 钓鱼检测、域名伪造、垃圾过滤、邮件分类")
        except ImportError as e:
            logger.warning(f"邮件管理模块导入失败: {e}")
    
    def _init_automation_engine(self):
        """初始化自动化引擎"""
        try:
            # 自动化编排器
            from automation_engine.orchestration.orchestrator import AutomationOrchestrator
            self._modules['automation_orchestrator'] = AutomationOrchestrator(self._config, self._storage)
            self._register_module_info('automation_orchestrator', '自动化编排器',
                                       SystemType.AUTOMATION_ENGINE.value)
            
            # 自动检测器
            from automation_engine.detection.auto_detector import AutoDetector
            self._modules['auto_detector'] = AutoDetector(self._config, self._storage)
            self._register_module_info('auto_detector', '自动检测引擎',
                                       SystemType.AUTOMATION_ENGINE.value)
            
            # 自动响应器
            from automation_engine.response.auto_responder import AutoResponder
            self._modules['auto_responder'] = AutoResponder(self._config, self._storage)
            self._register_module_info('auto_responder', '自动响应引擎',
                                       SystemType.AUTOMATION_ENGINE.value)
            
            # 任务调度器
            from automation_engine.orchestration.task_scheduler import TaskScheduler
            self._modules['task_scheduler'] = TaskScheduler(self._config, self._storage)
            self._register_module_info('task_scheduler', '任务调度器',
                                       SystemType.AUTOMATION_ENGINE.value)
            
            logger.info("✓ 自动化引擎初始化完成: 编排、检测、响应、调度")
        except ImportError as e:
            logger.warning(f"自动化引擎模块导入失败: {e}")
    
    def _init_self_implementation_system(self):
        """初始化自我实现系统"""
        try:
            # 自我监控
            from self_implementation.self_perception.self_monitor import SelfMonitor
            self._modules['self_monitor'] = SelfMonitor(self._config, self._storage)
            self._register_module_info('self_monitor', '自我监控系统',
                                       SystemType.SELF_IMPLEMENTATION.value)
            
            # 自我修复
            from self_implementation.self_healing.self_healer import SelfHealer
            self._modules['self_healer'] = SelfHealer(self._config, self._storage)
            self._register_module_info('self_healer', '自我修复系统',
                                       SystemType.SELF_IMPLEMENTATION.value)
            
            # 自我优化
            from self_implementation.self_optimization.self_optimizer import SelfOptimizer
            self._modules['self_optimizer'] = SelfOptimizer(self._config, self._storage)
            self._register_module_info('self_optimizer', '自我优化系统',
                                       SystemType.SELF_IMPLEMENTATION.value)
            
            # 自我学习
            from self_implementation.self_learning.threat_learner import ThreatLearner
            self._modules['threat_learner'] = ThreatLearner(self._config, self._storage)
            self._register_module_info('threat_learner', '威胁学习系统',
                                       SystemType.SELF_IMPLEMENTATION.value)
            
            logger.info("✓ 自我实现系统初始化完成: 感知、修复、优化、学习")
        except ImportError as e:
            logger.warning(f"自我实现系统模块导入失败: {e}")
    
    def _register_module_info(self, module_id: str, module_name: str, system_type: str):
        """注册模块信息"""
        config = self._config.get(f'modules.{module_id}', {})
        
        info = ModuleInfo(
            module_id=module_id,
            module_name=module_name,
            module_type='security_module',
            system_type=system_type,
            category=ModuleCategory.SECURITY.value,
            enabled=config.get('enabled', True),
            priority=config.get('priority', 50),
            description=f'{module_name} - 完全自主实现',
            version='1.0.0'
        )
        
        self._module_infos[module_id] = info
        self._stats['modules_initialized'].append(module_id)
    
    def check(self, request: Dict) -> SecurityResult:
        """
        统一安全检查入口
        
        参数：
            request: 请求数据
                - type: 请求类型 (email, network, file, access, generic)
                - 其他字段根据类型不同
        
        返回：
            SecurityResult: 安全检查结果
        """
        start_time = time.time()
        
        request_id = request.get('request_id', str(uuid.uuid4()))
        request_type = request.get('type', 'generic')
        
        result = SecurityResult(request_id=request_id)
        result.metadata['request_type'] = request_type
        
        # 获取适用的检测模块
        detectors = self._get_detectors_for_type(request_type)
        
        # 按优先级执行检测
        sorted_detectors = sorted(
            [(name, self._modules[name]) for name in detectors if name in self._modules],
            key=lambda x: self._module_infos.get(x[0], ModuleInfo('', '', '', '', '', True, 50, '', '1.0.0')).priority,
            reverse=True
        )
        
        for module_name, module in sorted_detectors:
            if not hasattr(module, 'check'):
                continue
            
            try:
                module_result = module.check(request)
                
                if isinstance(module_result, dict):
                    result.modules_executed.append(module_name)
                    
                    if module_result.get('detected') or module_result.get('threat_score', 0) > 0:
                        result.detections[module_name] = module_result
                        
                        threat_score = module_result.get('threat_score', 0)
                        result.threat_score = max(result.threat_score, threat_score)
                        
                        if module_result.get('rules'):
                            result.triggered_rules.extend(module_result.get('rules', []))
            except Exception as e:
                logger.warning(f"模块 {module_name} 检查失败: {e}")
        
        # 安全决策引擎评估
        if 'security_decision' in self._modules:
            try:
                decision_result = self._modules['security_decision'].evaluate(
                    result.threat_score,
                    result.detections,
                    request
                )
                if decision_result:
                    result.action = decision_result.get('action', result.action)
            except:
                pass
        
        # 确定威胁等级和动作
        result.threat_level = ThreatLevel.from_score(result.threat_score).label
        result.threat_level_emoji = ThreatLevel.from_score(result.threat_score).emoji
        
        if result.action == 'allow':
            result.action = self._determine_action(result.threat_score)
        
        result.confidence = self._calculate_confidence(result.detections)
        result.recommendations = self._generate_recommendations(result)
        
        # 计算处理时间
        result.processing_time_ms = (time.time() - start_time) * 1000
        
        # 更新统计
        self._stats['total_requests'] += 1
        if result.action == 'block':
            self._stats['threats_blocked'] += 1
        elif result.threat_score > 0.3:
            self._stats['threats_detected'] += 1
        
        # 记录安全事件
        event = SecurityEvent(
            event_type=f"security_check_{request_type}",
            severity=result.threat_level,
            source=request.get('from', request.get('source_ip', '')),
            description=f"{request_type}安全检查: {result.threat_level}",
            indicators=[f"{k}:{v.get('threat_score', 0):.2f}" for k, v in result.detections.items()],
            metadata={'request_id': request_id, 'action': result.action}
        )
        self._storage.log_event(event)
        
        return result
    
    def _get_detectors_for_type(self, request_type: str) -> List[str]:
        """获取对应类型的检测器"""
        mappings = {
            'email': [
                'phishing_detector', 'domain_spoof_detector', 'spam_filter',
                'antivirus', 'dlp', 'security_rules', 'security_analysis'
            ],
            'network': [
                'firewall', 'ids', 'waf', 'anti_ddos', 'security_rules'
            ],
            'file': [
                'antivirus', 'dlp', 'security_rules', 'security_analysis'
            ],
            'access': [
                'authentication', 'security_rules', 'threat_learner'
            ],
            'data': [
                'encryption_engine', 'data_masking', 'dlp', 'data_lineage'
            ],
            'generic': list(self._modules.keys())
        }
        return mappings.get(request_type, mappings['generic'])
    
    def _determine_action(self, threat_score: float) -> str:
        """根据威胁分数确定动作"""
        thresholds = self._config.get('thresholds', {})
        
        if threat_score >= thresholds.get('block', 0.7):
            return ActionType.BLOCK.value
        elif threat_score >= thresholds.get('quarantine', 0.4):
            return ActionType.QUARANTINE.value
        elif threat_score >= thresholds.get('alert', 0.2):
            return ActionType.ALERT.value
        return ActionType.ALLOW.value
    
    def _calculate_confidence(self, detections: Dict) -> float:
        """计算置信度"""
        if not detections:
            return 0.0
        return sum(d.get('confidence', d.get('threat_score', 0)) 
                  for d in detections.values()) / len(detections)
    
    def _generate_recommendations(self, result: SecurityResult) -> List[str]:
        """生成建议"""
        recommendations = []
        
        if result.threat_score >= 0.7:
            recommendations.append("🚨 高威胁风险，建议立即拦截并隔离处理")
        elif result.threat_score >= 0.4:
            recommendations.append("⚠️ 中等威胁风险，建议隔离审查")
        elif result.threat_score >= 0.2:
            recommendations.append("📧 低威胁风险，建议标记并监控")
        else:
            recommendations.append("✅ 通过安全检查，可正常放行")
        
        for module, detection in result.detections.items():
            if detection.get('detected'):
                recommendations.append(f"🔍 {module} 检测到异常")
        
        return recommendations
    
    # ========== 公共接口 ==========
    
    def get_module(self, name: str) -> Optional[Any]:
        """获取指定模块"""
        return self._modules.get(name)
    
    def get_all_modules(self) -> Dict[str, Any]:
        """获取所有模块"""
        return self._modules.copy()
    
    def get_module_info(self, name: str) -> Optional[ModuleInfo]:
        """获取模块信息"""
        return self._module_infos.get(name)
    
    def get_all_module_infos(self) -> List[ModuleInfo]:
        """获取所有模块信息"""
        return list(self._module_infos.values())
    
    def get_modules_by_system(self, system_type: str) -> List[ModuleInfo]:
        """获取指定系统的所有模块"""
        return [info for info in self._module_infos.values() 
                if info.system_type == system_type]
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        stats = self._stats.copy()
        stats['modules_count'] = len(self._modules)
        stats['module_infos'] = [info.to_dict() for info in self._module_infos.values()]
        return stats
    
    def get_capabilities(self) -> Dict:
        """获取引擎能力"""
        capabilities = {
            'total_modules': len(self._modules),
            'system_types': {},
            'modules': {},
            'features': {
                'offline_mode': True,
                'local_storage': True,
                'no_external_api': True,
                'customizable_rules': True,
                'automation_enabled': True,
                'self_implementation': True,
            }
        }
        
        # 按系统类型分组
        for info in self._module_infos.values():
            system = info.system_type
            if system not in capabilities['system_types']:
                capabilities['system_types'][system] = []
            capabilities['system_types'][system].append(info.module_id)
            
            capabilities['modules'][info.module_id] = {
                'enabled': info.enabled,
                'priority': info.priority,
                'system_type': info.system_type
            }
        
        return capabilities
    
    def execute_automation_task(self, task: AutomationTask) -> Dict:
        """执行自动化任务"""
        if 'automation_orchestrator' not in self._modules:
            return {'success': False, 'error': '自动化引擎未初始化'}
        
        try:
            orchestrator = self._modules['automation_orchestrator']
            return orchestrator.execute_task(task)
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_system_status(self) -> Dict:
        """获取系统状态"""
        return {
            'status': 'operational',
            'modules_initialized': len(self._modules),
            'uptime': (datetime.now() - datetime.fromisoformat(self._stats['start_time'])).total_seconds(),
            'statistics': self._stats,
            'timestamp': datetime.now().isoformat()
        }


# ========== 便捷函数 ==========

_engine_instance = None
_engine_lock = threading.Lock()

def get_engine() -> SecurityEngineCore:
    """获取引擎单例"""
    global _engine_instance
    if _engine_instance is None:
        with _engine_lock:
            if _engine_instance is None:
                _engine_instance = SecurityEngineCore()
    return _engine_instance


def security_check(request: Dict) -> SecurityResult:
    """快速安全检查"""
    engine = get_engine()
    return engine.check(request)


def is_safe(data: Dict) -> bool:
    """快速判断是否安全"""
    result = security_check(data)
    return result.is_safe


# ========== 主函数 ==========

if __name__ == '__main__':
    print("=" * 80)
    print("企业级综合安全引擎 v3.0.0")
    print("【五大独立系统】- 完全自主可控")
    print("=" * 80)
    
    engine = get_engine()
    capabilities = engine.get_capabilities()
    
    print(f"\n🔐 安全模块总数: {capabilities['total_modules']}")
    
    print("\n" + "-" * 80)
    print("【五大独立系统】")
    
    for system_type, modules in capabilities['system_types'].items():
        print(f"\n  📦 {system_type.replace('_', ' ').title()}")
        for module in modules:
            info = capabilities['modules'][module]
            status = "✅" if info['enabled'] else "❌"
            print(f"    {status} {module}: 优先级{info['priority']}")
    
    print("\n" + "-" * 80)
    print("【安全特性】")
    for feature, enabled in capabilities['features'].items():
        status = "✅" if enabled else "❌"
        print(f"  {status} {feature}")
    
    print("\n" + "-" * 80)
    print("【邮件安全测试】")
    
    test_cases = [
        {
            'type': 'email',
            'name': '钓鱼邮件',
            'from': 'security@paypa1.com',
            'subject': '【紧急】您的账户存在风险',
            'body': '请立即点击链接验证您的账户信息以避免账户被锁定。',
        },
        {
            'type': 'email',
            'name': '正常邮件',
            'from': 'colleague@company.com',
            'subject': '项目会议通知',
            'body': '明天下午3点有产品评审会议，请准时参加。',
        },
        {
            'type': 'email',
            'name': '垃圾邮件',
            'from': 'promotion@discount.xyz',
            'subject': '【限时优惠】免费领取iphone！',
            'body': '点击立即领取，不容错过！名额有限，马上行动！',
        }
    ]
    
    for test in test_cases:
        print(f"\n  【{test['name']}】")
        result = engine.check(test)
        print(f"    威胁等级: {result.threat_level_emoji} {result.threat_level}")
        print(f"    威胁分数: {result.threat_score:.2%}")
        print(f"    处理动作: {result.action}")
        print(f"    执行模块: {len(result.modules_executed)}个")
    
    print("\n" + "=" * 80)
    print("引擎就绪，等待处理安全请求...")
    print("=" * 80)
