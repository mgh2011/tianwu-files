"""
阻断措施模块
Blocking Countermeasure Module

提供攻击源封禁和流量清洗功能
"""

from .attack_source_blocker import AttackSourceBlocker
from .traffic_scrubber import TrafficScrubber

__version__ = "v3.0.0"
__all__ = [
    'AttackSourceBlocker',
    'TrafficScrubber'
]
