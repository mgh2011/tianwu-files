"""
域名伪造检测器 - 完全独立实现
Domain Spoofing Detector

【功能说明】
- 同形字攻击检测
- 域名相似度分析
- DNS验证
- 品牌域名保护

【检测技术】
1. Unicode同形字检测 (IDN Homograph Attack)
2. 视觉相似域名检测
3. 品牌域名混淆检测
4. 域名抢注检测
"""

import re
import unicodedata
from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


class DomainSpoofDetector:
    """
    域名伪造检测器
    
    检测各类域名仿冒攻击，包括Unicode同形字攻击、视觉欺骗等
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 已知品牌域名白名单
        self._protected_brands = {
            # 金融机构
            'paypal': {'paypal.com', 'paypal.co.uk', 'paypal.de', 'paypal.fr', 'paypal.it'},
            '工商银行': {'icbc.com.cn', 'icbc.com', '95588.com', 'icbc-net.com'},
            '建设银行': {'ccb.com', 'ccb.cn', '95533.com', 'ccbchina.com'},
            '中国银行': {'boc.cn', 'bankofchina.com', 'boc.htx.net'},
            '农业银行': {'abchina.com', '95599.com', 'abchina.cn'},
            '招商银行': {'cmbchina.com', 'cmb.com', 'cmbchina.com.cn'},
            
            # 科技巨头
            'microsoft': {'microsoft.com', 'microsoftonline.com', 'office.com', 
                         'outlook.com', 'live.com', 'azure.com', 'msft.cn'},
            'apple': {'apple.com', 'icloud.com', 'me.com', 'mac.com', 'apple.com.cn'},
            'google': {'google.com', 'google.co.uk', 'google.de', 'google.fr', 
                      'gmail.com', 'youtube.com'},
            'amazon': {'amazon.com', 'amazon.co.uk', 'amazon.cn', 'amazon.co.jp',
                      'aws.amazon.com', 'amazonaws.com'},
            'facebook': {'facebook.com', 'fb.com', 'messenger.com', 'instagram.com'},
            'twitter': {'twitter.com', 'x.com'},
            
            # 国内巨头
            '阿里巴巴': {'alibaba.com', 'aliyun.com', 'alipay.com', 'taobao.com', 
                        'tmall.com', '1688.com'},
            '腾讯': {'qq.com', 'tencent.com', 'wechat.com', 'weixin.qq.com'},
            '京东': {'jd.com', 'jd.ru', 'joybuy.com'},
            '百度': {'baidu.com', 'baidu.cn'},
            '网易': {'163.com', '126.com', 'yeah.net'},
        }
        
        # 常见钓鱼TLD
        self._suspicious_tlds = {
            'xyz', 'top', 'work', 'click', 'loan', 'date', 'review',
            'science', 'party', 'gq', 'ml', 'ga', 'cf', 'tk', 'pw',
            'cc', 'co', 'org', 'net'  # 合法但可疑
        }
        
        # 字符映射表 - 相似字符
        self._confusable_chars = {
            # 数字代替字母
            '0': 'oO', '1': 'lI', '2': 'z', '3': 'E', '4': 'A',
            '5': 'S', '6': 'G', '7': 'T', '8': 'B', '9': 'g',
            # 字母替代
            'a': '@', 'i': '1l|', 'l': '1i|', 'o': '0',
            'e': '3', 's': '5$', 'b': '6', 'g': '9',
            # Unicode同形字
            '\u0430': 'a',  # Cyrillic a
            '\u0435': 'e',  # Cyrillic e
            '\u043e': 'o',  # Cyrillic o
            '\u0440': 'p',  # Cyrillic p
            '\u0441': 'c',  # Cyrillic c
            '\u0445': 'x',  # Cyrillic x
        }
        
        # 品牌域名关键词
        self._brand_keywords = {
            'paypal': ['paypal', 'pay', 'pal'],
            'microsoft': ['microsoft', 'msft', 'office', 'outlook'],
            'apple': ['apple', 'icloud', 'app'],
            'amazon': ['amazon', 'aws', 'alexa'],
            'google': ['google', 'gmail', 'youtube'],
            'bank': ['bank', 'banking', 'secure', 'verify'],
            '财务': ['银行', '账户', '支付', '转账'],
        }
    
    def check(self, request: Dict) -> Dict:
        """
        检测域名伪造
        
        参数：
            request: 请求数据
                - from: 发件人邮箱
                - domain: 目标域名（可选）
        
        返回：
            检测结果
        """
        email_from = request.get('from', request.get('sender', ''))
        
        # 提取域名
        domain = self._extract_domain(email_from)
        if not domain:
            return {
                'detected': False,
                'threat_score': 0.0,
                'confidence': 0.0,
                'details': []
            }
        
        results = []
        total_score = 0.0
        total_confidence = 0.0
        
        # 1. IDN同形字攻击检测
        idn_result = self._check_idn_homograph(domain)
        if idn_result['detected']:
            results.append(idn_result)
            total_score += idn_result['confidence'] * 0.35
            total_confidence += 0.35
        
        # 2. 字符替换检测
        char_result = self._check_char_substitution(domain)
        if char_result['detected']:
            results.append(char_result)
            total_score += char_result['confidence'] * 0.3
            total_confidence += 0.3
        
        # 3. 品牌域名混淆检测
        brand_result = self._check_brand_confusion(domain)
        if brand_result['detected']:
            results.append(brand_result)
            total_score += brand_result['confidence'] * 0.25
            total_confidence += 0.25
        
        # 4. 可疑TLD检测
        tld_result = self._check_suspicious_tld(domain)
        if tld_result['detected']:
            results.append(tld_result)
            total_score += tld_result['confidence'] * 0.1
            total_confidence += 0.1
        
        threat_score = min(total_score, 1.0)
        
        return {
            'detected': threat_score >= 0.3,
            'threat_score': threat_score,
            'confidence': min(total_confidence, 1.0),
            'domain': domain,
            'domain_spoofing': threat_score >= 0.4,
            'spoof_type': [r['type'] for r in results if r['detected']],
            'details': [d for r in results for d in r.get('details', [])],
            'all_results': results
        }
    
    def _extract_domain(self, email_or_domain: str) -> str:
        """提取域名"""
        if '@' in email_or_domain:
            return email_or_domain.split('@')[-1].lower()
        return email_or_domain.lower()
    
    def _check_idn_homograph(self, domain: str) -> Dict:
        """检测IDN同形字攻击"""
        details = []
        confidence = 0.0
        detected = False
        
        # 检查是否包含非ASCII字符
        if not domain.isascii():
            detected = True
            details.append(f'域名包含Unicode字符: {domain}')
            confidence = 0.9
            
            # 分析每个字符
            suspicious_chars = []
            for char in domain:
                if not char.isascii() and char.isalpha():
                    name = unicodedata.name(char, 'UNKNOWN')
                    suspicious_chars.append(f'{char} ({name})')
            
            if suspicious_chars:
                details.append(f'可疑Unicode字符: {suspicious_chars[:5]}')
        
        # 检查Punycode形式
        if domain.startswith('xn--'):
            detected = True
            details.append(f'Punycode域名 (可能是IDN攻击): {domain}')
            confidence = 0.85
        
        # 转换为ASCII形式比较
        if not domain.isascii():
            try:
                import idna
                ascii_domain = idna.encode(domain, uts46=True).decode('ascii')
                if ascii_domain != domain:
                    details.append(f'IDN解码: {domain} -> {ascii_domain}')
            except:
                pass
        
        return {
            'detected': detected,
            'confidence': confidence,
            'type': 'idn_homograph',
            'details': details
        }
    
    def _check_char_substitution(self, domain: str) -> Dict:
        """检测字符替换"""
        details = []
        confidence = 0.0
        detected = False
        
        base_domain = domain
        
        # 检查数字替换字母
        digit_replacements = []
        for i, char in enumerate(base_domain):
            if char.isdigit():
                # 查找可能的替换
                for num, letters in self._confusable_chars.items():
                    if char == num and i < len(base_domain) - 1:
                        digit_replacements.append(f'{char}->{letters}')
        
        if len(digit_replacements) >= 2:
            detected = True
            confidence = 0.8
            details.append(f'数字替换字母: {digit_replacements}')
        elif len(digit_replacements) == 1:
            confidence = 0.4
        
        # 检查相似字符替换
        letter_replacements = []
        for i, char in enumerate(base_domain.lower()):
            for base, confusables in self._confusable_chars.items():
                if char in confusables.lower() and char != base.lower():
                    letter_replacements.append(f'{char}->{base}')
        
        if len(letter_replacements) >= 2:
            detected = True
            confidence = max(confidence, 0.75)
            details.append(f'相似字符替换: {letter_replacements[:5]}')
        
        # 检查@符号
        if '@' in base_domain:
            detected = True
            confidence = max(confidence, 0.6)
            details.append('域名包含@符号')
        
        return {
            'detected': detected,
            'confidence': confidence,
            'type': 'char_substitution',
            'details': details
        }
    
    def _check_brand_confusion(self, domain: str) -> Dict:
        """检测品牌域名混淆"""
        details = []
        confidence = 0.0
        detected = False
        matched_brand = None
        
        # 移除常见前缀
        clean_domain = domain.replace('www.', '').replace('mail.', '').replace('smtp.', '')
        
        # 提取主要部分
        parts = clean_domain.split('.')
        main_part = parts[0] if parts else ''
        
        for brand, legit_domains in self._protected_brands.items():
            # 检查是否包含品牌关键词
            brand_keywords = self._brand_keywords.get(brand.lower(), [brand.lower()])
            
            for keyword in brand_keywords:
                if keyword in main_part.lower():
                    # 检查是否是完全匹配的官方域名
                    if clean_domain not in legit_domains:
                        detected = True
                        matched_brand = brand
                        confidence = 0.7
                        details.append(f'包含{brand}关键词但不是官方域名: {domain}')
                        
                        # 计算相似度
                        for legit in legit_domains:
                            similarity = self._calculate_similarity(main_part, legit.split('.')[0])
                            if similarity > 0.6:
                                confidence = max(confidence, 0.8)
                                details.append(f'与{brand}官方域名相似: {main_part} ~ {legit.split(".")[0]} (相似度{similarity:.2f})')
        
        # 检查Typosquatting
        if not detected:
            for brand, legit_domains in self._protected_brands.items():
                for legit in legit_domains:
                    typo = self._generate_typosquatting(legit.split('.')[0])
                    if main_part in typo:
                        detected = True
                        confidence = 0.75
                        details.append(f'可能的Typosquatting: {main_part} (原域名: {legit})')
        
        return {
            'detected': detected,
            'confidence': confidence,
            'type': 'brand_confusion',
            'details': details,
            'matched_brand': matched_brand
        }
    
    def _check_suspicious_tld(self, domain: str) -> Dict:
        """检测可疑TLD"""
        details = []
        confidence = 0.0
        detected = False
        
        parts = domain.split('.')
        if len(parts) >= 2:
            tld = parts[-1].lower()
            
            if tld in self._suspicious_tlds:
                # 结合其他因素判断
                main_part = parts[0].lower()
                
                # 检查是否包含品牌名
                has_brand = any(
                    brand in main_part 
                    for brands in self._brand_keywords.values() 
                    for brand in brands
                )
                
                if has_brand:
                    detected = True
                    confidence = 0.5
                    details.append(f'可疑TLD({tld})但包含品牌关键词: {domain}')
                else:
                    detected = True
                    confidence = 0.2
                    details.append(f'使用可疑TLD: {tld}')
        
        return {
            'detected': detected,
            'confidence': confidence,
            'type': 'suspicious_tld',
            'details': details
        }
    
    def _calculate_similarity(self, s1: str, s2: str) -> float:
        """计算字符串相似度"""
        if not s1 or not s2:
            return 0.0
        
        # 简单相似度：公共字符占比
        common = sum(1 for c in s1 if c in s2)
        return (2.0 * common) / (len(s1) + len(s2))
    
    def _generate_typosquatting(self, domain: str) -> List[str]:
        """生成Typosquatting变体"""
        typos = []
        
        # 常见打字错误
        for i in range(len(domain)):
            prefix = domain[:i]
            suffix = domain[i+1:]
            
            # 删除一个字符
            if prefix and suffix:
                typos.append(prefix + suffix)
            
            # 相邻字符交换
            if i < len(domain) - 1:
                typos.append(domain[:i] + domain[i+1] + domain[i] + domain[i+2:])
        
        # 常见TLD替换
        common_tlds = ['.com', '.net', '.org', '.cn', '.io']
        for tld in common_tlds:
            typos.append(domain + tld)
        
        return typos


if __name__ == '__main__':
    print("=" * 60)
    print("域名伪造检测器测试")
    print("=" * 60)
    
    detector = DomainSpoofDetector(None, None)
    
    test_domains = [
        'paypa1.com',           # 数字1代替l
        'paypal.com',           # 正常
        'microsoft-verify.xyz', # 钓鱼
        'xn--80ak6aa92e.com',   # IDN
        'app1e.com',           # 仿冒apple
        'g00gle.com',           # 数字0代替o
        'amaz0n.co.uk',         # 仿冒amazon
    ]
    
    for domain in test_domains:
        result = detector.check({'from': f'test@{domain}'})
        print(f"\n{domain}:")
        print(f"  伪造检测: {'是' if result['detected'] else '否'}")
        print(f"  威胁分数: {result['threat_score']:.2%}")
        print(f"  类型: {result.get('spoof_type', [])}")
    
    print("\n" + "=" * 60)
