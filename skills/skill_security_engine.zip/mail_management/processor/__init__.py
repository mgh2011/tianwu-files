"""
邮件处理模块
Mail Processing Module

提供邮件处理和解析功能
"""

__version__ = "v3.0.0"
__all__ = []
