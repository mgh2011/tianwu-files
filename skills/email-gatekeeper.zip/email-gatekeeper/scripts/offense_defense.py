# ========== 反击与联动系统 v3.0.4 ==========
# 文件: scripts/offense_defense.py
# 版本: 3.0.4
# 优化: 版本统一、关联分析增强、防御联动完善

"""
企业级自动化反击与联动系统
支持: 攻击溯源、自动反击、蜜罐、SOAR编排
"""

import os
import json
import hashlib
import logging
import asyncio
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum

logger = logging.getLogger(__name__)


# ========== 枚举定义 ==========

class AttackType(Enum):
    """攻击类型"""
    PHISHING = "phishing"
    MALWARE = "malware"
    BRUTE_FORCE = "brute_force"
    DDOS = "ddos"
    DATA_BREACH = "data_breach"
    UNKNOWN = "unknown"


class RetaliationIntensity(Enum):
    """反击强度"""
    PASSIVE = "passive"     # 仅记录
    MODERATE = "moderate"   # 阻止
    AGGRESSIVE = "aggressive"  # 报告


# ========== 数据结构 ==========

@dataclass
class AttackEvidence:
    """攻击证据"""
    attack_id: str
    attack_type: AttackType
    source_ip: str = ""
    source_domain: str = ""
    target: str = ""
    evidence: List[str] = field(default_factory=list)
    confidence: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)
    malicious_urls: List[str] = field(default_factory=list)
    malware_hashes: List[str] = field(default_factory=list)


@dataclass
class RetaliationAction:
    """反击动作"""
    action_id: str
    action_type: str  # block_ip, quarantine, report, counter_measure
    target: str
    parameters: Dict = field(default_factory=dict)
    executed_at: datetime = None
    result: str = "pending"


# ========== 威胁情报管理器 ==========

class ThreatIntelManager:
    """威胁情报管理器"""
    
    def __init__(self):
        self.ioc_database: Dict[str, List] = {
            "malicious_ips": [],
            "malicious_domains": [],
            "malware_hashes": [],
            "phishing_urls": []
        }
        self.threat_feeds = []
        self.blocklist = set()
        logger.info("威胁情报管理器初始化完成")
    
    async def check_ip(self, ip: str) -> Dict:
        """检查IP信誉"""
        result = {
            "ip": ip,
            "is_malicious": False,
            "threat_types": [],
            "confidence": 0,
            "source": "local"
        }
        
        # 本地黑名单检查
        if any(ioc["value"] == ip for ioc in self.ioc_database["malicious_ips"]):
            result["is_malicious"] = True
            result["threat_types"].append("blacklisted")
            result["confidence"] = 100
        
        return result
    
    async def check_domain(self, domain: str) -> Dict:
        """检查域名信誉"""
        result = {
            "domain": domain,
            "is_malicious": False,
            "threat_types": []
        }
        
        # 本地检查
        if any(ioc["value"] == domain for ioc in self.ioc_database["malicious_domains"]):
            result["is_malicious"] = True
            result["threat_types"].append("blacklisted")
        
        return result
    
    def add_ioc(self, ioc_type: str, value: str, metadata: Dict = None):
        """添加IOC"""
        if ioc_type in self.ioc_database:
            entry = {
                "value": value,
                "added_at": datetime.now().isoformat(),
                "metadata": metadata or {}
            }
            self.ioc_database[ioc_type].append(entry)
            logger.info(f"添加IOC: {ioc_type} = {value}")
    
    def add_to_blocklist(self, value: str):
        """添加到阻止列表"""
        self.blocklist.add(value)
        logger.info(f"添加到阻止列表: {value}")
    
    def get_blocklist(self) -> List[str]:
        """获取阻止列表"""
        return list(self.blocklist)


# ========== 攻击溯源器 ==========

class AttackTracer:
    """攻击溯源器"""
    
    def __init__(self, threat_intel: ThreatIntelManager):
        self.threat_intel = threat_intel
        logger.info("攻击溯源器初始化完成")
    
    async def trace_attack(
        self, 
        evidence: AttackEvidence,
        depth: int = 2
    ) -> AttackEvidence:
        """
        溯源攻击
        
        Args:
            evidence: 攻击证据
            depth: 溯源深度
        """
        logger.info(f"开始溯源: {evidence.attack_id}, 深度: {depth}")
        
        # 1. IP分析
        if evidence.source_ip:
            await self._analyze_ip(evidence)
        
        # 2. 域名分析
        if evidence.source_domain:
            await self._analyze_domain(evidence)
        
        # 3. 关联分析
        await self._correlate_evidence(evidence)
        
        # 4. 计算置信度
        evidence.confidence = self._calculate_confidence(evidence)
        
        logger.info(f"溯源完成: {evidence.attack_id}, 置信度: {evidence.confidence}")
        
        return evidence
    
    async def _analyze_ip(self, evidence: AttackEvidence):
        """分析源IP"""
        ip_info = await self.threat_intel.check_ip(evidence.source_ip)
        
        if ip_info["is_malicious"]:
            evidence.evidence.append(f"IP在黑名单中: {evidence.source_ip}")
        
        # 简化的IP归属分析
        if evidence.source_ip.startswith("192.168."):
            evidence.evidence.append("来源: 内网IP")
        elif evidence.source_ip.startswith("10."):
            evidence.evidence.append("来源: 内网IP")
    
    async def _analyze_domain(self, evidence: AttackEvidence):
        """分析域名"""
        domain_info = await self.threat_intel.check_domain(evidence.source_domain)
        
        if domain_info["is_malicious"]:
            evidence.evidence.append(f"可疑域名: {evidence.source_domain}")
    
    async def _correlate_evidence(self, evidence: AttackEvidence):
        """关联分析 - v3.0.4增强"""
        # 检查与已知攻击的关联
        correlation_score = 0.0
        
        # 1. 时间关联：检查是否有其他相似攻击在相近时间发生
        if hasattr(self, 'attack_history'):
            recent_attacks = [
                a for a in self.attack_history
                if (datetime.now() - a.timestamp).total_seconds() < 3600  # 1小时内
            ]
            if recent_attacks:
                correlation_score += 0.2
                evidence.evidence.append(f"发现{len(recent_attacks)}个近期相似攻击")
        
        # 2. IP段关联：检查是否有同一IP段的攻击
        if evidence.source_ip:
            ip_prefix = ".".join(evidence.source_ip.split(".")[:3])
            if hasattr(self, 'attack_history'):
                same_prefix = [
                    a for a in self.attack_history
                    if a.source_ip and ".".join(a.source_ip.split(".")[:3]) == ip_prefix
                ]
                if same_prefix:
                    correlation_score += 0.3
                    evidence.evidence.append(f"同一IP段({ip_prefix}.x)存在{len(same_prefix)}个攻击")
        
        # 3. 域名关联：检查相似域名模式
        if evidence.source_domain:
            for historical in getattr(self, 'attack_history', []):
                if historical.source_domain:
                    # 简单域名相似度检查
                    if self._domain_similarity(evidence.source_domain, historical.source_domain) > 0.7:
                        correlation_score += 0.2
                        evidence.evidence.append("发现域名模式相似的历史攻击")
                        break
        
        # 4. 目标关联：检查是否针对同一目标
        if evidence.target:
            if hasattr(self, 'attack_history'):
                same_target = [a for a in self.attack_history if a.target == evidence.target]
                if same_target:
                    correlation_score += 0.2
                    evidence.evidence.append(f"同一目标({evidence.target})遭受{len(same_target)}次攻击")
        
        # 更新置信度
        evidence.confidence = min(1.0, evidence.confidence + correlation_score)
    
    def _domain_similarity(self, domain1: str, domain2: str) -> float:
        """计算域名相似度"""
        # 移除常见前缀
        for prefix in ['www.', 'mail.', 'secure.', 'login.']:
            domain1 = domain1.replace(prefix, '')
            domain2 = domain2.replace(prefix, '')
        
        # 获取主域名
        d1 = domain1.split('.')[0] if '.' in domain1 else domain1
        d2 = domain2.split('.')[0] if '.' in domain2 else domain2
        
        # 计算相似度
        if d1 == d2:
            return 1.0
        
        # 简单的字符重叠率
        common = sum(1 for c in d1 if c in d2)
        return common / max(len(d1), len(d2)) if max(len(d1), len(d2)) > 0 else 0
    
    def _calculate_confidence(self, evidence: AttackEvidence) -> float:
        """计算置信度"""
        confidence = 0.0
        
        # 基于证据数量
        confidence += min(0.3, len(evidence.evidence) * 0.05)
        
        # 基于IOC
        if evidence.malicious_urls:
            confidence += 0.3
        if evidence.malware_hashes:
            confidence += 0.3
        
        return min(1.0, confidence)


# ========== 蜜罐管理器 ==========

class HoneyPotManager:
    """蜜罐管理器"""
    
    def __init__(self):
        self.honey_pots = {}
        self.captured_attacks = []
        logger.info("蜜罐管理器初始化完成")
    
    def create_honey_port(
        self, 
        port: int, 
        service_type: str = "ftp"
    ) -> bool:
        """创建蜜罐端口"""
        honey = {
            "port": port,
            "service_type": service_type,
            "created_at": datetime.now(),
            "interactions": [],
            "is_active": True
        }
        
        self.honey_pots[port] = honey
        logger.info(f"创建蜜罐: 端口={port}, 类型={service_type}")
        return True
    
    def log_interaction(
        self, 
        port: int, 
        source_ip: str, 
        data: str
    ) -> tuple:
        """记录蜜罐交互"""
        if port in self.honey_pots:
            interaction = {
                "timestamp": datetime.now(),
                "source_ip": source_ip,
                "data_preview": data[:100] if data else "",
                "data_length": len(data) if data else 0
            }
            
            self.honey_pots[port]["interactions"].append(interaction)
            self.captured_attacks.append(interaction)
            
            logger.info(f"蜜罐捕获交互: {port} <- {source_ip}")
            
            if self._is_suspicious_interaction(interaction):
                return True, "Suspicious interaction detected"
        
        return False, ""
    
    def _is_suspicious_interaction(self, interaction: Dict) -> bool:
        """检测可疑交互"""
        suspicious_patterns = [
            "password", "admin", "root", "login",
            "../", "etc/passwd", "eval", "exec"
        ]
        
        data = interaction.get("data_preview", "").lower()
        return any(pattern.lower() in data for pattern in suspicious_patterns)
    
    def get_captured_attacks(self) -> List[Dict]:
        """获取捕获的攻击"""
        return self.captured_attacks
    
    def generate_honey_token(self) -> str:
        """生成蜜糖令牌"""
        token = hashlib.md5(
            f"admin:admin123:{datetime.now()}".encode()
        ).hexdigest()
        return token


# ========== 反击引擎 ==========

class RetaliationEngine:
    """反击引擎
    
    ⚠️ 默认禁用，必须明确授权才能启用！
    """
    
    def __init__(
        self, 
        threat_intel: ThreatIntelManager,
        intensity: str = "passive"
    ):
        self.threat_intel = threat_intel
        self.intensity = intensity
        self.action_history = []
        self.enabled = False  # ⚠️ 默认禁用！
        logger.info(f"反击引擎初始化: 强度={intensity}, 启用={self.enabled}")
    
    def set_intensity(self, intensity: str):
        """设置反击强度"""
        valid_intensities = ["passive", "moderate", "aggressive"]
        if intensity in valid_intensities:
            self.intensity = intensity
            logger.info(f"反击强度已更新: {intensity}")
    
    def enable(self):
        """启用反击⚠️ 必须明确授权"""
        logger.warning("⚠️ ⚠️ ⚠️ 反击系统已启用！ ⚠️ ⚠️ ⚠️")
        logger.warning("请确保您有权限执行自动反击！")
        self.enabled = True
    
    def disable(self):
        """禁用反击"""
        logger.info("反击系统已禁用")
        self.enabled = False
    
    async def execute_retaliation(
        self, 
        evidence: AttackEvidence
    ) -> List[RetaliationAction]:
        """
        执行反击
        
        ⚠️ 必须在明确授权后才能执行！
        """
        if not self.enabled:
            logger.warning("反击系统未启用，跳过反击")
            return []
        
        logger.warning(f"⚠️ 开始执行反击: {evidence.attack_id}")
        
        actions = []
        
        # 根据强度级别执行动作
        if self.intensity == "passive":
            action = RetaliationAction(
                action_id=hashlib.md5(b"passive").hexdigest()[:8],
                action_type="log",
                target=evidence.source_ip or evidence.source_domain,
                parameters={"evidence": evidence.evidence}
            )
            actions.append(action)
        
        elif self.intensity == "moderate":
            if evidence.source_ip:
                action = RetaliationAction(
                    action_id=hashlib.md5(b"block_ip").hexdigest()[:8],
                    action_type="block_ip",
                    target=evidence.source_ip
                )
                actions.append(action)
                self.threat_intel.add_ioc("malicious_ips", evidence.source_ip)
                self.threat_intel.add_to_blocklist(evidence.source_ip)
        
        elif self.intensity == "aggressive":
            if evidence.source_ip:
                action = RetaliationAction(
                    action_id=hashlib.md5(b"aggressive").hexdigest()[:8],
                    action_type="block_ip",
                    target=evidence.source_ip,
                    parameters={"report": True}
                )
                actions.append(action)
                self.threat_intel.add_to_blocklist(evidence.source_ip)
        
        # 执行所有动作
        for action in actions:
            await self._execute_action(action)
            self.action_history.append(action)
        
        return actions
    
    async def _execute_action(self, action: RetaliationAction):
        """执行单个动作"""
        logger.info(f"执行反击动作: {action.action_type} -> {action.target}")
        
        await asyncio.sleep(0.1)  # 模拟执行
        
        action.executed_at = datetime.now()
        action.result = "executed"
        
        logger.info(f"反击动作执行完成: {action.action_id}")


# ========== SOAR编排器 ==========

class SOAROrchestrator:
    """SOAR安全编排自动化响应"""
    
    def __init__(
        self, 
        threat_intel: ThreatIntelManager,
        retaliation_engine: RetaliationEngine
    ):
        self.threat_intel = threat_intel
        self.retaliation = retaliation_engine
        self.playbooks = {}
        self.active_incidents = {}
        self._load_default_playbooks()
        logger.info("SOAR编排器初始化完成")
    
    def _load_default_playbooks(self):
        """加载默认剧本"""
        self.playbooks = {
            "phishing_response": {
                "name": "钓鱼邮件响应",
                "steps": [
                    {"action": "extract_ioc", "description": "提取IOC"},
                    {"action": "block_sender", "description": "阻止发件人"},
                    {"action": "notify_security_team", "description": "通知安全团队"},
                    {"action": "analyze_urls", "description": "分析恶意URL"}
                ]
            },
            "malware_response": {
                "name": "恶意软件响应",
                "steps": [
                    {"action": "quarantine_file", "description": "隔离文件"},
                    {"action": "block_execution", "description": "阻止执行"},
                    {"action": "scan_network", "description": "扫描网络"},
                    {"action": "isolate_endpoint", "description": "隔离端点"}
                ]
            },
            "brute_force_response": {
                "name": "暴力破解响应",
                "steps": [
                    {"action": "block_ip", "description": "阻止IP"},
                    {"action": "alert_user", "description": "警告用户"},
                    {"action": "enable_mfa", "description": "启用多因素认证"}
                ]
            }
        }
    
    async def execute_playbook(
        self, 
        playbook_name: str, 
        incident_data: Dict
    ) -> Dict:
        """执行剧本"""
        if playbook_name not in self.playbooks:
            raise ValueError(f"剧本不存在: {playbook_name}")
        
        playbook = self.playbooks[playbook_name]
        incident_id = hashlib.md5(
            f"{playbook_name}{datetime.now()}".encode()
        ).hexdigest()[:16]
        
        logger.info(f"开始执行剧本: {playbook['name']}, ID: {incident_id}")
        
        results = {
            "incident_id": incident_id,
            "playbook": playbook_name,
            "steps_completed": [],
            "actions_taken": [],
            "status": "running"
        }
        
        self.active_incidents[incident_id] = results
        
        # 执行每一步
        for step in playbook["steps"]:
            step_result = await self._execute_step(step, incident_data)
            results["steps_completed"].append(step["action"])
            results["actions_taken"].append(step_result)
            
            if step_result.get("status") == "failed":
                results["status"] = "partial"
                break
        
        if results["status"] == "running":
            results["status"] = "completed"
        
        logger.info(f"剧本执行完成: {incident_id}, 状态: {results['status']}")
        
        return results
    
    async def _execute_step(
        self, 
        step: Dict, 
        incident_data: Dict
    ) -> Dict:
        """执行单个步骤"""
        action = step["action"]
        logger.info(f"执行步骤: {action}")
        
        result = {"action": action, "status": "success"}
        
        try:
            if action == "extract_ioc":
                iocs = incident_data.get("indicators", [])
                result["data"] = {"iocs_extracted": len(iocs)}
            
            elif action == "block_sender":
                sender = incident_data.get("sender", "")
                if sender:
                    self.threat_intel.add_ioc("malicious_ips", sender)
                    result["data"] = {"blocked": sender}
            
            elif action == "block_ip":
                ip = incident_data.get("source_ip", "")
                if ip:
                    self.threat_intel.add_ioc("malicious_ips", ip)
                    self.threat_intel.add_to_blocklist(ip)
                    result["data"] = {"blocked": ip}
            
            elif action == "notify_security_team":
                result["data"] = {"notified": True}
            
            elif action == "analyze_urls":
                urls = incident_data.get("urls", [])
                result["data"] = {"urls_analyzed": len(urls)}
            
            elif action == "quarantine_file":
                file_hash = incident_data.get("file_hash", "")
                result["data"] = {"quarantined": file_hash}
            
            else:
                result["data"] = {"message": f"Unknown action: {action}"}
        
        except Exception as e:
            logger.error(f"步骤执行失败: {action}, {e}")
            result["status"] = "failed"
            result["error"] = str(e)
        
        return result
    
    def create_custom_playbook(
        self, 
        name: str, 
        steps: List[Dict]
    ) -> bool:
        """创建自定义剧本"""
        playbook_id = hashlib.md5(name.encode()).hexdigest()[:8]
        
        self.playbooks[playbook_id] = {
            "name": name,
            "steps": steps
        }
        
        logger.info(f"创建剧本: {name}")
        return True


# ========== 统一防御管理器 ==========

class UnifiedDefenseManager:
    """统一防御管理器"""
    
    def __init__(self):
        # 初始化各组件
        self.threat_intel = ThreatIntelManager()
        self.honey_pot = HoneyPotManager()
        self.retaliation = RetaliationEngine(self.threat_intel, "passive")
        self.tracer = AttackTracer(self.threat_intel)
        self.soar = SOAROrchestrator(self.threat_intel, self.retaliation)
        
        # 联动规则
        self.trigger_rules = []
        
        # 统一状态
        self.status = {
            "threat_intel": "online",
            "honey_pot": "online",
            "retaliation": "disabled",  # 默认禁用
            "soar": "online"
        }
        
        logger.info("统一防御管理器初始化完成")
    
    def add_trigger_rule(
        self, 
        condition: str, 
        actions: List[str],
        name: str = None
    ):
        """添加联动触发规则"""
        rule = {
            "id": hashlib.md5(condition.encode()).hexdigest()[:8],
            "name": name or condition,
            "condition": condition,
            "actions": actions,
            "enabled": True
        }
        
        self.trigger_rules.append(rule)
        logger.info(f"添加联动规则: {rule['name']}")
    
    async def handle_security_event(
        self, 
        event_type: str, 
        event_data: Dict
    ) -> Dict:
        """处理安全事件"""
        logger.info(f"收到安全事件: {event_type}")
        
        results = {
            "event_type": event_type,
            "processed_at": datetime.now().isoformat(),
            "actions_taken": []
        }
        
        # 检查触发规则
        for rule in self.trigger_rules:
            if not rule["enabled"]:
                continue
            
            if self._match_condition(rule["condition"], event_type, event_data):
                logger.info(f"规则匹配: {rule['name']}")
                
                for action_name in rule["actions"]:
                    action_result = await self._execute_action(
                        action_name, event_data
                    )
                    results["actions_taken"].append(action_result)
        
        return results
    
    def _match_condition(
        self, 
        condition: str, 
        event_type: str, 
        event_data: Dict
    ) -> bool:
        """匹配条件"""
        if condition == "malware_detected":
            return event_type == "malware_found"
        elif condition == "phishing_detected":
            return event_type == "phishing_email"
        elif condition == "brute_force":
            return event_type == "login_failed" and event_data.get("attempts", 0) > 5
        
        return False
    
    async def _execute_action(
        self, 
        action_name: str, 
        event_data: Dict
    ) -> Dict:
        """执行动作"""
        result = {"action": action_name, "status": "success"}
        
        if action_name == "block_ip":
            ip = event_data.get("source_ip")
            if ip:
                self.threat_intel.add_ioc("malicious_ips", ip)
                self.threat_intel.add_to_blocklist(ip)
                result["data"] = f"Blocked {ip}"
        
        elif action_name == "quarantine":
            result["data"] = "Quarantine action taken"
        
        elif action_name == "notify":
            result["data"] = "Notification sent"
        
        elif action_name == "run_playbook":
            playbook = event_data.get("playbook")
            if playbook:
                playbook_result = await self.soar.execute_playbook(
                    playbook, event_data
                )
                result["data"] = playbook_result
        
        return result
    
    def get_status(self) -> Dict:
        """获取系统状态"""
        return {
            **self.status,
            "blocklist_size": {
                "malicious_ips": len(self.threat_intel.ioc_database["malicious_ips"]),
                "malicious_domains": len(self.threat_intel.ioc_database["malicious_domains"])
            },
            "active_incidents": len(self.soar.active_incidents),
            "trigger_rules": len(self.trigger_rules),
            "captured_attacks": len(self.honey_pot.captured_attacks)
        }


# ========== 统一管理平台 ==========

class UnifiedManagementPlatform:
    """统一管理平台"""
    
    def __init__(self):
        self.defense_manager = UnifiedDefenseManager()
        self.components = {}
        self._register_components()
        logger.info("统一管理平台初始化完成")
    
    def _register_components(self):
        """注册组件"""
        self.components = {
            "threat_intelligence": self.defense_manager.threat_intel,
            "honey_pot": self.defense_manager.honey_pot,
            "retaliation": self.defense_manager.retaliation,
            "soar": self.defense_manager.soar,
            "tracer": self.defense_manager.tracer
        }
    
    def get_overview(self) -> Dict:
        """获取总览"""
        return {
            "platform": "Unified Management Platform",
            "version": "3.0.4",
            "status": "online",
            "components": {
                name: "online" for name in self.components.keys()
            },
            "defense_status": self.defense_manager.get_status()
        }
    
    def enable_retaliation(self, intensity: str = "passive"):
        """启用反击系统⚠️"""
        logger.warning("⚠️ 启用反击系统...")
        self.defense_manager.retaliation.set_intensity(intensity)
        self.defense_manager.retaliation.enable()
    
    def disable_retaliation(self):
        """禁用反击系统"""
        self.defense_manager.retaliation.disable()


# ========== 使用示例 ==========

if __name__ == "__main__":
    async def main():
        print("="*70)
        print("🛡️ 统一防御系统测试")
        print("="*70)
        
        platform = UnifiedManagementPlatform()
        
        # 查看总览
        print("\n1️⃣ 系统总览...")
        overview = platform.get_overview()
        print(f"   平台: {overview['platform']}")
        print(f"   版本: {overview['version']}")
        print(f"   组件数: {len(overview['components'])}")
        
        # 添加联动规则
        print("\n2️⃣ 配置联动规则...")
        platform.defense_manager.add_trigger_rule(
            condition="malware_detected",
            actions=["block_ip", "notify", "run_playbook"],
            name="恶意软件响应"
        )
        print("   ✅ 规则已添加")
        
        # 模拟安全事件
        print("\n3️⃣ 模拟恶意软件检测事件...")
        event_result = await platform.defense_manager.handle_security_event(
            event_type="malware_found",
            event_data={
                "source_ip": "192.168.1.100",
                "file_hash": "abc123",
                "playbook": "malware_response"
            }
        )
        print(f"   执行动作: {[a['action'] for a in event_result['actions_taken']]}")
        
        # 查看状态
        print("\n4️⃣ 系统状态...")
        status = platform.defense_manager.get_status()
        print(f"   反击系统: {status['retaliation']}")
        print(f"   阻止列表IP: {status['blocklist_size']['malicious_ips']}")
        
        # 反击系统控制
        print("\n5️⃣ 反击系统控制...")
        print(f"   当前状态: {'启用' if platform.defense_manager.retaliation.enabled else '禁用'}")
        
        # ⚠️ 启用反击（需要明确授权）
        print("   ⚠️ 启用反击系统（passive模式）...")
        platform.enable_retaliation("passive")
        print(f"   启用后状态: {'启用' if platform.defense_manager.retaliation.enabled else '禁用'}")
        
        # 蜜罐测试
        print("\n6️⃣ 蜜罐测试...")
        platform.defense_manager.honey_pot.create_honey_port(21, "ftp")
        is_suspicious, reason = platform.defense_manager.honey_pot.log_interaction(
            21, "192.168.1.200", "USER admin\nPASS password123"
        )
        print(f"   捕获可疑交互: {is_suspicious}")
        
        print("\n" + "="*70)
        print("✅ 统一防御系统测试完成！")
        print("⚠️ 注意: 反击系统默认禁用，需要明确授权才能启用")
        print("="*70)
    
    asyncio.run(main())
