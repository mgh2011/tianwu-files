# dialog_engine/utils/helpers.py
"""
辅助函数
"""

import re
import hashlib
from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import uuid4


def generate_id(prefix: str = "") -> str:
    """生成唯一ID"""
    uid = uuid4().hex[:12]
    return f"{prefix}_{uid}" if prefix else uid


def mask_string(s: str, start: int = 3, end: int = 4, mask: str = "*") -> str:
    """字符串脱敏"""
    if len(s) <= start + end:
        return mask * len(s)
    return s[:start] + mask * (len(s) - start - end) + s[-end:]


def truncate_string(s: str, max_length: int = 100, suffix: str = "...") -> str:
    """截断字符串"""
    if len(s) <= max_length:
        return s
    return s[:max_length - len(suffix)] + suffix


def sanitize_filename(filename: str) -> str:
    """清理文件名"""
    # 移除非法的文件系统字符
    filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
    # 移除空白字符
    filename = re.sub(r'\s+', '_', filename)
    return filename


def parse_key_value(s: str, delimiter: str = "=") -> Dict[str, str]:
    """解析键值对"""
    result = {}
    for line in s.split('\n'):
        line = line.strip()
        if delimiter in line:
            key, value = line.split(delimiter, 1)
            result[key.strip()] = value.strip()
    return result


def deep_get(d: Dict, path: str, default: Any = None) -> Any:
    """
    深度获取字典值
    
    Args:
        d: 字典
        path: 路径,如 "a.b.c"
        default: 默认值
        
    Returns:
        值或默认值
    """
    keys = path.split('.')
    current = d
    
    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return default
    
    return current


def deep_merge(d1: Dict, d2: Dict) -> Dict:
    """
    深度合并字典
    
    Args:
        d1: 基础字典
        d2: 合并字典
        
    Returns:
        合并后的字典
    """
    result = d1.copy()
    
    for key, value in d2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    
    return result


def chunks(lst: List, n: int) -> List[List]:
    """将列表分块"""
    return [lst[i:i + n] for i in range(0, len(lst), n)]


def flatten(d: Dict, parent_key: str = '', sep: str = '.') -> Dict:
    """扁平化字典"""
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def md5(text: str) -> str:
    """计算MD5"""
    return hashlib.md5(text.encode('utf-8')).hexdigest()


def sha256(text: str) -> str:
    """计算SHA256"""
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def time_ago(dt: datetime) -> str:
    """获取相对时间"""
    now = datetime.now()
    diff = now - dt
    
    seconds = diff.total_seconds()
    
    if seconds < 60:
        return "刚刚"
    elif seconds < 3600:
        return f"{int(seconds / 60)}分钟前"
    elif seconds < 86400:
        return f"{int(seconds / 3600)}小时前"
    elif seconds < 604800:
        return f"{int(seconds / 86400)}天前"
    else:
        return dt.strftime("%Y-%m-%d")


def format_size(size_bytes: int) -> str:
    """格式化文件大小"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f}{unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f}PB"


def normalize_whitespace(s: str) -> str:
    """规范化空白字符"""
    return ' '.join(s.split())


def extract_numbers(s: str) -> List[float]:
    """提取数字"""
    return [float(x) for x in re.findall(r'-?\d+\.?\d*', s)]


def is_valid_email(email: str) -> bool:
    """验证邮箱"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def is_valid_phone(phone: str) -> bool:
    """验证手机号"""
    pattern = r'^1[3-9]\d{9}$'
    return bool(re.match(pattern, phone))


def is_valid_url(url: str) -> bool:
    """验证URL"""
    pattern = r'^https?://[^\s]+$'
    return bool(re.match(pattern, url))
