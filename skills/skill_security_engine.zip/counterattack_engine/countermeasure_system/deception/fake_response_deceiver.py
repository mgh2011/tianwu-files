"""
主动反制系统 - 欺骗反击引擎
Fake Response Deceiver - 提供虚假响应欺骗攻击者
"""

from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime
import json


class FakeResponseDeceiver:
    """假响应欺骗器"""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.enabled = self.config.get('enabled', True)

    def generate_fake_response(self, original_response: Dict,
                               deception_type: str = "mislead") -> Dict:
        """
        生成虚假响应

        Args:
            original_response: 原始响应
            deception_type: 欺骗类型

        Returns:
            虚假响应
        """
        if deception_type == "success":
            return self._fake_success_response(original_response)
        elif deception_type == "error":
            return self._fake_error_response(original_response)
        elif deception_type == "timeout":
            return self._fake_timeout_response(original_response)
        else:
            return self._fake_mislead_response(original_response)

    def _fake_success_response(self, original: Dict) -> Dict:
        """伪造成功响应"""
        return {
            'status': 'success',
            'data': {'result': 'ok', 'processed': True},
            'timestamp': datetime.now().isoformat(),
            'fake': True
        }

    def _fake_error_response(self, original: Dict) -> Dict:
        """伪造错误响应"""
        return {
            'status': 'error',
            'message': 'Internal server error',
            'timestamp': datetime.now().isoformat(),
            'fake': True
        }

    def _fake_timeout_response(self, original: Dict) -> Dict:
        """伪造超时响应"""
        return {
            'status': 'timeout',
            'message': 'Request timeout',
            'timestamp': datetime.now().isoformat(),
            'fake': True
        }

    def _fake_mislead_response(self, original: Dict) -> Dict:
        """伪造误导响应"""
        return {
            'status': 'success',
            'data': {'fake_data': 'misleading_content'},
            'timestamp': datetime.now().isoformat(),
            'fake': True
        }


if __name__ == "__main__":
    deceiver = FakeResponseDeceiver()

    original = {'status': 'ok'}
    fake = deceiver.generate_fake_response(original, 'success')
    print(f"虚假响应: {fake}")
