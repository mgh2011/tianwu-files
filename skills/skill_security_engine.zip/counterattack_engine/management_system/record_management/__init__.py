"""
记录管理模块
Record Management Module

提供反击行动的日志和报告功能
"""

from .counterattack_log_manager import CounterattackLogManager
from .counterattack_report_generator import CounterattackReportGenerator

__version__ = "v3.0.0"
__all__ = [
    'CounterattackLogManager',
    'CounterattackReportGenerator'
]
