"""
数据备份恢复模块
Data Backup and Recovery Module

提供完整的数据备份和恢复功能
"""

import os
import json
import shutil
import hashlib
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from pathlib import Path
import gzip
import tarfile

logger = logging.getLogger(__name__)


@dataclass
class BackupMetadata:
    """备份元数据"""
    backup_id: str
    backup_name: str
    backup_type: str  # full, incremental, differential
    created_at: str
    size_bytes: int
    file_count: int
    checksum: str
    source_path: str
    status: str  # completed, failed, in_progress
    compression: str = "gzip"
    retention_days: int = 30


class BackupManager:
    """备份管理器"""
    
    def __init__(self, backup_dir: str = "./data/backups", config: Dict = None):
        """
        初始化备份管理器
        
        Args:
            backup_dir: 备份存储目录
            config: 配置信息
        """
        self.backup_dir = Path(backup_dir)
        self.config = config or {}
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # 加载备份元数据
        self._metadata_file = self.backup_dir / "backup_metadata.json"
        self._metadata = self._load_metadata()
        
        logger.info(f"备份管理器初始化完成，备份目录: {self.backup_dir}")
    
    def _load_metadata(self) -> Dict:
        """加载备份元数据"""
        if self._metadata_file.exists():
            try:
                with open(self._metadata_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"加载备份元数据失败: {e}")
        return {'backups': [], 'version': 'v1.0'}
    
    def _save_metadata(self):
        """保存备份元数据"""
        try:
            with open(self._metadata_file, 'w', encoding='utf-8') as f:
                json.dump(self._metadata, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存备份元数据失败: {e}")
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """计算文件校验和"""
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    def create_backup(self, source_path: str, backup_name: str = None, 
                     backup_type: str = "full", compression: str = "gzip") -> BackupMetadata:
        """
        创建备份
        
        Args:
            source_path: 源数据路径
            source_name: 备份名称
            backup_type: 备份类型 (full, incremental, differential)
            compression: 压缩方式
        
        Returns:
            备份元数据
        """
        source = Path(source_path)
        if not source.exists():
            raise FileNotFoundError(f"源路径不存在: {source_path}")
        
        # 生成备份ID和文件名
        backup_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = backup_name or f"backup_{backup_id}"
        
        # 创建备份文件
        backup_file = self.backup_dir / f"{backup_name}.tar.gz"
        
        logger.info(f"开始创建备份: {backup_name}")
        
        try:
            # 创建tar.gz备份
            with tarfile.open(backup_file, 'w:gz') as tar:
                tar.add(source, arcname=source.name)
            
            # 计算校验和
            checksum = self._calculate_checksum(backup_file)
            
            # 获取备份大小和文件数
            size_bytes = backup_file.stat().st_size
            file_count = sum(1 for _ in tarfile.open(backup_file, 'r:*'))
            
            # 创建元数据
            metadata = BackupMetadata(
                backup_id=backup_id,
                backup_name=backup_name,
                backup_type=backup_type,
                created_at=datetime.now().isoformat(),
                size_bytes=size_bytes,
                file_count=file_count,
                checksum=checksum,
                source_path=str(source),
                status="completed",
                compression=compression
            )
            
            # 保存元数据
            self._metadata['backups'].append(metadata.__dict__)
            self._save_metadata()
            
            logger.info(f"备份创建成功: {backup_name}, 大小: {size_bytes} bytes")
            return metadata
            
        except Exception as e:
            logger.error(f"备份创建失败: {e}")
            raise
    
    def restore_backup(self, backup_name: str, restore_path: str) -> bool:
        """
        恢复备份
        
        Args:
            backup_name: 备份名称
            restore_path: 恢复目标路径
        
        Returns:
            是否恢复成功
        """
        backup_file = self.backup_dir / f"{backup_name}.tar.gz"
        if not backup_file.exists():
            raise FileNotFoundError(f"备份文件不存在: {backup_name}")
        
        # 验证校验和
        current_checksum = self._calculate_checksum(backup_file)
        metadata = self.get_backup_metadata(backup_name)
        
        if metadata and metadata.checksum != current_checksum:
            logger.warning(f"备份校验和不匹配，可能存在损坏")
        
        restore_dir = Path(restore_path)
        restore_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"开始恢复备份: {backup_name} -> {restore_path}")
        
        try:
            with tarfile.open(backup_file, 'r:gz') as tar:
                tar.extractall(restore_dir)
            
            logger.info(f"备份恢复成功: {backup_name}")
            return True
            
        except Exception as e:
            logger.error(f"备份恢复失败: {e}")
            raise
    
    def list_backups(self) -> List[BackupMetadata]:
        """列出所有备份"""
        backups = []
        for b in self._metadata.get('backups', []):
            backups.append(BackupMetadata(**b))
        return sorted(backups, key=lambda x: x.created_at, reverse=True)
    
    def get_backup_metadata(self, backup_name: str) -> Optional[BackupMetadata]:
        """获取备份元数据"""
        for b in self._metadata.get('backups', []):
            if b['backup_name'] == backup_name:
                return BackupMetadata(**b)
        return None
    
    def delete_backup(self, backup_name: str) -> bool:
        """
        删除备份
        
        Args:
            backup_name: 备份名称
        
        Returns:
            是否删除成功
        """
        backup_file = self.backup_dir / f"{backup_name}.tar.gz"
        if not backup_file.exists():
            return False
        
        try:
            # 删除备份文件
            backup_file.unlink()
            
            # 删除元数据
            self._metadata['backups'] = [
                b for b in self._metadata.get('backups', [])
                if b['backup_name'] != backup_name
            ]
            self._save_metadata()
            
            logger.info(f"备份删除成功: {backup_name}")
            return True
            
        except Exception as e:
            logger.error(f"备份删除失败: {e}")
            return False
    
    def cleanup_old_backups(self, retention_days: int = 30) -> int:
        """
        清理过期备份
        
        Args:
            retention_days: 保留天数
        
        Returns:
            删除的备份数量
        """
        cutoff_date = datetime.now() - timedelta(days=retention_days)
        deleted_count = 0
        
        for backup in self.list_backups():
            created = datetime.fromisoformat(backup.created_at)
            if created < cutoff_date:
                if self.delete_backup(backup.backup_name):
                    deleted_count += 1
        
        logger.info(f"清理过期备份完成，删除了 {deleted_count} 个备份")
        return deleted_count


def create_backup_manager(backup_dir: str = "./data/backups", config: Dict = None) -> BackupManager:
    """
    创建备份管理器实例
    
    Args:
        backup_dir: 备份存储目录
        config: 配置信息
    
    Returns:
        BackupManager实例
    """
    return BackupManager(backup_dir, config)


if __name__ == '__main__':
    print("=" * 60)
    print("数据备份恢复模块测试")
    print("=" * 60)
    
    # 创建备份管理器
    manager = create_backup_manager("./test_backups")
    
    # 列出备份
    print("\n当前备份列表:")
    for backup in manager.list_backups():
        print(f"  - {backup.backup_name} ({backup.backup_type}) - {backup.created_at}")
    
    print("\n备份管理器初始化完成")
