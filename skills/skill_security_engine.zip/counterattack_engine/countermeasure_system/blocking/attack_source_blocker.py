"""
主动反制系统 - 攻击源阻断模块
Attack Source Blocker - 阻断攻击来源
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import json


class BlockAction(Enum):
    """阻断动作"""
    IP_BLOCK = "ip_block"
    PORT_BLOCK = "port_block"
    PROTOCOL_BLOCK = "protocol_block"
    AS_BLOCK = "as_block"
    COUNTRY_BLOCK = "country_block"
    RATE_LIMIT = "rate_limit"


class BlockLevel(Enum):
    """阻断级别"""
    SOFT = "soft"  # 软阻断（限速）
    MEDIUM = "medium"  # 中等阻断
    HARD = "hard"  # 硬阻断（完全丢弃）
    BLACKHOLE = "blackhole"  # 黑洞路由


@dataclass
class BlockEntry:
    """阻断条目"""
    block_id: str
    target: str  # IP、CIDR、ASN等
    action: BlockAction
    level: BlockLevel
    reason: str
    source: str  # 阻断来源（自动/手动）
    created_at: str
    expires_at: Optional[str]
    hit_count: int = 0
    metadata: Dict = field(default_factory=dict)


@dataclass
class BlockResult:
    """阻断结果"""
    success: bool
    block_id: Optional[str]
    action: BlockAction
    target: str
    message: str
    estimated_effect: Dict


class AttackSourceBlocker:
    """攻击源阻断器"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化阻断器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.block_duration = self.config.get('default_duration', 3600)  # 秒
        self.blocks: Dict[str, BlockEntry] = {}
        self.block_history = []

    def block(self, target: str, action: BlockAction,
              level: BlockLevel = BlockLevel.MEDIUM,
              duration: int = None,
              reason: str = "",
              source: str = "manual",
              metadata: Dict = None) -> BlockResult:
        """
        执行阻断

        Args:
            target: 阻断目标（IP、CIDR、ASN等）
            action: 阻断动作
            level: 阻断级别
            duration: 持续时间（秒）
            reason: 阻断原因
            source: 来源
            metadata: 元数据

        Returns:
            阻断结果
        """
        duration = duration or self.block_duration

        # 检查是否已阻断
        existing = self._find_existing_block(target, action)
        if existing:
            # 更新现有阻断
            return self._update_block(existing, duration, reason)

        # 生成阻断ID
        block_id = self._generate_block_id(target, action)

        # 计算过期时间
        expires_at = None
        if duration > 0:
            expires_at = (datetime.now() + timedelta(seconds=duration)).isoformat()

        # 创建阻断条目
        entry = BlockEntry(
            block_id=block_id,
            target=target,
            action=action,
            level=level,
            reason=reason,
            source=source,
            created_at=datetime.now().isoformat(),
            expires_at=expires_at,
            metadata=metadata or {}
        )

        # 执行阻断（模拟）
        success = self._execute_block(entry)

        # 保存阻断
        if success:
            self.blocks[block_id] = entry

        # 记录历史
        self._record_block(entry, success)

        # 计算预估效果
        effect = self._estimate_effect(entry)

        return BlockResult(
            success=success,
            block_id=block_id if success else None,
            action=action,
            target=target,
            message="阻断成功" if success else "阻断失败",
            estimated_effect=effect
        )

    def unblock(self, block_id: str, reason: str = "") -> bool:
        """
        解除阻断

        Args:
            block_id: 阻断ID
            reason: 解除原因

        Returns:
            是否成功
        """
        if block_id not in self.blocks:
            return False

        entry = self.blocks[block_id]

        # 执行解除
        success = self._execute_unblock(entry)

        if success:
            entry.expires_at = datetime.now().isoformat()
            self._record_unblock(entry, reason)

        return success

    def unblock_by_target(self, target: str, action: BlockAction = None) -> int:
        """
        按目标解除阻断

        Args:
            target: 目标
            action: 动作类型

        Returns:
            解除数量
        """
        count = 0
        to_remove = []

        for block_id, entry in self.blocks.items():
            if entry.target == target:
                if action is None or entry.action == action:
                    if self._execute_unblock(entry):
                        count += 1
                        to_remove.append(block_id)

        for block_id in to_remove:
            del self.blocks[block_id]

        return count

    def get_block(self, block_id: str) -> Optional[BlockEntry]:
        """获取阻断条目"""
        return self.blocks.get(block_id)

    def is_blocked(self, target: str, action: BlockAction = None) -> Tuple[bool, Optional[BlockEntry]]:
        """
        检查是否被阻断

        Args:
            target: 目标
            action: 动作类型

        Returns:
            (是否阻断, 阻断条目)
        """
        for entry in self.blocks.values():
            if entry.target == target:
                if action is None or entry.action == action:
                    # 检查是否过期
                    if entry.expires_at:
                        expires = datetime.fromisoformat(entry.expires_at)
                        if datetime.now() > expires:
                            continue
                    return True, entry
        return False, None

    def list_blocks(self, filters: Dict = None) -> List[BlockEntry]:
        """
        列出阻断

        Args:
            filters: 筛选条件

        Returns:
            阻断列表
        """
        filters = filters or {}
        blocks = list(self.blocks.values())

        if 'action' in filters:
            blocks = [b for b in blocks if b.action == filters['action']]

        if 'level' in filters:
            blocks = [b for b in blocks if b.level == filters['level']]

        if 'source' in filters:
            blocks = [b for b in blocks if b.source == filters['source']]

        if 'active_only' in filters and filters['active_only']:
            blocks = [b for b in blocks
                     if not b.expires_at or
                     datetime.fromisoformat(b.expires_at) > datetime.now()]

        return blocks

    def increment_hit_count(self, block_id: str):
        """增加命中计数"""
        if block_id in self.blocks:
            self.blocks[block_id].hit_count += 1

    def get_statistics(self) -> Dict:
        """获取统计"""
        total_blocks = len(self.blocks)
        active_blocks = len([b for b in self.blocks.values()
                            if not b.expires_at or
                            datetime.fromisoformat(b.expires_at) > datetime.now()])

        total_hits = sum(b.hit_count for b in self.blocks.values())

        by_action = {}
        for block in self.blocks.values():
            action = block.action.value
            if action not in by_action:
                by_action[action] = {'count': 0, 'hits': 0}
            by_action[action]['count'] += 1
            by_action[action]['hits'] += block.hit_count

        return {
            'total_blocks': total_blocks,
            'active_blocks': active_blocks,
            'total_hits': total_hits,
            'by_action': by_action
        }

    def cleanup_expired(self) -> int:
        """清理过期阻断"""
        now = datetime.now()
        to_remove = []

        for block_id, entry in self.blocks.items():
            if entry.expires_at:
                expires = datetime.fromisoformat(entry.expires_at)
                if now > expires:
                    to_remove.append(block_id)

        for block_id in to_remove:
            del self.blocks[block_id]

        return len(to_remove)

    def _find_existing_block(self, target: str, action: BlockAction) -> Optional[str]:
        """查找现有阻断"""
        for block_id, entry in self.blocks.items():
            if entry.target == target and entry.action == action:
                return block_id
        return None

    def _update_block(self, block_id: str, duration: int, reason: str) -> BlockResult:
        """更新阻断"""
        entry = self.blocks[block_id]
        entry.expires_at = (datetime.now() + timedelta(seconds=duration)).isoformat()
        entry.reason = reason

        return BlockResult(
            success=True,
            block_id=block_id,
            action=entry.action,
            target=entry.target,
            message="阻断已更新",
            estimated_effect={}
        )

    def _generate_block_id(self, target: str, action: BlockAction) -> str:
        """生成阻断ID"""
        import hashlib
        content = f"{target}:{action.value}:{datetime.now().isoformat()}"
        return f"BLK-{hashlib.md5(content.encode()).hexdigest()[:12].upper()}"

    def _execute_block(self, entry: BlockEntry) -> bool:
        """执行阻断"""
        # 实际应用中会调用防火墙API等
        # 模拟执行
        return True

    def _execute_unblock(self, entry: BlockEntry) -> bool:
        """执行解除阻断"""
        # 实际应用中会调用防火墙API等
        # 模拟执行
        return True

    def _estimate_effect(self, entry: BlockEntry) -> Dict:
        """估算阻断效果"""
        return {
            'estimated_blocked_requests': entry.hit_count + 100,
            'attack_reduction': '70-90%',
            'collateral_impact': 'low' if entry.level in [BlockLevel.SOFT, BlockLevel.MEDIUM] else 'medium'
        }

    def _record_block(self, entry: BlockEntry, success: bool):
        """记录阻断历史"""
        self.block_history.append({
            'block_id': entry.block_id,
            'target': entry.target,
            'action': entry.action.value,
            'level': entry.level.value,
            'success': success,
            'timestamp': datetime.now().isoformat()
        })

        if len(self.block_history) > 5000:
            self.block_history = self.block_history[-4000:]

    def _record_unblock(self, entry: BlockEntry, reason: str):
        """记录解除阻断"""
        self.block_history.append({
            'block_id': entry.block_id,
            'target': entry.target,
            'action': 'unblock',
            'reason': reason,
            'timestamp': datetime.now().isoformat()
        })


# 独立运行测试
if __name__ == "__main__":
    blocker = AttackSourceBlocker({'default_duration': 3600})

    # 阻断单个IP
    result = blocker.block(
        target='192.168.1.100',
        action=BlockAction.IP_BLOCK,
        level=BlockLevel.HARD,
        duration=7200,
        reason='持续DDoS攻击',
        source='automated'
    )
    print(f"阻断结果: {result.message}")
    print(f"阻断ID: {result.block_id}")

    # 批量阻断CIDR
    result2 = blocker.block(
        target='10.0.0.0/24',
        action=BlockAction.IP_BLOCK,
        level=BlockLevel.MEDIUM,
        reason='异常流量来源'
    )
    print(f"CIDR阻断: {result2.message}")

    # 检查阻断状态
    is_blocked, entry = blocker.is_blocked('192.168.1.100')
    print(f"\n192.168.1.100 是否被阻断: {is_blocked}")
    if entry:
        print(f"阻断原因: {entry.reason}")
        print(f"阻断级别: {entry.level.value}")

    # 获取统计
    stats = blocker.get_statistics()
    print(f"\n阻断统计:")
    print(json.dumps(stats, indent=2))

    # 列出所有阻断
    blocks = blocker.list_blocks({'active_only': True})
    print(f"\n当前活跃阻断: {len(blocks)}个")
