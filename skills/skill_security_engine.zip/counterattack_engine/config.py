"""
自动反击引擎配置文件
Auto-Counterattack Engine Configuration
"""

class CounterattackConfig:
    """反击引擎全局配置"""

    # 反击决策配置
    DECISION = {
        'max_threat_level': 10,  # 最大威胁等级
        'min_damage_threshold': 1000,  # 最小损失阈值
        'auto_counterattack_enabled': False,  # 是否启用自动反击（默认关闭）
        'manual_approval_required': True,  # 是否需要人工审批
        'counterattack_timeout': 300,  # 反击超时时间（秒）
    }

    # 攻击溯源配置
    TRACING = {
        'max_trace_depth': 10,  # 最大追踪深度
        'trace_timeout': 600,  # 追踪超时时间（秒）
        'enable_ip_geolocation': True,  # 启用IP地理定位
        'enable_whois_query': True,  # 启用WHOIS查询
    }

    # 蜜罐配置
    HONEYPOT = {
        'network_honeypot_ports': [21, 22, 23, 80, 443, 3306, 3389, 5432],  # 监听端口
        'honeypot_log_retention': 90,  # 日志保留天数
        'decoy_data_size': 1000,  # 诱饵数据大小（MB）
        'auto_deploy_enabled': False,  # 自动部署蜜罐
    }

    # 主动反制配置
    COUNTERMEASURE = {
        'block_duration': 3600,  # 阻断时长（秒）
        'traffic_scrubbing_enabled': True,  # 启用流量清洗
        'deception_enabled': True,  # 启用欺骗技术
        'reverse_penetration_enabled': False,  # 反向渗透（默认关闭，需要高级授权）
        'legal_action_enabled': True,  # 启用法律反制
    }

    # 反击执行配置
    EXECUTION = {
        'max_concurrent_tasks': 10,  # 最大并发任务数
        'task_retry_limit': 3,  # 任务重试次数
        'task_timeout': 180,  # 任务超时时间（秒）
        'rollback_timeout': 300,  # 回滚超时时间（秒）
        'auto_rollback_on_error': True,  # 错误时自动回滚
    }

    # 协调系统配置
    COORDINATION = {
        'playbook_directory': './playbooks/',  # Playbook目录
        'system_api_timeout': 30,  # 系统API超时时间（秒）
        'multi_node_enabled': False,  # 多节点协同
        'node_sync_interval': 10,  # 节点同步间隔（秒）
    }

    # 管理系统配置
    MANAGEMENT = {
        'log_retention_days': 365,  # 日志保留天数
        'report_format': 'pdf',  # 报告格式：pdf/html/json
        'audit_enabled': True,  # 启用审计
        'compliance_check_interval': 86400,  # 合规检查间隔（秒）
    }

    # 安全合规配置
    SECURITY = {
        'legal_jurisdiction': 'CN',  # 法律管辖区
        'ethical_guidelines_enabled': True,  # 启用道德准则
        'attack_source_whitelist': [],  # 攻击源白名单
        'attack_target_blacklist': [],  # 攻击目标黑名单
        'max_counterattack_scope': 'network',  # 最大反击范围：network/host/application
    }

    # 回滚配置
    ROLLBACK = {
        'snapshot_enabled': True,  # 启用快照
        'snapshot_retention': 7,  # 快照保留天数
        'auto_rollback_on_failure': True,  # 失败时自动回滚
    }

    @classmethod
    def get_config(cls, section=None):
        """获取配置"""
        if section:
            return getattr(cls, section.upper(), {})
        return {k: v for k, v in cls.__dict__.items() if not k.startswith('_') and k.isupper()}
