"""
超级优化引擎 - 内存池优化引擎
Memory Pool Optimization Engine - 高效内存管理
"""

from typing import Dict, List, Optional, Any, Type
from dataclasses import dataclass, field
from datetime import datetime
import time
import threading
import hashlib
from collections import deque


@dataclass
class MemoryBlock:
    """内存块"""
    block_id: str
    size: int
    data: Any = None
    in_use: bool = False
    allocated_at: Optional[float] = None
    access_count: int = 0
    last_access: Optional[float] = None


@dataclass
class MemoryPoolStats:
    """内存池统计"""
    total_blocks: int = 0
    in_use_blocks: int = 0
    available_blocks: int = 0
    total_memory_bytes: int = 0
    in_use_bytes: int = 0
    hit_count: int = 0
    miss_count: int = 0
    hit_rate: float = 0.0


class MemoryPool:
    """内存池"""

    def __init__(self, block_size: int = 1024, initial_blocks: int = 100):
        """
        初始化内存池

        Args:
            block_size: 块大小(字节)
            initial_blocks: 初始块数
        """
        self.block_size = block_size
        self.blocks: Dict[str, MemoryBlock] = {}
        self.free_blocks: deque = deque()
        self.allocations: Dict[str, MemoryBlock] = {}

        # 统计
        self.stats = MemoryPoolStats()
        self._stats_lock = threading.Lock()

        # 预分配块
        self._preallocate(initial_blocks)

    def allocate(self, block_id: str = None, size: int = None) -> Optional[MemoryBlock]:
        """
        分配内存块

        Args:
            block_id: 块ID
            size: 大小

        Returns:
            内存块
        """
        block_id = block_id or self._generate_id()
        size = size or self.block_size

        with self._stats_lock:
            # 尝试从空闲池获取
            if self.free_blocks:
                block = self.free_blocks.popleft()
                block.in_use = True
                block.allocated_at = time.time()
                block.access_count = 0
                self.blocks[block.block_id] = block
                self.allocations[block.block_id] = block

                self._update_stats(hit=True)
                return block

            # 创建新块
            block = MemoryBlock(
                block_id=block_id,
                size=size,
                in_use=True,
                allocated_at=time.time()
            )
            self.blocks[block_id] = block
            self.allocations[block_id] = block

            self._update_stats(new_block=True)
            return block

    def release(self, block_id: str) -> bool:
        """
        释放内存块

        Args:
            block_id: 块ID

        Returns:
            是否成功
        """
        with self._stats_lock:
            if block_id not in self.blocks:
                return False

            block = self.blocks[block_id]
            block.in_use = False
            block.allocated_at = None

            if block_id in self.allocations:
                del self.allocations[block_id]

            # 放回空闲池
            self.free_blocks.append(block)

            self._update_stats()
            return True

    def get(self, block_id: str) -> Optional[MemoryBlock]:
        """
        获取内存块

        Args:
            block_id: 块ID

        Returns:
            内存块
        """
        with self._stats_lock:
            block = self.blocks.get(block_id)
            if block:
                block.access_count += 1
                block.last_access = time.time()
                self._update_stats(hit=True)
            else:
                self._update_stats(hit=False)

            return block

    def clear(self):
        """清空内存池"""
        with self._stats_lock:
            self.blocks.clear()
            self.free_blocks.clear()
            self.allocations.clear()
            self._update_stats()

    def get_stats(self) -> MemoryPoolStats:
        """获取统计"""
        with self._stats_lock:
            return self.stats.copy() if hasattr(self.stats, 'copy') else self.stats

    def _preallocate(self, count: int):
        """预分配"""
        for _ in range(count):
            block = MemoryBlock(
                block_id=self._generate_id(),
                size=self.block_size,
                in_use=False
            )
            self.blocks[block.block_id] = block
            self.free_blocks.append(block)

        self._update_stats()

    def _update_stats(self, hit: bool = None, new_block: bool = False):
        """更新统计"""
        total = len(self.blocks)
        in_use = len(self.allocations)
        available = total - in_use

        self.stats.total_blocks = total
        self.stats.in_use_blocks = in_use
        self.stats.available_blocks = available
        self.stats.total_memory_bytes = total * self.block_size
        self.stats.in_use_bytes = in_use * self.block_size

        if hit is not None:
            if hit:
                self.stats.hit_count += 1
            else:
                self.stats.miss_count += 1

            total_accesses = self.stats.hit_count + self.stats.miss_count
            if total_accesses > 0:
                self.stats.hit_rate = self.stats.hit_count / total_accesses

    def _generate_id(self) -> str:
        """生成ID"""
        return f"MB-{hashlib.md5(str(time.time()).encode()).hexdigest()[:12].upper()}"


class ObjectPool:
    """对象池"""

    def __init__(self, object_class: Type, initial_size: int = 10):
        """
        初始化对象池

        Args:
            object_class: 对象类
            initial_size: 初始大小
        """
        self.object_class = object_class
        self.pool: List[Any] = []
        self.in_use: Dict[int, Any] = {}
        self._lock = threading.Lock()

        # 预创建对象
        self._precreate(initial_size)

    def acquire(self, *args, **kwargs) -> Any:
        """
        获取对象

        Args:
            args: 位置参数
            kwargs: 关键字参数

        Returns:
            对象
        """
        with self._lock:
            if self.pool:
                obj = self.pool.pop()
            else:
                obj = self.object_class(*args, **kwargs)

            obj_id = id(obj)
            self.in_use[obj_id] = obj

            # 重新初始化对象
            if hasattr(obj, 'reset'):
                obj.reset(*args, **kwargs)
            elif hasattr(obj, '__init__'):
                try:
                    obj.__init__(*args, **kwargs)
                except:
                    pass

            return obj

    def release(self, obj: Any):
        """
        释放对象

        Args:
            obj: 对象
        """
        with self._lock:
            obj_id = id(obj)
            if obj_id in self.in_use:
                del self.in_use[obj_id]

                # 重置对象状态
                if hasattr(obj, 'clear'):
                    obj.clear()

                self.pool.append(obj)

    def clear(self):
        """清空对象池"""
        with self._lock:
            self.pool.clear()
            self.in_use.clear()

    def size(self) -> int:
        """获取池大小"""
        with self._lock:
            return len(self.pool)


class BufferPool:
    """缓冲区池"""

    def __init__(self, sizes: List[int] = None):
        """
        初始化缓冲区池

        Args:
            sizes: 缓冲区大小列表
        """
        self.sizes = sizes or [64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384]
        self.pools: Dict[int, MemoryPool] = {}

        for size in self.sizes:
            self.pools[size] = MemoryPool(block_size=size, initial_blocks=10)

    def allocate(self, size: int) -> Optional[MemoryBlock]:
        """
        分配缓冲区

        Args:
            size: 大小

        Returns:
            内存块
        """
        # 找到最接近的大小
        for pool_size in sorted(self.sizes):
            if pool_size >= size:
                return self.pools[pool_size].allocate()

        # 最大的也不够，创建新池
        new_pool = MemoryPool(block_size=size, initial_blocks=5)
        self.pools[size] = new_pool
        return new_pool.allocate()

    def release(self, block: MemoryBlock):
        """释放缓冲区"""
        if block.size in self.pools:
            self.pools[block.size].release(block.block_id)

    def get_stats(self) -> Dict:
        """获取所有统计"""
        stats = {}
        for size, pool in self.pools.items():
            p_stats = pool.get_stats()
            stats[size] = {
                'total': p_stats.total_blocks,
                'in_use': p_stats.in_use_blocks,
                'available': p_stats.available_blocks
            }
        return stats


# 独立运行测试
if __name__ == "__main__":
    print("=" * 60)
    print("内存池优化引擎测试")
    print("=" * 60)

    # 内存池测试
    print("\n1. 内存池测试...")
    pool = MemoryPool(block_size=1024, initial_blocks=10)

    print(f"   初始状态:")
    stats = pool.get_stats()
    print(f"     总块数: {stats.total_blocks}")
    print(f"     使用中: {stats.in_use_blocks}")
    print(f"     可用: {stats.available_blocks}")

    # 分配块
    blocks = []
    for i in range(15):
        block = pool.allocate(f"block_{i}")
        blocks.append(block)
        if block:
            block.data = f"data_{i}" * 100

    print(f"\n   分配后状态:")
    stats = pool.get_stats()
    print(f"     总块数: {stats.total_blocks}")
    print(f"     使用中: {stats.in_use_blocks}")
    print(f"     命中率: {stats.hit_rate:.1%}")

    # 释放块
    for i, block in enumerate(blocks[:5]):
        pool.release(block.block_id)

    print(f"\n   释放5块后状态:")
    stats = pool.get_stats()
    print(f"     可用: {stats.available_blocks}")

    # 再次分配（应该命中）
    for i in range(5):
        block = pool.allocate(f"new_block_{i}")
        if block:
            print(f"     分配new_block_{i}: 命中")

    stats = pool.get_stats()
    print(f"\n   最终命中率: {stats.hit_rate:.1%}")

    # 对象池测试
    print("\n2. 对象池测试...")

    class TestObject:
        def __init__(self, value=0):
            self.value = value
            self.data = []

        def reset(self, value=0):
            self.value = value
            self.data = []

        def clear(self):
            self.value = 0
            self.data = []

    obj_pool = ObjectPool(TestObject, initial_size=5)

    print(f"   初始池大小: {obj_pool.size()}")

    # 获取对象
    obj1 = obj_pool.acquire(42)
    obj2 = obj_pool.acquire(100)
    print(f"   获取2个对象后池大小: {obj_pool.size()}")
    print(f"   obj1.value: {obj1.value}")
    print(f"   obj2.value: {obj2.value}")

    # 释放对象
    obj_pool.release(obj1)
    obj_pool.release(obj2)
    print(f"   释放后池大小: {obj_pool.size()}")

    # 再次获取
    obj3 = obj_pool.acquire(999)
    print(f"   再次获取对象: obj3.value = {obj3.value}")

    # 缓冲区池测试
    print("\n3. 缓冲区池测试...")
    buf_pool = BufferPool([64, 128, 256, 512, 1024])

    # 分配不同大小的缓冲区
    sizes = [100, 200, 500, 800]
    allocated = []

    for size in sizes:
        block = buf_pool.allocate(size)
        allocated.append(block)
        print(f"   分配{size}字节 -> 实际{block.size if block else 0}字节")

    # 释放
    for block in allocated:
        buf_pool.release(block)

    print("\n   缓冲区池统计:")
    stats = buf_pool.get_stats()
    for size, stat in stats.items():
        print(f"     {size}字节: 总{stat['total']}, 使用{stat['in_use']}, 可用{stat['available']}")

    print("\n" + "=" * 60)
    print("内存池优化引擎测试完成")
    print("=" * 60)
