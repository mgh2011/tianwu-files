"""
邮件管理模块
Mail Management Module

提供钓鱼检测、域名仿冒检测、垃圾邮件过滤等功能
"""

from .phishing_detector import PhishingDetector
from .spam_filter import SpamFilter

__version__ = "v3.0.0"
__all__ = [
    'PhishingDetector',
    'SpamFilter'
]
