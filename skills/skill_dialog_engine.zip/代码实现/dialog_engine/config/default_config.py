# dialog_engine/config/default_config.py
"""对话引擎默认配置"""

class DefaultConfig:
    """默认配置类"""
    
    # ===== 对话引擎配置 =====
    DIALOG_ENGINE = {
        "name": "DialogEngine",
        "version": "1.0.0",
        "max_turns_per_session": 50,
        "session_timeout": 1800,  # 30分钟
        "default_language": "zh-CN",
        "enable_multimodal": True,
        "enable_streaming": True,
    }
    
    # ===== 状态管理配置 =====
    STATE_MANAGER = {
        "initial_state": "INIT",
        "max_state_history": 100,
        "enable_state_persistence": True,
        "state_check_interval": 60,
    }
    
    # ===== 上下文管理配置 =====
    CONTEXT_MANAGER = {
        "max_history_turns": 20,
        "max_context_size": 10000,
        "context_cleanup_interval": 300,
        "enable_context_compression": True,
    }
    
    # ===== 意图识别配置 =====
    INTENT_CLASSIFIER = {
        "default_confidence_threshold": 0.7,
        "fallback_intent": "UNKNOWN",
        "enable_ensemble": True,
        "model_type": "rule_ml_hybrid",  # rule | ml | hybrid | rule_ml_hybrid
        "supported_intents": [
            "greeting", "goodbye", "help", "complaint",
            "query", "booking", "cancellation", "modification",
            "payment", "refund", "repeat", "clarification",
            "confirmation", "denial", "unknown"
        ],
        "intent_rules": {
            "greeting": ["你好", "您好", "hi", "hello", "嗨", "早上好", "晚上好"],
            "goodbye": ["再见", "拜拜", "bye", "结束", "退出"],
            "help": ["帮助", "help", "怎么", "如何", "请问"],
            "query": ["查询", "问问", "看看", "有没有", "是什么"],
            "booking": ["预订", "预约", "订", "预约"],
            "cancellation": ["取消", "退", "撤销"],
            "confirmation": ["是的", "对", "确认", "好的", "ok", "可以"],
            "denial": ["不是", "不对", "否", "不要", "拒绝"],
        }
    }
    
    # ===== 实体抽取配置 =====
    ENTITY_EXTRACTOR = {
        "enable_ner": True,
        "enable_regex": True,
        "enable_dict": True,
        "confidence_threshold": 0.6,
        "supported_entity_types": [
            "person", "organization", "location", "time",
            "date", "number", "money", "phone", "email", "url"
        ],
        "entity_patterns": {
            "phone": [
                r"1[3-9]\d{9}",  # 手机号
                r"\d{3,4}-?\d{7,8}",  # 固话
            ],
            "email": [
                r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
            ],
            "url": [
                r"https?://[^\s]+",
                r"www\.[^\s]+",
            ],
            "money": [
                r"(\d+(?:\.\d+)?)\s*(?:元|块|美元|人民币)",
                r"\$\s*\d+",
            ],
            "date": [
                r"\d{4}[-/年]\d{1,2}[-/月]\d{1,2}[日]?",
                r"今天|明天|后天|昨天|前天",
                r"下周|下周[一二三四五六日]",
            ],
            "time": [
                r"\d{1,2}[:：]\d{2}",
                r"(?:早上|下午|晚上|上午|中午)?\d{1,2}点(?:半|\d{1,2}分)?",
            ],
        },
        "time_normalization_rules": {
            "今天": "relative_today",
            "明天": "relative_tomorrow",
            "后天": "relative_day_after_tomorrow",
            "昨天": "relative_yesterday",
            "早上": "morning",
            "下午": "afternoon",
            "晚上": "evening",
        }
    }
    
    # ===== 槽位填充配置 =====
    SLOT_FILLER = {
        "auto_fill_threshold": 0.8,
        "confirm_threshold": 0.6,
        "max_fill_attempts": 3,
        "enable_slot_carryover": True,  # 槽位跨意图继承
        "slot_expiration": 3600,  # 槽位过期时间（秒）
        "common_slots": {
            "user_name": {"type": "optional", "prompt": "请问您怎么称呼？"},
            "phone": {"type": "required", "prompt": "请留下您的联系电话"},
            "location": {"type": "optional", "prompt": "请问在哪个城市/地区？"},
            "time": {"type": "optional", "prompt": "您希望什么时间？"},
            "date": {"type": "optional", "prompt": "请问是哪一天？"},
        }
    }
    
    # ===== 策略路由配置 =====
    POLICY_ROUTER = {
        "default_policy": "fallback",
        "enable_contextual_routing": True,
        "fallback_policy": {
            "name": "fallback",
            "response_template": "抱歉，我没能理解您的意思。您可以：\n1. 换个说法\n2. 联系人工客服\n3. 尝试其他问题",
            "quick_replies": ["换个说法", "联系人工", "返回首页"]
        },
        "policies": {
            "greeting": {
                "name": "greeting",
                "response_templates": {
                    "default": "您好！有什么可以帮您的？",
                    "morning": "早上好！请问有什么可以帮您？",
                    "afternoon": "下午好！请问有什么需要？",
                    "evening": "晚上好！请问有什么可以帮您？",
                }
            },
            "goodbye": {
                "name": "goodbye",
                "response_templates": {
                    "default": "再见！如有需要随时找我。",
                    "satisfied": "感谢您的使用，再见！",
                    "unsatisfied": "希望下次能更好地为您服务，再见！",
                }
            },
            "help": {
                "name": "help",
                "response_templates": {
                    "default": "我可以帮您：\n1. 查询信息\n2. 预约服务\n3. 解答问题\n\n请告诉我您需要的帮助。",
                },
                "quick_replies": ["查询信息", "预约服务", "解答问题"]
            }
        }
    }
    
    # ===== 回复生成配置 =====
    RESPONSE_GENERATOR = {
        "default_temperature": 0.7,
        "max_response_length": 2000,
        "enable_template_rendering": True,
        "enable_multimodal": True,
        "quick_reply_limit": 5,
        "response_formats": {
            "text": {"max_length": 2000},
            "card": {"max_cards": 10},
            "quick_reply": {"max_options": 5},
        }
    }
    
    # ===== 短期记忆配置 =====
    SHORT_TERM_MEMORY = {
        "ttl": 1800,  # 30分钟
        "max_keys": 1000,
        "enable_persistence": True,
        "cleanup_interval": 300,
    }
    
    # ===== 长期记忆配置 =====
    LONG_TERM_MEMORY = {
        "max_memories_per_user": 1000,
        "importance_threshold": 0.5,
        "auto_summarize": True,
        "summarize_threshold": 100,
        "retention_days": 365,
    }
    
    # ===== 用户画像配置 =====
    USER_PROFILE = {
        "enable_auto_update": True,
        "update_interval": 86400,  # 24小时
        "extract_preferences": True,
        "min_interactions_for_profile": 5,
    }
    
    # ===== 安全配置 =====
    SECURITY = {
        # 内容过滤
        "enable_content_filter": True,
        "sensitive_word_lists": {
            "politics": ["敏感政治词1", "敏感政治词2"],
            "porn": ["色情词1", "色情词2"],
            "violence": ["暴力词1", "暴力词2"],
            "custom": []
        },
        "filter_action": "block",  # block | warn | replace
        
        # 隐私保护
        "enable_privacy_protection": True,
        "pii_detection": True,
        "pii_masking": True,
        "masking_patterns": {
            "phone": r"1[3-9]\d{9}",
            "id_card": r"\d{17}[\dXx]",
            "bank_card": r"\d{16,19}",
            "email": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
        },
        
        # 审计配置
        "enable_audit": True,
        "audit_log_level": "info",
        "audit_actions": [
            "session_start", "session_end", "message_sent",
            "intent_recognized", "policy_executed", "error_occurred"
        ],
        "audit_retention_days": 90,
    }
    
    # ===== API配置 =====
    API = {
        "version": "v1",
        "base_path": "/api/v1/dialogue",
        "rate_limit": {
            "enabled": True,
            "requests_per_minute": 60,
            "burst": 10,
        },
        "cors": {
            "enabled": True,
            "allow_origins": ["*"],
            "allow_methods": ["GET", "POST"],
            "allow_headers": ["*"],
        }
    }
    
    # ===== 日志配置 =====
    LOGGING = {
        "level": "INFO",
        "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        "handlers": {
            "console": {
                "enabled": True,
                "level": "INFO",
            },
            "file": {
                "enabled": True,
                "level": "DEBUG",
                "path": "./logs/dialog_engine.log",
                "max_bytes": 10485760,  # 10MB
                "backup_count": 5,
            }
        }
    }
    
    # ===== 缓存配置 =====
    CACHE = {
        "enabled": True,
        "backend": "redis",
        "redis": {
            "host": "localhost",
            "port": 6379,
            "db": 0,
            "password": None,
            "ssl": False,
        },
        "ttl": {
            "session": 1800,
            "context": 3600,
            "intent_result": 300,
            "entity_result": 300,
        }
    }
    
    # ===== 监控配置 =====
    MONITORING = {
        "enabled": True,
        "metrics_port": 9090,
        "health_check_interval": 30,
        "track_metrics": [
            "request_count",
            "response_time",
            "intent_accuracy",
            "session_count",
            "error_rate",
        ]
    }


# 全局配置实例
config = DefaultConfig()


def get_config(key: str = None):
    """获取配置"""
    if key is None:
        return config
    return getattr(config, key.upper(), None)


def merge_config(override: Dict):
    """合并自定义配置"""
    for section, values in override.items():
        if hasattr(config, section.upper()):
            current = getattr(config, section.upper())
            if isinstance(current, dict):
                current.update(values)
                setattr(config, section.upper(), current)
            else:
                setattr(config, section.upper(), values)
