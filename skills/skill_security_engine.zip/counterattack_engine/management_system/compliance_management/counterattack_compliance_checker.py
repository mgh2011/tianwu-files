"""
反击管理系统 - 合规检查模块
Counterattack Compliance Checker - 检查反击行动的合规性
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class ComplianceStatus(Enum):
    """合规状态"""
    COMPLIANT = "compliant"  # 合规
    NON_COMPLIANT = "non_compliant"  # 不合规
    PARTIAL = "partial"  # 部分合规
    PENDING = "pending"  # 待审查
    EXEMPT = "exempt"  # 豁免


class RegulationType(Enum):
    """法规类型"""
    CYBERSECURITY_LAW = "cybersecurity_law"  # 网络安全法
    DATA_PROTECTION = "data_protection"  # 数据保护法规
    COMPUTER_CRIME = "computer_crime"  # 计算机犯罪法
    INTERNATIONAL_LAW = "international_law"  # 国际法
    INDUSTRY_REGULATION = "industry_regulation"  # 行业法规


@dataclass
class ComplianceRule:
    """合规规则"""
    rule_id: str
    name: str
    description: str
    regulation: RegulationType
    applicable_actions: List[str]
    requirements: List[str]
    restrictions: List[str]
    severity: str = "high"  # high/medium/low


@dataclass
class ComplianceCheck:
    """合规检查"""
    check_id: str
    action_type: str
    target: Dict
    rules_checked: List[ComplianceRule]
    passed_rules: List[str]
    failed_rules: List[str]
    status: ComplianceStatus
    issues: List[str]
    recommendations: List[str]
    checked_at: str


@dataclass
class ComplianceReport:
    """合规报告"""
    report_id: str
    generated_at: str
    period: str
    overall_status: ComplianceStatus
    checks_performed: int
    pass_rate: float
    issues: List[Dict]
    recommendations: List[str]
    audit_trail: List[Dict]


class CounterattackComplianceChecker:
    """反击合规检查器"""

    # 合规规则库
    COMPLIANCE_RULES = [
        ComplianceRule(
            rule_id="LEGAL-001",
            name="法律授权要求",
            description="所有反击行动必须获得明确的法律授权",
            regulation=RegulationType.CYBERSECURITY_LAW,
            applicable_actions=["counterattack", "reverse_penetration"],
            requirements=["获得法律授权", "明确反击范围", "记录授权依据"],
            restrictions=["禁止无授权反击", "禁止超出授权范围"]
        ),
        ComplianceRule(
            rule_id="LEGAL-002",
            name="比例原则",
            description="反击行动的强度应与威胁相称",
            regulation=RegulationType.CYBERSECURITY_LAW,
            applicable_actions=["counterattack", "block", "disrupt"],
            requirements=["评估威胁程度", "选择适当反击强度", "避免过度反应"],
            restrictions=["禁止过度反击", "禁止造成不成比例的损害"]
        ),
        ComplianceRule(
            rule_id="LEGAL-003",
            name="跨境行动限制",
            description="跨境网络反击行动受到严格限制",
            regulation=RegulationType.INTERNATIONAL_LAW,
            applicable_actions=["counterattack", "trace", "investigate"],
            requirements=["确认攻击来源管辖区", "评估国际法合规性", "获得相关授权"],
            restrictions=["禁止未经授权的跨境行动", "禁止攻击他国关键基础设施"]
        ),
        ComplianceRule(
            rule_id="DATA-001",
            name="数据保护要求",
            description="反击行动中收集的数据必须符合数据保护法规",
            regulation=RegulationType.DATA_PROTECTION,
            applicable_actions=["trace", "investigate", "collect"],
            requirements=["遵守数据保护法规", "限制数据收集范围", "安全存储数据"],
            restrictions=["禁止收集无关数据", "禁止泄露个人数据"]
        ),
        ComplianceRule(
            rule_id="ETHIC-001",
            name="道德准则",
            description="反击行动应符合道德准则",
            regulation=RegulationType.INDUSTRY_REGULATION,
            applicable_actions=["*"],
            requirements=["避免伤害无辜第三方", "避免造成不必要破坏", "保护关键服务"],
            restrictions=["禁止攻击民用基础设施", "禁止影响紧急服务"]
        ),
        ComplianceRule(
            rule_id="PROC-001",
            name="审批流程",
            description="高风险反击行动必须经过审批",
            regulation=RegulationType.INDUSTRY_REGULATION,
            applicable_actions=["counterattack", "reverse_penetration"],
            requirements=["多层审批", "记录审批过程", "设置时限"],
            restrictions=["禁止绕过审批", "禁止超出审批范围"]
        ),
        ComplianceRule(
            rule_id="LOG-001",
            name="审计日志要求",
            description="所有反击行动必须有完整日志记录",
            regulation=RegulationType.INDUSTRY_REGULATION,
            applicable_actions=["*"],
            requirements=["记录所有行动", "保存审计日志", "确保日志完整性"],
            restrictions=["禁止删除日志", "禁止篡改记录"]
        ),
    ]

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化合规检查器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.jurisdiction = self.config.get('jurisdiction', 'CN')
        self.rules = self._load_rules()
        self.check_history = []

    def _load_rules(self) -> List[ComplianceRule]:
        """加载规则"""
        # 根据管辖区筛选适用规则
        applicable_rules = []

        for rule in self.COMPLIANCE_RULES:
            if self._is_rule_applicable(rule):
                applicable_rules.append(rule)

        return applicable_rules

    def _is_rule_applicable(self, rule: ComplianceRule) -> bool:
        """检查规则是否适用"""
        # 根据管辖区排除不适用的规则
        if self.jurisdiction == 'CN':
            # 中国管辖区适用规则
            return True
        elif self.jurisdiction == 'US':
            # 美国管辖区
            if rule.regulation == RegulationType.INTERNATIONAL_LAW:
                return True
            return True
        else:
            return True

    def check_action(self, action_type: str, target: Dict,
                   context: Dict = None) -> ComplianceCheck:
        """
        检查动作合规性

        Args:
            action_type: 动作类型
            target: 目标信息
            context: 上下文信息

        Returns:
            合规检查结果
        """
        import hashlib

        check_id = f"CHK-{hashlib.md5(f'{action_type}:{datetime.now().isoformat()}'.encode()).hexdigest()[:12].upper()}"

        context = context or {}
        passed_rules = []
        failed_rules = []
        issues = []
        recommendations = []

        # 检查适用规则
        for rule in self.rules:
            if not self._is_action_applicable(action_type, rule):
                continue

            rule_passed, rule_issues, rule_recs = self._check_rule(
                rule, action_type, target, context
            )

            if rule_passed:
                passed_rules.append(rule.rule_id)
            else:
                failed_rules.append(rule.rule_id)
                issues.extend(rule_issues)
                recommendations.extend(rule_recs)

        # 确定状态
        if not failed_rules:
            status = ComplianceStatus.COMPLIANT
        elif len(passed_rules) > len(failed_rules):
            status = ComplianceStatus.PARTIAL
        else:
            status = ComplianceStatus.NON_COMPLIANT

        # 创建检查结果
        check = ComplianceCheck(
            check_id=check_id,
            action_type=action_type,
            target=target,
            rules_checked=self.rules,
            passed_rules=passed_rules,
            failed_rules=failed_rules,
            status=status,
            issues=issues,
            recommendations=recommendations,
            checked_at=datetime.now().isoformat()
        )

        # 记录历史
        self._record_check(check)

        return check

    def _is_action_applicable(self, action_type: str, rule: ComplianceRule) -> bool:
        """检查动作是否适用规则"""
        applicable = rule.applicable_actions
        if '*' in applicable:
            return True
        return action_type in applicable

    def _check_rule(self, rule: ComplianceRule, action_type: str,
                   target: Dict, context: Dict) -> Tuple[bool, List[str], List[str]]:
        """
        检查单条规则

        Returns:
            (是否通过, 问题列表, 建议列表)
        """
        issues = []
        recommendations = []

        # 检查授权要求
        if '授权' in rule.name or 'approval' in rule.name.lower():
            authorized = context.get('authorized', False)
            if not authorized:
                issues.append(f"规则 {rule.rule_id}: 缺少必要授权")
                recommendations.append("获取明确的法律和运营授权")

        # 检查比例原则
        if '比例' in rule.name or 'proportional' in rule.name.lower():
            threat_level = context.get('threat_level', 5)
            response_intensity = context.get('response_intensity', 5)

            if response_intensity > threat_level * 1.5:
                issues.append(f"规则 {rule.rule_id}: 反击强度可能超出必要范围")
                recommendations.append("评估并调整反击强度")

        # 检查跨境限制
        if '跨境' in rule.name or 'cross-border' in rule.name.lower():
            is_cross_border = target.get('cross_border', False)
            if is_cross_border:
                has_permission = context.get('cross_border_permission', False)
                if not has_permission:
                    issues.append(f"规则 {rule.rule_id}: 跨境行动需要特别授权")
                    recommendations.append("确认跨境行动的法律依据")

        # 检查数据保护
        if '数据' in rule.name or 'data' in rule.name.lower():
            data_collection = context.get('data_collection', [])
            if len(data_collection) > 10:
                issues.append(f"规则 {rule.rule_id}: 可能收集了超出必要范围的数据")
                recommendations.append("限制数据收集范围，只收集必要信息")

        # 检查道德准则
        if '道德' in rule.name or 'ethical' in rule.name.lower():
            affects_civilian = target.get('affects_civilian_infrastructure', False)
            affects_emergency = target.get('affects_emergency_services', False)

            if affects_civilian:
                issues.append(f"规则 {rule.rule_id}: 可能影响民用基础设施")
                recommendations.append("避免攻击民用基础设施")

            if affects_emergency:
                issues.append(f"规则 {rule.rule_id}: 可能影响紧急服务")
                recommendations.append("确保不影响紧急服务系统")

        # 检查审批流程
        if '审批' in rule.name or 'approval' in rule.name.lower():
            if action_type in ['counterattack', 'reverse_penetration']:
                approval_level = context.get('approval_level', 0)
                required_level = 3  # 示例：需要3级以上审批

                if approval_level < required_level:
                    issues.append(f"规则 {rule.rule_id}: 审批级别不足")
                    recommendations.append(f"获取至少{required_level}级审批")

        passed = len(issues) == 0
        return passed, issues, recommendations

    def check_batch(self, actions: List[Dict]) -> List[ComplianceCheck]:
        """
        批量检查

        Args:
            actions: 动作列表

        Returns:
            检查结果列表
        """
        results = []
        for action in actions:
            check = self.check_action(
                action.get('type'),
                action.get('target', {}),
                action.get('context', {})
            )
            results.append(check)
        return results

    def generate_compliance_report(self, start_date: str,
                                  end_date: str) -> ComplianceReport:
        """
        生成合规报告

        Args:
            start_date: 开始日期
            end_date: 结束日期

        Returns:
            合规报告
        """
        import hashlib

        # 筛选时间范围内的检查
        checks = [
            c for c in self.check_history
            if start_date <= c.checked_at[:10] <= end_date
        ]

        total = len(checks)
        passed = sum(1 for c in checks if c.status == ComplianceStatus.COMPLIANT)
        pass_rate = passed / total if total > 0 else 0

        # 汇总问题
        all_issues = []
        for check in checks:
            for issue in check.issues:
                all_issues.append({
                    'check_id': check.check_id,
                    'action_type': check.action_type,
                    'issue': issue,
                    'timestamp': check.checked_at
                })

        # 汇总建议
        all_recommendations = []
        seen = set()
        for check in checks:
            for rec in check.recommendations:
                if rec not in seen:
                    all_recommendations.append(rec)
                    seen.add(rec)

        # 确定整体状态
        if pass_rate >= 0.9:
            overall_status = ComplianceStatus.COMPLIANT
        elif pass_rate >= 0.7:
            overall_status = ComplianceStatus.PARTIAL
        else:
            overall_status = ComplianceStatus.NON_COMPLIANT

        # 生成审计跟踪
        audit_trail = [
            {
                'check_id': c.check_id,
                'action_type': c.action_type,
                'status': c.status.value,
                'timestamp': c.checked_at
            }
            for c in checks[-100:]  # 最近100条
        ]

        return ComplianceReport(
            report_id=f"COMP-{hashlib.md5(f'{start_date}:{end_date}'.encode()).hexdigest()[:12].upper()}",
            generated_at=datetime.now().isoformat(),
            period=f"{start_date} 至 {end_date}",
            overall_status=overall_status,
            checks_performed=total,
            pass_rate=pass_rate,
            issues=all_issues,
            recommendations=all_recommendations,
            audit_trail=audit_trail
        )

    def get_violations(self, start_date: str = None,
                      end_date: str = None) -> List[Dict]:
        """
        获取违规记录

        Args:
            start_date: 开始日期
            end_date: 结束日期

        Returns:
            违规列表
        """
        violations = []

        for check in self.check_history:
            if check.status == ComplianceStatus.NON_COMPLIANT:
                if start_date and check.checked_at[:10] < start_date:
                    continue
                if end_date and check.checked_at[:10] > end_date:
                    continue

                violations.append({
                    'check_id': check.check_id,
                    'action_type': check.action_type,
                    'failed_rules': check.failed_rules,
                    'issues': check.issues,
                    'timestamp': check.checked_at
                })

        return violations

    def get_rules(self) -> List[ComplianceRule]:
        """获取所有合规规则"""
        return self.rules.copy()

    def _record_check(self, check: ComplianceCheck):
        """记录检查"""
        self.check_history.append(check)

        # 限制历史大小
        if len(self.check_history) > 10000:
            self.check_history = self.check_history[-8000:]

    def export_rules(self, format: str = "json") -> str:
        """
        导出规则

        Args:
            format: 格式

        Returns:
            规则内容
        """
        rules_data = [
            {
                'rule_id': r.rule_id,
                'name': r.name,
                'description': r.description,
                'regulation': r.regulation.value,
                'requirements': r.requirements,
                'restrictions': r.restrictions,
                'severity': r.severity
            }
            for r in self.rules
        ]

        if format == "json":
            return json.dumps(rules_data, indent=2, ensure_ascii=False)
        else:
            return str(rules_data)


# 独立运行测试
if __name__ == "__main__":
    checker = CounterattackComplianceChecker({
        'jurisdiction': 'CN'
    })

    print("合规规则库:")
    rules = checker.get_rules()
    for rule in rules:
        print(f"  [{rule.rule_id}] {rule.name} ({rule.regulation.value})")

    # 检查反击行动
    print("\n检查反击行动:")

    # 合规行动
    check1 = checker.check_action(
        'honeypot',
        {'target': 'internal_network'},
        {
            'authorized': True,
            'threat_level': 6,
            'response_intensity': 5
        }
    )
    print(f"\n蜜罐行动: {check1.status.value}")
    print(f"通过规则: {len(check1.passed_rules)}")
    print(f"失败规则: {len(check1.failed_rules)}")

    # 需要授权的行动
    check2 = checker.check_action(
        'counterattack',
        {'target': '192.168.1.100', 'cross_border': False},
        {
            'authorized': True,
            'approval_level': 4,
            'threat_level': 8,
            'response_intensity': 7
        }
    )
    print(f"\n反击行动: {check2.status.value}")
    print(f"问题: {check2.issues}")

    # 违规行动
    check3 = checker.check_action(
        'counterattack',
        {'target': 'external', 'cross_border': True},
        {
            'authorized': False,
            'approval_level': 1
        }
    )
    print(f"\n违规反击: {check3.status.value}")
    print(f"问题: {check3.issues}")
    print(f"建议: {check3.recommendations}")

    # 获取违规记录
    violations = checker.get_violations()
    print(f"\n总违规数: {len(violations)}")
