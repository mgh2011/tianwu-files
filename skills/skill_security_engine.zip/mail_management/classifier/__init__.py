"""
邮件分类模块
Mail Classification Module

提供邮件智能分类功能
"""

__version__ = "v3.0.0"
__all__ = []
