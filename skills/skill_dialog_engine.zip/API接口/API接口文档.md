# API接口文档

## 概述

对话引擎API基于FastAPI构建，提供RESTful风格的HTTP接口，支持对话、会话管理、历史查询等功能。

## 基础信息

- **Base URL**: `/api/v1/dialogue`
- **Content-Type**: `application/json`
- **认证方式**: API Key (Header: `X-API-Key`)

## 接口列表

### 1. 发送消息 (Chat)

**POST** `/api/v1/dialogue/chat`

发送用户消息并获取对话响应。

**请求体:**
```json
{
    "session_id": "sess_abc123",
    "user_id": "user_001",
    "message": "帮我查询明天的天气",
    "message_type": "text",
    "context": {
        "channel": "web"
    },
    "stream": false
}
```

**响应:**
```json
{
    "code": 0,
    "message": "success",
    "data": {
        "response_id": "resp_xyz789",
        "session_id": "sess_abc123",
        "message": {
            "type": "text",
            "content": "明天北京天气晴，最高温度15℃。"
        },
        "intent": "weather_query",
        "entities": [
            {"type": "date", "value": "明天", "normalized": "2024-01-16"},
            {"type": "location", "value": "北京"}
        ],
        "slots": {"date": "2024-01-16", "location": "北京"},
        "quick_replies": [
            {"text": "后天呢", "value": "后天天气"}
        ],
        "timestamp": "2024-01-15T10:30:00Z"
    }
}
```

---

### 2. 开始会话 (Session Start)

**POST** `/api/v1/dialogue/session/start`

创建新的对话会话。

**请求体:**
```json
{
    "user_id": "user_001",
    "metadata": {
        "source": "web",
        "platform": "windows"
    }
}
```

**响应:**
```json
{
    "code": 0,
    "message": "success",
    "data": {
        "session_id": "sess_new123",
        "user_id": "user_001",
        "state": "INIT",
        "created_at": "2024-01-15T10:30:00Z"
    }
}
```

---

### 3. 结束会话 (Session End)

**POST** `/api/v1/dialogue/session/end?session_id=sess_abc123`

结束指定会话。

**响应:**
```json
{
    "code": 0,
    "message": "Session ended",
    "data": {
        "session_id": "sess_abc123"
    }
}
```

---

### 4. 获取会话状态 (Get Session)

**GET** `/api/v1/dialogue/session/{session_id}`

获取指定会话的当前状态。

**响应:**
```json
{
    "code": 0,
    "message": "success",
    "data": {
        "session_id": "sess_abc123",
        "user_id": "user_001",
        "state": "ACTIVE",
        "current_turn": 5,
        "created_at": "2024-01-15T10:00:00Z",
        "last_active_at": "2024-01-15T10:30:00Z",
        "context_summary": {
            "intent": "query",
            "slots_count": 2
        }
    }
}
```

---

### 5. 获取对话历史 (Get History)

**GET** `/api/v1/dialogue/history?session_id=sess_abc123&limit=20`

获取会话的对话历史记录。

**响应:**
```json
{
    "code": 0,
    "message": "success",
    "data": {
        "session_id": "sess_abc123",
        "history": [
            {
                "turn_id": 1,
                "user_message": "你好",
                "bot_response": "您好！有什么可以帮您？",
                "intent": "greeting",
                "timestamp": "2024-01-15T10:00:00Z"
            },
            {
                "turn_id": 2,
                "user_message": "帮我查询天气",
                "bot_response": "请问您要查询哪里的天气？",
                "intent": "query",
                "timestamp": "2024-01-15T10:00:30Z"
            }
        ]
    }
}
```

---

### 6. 提交反馈 (Submit Feedback)

**POST** `/api/v1/dialogue/feedback`

用户对对话响应进行评分和评论。

**请求体:**
```json
{
    "session_id": "sess_abc123",
    "response_id": "resp_xyz789",
    "rating": 5,
    "comment": "回答很准确",
    "tags": ["有用", "专业"]
}
```

**响应:**
```json
{
    "code": 0,
    "message": "Feedback submitted",
    "data": {
        "session_id": "sess_abc123",
        "response_id": "resp_xyz789",
        "rating": 5,
        "timestamp": "2024-01-15T10:35:00Z"
    }
}
```

---

### 7. 获取支持的意图 (Get Intents)

**GET** `/api/v1/dialogue/intents`

获取所有支持的对话意图列表。

**响应:**
```json
{
    "code": 0,
    "message": "success",
    "data": {
        "intents": [
            {"name": "greeting", "description": "处理问候意图", "required_slots": []},
            {"name": "goodbye", "description": "处理告别意图", "required_slots": []},
            {"name": "query", "description": "处理查询意图", "required_slots": ["query_type"]},
            {"name": "booking", "description": "处理预约意图", "required_slots": ["date", "time"]}
        ]
    }
}
```

---

### 8. 健康检查 (Health Check)

**GET** `/api/v1/dialogue/health`

检查对话引擎的运行状态。

**响应:**
```json
{
    "status": "healthy",
    "timestamp": "2024-01-15T10:30:00Z",
    "components": {
        "intent_classifier": true,
        "entity_extractor": true,
        "slot_filler": true,
        "policy_router": true,
        "response_generator": true
    },
    "metrics": {
        "total_requests": 1000,
        "successful_requests": 980,
        "failed_requests": 20,
        "avg_response_time": 0.25
    },
    "active_sessions": 50
}
```

---

### 9. 获取性能指标 (Get Metrics)

**GET** `/api/v1/dialogue/metrics`

获取对话引擎的性能统计数据。

**响应:**
```json
{
    "code": 0,
    "message": "success",
    "data": {
        "total_requests": 1000,
        "successful_requests": 980,
        "failed_requests": 20,
        "avg_response_time": 0.25,
        "success_rate": 0.98
    }
}
```

---

## 响应码

| 码值 | 名称 | 描述 |
|------|------|------|
| 0 | SUCCESS | 成功 |
| 1000 | GENERAL_ERROR | 一般错误 |
| 1001 | INVALID_REQUEST | 无效请求 |
| 1002 | SESSION_NOT_FOUND | 会话不存在 |
| 1003 | SESSION_EXPIRED | 会话已过期 |
| 1004 | INTENT_NOT_RECOGNIZED | 意图未识别 |
| 1005 | SLOT_FILLING_FAILED | 槽位填充失败 |
| 1006 | POLICY_NOT_FOUND | 策略未找到 |
| 1007 | CONTENT_BLOCKED | 内容被拦截 |
| 1008 | SERVICE_UNAVAILABLE | 服务不可用 |
| 1009 | RATE_LIMIT_EXCEEDED | 超出速率限制 |
| 1010 | UNAUTHORIZED | 未授权 |

---

## 使用示例

### cURL

```bash
# 发送消息
curl -X POST http://localhost:8000/api/v1/dialogue/chat \
  -H "Content-Type: application/json" \
  -d '{"session_id":"sess_test","user_id":"user_001","message":"你好"}'

# 开始会话
curl -X POST http://localhost:8000/api/v1/dialogue/session/start \
  -H "Content-Type: application/json" \
  -d '{"user_id":"user_001"}'

# 健康检查
curl http://localhost:8000/api/v1/dialogue/health
```

### Python

```python
import requests

# 发送消息
response = requests.post(
    "http://localhost:8000/api/v1/dialogue/chat",
    json={
        "session_id": "sess_test",
        "user_id": "user_001",
        "message": "你好"
    }
)
print(response.json())

# 健康检查
response = requests.get("http://localhost:8000/api/v1/dialogue/health")
print(response.json())
```

### JavaScript

```javascript
// 发送消息
fetch('http://localhost:8000/api/v1/dialogue/chat', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    session_id: 'sess_test',
    user_id: 'user_001',
    message: '你好'
  })
})
.then(res => res.json())
.then(data => console.log(data));
```
