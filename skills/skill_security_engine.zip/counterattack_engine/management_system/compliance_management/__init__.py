"""
合规管理模块
Compliance Management Module

提供反击行动的合规检查功能
"""

from .counterattack_compliance_checker import CounterattackComplianceChecker

__version__ = "v3.0.0"
__all__ = [
    'CounterattackComplianceChecker'
]
