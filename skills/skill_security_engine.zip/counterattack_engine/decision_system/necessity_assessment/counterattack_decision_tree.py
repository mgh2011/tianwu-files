"""
反击决策树模块
Counterattack Decision Tree - 基于决策树的反击决策系统
"""

from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class DecisionResult(Enum):
    """决策结果"""
    APPROVE = "approve"  # 批准执行
    REJECT = "reject"  # 拒绝执行
    DEFER = "defer"  # 延迟决策
    ESCALATE = "escalate"  # 升级决策
    REQUIRE_REVIEW = "require_review"  # 需要人工审核


class DecisionNode:
    """决策节点"""

    def __init__(self, node_id: str, question: str, yes_node: Any = None,
                 no_node: Any = None, yes_action: str = None,
                 no_action: str = None, weight: float = 1.0):
        self.node_id = node_id
        self.question = question
        self.yes_node = yes_node
        self.no_node = no_node
        self.yes_action = yes_action
        self.no_action = no_action
        self.weight = weight

    def evaluate(self, context: Dict) -> 'DecisionResult':
        """评估节点"""
        raise NotImplementedError


@dataclass
class DecisionOutcome:
    """决策结果"""
    result: DecisionResult
    action: Optional[str]
    confidence: float
    reasoning: List[str]
    conditions: List[str]
    warnings: List[str]
    next_steps: List[str]


class ConditionNode(DecisionNode):
    """条件判断节点"""

    def __init__(self, node_id: str, question: str, condition_func: Callable,
                 yes_node: Any = None, no_node: Any = None,
                 yes_action: str = None, no_action: str = None,
                 weight: float = 1.0):
        super().__init__(node_id, question, yes_node, no_node,
                        yes_action, no_action, weight)
        self.condition_func = condition_func

    def evaluate(self, context: Dict) -> 'DecisionOutcome':
        """评估条件"""
        try:
            condition_met = self.condition_func(context)
        except Exception as e:
            return DecisionOutcome(
                result=DecisionResult.DEFER,
                action=None,
                confidence=0.0,
                reasoning=[f"评估出错: {str(e)}"],
                conditions=[],
                warnings=["评估过程发生错误"],
                next_steps=["检查决策条件配置"]
            )

        reasoning = [f"问题: {self.question}", f"答案: {'是' if condition_met else '否'}"]

        if condition_met:
            reasoning.append(f"执行动作: {self.yes_action}" if self.yes_action else "")
            if self.yes_node:
                return self.yes_node.evaluate(context)
            else:
                return DecisionOutcome(
                    result=DecisionResult.APPROVE,
                    action=self.yes_action,
                    confidence=self.weight,
                    reasoning=reasoning,
                    conditions=[],
                    warnings=[],
                    next_steps=[self.yes_action] if self.yes_action else []
                )
        else:
            reasoning.append(f"执行动作: {self.no_action}" if self.no_action else "")
            if self.no_node:
                return self.no_node.evaluate(context)
            else:
                return DecisionOutcome(
                    result=DecisionResult.REJECT,
                    action=self.no_action,
                    confidence=self.weight,
                    reasoning=reasoning,
                    conditions=[],
                    warnings=[],
                    next_steps=[self.no_action] if self.no_action else []
                )


@dataclass
class DecisionTreeConfig:
    """决策树配置"""
    threat_threshold: float = 50.0
    damage_threshold: float = 10000.0
    benefit_threshold: float = 50000.0
    risk_threshold: float = 50.0
    auto_approve_enabled: bool = False
    legal_review_required: bool = True
    management_approval_levels: Dict[str, str] = field(default_factory=dict)


class CounterattackDecisionTree:
    """反击决策树"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化反击决策树

        Args:
            config: 配置字典
        """
        self.config = config or {}
        tree_config = self.config.get('tree_config', {})
        self.tree_config = DecisionTreeConfig(
            threat_threshold=tree_config.get('threat_threshold', 50.0),
            damage_threshold=tree_config.get('damage_threshold', 10000.0),
            benefit_threshold=tree_config.get('benefit_threshold', 50000.0),
            risk_threshold=tree_config.get('risk_threshold', 50.0),
            auto_approve_enabled=tree_config.get('auto_approve_enabled', False),
            legal_review_required=tree_config.get('legal_review_required', True),
        )
        self.decision_tree = self._build_decision_tree()
        self.decision_history = []

    def make_decision(self, context: Dict) -> DecisionOutcome:
        """
        做出决策

        Args:
            context: 决策上下文，包含：
                - threat_level: 威胁等级
                - damage_assessment: 损失评估
                - benefit_analysis: 收益分析
                - risk_analysis: 风险分析
                - legal_context: 法律背景
                - requester: 请求者信息
                - timestamp: 时间戳

        Returns:
            决策结果
        """
        # 添加时间戳
        if 'timestamp' not in context:
            context['timestamp'] = datetime.now().isoformat()

        # 执行决策树
        outcome = self.decision_tree.evaluate(context)

        # 添加元数据
        outcome.reasoning.append(f"决策时间: {context['timestamp']}")

        # 更新历史
        self._update_history(outcome, context)

        return outcome

    def _build_decision_tree(self) -> ConditionNode:
        """构建决策树"""

        # 叶子节点：批准
        approve_node = ConditionNode(
            node_id="approve",
            question="是否批准反击",
            condition_func=lambda ctx: True,
            yes_action="批准反击行动",
            weight=1.0
        )

        # 叶子节点：拒绝
        reject_node = ConditionNode(
            node_id="reject",
            question="是否拒绝反击",
            condition_func=lambda ctx: False,
            no_action="拒绝反击行动",
            weight=1.0
        )

        # 叶子节点：升级
        escalate_node = ConditionNode(
            node_id="escalate",
            question="是否升级决策",
            condition_func=lambda ctx: True,
            yes_action="升级至管理层决策",
            weight=1.0
        )

        # 叶子节点：需要审核
        review_node = ConditionNode(
            node_id="require_review",
            question="是否需要人工审核",
            condition_func=lambda ctx: True,
            yes_action="需要人工审核",
            weight=1.0
        )

        # N1: 是否有明确授权
        node_n1 = ConditionNode(
            node_id="n1",
            question="是否有明确的法律和运营授权",
            condition_func=lambda ctx: ctx.get('has_authorization', False),
            yes_action="继续评估",
            no_action="需要授权",
            weight=1.5
        )

        # N1的YES分支：继续评估
        node_n2 = ConditionNode(
            node_id="n2",
            question="威胁等级是否高于阈值",
            condition_func=lambda ctx: ctx.get('threat_level', 0) >= self.tree_config.threat_threshold,
            yes_action="威胁等级足够",
            no_action="威胁等级不足",
            weight=1.2
        )

        # N2的NO分支：拒绝
        node_n2.no_node = reject_node

        # N2的YES分支：继续
        node_n3 = ConditionNode(
            node_id="n3",
            question="潜在损失是否大于阈值",
            condition_func=lambda ctx: ctx.get('potential_damage', 0) >= self.tree_config.damage_threshold,
            yes_action="损失可接受",
            no_action="损失太小",
            weight=1.0
        )

        # N3的NO分支：拒绝
        node_n3.no_node = reject_node

        # N3的YES分支：继续
        node_n4 = ConditionNode(
            node_id="n4",
            question="收益是否大于风险",
            condition_func=lambda ctx: ctx.get('benefit_risk_ratio', 0) >= 1.0,
            yes_action="收益风险比可接受",
            no_action="风险大于收益",
            weight=1.3
        )

        # N4的NO分支：拒绝
        node_n4.no_node = reject_node

        # N4的YES分支：法律检查
        node_n5 = ConditionNode(
            node_id="n5",
            question="法律风险是否可接受",
            condition_func=lambda ctx: ctx.get('legal_risk_level', 'high') != 'critical',
            yes_action="法律风险可接受",
            no_action="法律风险过高",
            weight=1.5
        )

        # N5的NO分支：升级
        node_n5.no_node = escalate_node

        # N5的YES分支：自动批准检查
        node_n6 = ConditionNode(
            node_id="n6",
            question="是否启用自动批准",
            condition_func=lambda ctx: self.tree_config.auto_approve_enabled,
            yes_action="自动批准",
            no_action="需要审核",
            weight=1.0
        )

        # N6的YES分支：批准
        node_n6.yes_node = approve_node

        # N6的NO分支：风险等级检查
        node_n7 = ConditionNode(
            node_id="n7",
            question="风险等级是否低于阈值",
            condition_func=lambda ctx: ctx.get('overall_risk_score', 100) < self.tree_config.risk_threshold,
            yes_action="风险可接受",
            no_action="风险过高",
            weight=1.2
        )

        # N7的NO分支：升级
        node_n7.no_node = escalate_node

        # N7的YES分支：人工审核检查
        node_n8 = ConditionNode(
            node_id="n8",
            question="是否需要人工审核",
            condition_func=lambda ctx: ctx.get('requires_manual_review', False),
            yes_action="需要人工审核",
            no_action="快速批准",
            weight=1.0
        )

        # N8的YES分支：审核节点
        node_n8.yes_node = review_node

        # N8的NO分支：批准
        node_n8.no_node = approve_node

        # 连接节点
        node_n7.yes_node = node_n8
        node_n6.no_node = node_n7
        node_n5.yes_node = node_n6
        node_n4.yes_node = node_n5
        node_n3.yes_node = node_n4
        node_n2.yes_node = node_n3
        node_n1.yes_node = node_n2
        node_n1.no_node = escalate_node

        return node_n1

    def _update_history(self, outcome: DecisionOutcome, context: Dict):
        """更新历史记录"""
        self.decision_history.append({
            'outcome': {
                'result': outcome.result.value,
                'action': outcome.action,
                'confidence': outcome.confidence,
                'reasoning': outcome.reasoning,
            },
            'context': {
                'threat_level': context.get('threat_level'),
                'potential_damage': context.get('potential_damage'),
                'has_authorization': context.get('has_authorization'),
            },
            'timestamp': context.get('timestamp', datetime.now().isoformat())
        })

        if len(self.decision_history) > 1000:
            self.decision_history = self.decision_history[-800:]

    def get_statistics(self) -> Dict:
        """获取决策统计"""
        if not self.decision_history:
            return {}

        results = {}
        for record in self.decision_history:
            result = record['outcome']['result']
            results[result] = results.get(result, 0) + 1

        return {
            'total_decisions': len(self.decision_history),
            'by_result': results,
            'approval_rate': results.get('approve', 0) / len(self.decision_history)
        }

    def export_tree(self) -> Dict:
        """导出决策树结构"""
        return self._node_to_dict(self.decision_tree)

    def _node_to_dict(self, node: ConditionNode) -> Dict:
        """节点转字典"""
        return {
            'node_id': node.node_id,
            'question': node.question,
            'yes_action': node.yes_action,
            'no_action': node.no_action,
            'weight': node.weight,
        }


# 独立运行测试
if __name__ == "__main__":
    # 创建决策树
    tree = CounterattackDecisionTree({
        'tree_config': {
            'threat_threshold': 50.0,
            'damage_threshold': 10000.0,
            'benefit_threshold': 50000.0,
            'risk_threshold': 50.0,
            'auto_approve_enabled': False,
            'legal_review_required': True,
        }
    })

    # 测试场景1：符合条件的反击
    context1 = {
        'has_authorization': True,
        'threat_level': 75.0,
        'potential_damage': 500000,
        'benefit_risk_ratio': 2.5,
        'legal_risk_level': 'medium',
        'overall_risk_score': 35.0,
        'requires_manual_review': False,
    }

    outcome1 = tree.make_decision(context1)
    print("场景1 - 符合条件的反击:")
    print(f"决策: {outcome1.result.value}")
    print(f"动作: {outcome1.action}")
    print(f"置信度: {outcome1.confidence:.2f}")
    print(f"推理过程:")
    for r in outcome1.reasoning:
        print(f"  - {r}")
    print()

    # 测试场景2：需要升级的反击
    context2 = {
        'has_authorization': True,
        'threat_level': 80.0,
        'potential_damage': 1000000,
        'benefit_risk_ratio': 1.5,
        'legal_risk_level': 'critical',
        'overall_risk_score': 60.0,
        'requires_manual_review': True,
    }

    outcome2 = tree.make_decision(context2)
    print("场景2 - 法律风险过高:")
    print(f"决策: {outcome2.result.value}")
    print(f"动作: {outcome2.action}")
    print(f"推理过程:")
    for r in outcome2.reasoning:
        print(f"  - {r}")
    print()

    # 测试场景3：无授权
    context3 = {
        'has_authorization': False,
        'threat_level': 90.0,
        'potential_damage': 2000000,
    }

    outcome3 = tree.make_decision(context3)
    print("场景3 - 无授权:")
    print(f"决策: {outcome3.result.value}")
    print(f"动作: {outcome3.action}")
    print()

    print("决策统计:")
    print(json.dumps(tree.get_statistics(), indent=2))
