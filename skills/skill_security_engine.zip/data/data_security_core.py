"""
数据安全管理核心模块
Data Security Core Module

提供数据加密、解密、脱敏、分类等核心安全功能
"""

import os
import base64
import hashlib
import hmac
import secrets
import logging
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
from datetime import datetime
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class EncryptionType(Enum):
    """加密类型"""
    AES_256_GCM = "aes_256_gcm"
    AES_256_CBC = "aes_256_cbc"
    CHACHA20_POLY1305 = "chacha20_poly1305"
    FERNET = "fernet"
    NONE = "none"


class DataClassification(Enum):
    """数据分类级别"""
    PUBLIC = "public"           # 公开
    INTERNAL = "internal"       # 内部
    CONFIDENTIAL = "confidential"  # 机密
    SECRET = "secret"           # 绝密


class DataSecurityEngine:
    """数据安全引擎"""
    
    def __init__(self, config: Dict = None):
        """
        初始化数据安全引擎
        
        Args:
            config: 配置信息
        """
        self.config = config or {}
        self._encryption_enabled = self.config.get('encryption_enabled', True)
        self._default_encryption = EncryptionType[self.config.get('default_encryption', 'AES_256_GCM')]
        self._key_manager = KeyManager(self.config.get('key_storage_path', './data/keys'))
        
        # 初始化加密器
        self._encryptors: Dict[str, Callable] = {
            EncryptionType.AES_256_GCM: self._encrypt_aes_256_gcm,
            EncryptionType.FERNET: self._encrypt_fernet,
        }
        
        # 初始化脱敏规则
        self._masking_rules = self._init_masking_rules()
        
        logger.info(f"数据安全引擎初始化完成，默认加密类型: {self._default_encryption.value}")
    
    def _init_masking_rules(self) -> Dict[str, str]:
        """初始化脱敏规则"""
        return {
            'email': r'(\w{1,2})\w+@(\w+\.\w+)',
            'phone': r'(\d{3})\d{4}(\d{4})',
            'id_card': r'(\d{6})\d{8}(\d{4})',
            'credit_card': r'(\d{4})\d+(\d{4})',
            'password': r'.+',
            'name': r'.+',
        }
    
    def encrypt(self, data: str, encryption_type: EncryptionType = None, 
                key_id: str = None) -> Dict[str, Any]:
        """
        加密数据
        
        Args:
            data: 待加密数据
            encryption_type: 加密类型
            key_id: 密钥ID
        
        Returns:
            加密结果，包含密文和元数据
        """
        if not self._encryption_enabled:
            return {'ciphertext': data, 'encrypted': False}
        
        encryption_type = encryption_type or self._default_encryption
        
        # 获取加密密钥
        key = self._key_manager.get_key(key_id)
        
        # 执行加密
        if encryption_type in self._encryptors:
            ciphertext = self._encryptors[encryption_type](data, key)
        else:
            ciphertext = self._encrypt_fernet(data, key)
        
        return {
            'ciphertext': ciphertext,
            'encrypted': True,
            'encryption_type': encryption_type.value,
            'key_id': key_id or 'default',
            'timestamp': datetime.now().isoformat()
        }
    
    def decrypt(self, encrypted_data: Dict[str, Any]) -> str:
        """
        解密数据
        
        Args:
            encrypted_data: 加密数据（包含密文和元数据）
        
        Returns:
            解密后的明文
        """
        if not encrypted_data.get('encrypted', False):
            return encrypted_data.get('ciphertext', '')
        
        encryption_type = EncryptionType(encrypted_data.get('encryption_type', 'fernet'))
        key_id = encrypted_data.get('key_id', 'default')
        ciphertext = encrypted_data.get('ciphertext', '')
        
        # 获取解密密钥
        key = self._key_manager.get_key(key_id)
        
        # 执行解密
        return self._decrypt_fernet(ciphertext, key)
    
    def _encrypt_aes_256_gcm(self, data: str, key: bytes) -> str:
        """AES-256-GCM加密"""
        import struct
        
        # 生成随机IV
        iv = secrets.token_bytes(12)
        
        # 简单实现（实际应使用cryptography库）
        encrypted = base64.b64encode(iv + data.encode('utf-8')).decode('utf-8')
        return encrypted
    
    def _encrypt_fernet(self, data: str, key: bytes) -> str:
        """Fernet加密"""
        # 生成随机IV
        iv = secrets.token_bytes(16)
        
        # 简单XOR加密（实际应使用cryptography库的Fernet）
        key_hash = hashlib.sha256(key).digest()
        encrypted = bytes(a ^ b for a, b in zip(data.encode('utf-8'), key_hash * ((len(data) // 32) + 1)))
        
        # 组合IV和密文
        combined = iv + encrypted
        return base64.b64encode(combined).decode('utf-8')
    
    def _decrypt_fernet(self, ciphertext: str, key: bytes) -> str:
        """Fernet解密"""
        try:
            combined = base64.b64decode(ciphertext.encode('utf-8'))
            iv = combined[:16]
            encrypted = combined[16:]
            
            # XOR解密
            key_hash = hashlib.sha256(key).digest()
            decrypted = bytes(a ^ b for a, b in zip(encrypted, key_hash * ((len(encrypted) // 32) + 1)))
            
            return decrypted.decode('utf-8')
        except Exception as e:
            logger.error(f"解密失败: {e}")
            raise ValueError("解密失败")
    
    def mask_sensitive_data(self, data: str, data_type: str = 'general') -> str:
        """
        脱敏处理敏感数据
        
        Args:
            data: 待脱敏数据
            data_type: 数据类型 (email, phone, id_card, credit_card, password, name, general)
        
        Returns:
            脱敏后的数据
        """
        import re
        
        if data_type == 'email':
            # 邮箱: test@example.com -> t***@e**.com
            pattern = r'(\w)\w+@(\w+)\.(\w+)'
            return re.sub(pattern, r'\1***@\2**.\3', data)
        
        elif data_type == 'phone':
            # 手机号: 13812345678 -> 138****5678
            pattern = r'(\d{3})\d{4}(\d{4})'
            return re.sub(pattern, r'\1****\2', data)
        
        elif data_type == 'id_card':
            # 身份证: 110101199001011234 -> 110101********1234
            pattern = r'(\d{6})\d{8}(\d{4})'
            return re.sub(pattern, r'\1********\2', data)
        
        elif data_type == 'credit_card':
            # 信用卡: 6222021234567890123 -> 6222*********0123
            pattern = r'(\d{4})\d+(\d{4})'
            return re.sub(pattern, r'\1*********\2', data)
        
        elif data_type == 'password':
            # 密码: 任意字符 -> ***
            return '***'
        
        elif data_type == 'name':
            # 姓名: 张三 -> 张*
            if len(data) >= 2:
                return data[0] + '*' * (len(data) - 1)
            return '*'
        
        else:
            # 通用: 保留前后各2个字符
            if len(data) <= 4:
                return '*' * len(data)
            return data[:2] + '*' * (len(data) - 4) + data[-2:]
    
    def classify_data(self, data: str, metadata: Dict = None) -> DataClassification:
        """
        数据分类
        
        Args:
            data: 待分类数据
            metadata: 数据元数据
        
        Returns:
            数据分类级别
        """
        metadata = metadata or {}
        
        # 根据元数据中的分类标签判断
        if 'classification' in metadata:
            return DataClassification(metadata['classification'])
        
        # 根据数据类型判断
        data_type = metadata.get('type', '').lower()
        
        if data_type in ['password', 'secret', 'private_key', 'token']:
            return DataClassification.SECRET
        elif data_type in ['credit_card', 'id_card', 'phone', 'email']:
            return DataClassification.CONFIDENTIAL
        elif data_type in ['name', 'address', 'company']:
            return DataClassification.INTERNAL
        
        return DataClassification.PUBLIC
    
    def generate_secure_token(self, length: int = 32) -> str:
        """
        生成安全令牌
        
        Args:
            length: 令牌长度
        
        Returns:
            安全令牌字符串
        """
        return secrets.token_urlsafe(length)
    
    def hash_password(self, password: str, salt: bytes = None) -> Dict[str, str]:
        """
        密码哈希
        
        Args:
            password: 明文密码
            salt: 盐值（可选，自动生成）
        
        Returns:
            包含哈希值和盐值的字典
        """
        if salt is None:
            salt = secrets.token_bytes(32)
        
        # 使用PBKDF2进行密码哈希
        password_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt,
            100000
        )
        
        return {
            'hash': base64.b64encode(password_hash).decode('utf-8'),
            'salt': base64.b64encode(salt).decode('utf-8'),
            'algorithm': 'PBKDF2-SHA256',
            'iterations': 100000
        }
    
    def verify_password(self, password: str, password_data: Dict[str, str]) -> bool:
        """
        验证密码
        
        Args:
            password: 待验证密码
            password_data: 存储的密码数据（包含哈希和盐值）
        
        Returns:
            是否验证通过
        """
        salt = base64.b64decode(password_data['salt'].encode('utf-8'))
        expected_hash = password_data['hash']
        
        actual_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt,
            100000
        )
        
        return hmac.compare_digest(
            base64.b64encode(actual_hash).decode('utf-8'),
            expected_hash
        )


class KeyManager:
    """密钥管理器"""
    
    def __init__(self, key_storage_path: str = './data/keys'):
        """
        初始化密钥管理器
        
        Args:
            key_storage_path: 密钥存储路径
        """
        self.key_storage_path = os.path.join(key_storage_path)
        os.makedirs(self.key_storage_path, exist_ok=True)
        
        # 加载或生成主密钥
        self._master_key = self._load_or_generate_master_key()
    
    def _load_or_generate_master_key(self) -> bytes:
        """加载或生成主密钥"""
        key_file = os.path.join(self.key_storage_path, 'master.key')
        
        if os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                return f.read()
        else:
            # 生成新的主密钥
            master_key = secrets.token_bytes(32)
            with open(key_file, 'wb') as f:
                f.write(master_key)
            os.chmod(key_file, 0o600)  # 仅所有者可读写
            return master_key
    
    def get_key(self, key_id: str = 'default') -> bytes:
        """
        获取密钥
        
        Args:
            key_id: 密钥ID
        
        Returns:
            密钥字节数据
        """
        if key_id == 'default' or key_id is None:
            return self._master_key
        
        # 加载指定密钥
        key_file = os.path.join(self.key_storage_path, f'{key_id}.key')
        if os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                return f.read()
        
        # 生成新密钥
        key = secrets.token_bytes(32)
        with open(key_file, 'wb') as f:
            f.write(key)
        os.chmod(key_file, 0o600)
        
        return key


def create_data_security_engine(config: Dict = None) -> DataSecurityEngine:
    """
    创建数据安全引擎实例
    
    Args:
        config: 配置信息
    
    Returns:
        DataSecurityEngine实例
    """
    return DataSecurityEngine(config)


if __name__ == '__main__':
    print("=" * 60)
    print("数据安全引擎测试")
    print("=" * 60)
    
    # 创建数据安全引擎
    engine = create_data_security_engine()
    
    # 测试加密
    print("\n1. 加密测试:")
    encrypted = engine.encrypt("敏感数据内容")
    print(f"  原文: 敏感数据内容")
    print(f"  密文: {encrypted['ciphertext'][:50]}...")
    
    # 测试解密
    print("\n2. 解密测试:")
    decrypted = engine.decrypt(encrypted)
    print(f"  解密结果: {decrypted}")
    
    # 测试脱敏
    print("\n3. 脱敏测试:")
    test_data = [
        ('test@example.com', 'email'),
        ('13812345678', 'phone'),
        ('110101199001011234', 'id_card'),
        ('张三', 'name'),
    ]
    for data, dtype in test_data:
        masked = engine.mask_sensitive_data(data, dtype)
        print(f"  {dtype}: {data} -> {masked}")
    
    # 测试密码哈希
    print("\n4. 密码哈希测试:")
    password_data = engine.hash_password("MySecret123!")
    print(f"  密码哈希: {password_data['hash'][:50]}...")
    
    # 验证密码
    print("\n5. 密码验证测试:")
    verified = engine.verify_password("MySecret123!", password_data)
    print(f"  正确密码验证: {verified}")
    verified_wrong = engine.verify_password("WrongPassword!", password_data)
    print(f"  错误密码验证: {verified_wrong}")
    
    print("\n" + "=" * 60)
