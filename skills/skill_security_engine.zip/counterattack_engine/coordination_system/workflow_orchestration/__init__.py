"""
工作流编排模块
Workflow Orchestration Module

提供反击工作流的编排和管理功能
"""

from .counterattack_playbook_manager import CounterattackPlaybookManager

__version__ = "v3.0.0"
__all__ = [
    'CounterattackPlaybookManager'
]
