# ========== 反击与联动系统 v3.0.3 ==========
# 文件: scripts/offense_defense.py
# 版本: 3.0.3
# 更新: 新增VirusTotal/PhishTank威胁情报API集成

"""
自动化反击与联动系统
支持: 攻击溯源、威胁情报、蜜罐、SOAR编排
"""

import os
import json
import hashlib
import logging
import asyncio
import aiohttp
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum

logger = logging.getLogger(__name__)


# ========== 枚举定义 ==========

class AttackType(Enum):
    """攻击类型"""
    PHISHING = "phishing"
    MALWARE = "malware"
    BRUTE_FORCE = "brute_force"
    DDOS = "ddos"
    DATA_BREACH = "data_breach"
    BEC = "bec_fraud"
    RANSOMWARE = "ransomware"
    UNKNOWN = "unknown"


class RetaliationIntensity(Enum):
    """反击强度"""
    PASSIVE = "passive"     # 仅记录
    MODERATE = "moderate"   # 阻止
    AGGRESSIVE = "aggressive"  # 报告


# ========== 数据结构 ==========

@dataclass
class AttackEvidence:
    """攻击证据"""
    attack_id: str
    attack_type: AttackType
    source_ip: str = ""
    source_domain: str = ""
    target: str = ""
    evidence: List[str] = field(default_factory=list)
    confidence: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)
    malicious_urls: List[str] = field(default_factory=list)
    malware_hashes: List[str] = field(default_factory=list)


@dataclass
class RetaliationAction:
    """反击动作"""
    action_id: str
    action_type: str
    target: str
    parameters: Dict = field(default_factory=dict)
    executed_at: datetime = None
    result: str = "pending"


# ========== 实时威胁情报客户端 v3.0.3 ==========

class ThreatIntelAPIClient:
    """
    实时威胁情报API客户端 - v3.0.3新增
    支持: VirusTotal, PhishTank, Google Safe Browsing
    """
    
    def __init__(self, api_keys: Dict[str, str] = None):
        self.api_keys = api_keys or {}
        self.cache = {}
        self.cache_ttl = 3600  # 1小时缓存
        
        # API配置
        self.virustotal_base = "https://www.virustotal.com/api/v3"
        self.phishtank_api = "https://checkurl.phishtank.com/checkurl/"
        
        logger.info("威胁情报API客户端初始化完成 (v3.0.3)")
    
    async def check_virustotal(self, indicator: str, indicator_type: str = "domain") -> Dict:
        """
        查询VirusTotal威胁情报
        
        Args:
            indicator: 威胁指标（域名/IP/URL/哈希）
            indicator_type: 类型 (domain/ip/url/file)
        """
        api_key = self.api_keys.get("virustotal")
        if not api_key:
            logger.warning("VirusTotal API密钥未配置")
            return {"error": "API key not configured"}
        
        cache_key = f"vt_{indicator_type}_{indicator}"
        if cache_key in self.cache:
            cached = self.cache[cache_key]
            if (datetime.now() - cached["timestamp"]).seconds < self.cache_ttl:
                return cached["data"]
        
        headers = {"x-apikey": api_key}
        endpoint = f"{self.virustotal_base}/{indicator_type}s/{indicator}"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(endpoint, headers=headers, timeout=10) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        result = self._parse_virustotal_response(data, indicator_type)
                        self.cache[cache_key] = {"data": result, "timestamp": datetime.now()}
                        return result
                    elif resp.status == 404:
                        return {"found": False, "malicious": False}
                    else:
                        return {"error": f"API error: {resp.status}"}
        except Exception as e:
            logger.error(f"VirusTotal查询失败: {e}")
            return {"error": str(e)}
    
    def _parse_virustotal_response(self, data: Dict, indicator_type: str) -> Dict:
        """解析VirusTotal响应"""
        result = {
            "found": True,
            "malicious": False,
            "suspicious": False,
            "detection_count": 0,
            "total_engines": 0,
            "threat_labels": [],
            "last_analysis_date": None
        }
        
        if "data" in data:
            attributes = data["data"].get("attributes", {})
            last_analysis = attributes.get("last_analysis_results", {})
            
            result["total_engines"] = len(last_analysis)
            result["detection_count"] = sum(
                1 for r in last_analysis.values() 
                if r.get("category") in ["malicious", "suspicious"]
            )
            result["malicious"] = result["detection_count"] > 5
            result["suspicious"] = 0 < result["detection_count"] <= 5
            result["last_analysis_date"] = attributes.get("last_analysis_date")
            
            # 提取威胁标签
            for r in last_analysis.values():
                if r.get("result") and r.get("category") in ["malicious", "suspicious"]:
                    if r["result"] not in result["threat_labels"]:
                        result["threat_labels"].append(r["result"])
        
        return result
    
    async def check_phishtank(self, url: str) -> Dict:
        """
        查询PhishTank钓鱼URL数据库
        """
        api_key = self.api_keys.get("phishtank")
        if not api_key:
            logger.warning("PhishTank API密钥未配置")
            return {"error": "API key not configured"}
        
        cache_key = f"pt_url_{hashlib.md5(url.encode()).hexdigest()}"
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        try:
            async with aiohttp.ClientSession() as session:
                payload = {"url": url, "format": "json"}
                headers = {"Content-Type": "application/x-www-form-urlencoded"}
                async with session.post(
                    self.phishtank_api, 
                    data=payload, 
                    headers=headers,
                    timeout=10
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        result = {
                            "found": True,
                            "is_phishing": data.get("results", {}).get("phish_detail_dialog", {}).get("phish_yes", 0) > 5,
                            "confidence": data.get("results", {}).get("phish_detail_dialog", {}).get("phish_yes", 0),
                            "verified": data.get("results", {}).get("verified", False)
                        }
                        self.cache[cache_key] = result
                        return result
                    return {"found": False}
        except Exception as e:
            logger.error(f"PhishTank查询失败: {e}")
            return {"error": str(e)}
    
    async def check_google_safe_browsing(self, url: str) -> Dict:
        """
        查询Google Safe Browsing
        """
        api_key = self.api_keys.get("google_safe_browsing")
        if not api_key:
            return {"error": "API key not configured"}
        
        endpoint = f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={api_key}"
        
        payload = {
            "client": {"clientId": "email-gatekeeper", "clientVersion": "1.0"},
            "threatInfo": {
                "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE"],
                "platformTypes": ["ANY_PLATFORM"],
                "threatEntryTypes": ["URL"],
                "threatEntries": [{"url": url}]
            }
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(endpoint, json=payload, timeout=10) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        matches = data.get("matches", [])
                        return {
                            "found": len(matches) > 0,
                            "threats": [m.get("threatType") for m in matches],
                            "is_malicious": len(matches) > 0
                        }
                    return {"found": False}
        except Exception as e:
            logger.error(f"Google Safe Browsing查询失败: {e}")
            return {"error": str(e)}
    
    async def check_ip_reputation(self, ip: str) -> Dict:
        """综合检查IP信誉"""
        result = {
            "ip": ip,
            "sources_checked": [],
            "is_malicious": False,
            "threat_types": [],
            "confidence": 0
        }
        
        # VirusTotal检查
        vt_result = await self.check_virustotal(ip, "ip")
        if "found" in vt_result and vt_result["found"]:
            result["sources_checked"].append("virustotal")
            if vt_result.get("malicious"):
                result["is_malicious"] = True
                result["threat_types"].extend(vt_result.get("threat_labels", []))
                result["confidence"] = max(result["confidence"], 70)
        
        return result
    
    async def check_domain_reputation(self, domain: str) -> Dict:
        """综合检查域名信誉"""
        result = {
            "domain": domain,
            "sources_checked": [],
            "is_malicious": False,
            "threat_types": [],
            "confidence": 0
        }
        
        # VirusTotal检查
        vt_result = await self.check_virustotal(domain, "domain")
        if "found" in vt_result:
            result["sources_checked"].append("virustotal")
            if vt_result.get("malicious"):
                result["is_malicious"] = True
                result["threat_types"].extend(vt_result.get("threat_labels", []))
                result["confidence"] = max(result["confidence"], 70)
            elif vt_result.get("suspicious"):
                result["threat_types"].extend(vt_result.get("threat_labels", []))
                result["confidence"] = max(result["confidence"], 40)
        
        return result
    
    async def check_url_safety(self, url: str) -> Dict:
        """综合检查URL安全性"""
        result = {
            "url": url,
            "sources_checked": [],
            "is_malicious": False,
            "is_phishing": False,
            "threat_types": [],
            "confidence": 0
        }
        
        # VirusTotal检查
        vt_result = await self.check_virustotal(url, "url")
        if "found" in vt_result:
            result["sources_checked"].append("virustotal")
            if vt_result.get("malicious"):
                result["is_malicious"] = True
                result["confidence"] = max(result["confidence"], 70)
        
        # PhishTank检查
        pt_result = await self.check_phishtank(url)
        if "found" in pt_result:
            result["sources_checked"].append("phishtank")
            if pt_result.get("is_phishing"):
                result["is_phishing"] = True
                result["is_malicious"] = True
                result["confidence"] = max(result["confidence"], 80)
        
        # Google Safe Browsing检查
        gsb_result = await self.check_google_safe_browsing(url)
        if "found" in gsb_result:
            result["sources_checked"].append("google_safe_browsing")
            if gsb_result.get("is_malicious"):
                result["is_malicious"] = True
                result["threat_types"].extend(gsb_result.get("threats", []))
                result["confidence"] = max(result["confidence"], 60)
        
        return result


# ========== 威胁情报管理器 ==========

class ThreatIntelManager:
    """威胁情报管理器"""
    
    def __init__(self, api_keys: Dict[str, str] = None):
        self.api_keys = api_keys or {}
        self.ioc_database: Dict[str, List] = {
            "malicious_ips": [],
            "malicious_domains": [],
            "malware_hashes": [],
            "phishing_urls": []
        }
        self.threat_feeds = []
        self.blocklist = set()
        self.api_client = ThreatIntelAPIClient(api_keys)
        logger.info("威胁情报管理器初始化完成 (v3.0.3)")
    
    async def check_ip(self, ip: str) -> Dict:
        """检查IP信誉"""
        # 本地黑名单检查
        result = {
            "ip": ip,
            "is_malicious": False,
            "threat_types": [],
            "confidence": 0,
            "source": "local"
        }
        
        if any(ioc["value"] == ip for ioc in self.ioc_database["malicious_ips"]):
            result["is_malicious"] = True
            result["threat_types"].append("blacklisted")
            result["confidence"] = 100
        else:
            # 尝试API查询
            api_result = await self.api_client.check_ip_reputation(ip)
            if api_result.get("is_malicious"):
                result["is_malicious"] = True
                result["threat_types"].extend(api_result.get("threat_types", []))
                result["confidence"] = api_result.get("confidence", 50)
                result["source"] = "api"
        
        return result
    
    async def check_domain(self, domain: str) -> Dict:
        """检查域名信誉"""
        result = {
            "domain": domain,
            "is_malicious": False,
            "threat_types": []
        }
        
        if any(ioc["value"] == domain for ioc in self.ioc_database["malicious_domains"]):
            result["is_malicious"] = True
            result["threat_types"].append("blacklisted")
        else:
            api_result = await self.api_client.check_domain_reputation(domain)
            if api_result.get("is_malicious"):
                result["is_malicious"] = True
                result["threat_types"].extend(api_result.get("threat_types", []))
        
        return result
    
    async def check_url(self, url: str) -> Dict:
        """检查URL安全性 - v3.0.3新增"""
        return await self.api_client.check_url_safety(url)
    
    def add_ioc(self, ioc_type: str, value: str, metadata: Dict = None):
        """添加IOC"""
        if ioc_type in self.ioc_database:
            entry = {
                "value": value,
                "added_at": datetime.now().isoformat(),
                "metadata": metadata or {}
            }
            self.ioc_database[ioc_type].append(entry)
            logger.info(f"添加IOC: {ioc_type} = {value}")
    
    def add_to_blocklist(self, value: str):
        """添加到阻止列表"""
        self.blocklist.add(value)
        logger.info(f"添加到阻止列表: {value}")
    
    def get_blocklist(self) -> List[str]:
        """获取阻止列表"""
        return list(self.blocklist)


# ========== 攻击溯源器 ==========

class AttackTracer:
    """攻击溯源器"""
    
    def __init__(self, threat_intel: ThreatIntelManager):
        self.threat_intel = threat_intel
        logger.info("攻击溯源器初始化完成")
    
    async def trace_attack(self, evidence: AttackEvidence, depth: int = 2) -> AttackEvidence:
        """溯源攻击"""
        logger.info(f"开始溯源: {evidence.attack_id}, 深度: {depth}")
        
        if evidence.source_ip:
            await self._analyze_ip(evidence)
        
        if evidence.source_domain:
            await self._analyze_domain(evidence)
        
        await self._correlate_evidence(evidence)
        evidence.confidence = self._calculate_confidence(evidence)
        
        logger.info(f"溯源完成: {evidence.attack_id}, 置信度: {evidence.confidence}")
        return evidence
    
    async def _analyze_ip(self, evidence: AttackEvidence):
        """分析源IP"""
        ip_info = await self.threat_intel.check_ip(evidence.source_ip)
        if ip_info["is_malicious"]:
            evidence.evidence.append(f"IP在黑名单中: {evidence.source_ip}")
    
    async def _analyze_domain(self, evidence: AttackEvidence):
        """分析域名"""
        domain_info = await self.threat_intel.check_domain(evidence.source_domain)
        if domain_info["is_malicious"]:
            evidence.evidence.append(f"可疑域名: {evidence.source_domain}")
    
    async def _correlate_evidence(self, evidence: AttackEvidence):
        """关联分析"""
        pass
    
    def _calculate_confidence(self, evidence: AttackEvidence) -> float:
        """计算置信度"""
        confidence = 0.0
        confidence += min(0.3, len(evidence.evidence) * 0.05)
        if evidence.malicious_urls:
            confidence += 0.3
        if evidence.malware_hashes:
            confidence += 0.3
        return min(1.0, confidence)


# ========== 蜜罐管理器 ==========

class HoneyPotManager:
    """蜜罐管理器"""
    
    def __init__(self):
        self.honey_pots = {}
        self.captured_attacks = []
        logger.info("蜜罐管理器初始化完成")
    
    def create_honey_port(self, port: int, service_type: str = "ftp") -> bool:
        """创建蜜罐端口"""
        honey = {
            "port": port,
            "service_type": service_type,
            "created_at": datetime.now(),
            "interactions": [],
            "is_active": True
        }
        self.honey_pots[port] = honey
        logger.info(f"创建蜜罐: 端口={port}, 类型={service_type}")
        return True
    
    def log_interaction(self, port: int, source_ip: str, data: str) -> tuple:
        """记录蜜罐交互"""
        if port in self.honey_pots:
            interaction = {
                "timestamp": datetime.now(),
                "source_ip": source_ip,
                "data_preview": data[:100] if data else "",
                "data_length": len(data) if data else 0
            }
            self.honey_pots[port]["interactions"].append(interaction)
            self.captured_attacks.append(interaction)
            
            if self._is_suspicious_interaction(interaction):
                return True, "Suspicious interaction detected"
        return False, ""
    
    def _is_suspicious_interaction(self, interaction: Dict) -> bool:
        """检测可疑交互"""
        suspicious_patterns = ["password", "admin", "root", "login", "../", "etc/passwd", "eval", "exec"]
        data = interaction.get("data_preview", "").lower()
        return any(pattern.lower() in data for pattern in suspicious_patterns)
    
    def get_captured_attacks(self) -> List[Dict]:
        """获取捕获的攻击"""
        return self.captured_attacks


# ========== 反击引擎 ==========

class RetaliationEngine:
    """反击引擎 ⚠️ 默认禁用"""
    
    def __init__(self, threat_intel: ThreatIntelManager, intensity: str = "passive"):
        self.threat_intel = threat_intel
        self.intensity = intensity
        self.action_history = []
        self.enabled = False
        logger.info(f"反击引擎初始化: 强度={intensity}, 启用={self.enabled}")
    
    def set_intensity(self, intensity: str):
        """设置反击强度"""
        valid_intensities = ["passive", "moderate", "aggressive"]
        if intensity in valid_intensities:
            self.intensity = intensity
    
    def enable(self):
        """启用反击⚠️ 必须明确授权"""
        logger.warning("⚠️ 反击系统已启用！")
        self.enabled = True
    
    def disable(self):
        """禁用反击"""
        logger.info("反击系统已禁用")
        self.enabled = False
    
    async def execute_retaliation(self, evidence: AttackEvidence) -> List[RetaliationAction]:
        """执行反击"""
        if not self.enabled:
            logger.warning("反击系统未启用，跳过反击")
            return []
        
        logger.warning(f"⚠️ 开始执行反击: {evidence.attack_id}")
        actions = []
        
        if self.intensity == "passive":
            action = RetaliationAction(
                action_id=hashlib.md5(b"passive").hexdigest()[:8],
                action_type="log",
                target=evidence.source_ip or evidence.source_domain,
                parameters={"evidence": evidence.evidence}
            )
            actions.append(action)
        
        elif self.intensity == "moderate":
            if evidence.source_ip:
                action = RetaliationAction(
                    action_id=hashlib.md5(b"block_ip").hexdigest()[:8],
                    action_type="block_ip",
                    target=evidence.source_ip
                )
                actions.append(action)
                self.threat_intel.add_ioc("malicious_ips", evidence.source_ip)
        
        elif self.intensity == "aggressive":
            if evidence.source_ip:
                action = RetaliationAction(
                    action_id=hashlib.md5(b"aggressive").hexdigest()[:8],
                    action_type="block_ip",
                    target=evidence.source_ip,
                    parameters={"report": True}
                )
                actions.append(action)
        
        for action in actions:
            await self._execute_action(action)
            self.action_history.append(action)
        
        return actions
    
    async def _execute_action(self, action: RetaliationAction):
        """执行单个动作"""
        logger.info(f"执行反击动作: {action.action_type} -> {action.target}")
        await asyncio.sleep(0.1)
        action.executed_at = datetime.now()
        action.result = "executed"


# ========== SOAR编排器 ==========

class SOAROrchestrator:
    """SOAR安全编排自动化响应"""
    
    def __init__(self, threat_intel: ThreatIntelManager, retaliation_engine: RetaliationEngine):
        self.threat_intel = threat_intel
        self.retaliation = retaliation_engine
        self.playbooks = {}
        self.active_incidents = {}
        self._load_default_playbooks()
        logger.info("SOAR编排器初始化完成")
    
    def _load_default_playbooks(self):
        """加载默认剧本"""
        self.playbooks = {
            "phishing_response": {
                "name": "钓鱼邮件响应",
                "steps": [
                    {"action": "extract_ioc", "description": "提取IOC"},
                    {"action": "block_sender", "description": "阻止发件人"},
                    {"action": "notify_security_team", "description": "通知安全团队"},
                ]
            },
            "malware_response": {
                "name": "恶意软件响应",
                "steps": [
                    {"action": "quarantine_file", "description": "隔离文件"},
                    {"action": "block_execution", "description": "阻止执行"},
                ]
            },
            "brute_force_response": {
                "name": "暴力破解响应",
                "steps": [
                    {"action": "block_ip", "description": "阻止IP"},
                    {"action": "enable_mfa", "description": "启用多因素认证"}
                ]
            }
        }
    
    async def execute_playbook(self, playbook_name: str, incident_data: Dict) -> Dict:
        """执行剧本"""
        if playbook_name not in self.playbooks:
            raise ValueError(f"剧本不存在: {playbook_name}")
        
        playbook = self.playbooks[playbook_name]
        incident_id = hashlib.md5(f"{playbook_name}{datetime.now()}".encode()).hexdigest()[:16]
        
        results = {
            "incident_id": incident_id,
            "playbook": playbook_name,
            "steps_completed": [],
            "actions_taken": [],
            "status": "running"
        }
        
        self.active_incidents[incident_id] = results
        
        for step in playbook["steps"]:
            step_result = await self._execute_step(step, incident_data)
            results["steps_completed"].append(step["action"])
            results["actions_taken"].append(step_result)
        
        results["status"] = "completed"
        return results
    
    async def _execute_step(self, step: Dict, incident_data: Dict) -> Dict:
        """执行单个步骤"""
        action = step["action"]
        result = {"action": action, "status": "success"}
        
        try:
            if action == "extract_ioc":
                iocs = incident_data.get("indicators", [])
                result["data"] = {"iocs_extracted": len(iocs)}
            elif action == "block_sender":
                sender = incident_data.get("sender", "")
                if sender:
                    self.threat_intel.add_ioc("malicious_ips", sender)
                    result["data"] = {"blocked": sender}
            elif action == "block_ip":
                ip = incident_data.get("source_ip", "")
                if ip:
                    self.threat_intel.add_ioc("malicious_ips", ip)
                    self.threat_intel.add_to_blocklist(ip)
                    result["data"] = {"blocked": ip}
            elif action == "notify_security_team":
                result["data"] = {"notified": True}
            elif action == "quarantine_file":
                result["data"] = {"quarantined": incident_data.get("file_hash", "")}
        except Exception as e:
            logger.error(f"步骤执行失败: {action}, {e}")
            result["status"] = "failed"
        
        return result


# ========== 统一防御管理器 ==========

class UnifiedDefenseManager:
    """统一防御管理器"""
    
    def __init__(self, api_keys: Dict[str, str] = None):
        self.threat_intel = ThreatIntelManager(api_keys)
        self.honey_pot = HoneyPotManager()
        self.retaliation = RetaliationEngine(self.threat_intel, "passive")
        self.tracer = AttackTracer(self.threat_intel)
        self.soar = SOAROrchestrator(self.threat_intel, self.retaliation)
        self.trigger_rules = []
        
        self.status = {
            "threat_intel": "online",
            "honey_pot": "online",
            "retaliation": "disabled",
            "soar": "online"
        }
        
        logger.info("统一防御管理器初始化完成 (v3.0.3)")
    
    async def handle_security_event(self, event_type: str, event_data: Dict) -> Dict:
        """处理安全事件"""
        logger.info(f"收到安全事件: {event_type}")
        
        results = {
            "event_type": event_type,
            "processed_at": datetime.now().isoformat(),
            "actions_taken": []
        }
        
        for rule in self.trigger_rules:
            if not rule["enabled"]:
                continue
            if self._match_condition(rule["condition"], event_type, event_data):
                for action_name in rule["actions"]:
                    action_result = await self._execute_action(action_name, event_data)
                    results["actions_taken"].append(action_result)
        
        return results
    
    def _match_condition(self, condition: str, event_type: str, event_data: Dict) -> bool:
        """匹配条件"""
        if condition == "malware_detected":
            return event_type == "malware_found"
        elif condition == "phishing_detected":
            return event_type == "phishing_email"
        return False
    
    async def _execute_action(self, action_name: str, event_data: Dict) -> Dict:
        """执行动作"""
        result = {"action": action_name, "status": "success"}
        
        if action_name == "block_ip":
            ip = event_data.get("source_ip")
            if ip:
                self.threat_intel.add_ioc("malicious_ips", ip)
                self.threat_intel.add_to_blocklist(ip)
                result["data"] = f"Blocked {ip}"
        elif action_name == "notify":
            result["data"] = "Notification sent"
        
        return result
    
    def get_status(self) -> Dict:
        """获取系统状态"""
        return {
            **self.status,
            "blocklist_size": {
                "malicious_ips": len(self.threat_intel.ioc_database["malicious_ips"]),
                "malicious_domains": len(self.threat_intel.ioc_database["malicious_domains"])
            },
            "active_incidents": len(self.soar.active_incidents)
        }


# ========== 使用示例 ==========

if __name__ == "__main__":
    async def main():
        print("="*60)
        print("🛡️ 反击与联动系统 v3.0.3 测试")
        print("="*60)
        
        # 配置API密钥
        api_keys = {
            "virustotal": "your-api-key",  # 替换为实际密钥
        }
        
        manager = UnifiedDefenseManager(api_keys)
        
        # 威胁情报查询
        print("\n📡 测试威胁情报查询...")
        ip_result = await manager.threat_intel.check_ip("8.8.8.8")
        print(f"   IP 8.8.8.8: 恶意={ip_result['is_malicious']}")
        
        domain_result = await manager.threat_intel.check_domain("google.com")
        print(f"   域名 google.com: 恶意={domain_result['is_malicious']}")
        
        # 系统状态
        print("\n📊 系统状态:")
        status = manager.get_status()
        print(f"   威胁情报: {status['threat_intel']}")
        print(f"   反击系统: {status['retaliation']}")
        print(f"   阻止列表IP: {status['blocklist_size']['malicious_ips']}")
        
        print("\n✅ v3.0.3 测试完成！")
    
    asyncio.run(main())
