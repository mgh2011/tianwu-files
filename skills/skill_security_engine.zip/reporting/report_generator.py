"""
安全检测报告生成器
Security Detection Report Generator

生成专业的安全检测报告
"""

import os
import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import uuid

logger = logging.getLogger(__name__)


class ReportType(Enum):
    """报告类型"""
    DAILY = "daily"           # 日报
    WEEKLY = "weekly"          # 周报
    MONTHLY = "monthly"        # 月报
    QUARTERLY = "quarterly"    # 季报
    ANNUAL = "annual"          # 年报
    INCIDENT = "incident"      # 事件报告
    AUDIT = "audit"           # 审计报告
    COMPLIANCE = "compliance"  # 合规报告
    THREAT = "threat"         # 威胁报告
    RISK = "risk"             # 风险评估报告


class ReportFormat(Enum):
    """报告格式"""
    JSON = "json"
    HTML = "html"
    MARKDOWN = "markdown"
    PDF = "pdf"


@dataclass
class ReportSection:
    """报告章节"""
    title: str
    content: Dict
    order: int
    charts: List[Dict] = field(default_factory=list)


@dataclass
class SecurityReport:
    """安全报告"""
    report_id: str
    report_type: ReportType
    title: str
    generated_at: str
    period_start: str
    period_end: str
    summary: Dict
    sections: List[ReportSection]
    statistics: Dict
    recommendations: List[str]
    metadata: Dict


class ReportGenerator:
    """报告生成器"""
    
    def __init__(self, output_dir: str = "./reports"):
        """
        初始化报告生成器
        
        Args:
            output_dir: 报告输出目录
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # 报告存储
        self._reports: Dict[str, SecurityReport] = {}
        
        logger.info(f"报告生成器初始化完成，输出目录: {self.output_dir}")
    
    def generate_report(
        self,
        report_type: ReportType,
        period_start: datetime,
        period_end: datetime,
        data: Dict
    ) -> SecurityReport:
        """
        生成安全报告
        
        Args:
            report_type: 报告类型
            period_start: 报告周期开始时间
            period_end: 报告周期结束时间
            data: 报告数据
        
        Returns:
            安全报告对象
        """
        report_id = str(uuid.uuid4())
        
        # 生成报告标题
        title = self._generate_title(report_type, period_start, period_end)
        
        # 生成摘要
        summary = self._generate_summary(report_type, data)
        
        # 生成章节
        sections = self._generate_sections(report_type, data)
        
        # 生成统计
        statistics = self._generate_statistics(data)
        
        # 生成建议
        recommendations = self._generate_recommendations(report_type, data)
        
        # 创建报告对象
        report = SecurityReport(
            report_id=report_id,
            report_type=report_type,
            title=title,
            generated_at=datetime.now().isoformat(),
            period_start=period_start.isoformat(),
            period_end=period_end.isoformat(),
            summary=summary,
            sections=sections,
            statistics=statistics,
            recommendations=recommendations,
            metadata=data.get('metadata', {})
        )
        
        # 存储报告
        self._reports[report_id] = report
        
        logger.info(f"报告生成完成: {report_id} - {title}")
        return report
    
    def _generate_title(self, report_type: ReportType, start: datetime, end: datetime) -> str:
        """生成报告标题"""
        type_names = {
            ReportType.DAILY: "每日",
            ReportType.WEEKLY: "每周",
            ReportType.MONTHLY: "每月",
            ReportType.QUARTERLY: "季度",
            ReportType.ANNUAL: "年度",
            ReportType.INCIDENT: "安全事件",
            ReportType.AUDIT: "安全审计",
            ReportType.COMPLIANCE: "合规性",
            ReportType.THREAT: "威胁态势",
            ReportType.RISK: "风险评估"
        }
        
        period = f"{start.strftime('%Y-%m-%d')} 至 {end.strftime('%Y-%m-%d')}"
        return f"{type_names.get(report_type, '安全')}安全报告 - {period}"
    
    def _generate_summary(self, report_type: ReportType, data: Dict) -> Dict:
        """生成报告摘要"""
        stats = data.get('statistics', {})
        
        return {
            'total_events': stats.get('total_events', 0),
            'total_alerts': stats.get('total_alerts', 0),
            'critical_threats': stats.get('critical_threats', 0),
            'high_threats': stats.get('high_threats', 0),
            'medium_threats': stats.get('medium_threats', 0),
            'low_threats': stats.get('low_threats', 0),
            'overall_risk_score': stats.get('risk_score', 0.0),
            'compliance_status': data.get('compliance_status', 'compliant'),
            'key_findings': data.get('key_findings', [])
        }
    
    def _generate_sections(self, report_type: ReportType, data: Dict) -> List[ReportSection]:
        """生成报告章节"""
        sections = []
        
        # 执行摘要
        sections.append(ReportSection(
            title="执行摘要",
            content={
                'overview': data.get('overview', '本报告对安全态势进行了全面分析'),
                'highlights': data.get('highlights', []),
                'concerns': data.get('concerns', [])
            },
            order=1
        ))
        
        # 威胁分析
        sections.append(ReportSection(
            title="威胁分析",
            content=data.get('threat_analysis', {
                'attack_types': [],
                'top_attack_sources': [],
                'attack_trends': []
            }),
            order=2
        ))
        
        # 漏洞分析
        sections.append(ReportSection(
            title="漏洞分析",
            content=data.get('vulnerability_analysis', {
                'critical_vulnerabilities': [],
                'high_vulnerabilities': [],
                'remediation_status': 'N/A'
            }),
            order=3
        ))
        
        # 合规性状态
        sections.append(ReportSection(
            title="合规性状态",
            content=data.get('compliance_status_detail', {
                'standards': [],
                'pass_rate': 0,
                'issues': []
            }),
            order=4
        ))
        
        # 建议和改进
        sections.append(ReportSection(
            title="建议和改进",
            content={
                'immediate_actions': data.get('immediate_actions', []),
                'short_term_actions': data.get('short_term_actions', []),
                'long_term_actions': data.get('long_term_actions', [])
            },
            order=5
        ))
        
        return sections
    
    def _generate_statistics(self, data: Dict) -> Dict:
        """生成统计数据"""
        return {
            'total_events': data.get('statistics', {}).get('total_events', 0),
            'total_alerts': data.get('statistics', {}).get('total_alerts', 0),
            'blocked_attacks': data.get('statistics', {}).get('blocked_attacks', 0),
            'detected_threats': data.get('statistics', {}).get('detected_threats', 0),
            'false_positives': data.get('statistics', {}).get('false_positives', 0),
            'uptime': data.get('statistics', {}).get('uptime', '100%')
        }
    
    def _generate_recommendations(self, report_type: ReportType, data: Dict) -> List[str]:
        """生成建议"""
        recommendations = []
        
        # 根据风险评分生成建议
        risk_score = data.get('statistics', {}).get('risk_score', 0)
        if risk_score > 0.7:
            recommendations.append("立即进行全面的安全评估")
            recommendations.append("增加安全监控频率")
        elif risk_score > 0.4:
            recommendations.append("在两周内完成关键漏洞修复")
            recommendations.append("加强访问控制策略")
        else:
            recommendations.append("继续保持当前的安全实践")
        
        # 根据检测到的威胁类型生成建议
        threats = data.get('threat_analysis', {}).get('attack_types', [])
        if 'phishing' in threats:
            recommendations.append("加强钓鱼邮件防护培训")
        if 'malware' in threats:
            recommendations.append("更新终端防护策略")
        if 'intrusion' in threats:
            recommendations.append("强化网络边界防护")
        
        return recommendations
    
    def export_report(
        self,
        report: SecurityReport,
        format: ReportFormat = ReportFormat.JSON
    ) -> str:
        """
        导出报告
        
        Args:
            report: 安全报告
            format: 报告格式
        
        Returns:
            导出的文件路径
        """
        if format == ReportFormat.JSON:
            return self._export_json(report)
        elif format == ReportFormat.HTML:
            return self._export_html(report)
        elif format == ReportFormat.MARKDOWN:
            return self._export_markdown(report)
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def _export_json(self, report: SecurityReport) -> str:
        """导出JSON格式报告"""
        report_data = {
            'report_id': report.report_id,
            'report_type': report.report_type.value,
            'title': report.title,
            'generated_at': report.generated_at,
            'period': {
                'start': report.period_start,
                'end': report.period_end
            },
            'summary': report.summary,
            'sections': [
                {
                    'title': s.title,
                    'content': s.content
                }
                for s in report.sections
            ],
            'statistics': report.statistics,
            'recommendations': report.recommendations,
            'metadata': report.metadata
        }
        
        filename = f"{report.report_id}.json"
        filepath = os.path.join(self.output_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, ensure_ascii=False, indent=2)
        
        return filepath
    
    def _export_html(self, report: SecurityReport) -> str:
        """导出HTML格式报告"""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{report.title}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; }}
        h1 {{ color: #333; }}
        h2 {{ color: #666; border-bottom: 2px solid #ddd; }}
        .summary {{ background: #f5f5f5; padding: 20px; border-radius: 5px; }}
        .stat {{ display: inline-block; margin: 10px 20px; }}
        .stat-value {{ font-size: 24px; font-weight: bold; color: #2196F3; }}
        .stat-label {{ color: #666; }}
        .recommendation {{ background: #fff3cd; padding: 10px; margin: 5px 0; border-left: 4px solid #ffc107; }}
    </style>
</head>
<body>
    <h1>{report.title}</h1>
    <p><strong>生成时间:</strong> {report.generated_at}</p>
    <p><strong>报告周期:</strong> {report.period_start} 至 {report.period_end}</p>
    
    <h2>执行摘要</h2>
    <div class="summary">
        <div class="stat">
            <div class="stat-value">{report.summary.get('total_events', 0)}</div>
            <div class="stat-label">安全事件</div>
        </div>
        <div class="stat">
            <div class="stat-value">{report.summary.get('total_alerts', 0)}</div>
            <div class="stat-label">告警数量</div>
        </div>
        <div class="stat">
            <div class="stat-value">{report.summary.get('critical_threats', 0)}</div>
            <div class="stat-label">严重威胁</div>
        </div>
        <div class="stat">
            <div class="stat-value">{report.summary.get('overall_risk_score', 0):.1%}</div>
            <div class="stat-label">风险评分</div>
        </div>
    </div>
    
    <h2>建议</h2>
    <div class="recommendations">
        {"".join(f'<div class="recommendation">{r}</div>' for r in report.recommendations)}
    </div>
    
    <footer style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666;">
        <p>企业级综合安全引擎 v3.0.1 | 报告ID: {report.report_id}</p>
    </footer>
</body>
</html>"""
        
        filename = f"{report.report_id}.html"
        filepath = os.path.join(self.output_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html)
        
        return filepath
    
    def _export_markdown(self, report: SecurityReport) -> str:
        """导出Markdown格式报告"""
        md = f"""# {report.title}

## 基本信息

- **生成时间**: {report.generated_at}
- **报告周期**: {report.period_start} 至 {report.period_end}
- **报告类型**: {report.report_type.value}

## 执行摘要

| 指标 | 数值 |
|------|------|
| 安全事件 | {report.summary.get('total_events', 0)} |
| 告警数量 | {report.summary.get('total_alerts', 0)} |
| 严重威胁 | {report.summary.get('critical_threats', 0)} |
| 高危威胁 | {report.summary.get('high_threats', 0)} |
| 风险评分 | {report.summary.get('overall_risk_score', 0):.1%} |

"""
        
        # 添加章节
        for section in report.sections:
            md += f"\n## {section.title}\n\n"
            if isinstance(section.content, dict):
                for key, value in section.content.items():
                    if isinstance(value, list):
                        md += f"\n### {key}\n\n"
                        for item in value:
                            md += f"- {item}\n"
                    else:
                        md += f"**{key}**: {value}\n"
        
        # 添加建议
        md += "\n## 建议\n\n"
        for i, rec in enumerate(report.recommendations, 1):
            md += f"{i}. {rec}\n"
        
        # 添加页脚
        md += f"\n---\n\n*企业级综合安全引擎 v3.0.1 | 报告ID: {report.report_id}*\n"
        
        filename = f"{report.report_id}.md"
        filepath = os.path.join(self.output_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(md)
        
        return filepath
    
    def get_report(self, report_id: str) -> Optional[SecurityReport]:
        """获取报告"""
        return self._reports.get(report_id)
    
    def list_reports(self) -> List[SecurityReport]:
        """列出所有报告"""
        return list(self._reports.values())


def create_report_generator(output_dir: str = "./reports") -> ReportGenerator:
    """
    创建报告生成器实例
    
    Args:
        output_dir: 报告输出目录
    
    Returns:
        ReportGenerator实例
    """
    return ReportGenerator(output_dir)


if __name__ == '__main__':
    print("=" * 60)
    print("安全检测报告生成器测试")
    print("=" * 60)
    
    # 创建报告生成器
    generator = create_report_generator("./test_reports")
    
    # 准备测试数据
    test_data = {
        'statistics': {
            'total_events': 1523,
            'total_alerts': 287,
            'critical_threats': 5,
            'high_threats': 23,
            'medium_threats': 89,
            'low_threats': 170,
            'risk_score': 0.35,
            'blocked_attacks': 1205,
            'detected_threats': 117,
            'false_positives': 15,
            'uptime': '99.9%'
        },
        'overview': '本期安全报告覆盖了系统运行期间的各项安全指标，整体安全态势良好。',
        'highlights': [
            '成功阻止1205次攻击尝试',
            '检测并响应117个安全威胁',
            '系统可用性达到99.9%'
        ],
        'concerns': [
            '发现5个严重级别漏洞需立即处理',
            '钓鱼攻击尝试较上期增加15%'
        ],
        'threat_analysis': {
            'attack_types': ['phishing', 'malware', 'intrusion', 'ddos'],
            'top_attack_sources': ['192.168.1.100', '10.0.0.50', '172.16.0.25'],
            'attack_trends': '较上期下降10%'
        },
        'vulnerability_analysis': {
            'critical_vulnerabilities': ['CVE-2024-1234', 'CVE-2024-5678'],
            'high_vulnerabilities': ['CVE-2024-9012', 'CVE-2024-3456'],
            'remediation_status': '进行中'
        },
        'compliance_status': 'compliant',
        'metadata': {
            'generated_by': 'Security Report Generator',
            'version': 'v3.0.1'
        }
    }
    
    # 生成报告
    period_start = datetime.now() - timedelta(days=7)
    period_end = datetime.now()
    
    report = generator.generate_report(
        report_type=ReportType.WEEKLY,
        period_start=period_start,
        period_end=period_end,
        data=test_data
    )
    
    print(f"\n报告生成成功!")
    print(f"报告ID: {report.report_id}")
    print(f"报告标题: {report.title}")
    print(f"风险评分: {report.summary['overall_risk_score']:.1%}")
    
    # 导出报告
    json_path = generator.export_report(report, ReportFormat.JSON)
    print(f"\nJSON报告已导出: {json_path}")
    
    html_path = generator.export_report(report, ReportFormat.HTML)
    print(f"HTML报告已导出: {html_path}")
    
    md_path = generator.export_report(report, ReportFormat.MARKDOWN)
    print(f"Markdown报告已导出: {md_path}")
    
    print("\n" + "=" * 60)
