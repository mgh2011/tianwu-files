"""
数据安全模块
Data Security Module

提供数据加密、备份、恢复等安全功能
"""

from .data_security_core import (
    DataSecurityEngine,
    EncryptionType,
    create_data_security_engine
)

__version__ = "v3.0.0"
__all__ = [
    'DataSecurityEngine',
    'EncryptionType',
    'create_data_security_engine'
]
