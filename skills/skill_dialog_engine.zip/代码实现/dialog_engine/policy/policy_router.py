# dialog_engine/policy/policy_router.py
"""
策略路由器
根据意图、上下文选择合适的策略
"""

import logging
from typing import Dict, List, Optional, Any

from ..models.data_models import DialogPolicy, IntentResult, IntentType, DialogContext
from ..config.default_config import config


logger = logging.getLogger(__name__)


class PolicyRouter:
    """
    对话策略路由器
    根据意图、上下文选择合适的策略
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        self.config = config_dict or config.POLICY_ROUTER
        self.policies: Dict[str, DialogPolicy] = {}
        self.default_policy = self.config.get("default_policy", "fallback")
        self.enable_contextual = self.config.get("enable_contextual_routing", True)
        
        # 初始化默认策略
        self._init_default_policies()
        
        # 策略匹配器
        self.matchers: List[callable] = []
        
    def _init_default_policies(self):
        """初始化默认策略"""
        policies_config = self.config.get("policies", {})
        
        for policy_name, policy_config in policies_config.items():
            policy = DialogPolicy(
                name=policy_config.get("name", policy_name),
                intent=IntentType(policy_name),
                response_templates=policy_config.get("response_templates", {}),
                slot_requirements=policy_config.get("slot_requirements", []),
                confirm_needed=policy_config.get("confirm_needed", False),
                max_turns=policy_config.get("max_turns", 10),
                fallback_policy=policy_config.get("fallback_policy")
            )
            self.policies[policy_name] = policy
        
        # 添加fallback策略
        fallback_config = self.config.get("fallback_policy", {})
        self.policies["fallback"] = DialogPolicy(
            name="fallback",
            intent=IntentType.UNKNOWN,
            response_templates={
                "default": fallback_config.get("response_template", "抱歉，我没能理解您的意思。")
            },
            quick_replies=fallback_config.get("quick_replies", [])
        )
        
    async def route(self, intent_result: IntentResult,
                   context: Optional[DialogContext] = None) -> DialogPolicy:
        """
        策略路由
        
        Args:
            intent_result: 意图识别结果
            context: 对话上下文
            
        Returns:
            DialogPolicy: 选中的对话策略
        """
        intent_name = intent_result.intent.value if intent_result else "unknown"
        
        # 1. 直接匹配
        if intent_name in self.policies:
            policy = self.policies[intent_name]
            logger.debug(f"Direct policy match: {intent_name}")
            return policy
        
        # 2. 上下文匹配
        if self.enable_contextual and context:
            contextual_policy = await self._route_by_context(intent_result, context)
            if contextual_policy:
                return contextual_policy
        
        # 3. 相似意图匹配
        similar_policy = await self._route_by_similarity(intent_result)
        if similar_policy:
            return similar_policy
        
        # 4. 使用默认策略
        logger.debug(f"Using default policy: {self.default_policy}")
        return self.policies.get(self.default_policy, self.policies["fallback"])
    
    async def _route_by_context(self, intent_result: IntentResult,
                               context: DialogContext) -> Optional[DialogPolicy]:
        """基于上下文的路由"""
        # 检查之前的意图
        if context.intent:
            prev_intent = context.intent.intent.value
            
            # 查询->详细查询: 保持查询策略
            if prev_intent == "query" and intent_result.intent == IntentType.QUERY:
                return self.policies.get("query")
            
            # 确认/否定后的意图
            if context.variables.get("awaiting_confirmation"):
                return self.policies.get("confirmation")
        
        # 检查上下文变量中的策略提示
        strategy_hint = context.variables.get("suggested_policy")
        if strategy_hint and strategy_hint in self.policies:
            return self.policies[strategy_hint]
        
        return None
    
    async def _route_by_similarity(self, intent_result: IntentResult) -> Optional[DialogPolicy]:
        """基于相似度的路由"""
        # 检查意图的策略名称
        if intent_result.policy_name and intent_result.policy_name in self.policies:
            return self.policies[intent_result.policy_name]
        
        # 检查意图变体
        intent_name = intent_result.intent.value
        
        # 意图别名映射
        intent_aliases = {
            "greeting": ["greeting", "hi", "hello"],
            "goodbye": ["goodbye", "bye", "exit"],
            "query": ["query", "search", "find"],
            "booking": ["booking", "reserve", "schedule"],
        }
        
        for policy_name, aliases in intent_aliases.items():
            if intent_name in aliases and policy_name in self.policies:
                return self.policies[policy_name]
        
        return None
    
    def register_policy(self, policy: DialogPolicy) -> None:
        """注册策略"""
        self.policies[policy.name] = policy
        logger.info(f"Registered policy: {policy.name}")
    
    def unregister_policy(self, policy_name: str) -> None:
        """注销策略"""
        if policy_name in self.policies:
            del self.policies[policy_name]
            logger.info(f"Unregistered policy: {policy_name}")
    
    def get_policy(self, policy_name: str) -> Optional[DialogPolicy]:
        """获取策略"""
        return self.policies.get(policy_name)
    
    def get_all_policies(self) -> List[DialogPolicy]:
        """获取所有策略"""
        return list(self.policies.values())
    
    def add_matcher(self, matcher: callable):
        """添加自定义匹配器"""
        self.matchers.append(matcher)
    
    def update_policy_response_template(self, policy_name: str,
                                        template_key: str,
                                        template: str):
        """更新策略响应模板"""
        if policy_name in self.policies:
            self.policies[policy_name].response_templates[template_key] = template
            logger.info(f"Updated template for policy: {policy_name}")
