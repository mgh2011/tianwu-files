"""
数据安全模块
Data Security Module

提供数据安全相关的核心功能
"""

from .data_security_core import (
    DataSecurityEngine,
    BackupManager,
    EncryptionType,
    DataClassification,
    create_data_security_engine,
    create_backup_manager
)

__version__ = "v3.0.0"
__all__ = [
    'DataSecurityEngine',
    'BackupManager',
    'EncryptionType',
    'DataClassification',
    'create_data_security_engine',
    'create_backup_manager'
]
