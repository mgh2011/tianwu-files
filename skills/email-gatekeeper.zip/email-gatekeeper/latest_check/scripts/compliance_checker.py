# ========== 法律合规模块 ==========
# 文件: scripts/compliance_checker.py
# 版本: 1.0.0

"""
邮件安全守门员法律合规模块
支持: 中国法规、GDPR、数据保护、用户权利
"""

import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, field, asdict
from enum import Enum
from collections import defaultdict

logger = logging.getLogger(__name__)


class ComplianceLaw(Enum):
    """合规法律类型"""
    # 中国法规
    CHINA_CYBER_SECURITY = "网络安全法"
    CHINA_DATA_SECURITY = "数据安全法"
    CHINA_PIPL = "个人信息保护法"
    CHINA_ELECTRONIC_SIGNATURE = "电子签名法"
    CHINA_ANTI_SPAM = "反垃圾邮件规定"
    # 国际法规
    GDPR = "GDPR"
    CAN_SPAM = "CAN-SPAM法案"
    CCPA = "CCPA加州消费者隐私法"


class DataLevel(Enum):
    """数据安全等级"""
    GENERAL = "一般数据"
    PERSONAL = "个人信息"
    SENSITIVE = "敏感个人信息"
    IMPORTANT = "重要数据"


class RiskLevel(Enum):
    """风险等级"""
    LOW = "低风险"
    MEDIUM = "中风险"
    HIGH = "高风险"
    CRITICAL = "极高风险"


@dataclass
class ComplianceRequirement:
    """合规要求"""
    law: ComplianceLaw
    requirement: str
    description: str
    article: str = ""  # 法规条款
    is_satisfied: bool = False
    evidence: str = ""
    last_checked: str = ""


@dataclass
class UserRight:
    """用户权利"""
    right_type: str
    description: str
    is_supported: bool = False
    endpoint: str = ""


@dataclass
class AuditEntry:
    """审计日志条目"""
    timestamp: str
    action: str
    details: Dict[str, Any]
    user_id: str = ""
    result: str = "success"


class ComplianceChecker:
    """合规检查器"""
    
    # 法规条款映射
    LAW_ARTICLES = {
        ComplianceLaw.CHINA_CYBER_SECURITY: {
            "日志留存": "第21条",
            "用户信息保护": "第40条",
            "安全事件报告": "第25条",
            "数据分类": "第21条"
        },
        ComplianceLaw.CHINA_DATA_SECURITY: {
            "数据分类分级": "第21条",
            "数据安全保护": "第27条",
            "数据安全事件": "第29条",
            "重要数据保护": "第21条"
        },
        ComplianceLaw.CHINA_PIPL: {
            "用户知情同意": "第14条",
            "最小必要原则": "第6条",
            "用户权利保障": "第44-49条",
            "跨境传输评估": "第38条",
            "敏感信息处理": "第29条",
            "自动化决策": "第24条"
        },
        ComplianceLaw.CHINA_ELECTRONIC_SIGNATURE: {
            "电子签名效力": "第14条",
            "邮件证据保存": "第6条"
        },
        ComplianceLaw.CHINA_ANTI_SPAM: {
            "垃圾邮件识别": "第3条",
            "用户投诉处理": "第10条",
            "退订机制": "第9条"
        },
        ComplianceLaw.GDPR: {
            "数据处理合法性": "第6条",
            "数据主体权利": "第15-22条",
            "数据泄露通知": "第33条",
            "DPO任命": "第37条",
            "数据保护影响评估": "第35条"
        },
        ComplianceLaw.CAN_SPAM: {
            "标识要求": "第5条",
            "退订机制": "第16条",
            "发送频率": "第8条"
        },
        ComplianceLaw.CCPA: {
            "消费者知情权": "第1798.100条",
            "删除权": "第1798.105条",
            "拒绝出售权": "第1798.120条"
        }
    }
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.requirements = self._init_requirements()
        self.audit_log: List[AuditEntry] = []
        self.user_rights = self._init_user_rights()
        
        # 配置参数
        self.log_retention_days = self.config.get('log_retention_days', 180)
        self.data_retention_days = self.config.get('data_retention_days', 365)
        self.cross_border_allowed = self.config.get('cross_border_allowed', False)
        self.dpo_appointed = self.config.get('dpo_appointed', False)
        self.breach_notification_hours = self.config.get('breach_notification_hours', 72)
        
        logger.info("🛡️ 合规检查器初始化完成")
        self.log_audit("system_init", {"version": "v1.0.0"}, "system")
    
    def _init_requirements(self) -> List[ComplianceRequirement]:
        """初始化合规要求清单"""
        return [
            # 网络安全法
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_CYBER_SECURITY,
                requirement="日志留存",
                description="网络日志留存不少于6个月",
                article="第21条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_CYBER_SECURITY,
                requirement="用户信息保护",
                description="采取技术措施保护用户信息安全",
                article="第40条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_CYBER_SECURITY,
                requirement="安全事件报告",
                description="发生安全事件及时向有关主管部门报告",
                article="第25条"
            ),
            
            # 数据安全法
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_DATA_SECURITY,
                requirement="数据分类分级",
                description="建立数据分类分级保护制度",
                article="第21条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_DATA_SECURITY,
                requirement="数据安全保护",
                description="采取相应的技术措施保障数据安全",
                article="第27条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_DATA_SECURITY,
                requirement="数据安全事件处置",
                description="发生数据安全事件立即启动应急预案",
                article="第29条"
            ),
            
            # 个人信息保护法
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_PIPL,
                requirement="用户知情同意",
                description="处理个人信息需取得用户明确同意",
                article="第14条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_PIPL,
                requirement="最小必要原则",
                description="仅收集处理与实现目的直接相关的必要信息",
                article="第6条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_PIPL,
                requirement="用户权利保障",
                description="保障用户访问、更正、删除、撤回同意等权利",
                article="第44-49条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_PIPL,
                requirement="跨境传输评估",
                description="个人信息跨境传输需通过安全评估",
                article="第38条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_PIPL,
                requirement="敏感信息单独同意",
                description="处理敏感个人信息需单独取得用户同意",
                article="第29条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_PIPL,
                requirement="自动化决策透明",
                description="保障用户对自动化决策的知情权和退出权",
                article="第24条"
            ),
            
            # 电子签名法
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_ELECTRONIC_SIGNATURE,
                requirement="电子签名效力",
                description="符合条件的电子签名具有法律效力",
                article="第14条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_ELECTRONIC_SIGNATURE,
                requirement="邮件证据保存",
                description="重要邮件证据需安全保存",
                article="第6条"
            ),
            
            # 反垃圾邮件规定
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_ANTI_SPAM,
                requirement="垃圾邮件识别",
                description="遵守垃圾邮件识别和处理标准",
                article="第3条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CHINA_ANTI_SPAM,
                requirement="用户投诉处理",
                description="建立投诉处理机制，7日内回复",
                article="第10条"
            ),
            
            # GDPR
            ComplianceRequirement(
                law=ComplianceLaw.GDPR,
                requirement="数据处理合法性",
                description="数据处理需有合法基础（同意/合同/法定义务等）",
                article="第6条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.GDPR,
                requirement="数据主体权利",
                description="保障访问、删除、移植、可携带等权利",
                article="第15-22条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.GDPR,
                requirement="数据泄露通知",
                description="72小时内向监管机构报告数据泄露",
                article="第33条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.GDPR,
                requirement="DPO任命",
                description="核心业务涉及大规模数据处理时需任命DPO",
                article="第37条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.GDPR,
                requirement="数据保护影响评估",
                description="高风险数据处理需进行影响评估",
                article="第35条"
            ),
            
            # CAN-SPAM
            ComplianceRequirement(
                law=ComplianceLaw.CAN_SPAM,
                requirement="标识要求",
                description="商业邮件需清晰标识为广告",
                article="第5条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CAN_SPAM,
                requirement="退订机制",
                description="提供简单有效的退订机制，10日内处理",
                article="第16条"
            ),
            
            # CCPA
            ComplianceRequirement(
                law=ComplianceLaw.CCPA,
                requirement="消费者知情权",
                description="消费者有权知道数据收集和使用目的",
                article="第1798.100条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CCPA,
                requirement="删除权",
                description="消费者有权要求删除个人信息",
                article="第1798.105条"
            ),
            ComplianceRequirement(
                law=ComplianceLaw.CCPA,
                requirement="拒绝出售权",
                description="消费者有权选择退出个人信息出售",
                article="第1798.120条"
            ),
        ]
    
    def _init_user_rights(self) -> List[UserRight]:
        """初始化用户权利清单"""
        return [
            UserRight(
                right_type="access",
                description="数据访问权 - 用户可查看其个人信息的收集和使用情况",
                is_supported=True,
                endpoint="/api/v1/user/data/access"
            ),
            UserRight(
                right_type="rectification",
                description="数据更正权 - 用户可更正不准确的个人信息",
                is_supported=True,
                endpoint="/api/v1/user/data/rectify"
            ),
            UserRight(
                right_type="erasure",
                description="数据删除权 - 用户可要求删除其个人信息",
                is_supported=True,
                endpoint="/api/v1/user/data/delete"
            ),
            UserRight(
                right_type="portability",
                description="数据可携带权 - 用户可获取其个人信息的副本",
                is_supported=True,
                endpoint="/api/v1/user/data/export"
            ),
            UserRight(
                right_type="withdraw_consent",
                description="撤回同意权 - 用户可撤回对个人信息处理的同意",
                is_supported=True,
                endpoint="/api/v1/user/consent/withdraw"
            ),
            UserRight(
                right_type="restriction",
                description="限制处理权 - 用户可限制对个人信息的处理",
                is_supported=True,
                endpoint="/api/v1/user/data/restrict"
            ),
            UserRight(
                right_type="objection",
                description="反对权 - 用户可反对基于合法利益的处理",
                is_supported=True,
                endpoint="/api/v1/user/data/object"
            ),
            UserRight(
                right_type="complaint",
                description="投诉权 - 用户可向监管机构投诉",
                is_supported=True,
                endpoint="/api/v1/user/complaint"
            ),
        ]
    
    # ========== 中国法规合规检查 ==========
    
    def check_log_retention(self, retention_days: int) -> Dict:
        """
        检查日志留存合规性（网络安全法第21条）
        要求：网络日志留存不少于6个月（180天）
        """
        result = {
            'check_type': 'log_retention',
            'law': '网络安全法第21条',
            'is_compliant': retention_days >= 180,
            'retention_days': retention_days,
            'required_days': 180,
            'status': '✅ 合规' if retention_days >= 180 else '⚠️ 不合规',
            'recommendation': '日志留存应不少于6个月（180天），建议设置为180-365天'
        }
        
        if result['is_compliant']:
            logger.info(f"✅ 日志留存合规: {retention_days}天 >= 180天")
        else:
            logger.warning(f"⚠️ 日志留存不合规: {retention_days}天 < 180天")
        
        self.log_audit("compliance_check", result, "system")
        return result
    
    def check_cyber_security_user_protection(self, has_protection: bool, methods: List[str] = None) -> Dict:
        """
        检查用户信息保护措施（网络安全法第40条）
        """
        result = {
            'check_type': 'user_protection',
            'law': '网络安全法第40条',
            'is_compliant': has_protection,
            'protection_methods': methods or [],
            'status': '✅ 合规' if has_protection else '⚠️ 不合规',
            'recommendation': '应采取加密、访问控制、审计等技术措施保护用户信息安全'
        }
        
        self.log_audit("compliance_check", result, "system")
        return result
    
    def check_cyber_security_incident_report(self, incident_time: datetime, report_time: datetime) -> Dict:
        """
        检查安全事件报告时效（网络安全法第25条）
        """
        hours_elapsed = (report_time - incident_time).total_seconds() / 3600
        
        result = {
            'check_type': 'incident_report',
            'law': '网络安全法第25条',
            'is_compliant': hours_elapsed <= 24,  # 建议24小时内报告
            'hours_elapsed': round(hours_elapsed, 2),
            'required_hours': 24,
            'incident_time': incident_time.isoformat(),
            'report_time': report_time.isoformat(),
            'status': '✅ 及时报告' if hours_elapsed <= 24 else '⚠️ 报告延迟',
            'recommendation': '发生安全事件应在24小时内向有关主管部门报告'
        }
        
        self.log_audit("security_incident", result, "system")
        return result
    
    # ========== 数据安全法合规检查 ==========
    
    def check_data_classification(self, data_items: List[Dict]) -> Dict:
        """
        检查数据分类分级（数据安全法第21条）
        """
        classification_stats = defaultdict(int)
        unclassified_count = 0
        
        for item in data_items:
            level = item.get('data_level', 'UNCLASSIFIED')
            if level == 'UNCLASSIFIED':
                unclassified_count += 1
            classification_stats[level] += 1
        
        has_important_data = any(
            item.get('data_level') in ['IMPORTANT', 'CORE']
            for item in data_items
        )
        
        result = {
            'check_type': 'data_classification',
            'law': '数据安全法第21条',
            'is_compliant': unclassified_count == 0,
            'total_items': len(data_items),
            'classified_items': len(data_items) - unclassified_count,
            'unclassified_items': unclassified_count,
            'classification_stats': dict(classification_stats),
            'has_important_data': has_important_data,
            'status': '✅ 全部分类' if unclassified_count == 0 else f'⚠️ {unclassified_count}项未分类',
            'recommendation': '所有数据均需按照一般/重要/核心进行分类分级保护'
        }
        
        self.log_audit("data_classification_check", result, "system")
        return result
    
    def check_data_security_protection(self, data: Dict) -> Dict:
        """
        检查数据安全保护措施（数据安全法第27条）
        """
        required_measures = {
            'encryption': False,           # 加密保护
            'access_control': False,       # 访问控制
            'audit_log': False,           # 日志审计
            'backup': False,              # 数据备份
            'disaster_recovery': False,   # 灾难恢复
        }
        
        if 'security_measures' in data:
            for measure in data['security_measures']:
                if measure in required_measures:
                    required_measures[measure] = True
        
        implemented_count = sum(required_measures.values())
        required_count = len(required_measures)
        
        result = {
            'check_type': 'data_security_protection',
            'law': '数据安全法第27条',
            'is_compliant': implemented_count >= 3,  # 至少实现3项核心措施
            'implemented_measures': [k for k, v in required_measures.items() if v],
            'missing_measures': [k for k, v in required_measures.items() if not v],
            'coverage': f"{implemented_count}/{required_count}",
            'status': '✅ 保护完善' if implemented_count >= 3 else '⚠️ 保护不足',
            'recommendation': '应采取加密、访问控制、日志审计、备份、灾难恢复等综合措施'
        }
        
        self.log_audit("security_protection_check", result, "system")
        return result
    
    # ========== 个人信息保护法合规检查 ==========
    
    def check_consent(self, email_data: Dict) -> Dict:
        """
        检查用户同意合规性（个人信息保护法第14条）
        """
        result = {
            'check_type': 'user_consent',
            'law': '个人信息保护法第14条',
            'has_consent': email_data.get('user_consent', False),
            'consent_type': email_data.get('consent_type'),
            'consent_time': email_data.get('consent_time'),
            'consent_method': email_data.get('consent_method'),
            'is_withdrawn': email_data.get('consent_withdrawn', False),
            'is_compliant': False,
            'status': '',
            'recommendation': ''
        }
        
        # 合规判断
        if result['has_consent'] and not result['is_withdrawn']:
            if result['consent_time']:
                consent_age_days = (datetime.now() - datetime.fromisoformat(result['consent_time'])).days
                result['consent_age_days'] = consent_age_days
                
                # 同意超过1年需要重新获取
                if consent_age_days > 365:
                    result['is_compliant'] = False
                    result['status'] = '⚠️ 同意过期'
                    result['recommendation'] = '用户同意已超过1年，建议重新获取同意'
                else:
                    result['is_compliant'] = True
                    result['status'] = '✅ 同意有效'
            else:
                result['is_compliant'] = True
                result['status'] = '✅ 有同意记录'
        else:
            result['is_compliant'] = False
            result['status'] = '⚠️ 缺少同意记录'
            result['recommendation'] = '处理个人信息必须获得用户明确同意'
        
        self.log_audit("consent_check", result, "system")
        return result
    
    def check_minimal_necessity(self, email_data: Dict, purpose: str = None) -> Dict:
        """
        检查最小必要原则（个人信息保护法第6条）
        """
        # 必要字段（邮件处理必需）
        necessary_fields = {'sender', 'recipient', 'subject', 'timestamp', 'message_id'}
        
        # 可选但常见字段
        optional_common = {'cc', 'bcc', 'reply_to', 'headers'}
        
        # 不必要字段（过度收集）
        unnecessary_fields = {'device_id', 'location', 'ip_address', 'browser_fingerprint'}
        
        collected = set(email_data.keys())
        necessary_collected = collected & necessary_fields
        optional_collected = collected & optional_common
        unnecessary_collected = collected & unnecessary_fields
        
        # 检查是否有未知字段
        known_fields = necessary_fields | optional_common | unnecessary_fields
        unknown_fields = collected - known_fields
        
        result = {
            'check_type': 'minimal_necessity',
            'law': '个人信息保护法第6条',
            'purpose': purpose or '邮件处理',
            'is_compliant': len(unnecessary_collected) == 0 and len(unknown_fields) == 0,
            'necessary_fields': list(necessary_collected),
            'optional_fields': list(optional_collected),
            'unnecessary_fields': list(unnecessary_collected),
            'unknown_fields': list(unknown_fields),
            'status': '',
            'recommendation': ''
        }
        
        if result['is_compliant']:
            result['status'] = '✅ 符合最小必要'
            result['recommendation'] = '仅收集实现目的所必需的个人信息'
        else:
            if unnecessary_collected:
                result['status'] = '⚠️ 过度收集'
                result['recommendation'] = f'不应收集: {list(unnecessary_collected)}'
            if unknown_fields:
                result['status'] = '⚠️ 存在未知字段'
                result['recommendation'] = f'请确认以下字段的收集必要性: {list(unknown_fields)}'
        
        self.log_audit("minimal_check", result, "system")
        return result
    
    def check_data_subject_rights(self, user_id: str = None) -> Dict:
        """
        检查数据主体权利保障（个人信息保护法第44-49条）
        """
        supported_rights = {r.right_type: r.is_supported for r in self.user_rights}
        
        result = {
            'check_type': 'data_subject_rights',
            'law': '个人信息保护法第44-49条',
            'is_compliant': all(supported_rights.values()),
            'rights': [
                {
                    'type': r.right_type,
                    'description': r.description,
                    'is_supported': r.is_supported,
                    'endpoint': r.endpoint
                }
                for r in self.user_rights
            ],
            'supported_count': sum(supported_rights.values()),
            'total_count': len(supported_rights),
            'status': '✅ 权利完善' if all(supported_rights.values()) else '⚠️ 部分缺失',
            'recommendation': '应支持用户行使所有法定数据权利'
        }
        
        self.log_audit("rights_check", result, user_id or "system")
        return result
    
    def check_cross_border_transfer(self, email_data: Dict) -> Dict:
        """
        检查跨境传输合规性（个人信息保护法第38条）
        """
        sender_domain = ''
        recipient_domain = ''
        
        if 'sender' in email_data and '@' in email_data.get('sender', ''):
            sender_domain = email_data['sender'].split('@')[-1]
        if 'recipient' in email_data and '@' in email_data.get('recipient', ''):
            recipient_domain = email_data['recipient'].split('@')[-1]
        
        # 中国域名
        china_domains = {'.cn', '.com.cn', '.net.cn', '.org.cn', '.gov.cn'}
        is_cross_border = not any(
            sender_domain.endswith(d) or recipient_domain.endswith(d)
            for d in china_domains
        )
        
        # 跨境传输安全评估状态
        assessment_status = email_data.get('cross_border_assessment', 'NOT_STARTED')
        
        result = {
            'check_type': 'cross_border_transfer',
            'law': '个人信息保护法第38条',
            'is_cross_border': is_cross_border,
            'sender_domain': sender_domain,
            'recipient_domain': recipient_domain,
            'assessment_status': assessment_status,
            'is_compliant': not is_cross_border or assessment_status == 'APPROVED',
            'status': '',
            'recommendation': ''
        }
        
        if not is_cross_border:
            result['status'] = '✅ 国内传输'
        elif assessment_status == 'APPROVED':
            result['status'] = '✅ 已通过评估'
        elif assessment_status == 'PENDING':
            result['status'] = '⏳ 评估中'
            result['recommendation'] = '跨境传输需完成安全评估后方可进行'
        else:
            result['status'] = '⚠️ 未评估'
            result['recommendation'] = '个人信息跨境传输需通过国家网信部门安全评估'
        
        self.log_audit("cross_border_check", result, "system")
        return result
    
    def check_sensitive_data_processing(self, email_data: Dict) -> Dict:
        """
        检查敏感个人信息处理（个人信息保护法第29条）
        """
        sensitive_fields = {'id_number', 'bank_account', 'biometric', 'medical', 
                           'financial', 'location', 'sexual_orientation'}
        
        collected = set(email_data.keys())
        sensitive_collected = collected & sensitive_fields
        
        has_separate_consent = email_data.get('sensitive_consent', False)
        
        result = {
            'check_type': 'sensitive_data',
            'law': '个人信息保护法第29条',
            'has_sensitive_data': len(sensitive_collected) > 0,
            'sensitive_fields_found': list(sensitive_collected),
            'has_separate_consent': has_separate_consent,
            'is_compliant': len(sensitive_collected) == 0 or has_separate_consent,
            'status': '',
            'recommendation': ''
        }
        
        if len(sensitive_collected) == 0:
            result['status'] = '✅ 无敏感数据'
        elif has_separate_consent:
            result['status'] = '✅ 单独同意'
        else:
            result['status'] = '⚠️ 缺少单独同意'
            result['recommendation'] = '处理敏感个人信息必须单独取得用户明示同意'
        
        self.log_audit("sensitive_check", result, "system")
        return result
    
    # ========== GDPR合规检查 ==========
    
    def check_gdpr_compliance(self, email_data: Dict) -> Dict:
        """
        检查GDPR合规性（欧盟通用数据保护条例）
        """
        lawful_bases = ['consent', 'contract', 'legal_obligation', 
                       'vital_interests', 'public_task', 'legitimate_interests']
        
        lawful_basis = email_data.get('gdpr_lawful_basis')
        has_basis = lawful_basis in lawful_bases if lawful_basis else False
        
        result = {
            'check_type': 'gdpr_compliance',
            'law': 'GDPR第6条',
            'is_compliant': has_basis,
            'lawful_basis': lawful_basis,
            'available_bases': lawful_bases,
            'dpo_appointed': self.dpo_appointed,
            'data_controller': email_data.get('data_controller', 'Not specified'),
            'issues': [],
            'status': '',
            'recommendation': ''
        }
        
        if has_basis:
            result['status'] = '✅ 合法基础明确'
        else:
            result['status'] = '⚠️ 缺少合法基础'
            result['issues'].append('未明确数据处理的合法基础')
            result['recommendation'] = 'GDPR要求所有数据处理必须有合法基础（同意、合同、法定义务等）'
        
        self.log_audit("gdpr_check", result, "system")
        return result
    
    def check_gdpr_breach_notification(self, breach_time: datetime, notification_time: datetime) -> Dict:
        """
        检查数据泄露通知时效（GDPR第33条）
        要求：72小时内向监管机构报告
        """
        hours_elapsed = (notification_time - breach_time).total_seconds() / 3600
        
        result = {
            'check_type': 'gdpr_breach_notification',
            'law': 'GDPR第33条',
            'is_compliant': hours_elapsed <= 72,
            'hours_elapsed': round(hours_elapsed, 2),
            'required_hours': 72,
            'breach_time': breach_time.isoformat(),
            'notification_time': notification_time.isoformat(),
            'status': '✅ 及时通知' if hours_elapsed <= 72 else '⚠️ 通知超时',
            'recommendation': '数据泄露需在72小时内向相关监管机构报告'
        }
        
        self.log_audit("breach_notification", result, "system")
        return result
    
    def check_gdpr_data_subject_rights(self, data: Dict) -> Dict:
        """
        检查GDPR数据主体权利（GDPR第15-22条）
        """
        gdpr_rights = {
            'access': data.get('right_access', False),           # 访问权
            'rectification': data.get('right_rectification', False),  # 更正权
            'erasure': data.get('right_erasure', False),         # 删除权（被遗忘权）
            'restriction': data.get('right_restriction', False), # 限制处理权
            'portability': data.get('right_portability', False), # 数据可携带权
            'objection': data.get('right_objection', False),    # 反对权
        }
        
        supported_count = sum(gdpr_rights.values())
        
        result = {
            'check_type': 'gdpr_data_subject_rights',
            'law': 'GDPR第15-22条',
            'is_compliant': supported_count == len(gdpr_rights),
            'rights': gdpr_rights,
            'supported_count': supported_count,
            'total_count': len(gdpr_rights),
            'status': '✅ 权利完整' if supported_count == len(gdpr_rights) else f'⚠️ {supported_count}/{len(gdpr_rights)}',
            'recommendation': 'GDPR要求支持所有数据主体权利'
        }
        
        self.log_audit("gdpr_rights_check", result, "system")
        return result
    
    # ========== CAN-SPAM合规检查 ==========
    
    def check_can_spam_compliance(self, email_data: Dict) -> Dict:
        """
        检查CAN-SPAM法案合规性（美国反垃圾邮件法）
        """
        has_physical_address = bool(email_data.get('physical_address'))
        has_opt_out = email_data.get('has_opt_out_mechanism', False)
        has_clear_identification = email_data.get('clear_identification', False)
        accurate_sender = email_data.get('sender_info_accurate', True)
        
        result = {
            'check_type': 'can_spam_compliance',
            'law': 'CAN-SPAM法案',
            'is_compliant': has_physical_address and has_opt_out and has_clear_identification and accurate_sender,
            'checks': {
                'physical_address': {
                    'passed': has_physical_address,
                    'value': email_data.get('physical_address', 'Missing')
                },
                'opt_out_mechanism': {
                    'passed': has_opt_out,
                    'value': 'Available' if has_opt_out else 'Missing'
                },
                'clear_identification': {
                    'passed': has_clear_identification,
                    'value': 'Clear' if has_clear_identification else 'Unclear'
                },
                'accurate_sender': {
                    'passed': accurate_sender,
                    'value': 'Accurate' if accurate_sender else 'Misleading'
                }
            },
            'issues': [],
            'status': '',
            'recommendation': ''
        }
        
        if result['is_compliant']:
            result['status'] = '✅ CAN-SPAM合规'
        else:
            if not has_physical_address:
                result['issues'].append('缺少实体地址')
            if not has_opt_out:
                result['issues'].append('缺少退订机制')
            if not has_clear_identification:
                result['issues'].append('广告标识不清晰')
            if not accurate_sender:
                result['issues'].append('发件人信息不准确')
            result['status'] = '⚠️ CAN-SPAM不合规'
            result['recommendation'] = '商业邮件必须包含实体地址、有效的退订机制和清晰的广告标识'
        
        self.log_audit("can_spam_check", result, "system")
        return result
    
    def check_opt_out_timeline(self, request_time: datetime, processed_time: datetime) -> Dict:
        """
        检查退订处理时效（CAN-SPAM第16条）
        要求：10个工作日内处理
        """
        business_days = self._count_business_days(request_time, processed_time)
        
        result = {
            'check_type': 'opt_out_timeline',
            'law': 'CAN-SPAM第16条',
            'is_compliant': business_days <= 10,
            'business_days': business_days,
            'required_days': 10,
            'status': '✅ 及时处理' if business_days <= 10 else '⚠️ 处理延迟',
            'recommendation': '退订请求应在10个工作日内处理完成'
        }
        
        self.log_audit("opt_out_processing", result, "system")
        return result
    
    # ========== CCPA合规检查 ==========
    
    def check_ccpa_compliance(self, data: Dict) -> Dict:
        """
        检查CCPA加州消费者隐私法合规性
        """
        has_privacy_policy = data.get('has_privacy_policy', False)
        has_delete_mechanism = data.get('has_delete_mechanism', False)
        has_opt_out_sale = data.get('has_opt_out_sale', False)
        has_non_discrimination = data.get('non_discrimination_policy', False)
        
        result = {
            'check_type': 'ccpa_compliance',
            'law': 'CCPA加州消费者隐私法',
            'is_compliant': has_privacy_policy and has_delete_mechanism and has_opt_out_sale,
            'checks': {
                'privacy_policy': has_privacy_policy,
                'delete_mechanism': has_delete_mechanism,
                'opt_out_sale': has_opt_out_sale,
                'non_discrimination': has_non_discrimination
            },
            'issues': [],
            'status': '',
            'recommendation': ''
        }
        
        if result['is_compliant']:
            result['status'] = '✅ CCPA合规'
        else:
            if not has_privacy_policy:
                result['issues'].append('缺少隐私声明')
            if not has_delete_mechanism:
                result['issues'].append('缺少删除机制')
            if not has_opt_out_sale:
                result['issues'].append('缺少拒绝出售选项')
            result['status'] = '⚠️ CCPA不合规'
            result['recommendation'] = '应提供隐私声明、数据删除和拒绝出售功能'
        
        self.log_audit("ccpa_check", result, "system")
        return result
    
    # ========== 综合合规检查 ==========
    
    def check_all_compliance(self, email_data: Dict = None) -> Dict:
        """
        执行全面合规检查
        """
        email_data = email_data or {}
        
        results = {
            'timestamp': datetime.now().isoformat(),
            'overall_compliant': True,
            'checks': [],
            'issues': [],
            'recommendations': []
        }
        
        # 中国法规检查
        results['checks'].append(self.check_log_retention(self.log_retention_days))
        results['checks'].append(self.check_cyber_security_user_protection(
            email_data.get('has_user_protection', True),
            email_data.get('protection_methods')
        ))
        
        # 个人信息保护法
        results['checks'].append(self.check_consent(email_data))
        results['checks'].append(self.check_minimal_necessity(email_data))
        results['checks'].append(self.check_data_subject_rights())
        results['checks'].append(self.check_cross_border_transfer(email_data))
        
        # GDPR
        results['checks'].append(self.check_gdpr_compliance(email_data))
        
        # CAN-SPAM
        results['checks'].append(self.check_can_spam_compliance(email_data))
        
        # 汇总问题和建议
        for check in results['checks']:
            if not check.get('is_compliant', False):
                results['overall_compliant'] = False
                if check.get('issues'):
                    results['issues'].extend(check['issues'])
                if check.get('status') and '⚠️' in check['status']:
                    results['issues'].append(check['status'])
            if check.get('recommendation'):
                results['recommendations'].append(check['recommendation'])
        
        return results
    
    def generate_compliance_report(self, format: str = 'dict') -> Dict:
        """
        生成合规报告
        
        Args:
            format: 输出格式，支持 dict/html/markdown
        """
        report = {
            'report_id': f"COMPLIANCE_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            'generated_at': datetime.now().isoformat(),
            'version': 'v1.0.0',
            'overall_compliance': True,
            'summary': {
                'total_requirements': len(self.requirements),
                'satisfied_requirements': sum(1 for r in self.requirements if r.is_satisfied),
                'unsatisfied_requirements': sum(1 for r in self.requirements if not r.is_satisfied),
                'audit_log_entries': len(self.audit_log)
            },
            'requirements_by_law': {},
            'recommendations': []
        }
        
        # 按法律分组
        law_groups = defaultdict(list)
        for req in self.requirements:
            law_groups[req.law.value].append(asdict(req))
        
        for law, requirements in law_groups.items():
            satisfied = sum(1 for r in requirements if r['is_satisfied'])
            total = len(requirements)
            report['requirements_by_law'][law] = {
                'total': total,
                'satisfied': satisfied,
                'compliance_rate': f"{satisfied/total*100:.1f}%" if total > 0 else "0%",
                'requirements': requirements
            }
            report['overall_compliance'] = report['overall_compliance'] and satisfied == total
            
            if satisfied < total:
                report['recommendations'].append(
                    f"[{law}] {total - satisfied}项合规要求未满足"
                )
        
        # 用户权利保障
        report['user_rights'] = {
            'total': len(self.user_rights),
            'supported': sum(1 for r in self.user_rights if r.is_supported),
            'details': [
                {
                    'type': r.right_type,
                    'description': r.description,
                    'is_supported': r.is_supported,
                    'endpoint': r.endpoint
                }
                for r in self.user_rights
            ]
        }
        
        # 最近的审计日志
        report['recent_audit_logs'] = [
            asdict(entry) for entry in self.audit_log[-10:]
        ]
        
        return report
    
    def generate_html_report(self) -> str:
        """生成HTML格式合规报告"""
        report = self.generate_compliance_report()
        
        html = f"""
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>邮件安全守门员 - 合规报告</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        h1 {{ color: #1a1a2e; border-bottom: 3px solid #4361ee; padding-bottom: 10px; }}
        h2 {{ color: #3730a3; margin-top: 30px; }}
        .summary {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; margin: 20px 0; }}
        .compliance-badge {{ display: inline-block; padding: 8px 16px; border-radius: 20px; font-weight: bold; }}
        .pass {{ background: #10b981; color: white; }}
        .fail {{ background: #ef4444; color: white; }}
        table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }}
        th {{ background: #f3f4f6; font-weight: 600; }}
        .law-section {{ background: #f9fafb; padding: 15px; border-radius: 8px; margin: 10px 0; }}
        .recommendation {{ background: #fef3c7; padding: 10px; border-left: 4px solid #f59e0b; margin: 5px 0; }}
        .rights-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 10px; }}
        .right-card {{ background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 10px; }}
        .right-card.supported {{ border-color: #10b981; }}
        .right-card.unsupported {{ border-color: #ef4444; }}
    </style>
</head>
<body>
    <h1>🛡️ 邮件安全守门员合规报告</h1>
    
    <div class="summary">
        <h2 style="color: white; margin-top: 0;">报告概览</h2>
        <p><strong>报告ID:</strong> {report['report_id']}</p>
        <p><strong>生成时间:</strong> {report['generated_at']}</p>
        <p><strong>总体合规状态:</strong> <span class="compliance-badge {'pass' if report['overall_compliance'] else 'fail'}">
            {'✅ 合规' if report['overall_compliance'] else '⚠️ 存在不合规项'}
        </span></p>
        <p><strong>满足要求:</strong> {report['summary']['satisfied_requirements']}/{report['summary']['total_requirements']}</p>
    </div>
    
    <h2>📋 各法规合规情况</h2>
"""
        
        for law, data in report['requirements_by_law'].items():
            compliance_class = 'pass' if data['satisfied'] == data['total'] else 'fail'
            html += f"""
    <div class="law-section">
        <h3>{law} - <span class="compliance-badge {compliance_class}">{data['compliance_rate']}</span></h3>
        <table>
            <tr><th>要求</th><th>描述</th><th>条款</th><th>状态</th></tr>
"""
            for req in data['requirements']:
                status_icon = '✅' if req['is_satisfied'] else '⚠️'
                html += f"""
            <tr>
                <td>{req['requirement']}</td>
                <td>{req['description']}</td>
                <td>{req['article']}</td>
                <td>{status_icon} {'满足' if req['is_satisfied'] else '不满足'}</td>
            </tr>
"""
            html += """
        </table>
    </div>
"""
        
        html += """
    <h2>👤 用户权利保障</h2>
    <div class="rights-grid">
"""
        for right in report['user_rights']['details']:
            status_class = 'supported' if right['is_supported'] else 'unsupported'
            status_icon = '✅' if right['is_supported'] else '❌'
            html += f"""
        <div class="right-card {status_class}">
            <strong>{status_icon} {right['type']}</strong>
            <p>{right['description']}</p>
            <small>端点: {right['endpoint']}</small>
        </div>
"""
        
        html += """
    </div>
    
    <h2>💡 改进建议</h2>
"""
        for rec in report['recommendations']:
            html += f'<div class="recommendation">{rec}</div>'
        
        if not report['recommendations']:
            html += '<p>🎉 所有合规要求均已满足！</p>'
        
        html += """
    <footer style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 12px;">
        <p>本报告由邮件安全守门员自动生成 · 仅供内部参考</p>
    </footer>
</body>
</html>
"""
        return html
    
    # ========== 辅助方法 ==========
    
    def _count_business_days(self, start: datetime, end: datetime) -> int:
        """计算工作日数"""
        days = 0
        current = start
        while current <= end:
            if current.weekday() < 5:  # 周一到周五
                days += 1
            current += timedelta(days=1)
        return days
    
    def log_audit(self, action: str, details: Dict, user_id: str = ""):
        """记录审计日志"""
        entry = AuditEntry(
            timestamp=datetime.now().isoformat(),
            action=action,
            details=details,
            user_id=user_id,
            result="success"
        )
        self.audit_log.append(entry)
        logger.info(f"📝 审计日志: {action} - 用户: {user_id or 'system'}")
    
    def set_requirement_satisfied(self, law: str, requirement: str, satisfied: bool, evidence: str = ""):
        """更新合规要求状态"""
        for req in self.requirements:
            if req.law.value == law and req.requirement == requirement:
                req.is_satisfied = satisfied
                req.evidence = evidence
                req.last_checked = datetime.now().isoformat()
                logger.info(f"📝 合规更新: [{law}] {requirement} = {satisfied}")
                break
    
    def get_law_article(self, law: ComplianceLaw, requirement: str) -> str:
        """获取法规条款"""
        if law in self.LAW_ARTICLES and requirement in self.LAW_ARTICLES[law]:
            return self.LAW_ARTICLES[law][requirement]
        return ""


# ========== 邮件证据保存 ==========

class EmailEvidencePreserver:
    """邮件证据保存器（电子签名法第6条）"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.preserved_emails = []
        self.retention_years = self.config.get('retention_years', 3)
    
    def preserve_email(self, email_data: Dict) -> Dict:
        """
        保存邮件证据
        要求：重要邮件证据需保存3年以上
        """
        evidence = {
            'evidence_id': f"EV_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            'preserved_at': datetime.now().isoformat(),
            'retention_until': (datetime.now() + timedelta(days=365*self.retention_years)).isoformat(),
            'email_data': email_data,
            'integrity_hash': self._calculate_hash(email_data),
            'metadata': {
                'format': 'EML',
                'encryption': 'AES-256',
                'compliance': ['电子签名法第6条', '电子商务法第48条']
            }
        }
        
        self.preserved_emails.append(evidence)
        logger.info(f"📧 邮件证据已保存: {evidence['evidence_id']}")
        
        return evidence
    
    def verify_evidence(self, evidence_id: str) -> Dict:
        """验证证据完整性"""
        for evidence in self.preserved_emails:
            if evidence['evidence_id'] == evidence_id:
                current_hash = self._calculate_hash(evidence['email_data'])
                is_valid = current_hash == evidence['integrity_hash']
                
                return {
                    'evidence_id': evidence_id,
                    'is_valid': is_valid,
                    'preserved_at': evidence['preserved_at'],
                    'verification_time': datetime.now().isoformat()
                }
        
        return {'error': 'Evidence not found'}
    
    def _calculate_hash(self, data: Dict) -> str:
        """计算数据哈希（简化版）"""
        import hashlib
        data_str = str(sorted(data.items()))
        return hashlib.sha256(data_str.encode()).hexdigest()


# ========== 使用示例 ==========

if __name__ == "__main__":
    # 初始化
    print("=" * 60)
    print("🛡️ 邮件安全守门员 - 合规检查器测试")
    print("=" * 60)
    
    # 创建检查器
    checker = ComplianceChecker({
        'log_retention_days': 200,
        'dpo_appointed': True
    })
    
    # 1. 测试日志留存检查
    print("\n📋 1. 日志留存合规检查")
    result = checker.check_log_retention(90)
    print(f"   结果: {result['status']}")
    print(f"   建议: {result['recommendation']}")
    
    # 2. 测试用户同意检查
    print("\n📋 2. 用户同意合规检查")
    email_data = {
        'user_consent': True,
        'consent_time': '2026-01-01T00:00:00',
        'consent_type': 'explicit'
    }
    result = checker.check_consent(email_data)
    print(f"   结果: {result['status']}")
    
    # 3. 测试最小必要原则
    print("\n📋 3. 最小必要原则检查")
    email_data = {
        'sender': 'test@example.com',
        'recipient': 'user@example.com',
        'subject': 'Test',
        'timestamp': '2026-01-01T00:00:00',
        'message_id': '123'
    }
    result = checker.check_minimal_necessity(email_data)
    print(f"   结果: {result['status']}")
    
    # 4. 测试GDPR合规
    print("\n📋 4. GDPR合规检查")
    result = checker.check_gdpr_compliance({'gdpr_lawful_basis': 'consent'})
    print(f"   结果: {result['status']}")
    
    # 5. 测试数据主体权利
    print("\n📋 5. 数据主体权利检查")
    result = checker.check_data_subject_rights()
    print(f"   支持的权利: {result['supported_count']}/{result['total_count']}")
    
    # 6. 生成完整合规报告
    print("\n📋 6. 生成合规报告")
    report = checker.generate_compliance_report()
    print(f"   报告ID: {report['report_id']}")
    print(f"   总体合规: {'是' if report['overall_compliance'] else '否'}")
    print(f"   满足要求: {report['summary']['satisfied_requirements']}/{report['summary']['total_requirements']}")
    
    # 7. 测试证据保存
    print("\n📋 7. 邮件证据保存")
    preserver = EmailEvidencePreserver()
    evidence = preserver.preserve_email(email_data)
    print(f"   证据ID: {evidence['evidence_id']}")
    print(f"   保存期限: {evidence['retention_until']}")
    
    print("\n" + "=" * 60)
    print("✅ 合规检查器测试完成")
    print("=" * 60)
