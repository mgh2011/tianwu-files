"""
超级优化引擎 - 百万并发引擎
Million Concurrency Engine - 百万级并发处理能力
"""

from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime
import time
import threading
import asyncio
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from queue import Queue, PriorityQueue, LifoQueue
import hashlib
import json


@dataclass
class Worker:
    """工作器"""
    worker_id: str
    status: str
    tasks_processed: int = 0
    current_task: Optional[str] = None


@dataclass
class Task:
    """任务"""
    task_id: str
    priority: int
    handler: Callable
    args: tuple = ()
    kwargs: dict = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    timeout: float = 30.0


@dataclass
class ConcurrencyStats:
    """并发统计"""
    total_tasks: int = 0
    completed_tasks: int = 0
    failed_tasks: int = 0
    active_workers: int = 0
    queued_tasks: int = 0
    throughput_rps: float = 0.0
    avg_latency_ms: float = 0.0


class MillionConcurrencyEngine:
    """百万并发引擎"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化百万并发引擎

        Args:
            config: 配置字典
        """
        self.config = config or {}

        # 核心配置
        self.max_workers = self.config.get('max_workers', 10000)
        self.max_queue_size = self.config.get('max_queue_size', 1000000)
        self.batch_size = self.config.get('batch_size', 1000)
        self.timeout_default = self.config.get('timeout', 60.0)

        # 线程池
        self.thread_pool = ThreadPoolExecutor(
            max_workers=min(self.max_workers, 1000),
            thread_name_prefix="mce_worker_"
        )

        # 进程池
        self.process_pool = ProcessPoolExecutor(
            max_workers=min(self.max_workers // 10, 100)
        )

        # 任务队列
        self.task_queue: PriorityQueue = PriorityQueue(maxsize=self.max_queue_size)
        self.result_queue: Queue = Queue(maxsize=self.max_queue_size)

        # 工作器管理
        self.workers: Dict[str, Worker] = {}
        self.worker_lock = threading.Lock()

        # 统计
        self.stats = ConcurrencyStats()
        self.stats_lock = threading.Lock()

        # 性能追踪
        self.latencies: List[float] = []
        self.throughput_samples: List[float] = []
        self.start_time = time.time()

        # 运行状态
        self.running = False
        self.dispatcher_thread: Optional[threading.Thread] = None

    def start(self):
        """启动引擎"""
        if self.running:
            return

        self.running = True
        self.start_time = time.time()

        # 启动任务分发线程
        self.dispatcher_thread = threading.Thread(
            target=self._dispatch_loop,
            daemon=True,
            name="mce_dispatcher"
        )
        self.dispatcher_thread.start()

        # 初始化工作器
        self._initialize_workers()

    def stop(self):
        """停止引擎"""
        self.running = False

        if self.dispatcher_thread:
            self.dispatcher_thread.join(timeout=5)

        self.thread_pool.shutdown(wait=False)
        self.process_pool.shutdown(wait=False)

    def submit(self, handler: Callable, args: tuple = (), kwargs: dict = None,
               priority: int = 5, timeout: float = None) -> str:
        """
        提交任务

        Args:
            handler: 处理函数
            args: 位置参数
            kwargs: 关键字参数
            priority: 优先级(1-10, 1最高)
            timeout: 超时时间

        Returns:
            任务ID
        """
        kwargs = kwargs or {}
        timeout = timeout or self.timeout_default

        task = Task(
            task_id=self._generate_task_id(),
            priority=priority,
            handler=handler,
            args=args,
            kwargs=kwargs,
            timeout=timeout
        )

        try:
            self.task_queue.put_nowait(task)

            with self.stats_lock:
                self.stats.total_tasks += 1
                self.stats.queued_tasks = self.task_queue.qsize()

            return task.task_id

        except:
            return None

    def submit_batch(self, tasks: List[Dict]) -> List[str]:
        """
        批量提交任务

        Args:
            tasks: 任务列表

        Returns:
            任务ID列表
        """
        task_ids = []

        for task in tasks:
            task_id = self.submit(
                handler=task.get('handler'),
                args=task.get('args', ()),
                kwargs=task.get('kwargs', {}),
                priority=task.get('priority', 5),
                timeout=task.get('timeout')
            )
            if task_id:
                task_ids.append(task_id)

        return task_ids

    def submit_parallel(self, handlers: List[Callable], args_list: List[tuple] = None) -> List[Any]:
        """
        并行执行

        Args:
            handlers: 处理函数列表
            args_list: 参数列表

        Returns:
            结果列表
        """
        args_list = args_list or [()] * len(handlers)
        results = []

        # 使用线程池并行执行
        futures = []
        for handler, args in zip(handlers, args_list):
            future = self.thread_pool.submit(handler, *args)
            futures.append(future)

        # 收集结果
        for future in as_completed(futures, timeout=self.timeout_default):
            try:
                result = future.result()
                results.append({'success': True, 'result': result})
            except Exception as e:
                results.append({'success': False, 'error': str(e)})

        return results

    def map_reduce(self, data: List[Any], mapper: Callable,
                   reducer: Callable, workers: int = None) -> Any:
        """
        MapReduce处理

        Args:
            data: 数据列表
            mapper: Map函数
            reducer: Reduce函数
            workers: 工作线程数

        Returns:
            处理结果
        """
        workers = workers or min(len(data), 100)

        # Map阶段
        chunk_size = max(1, len(data) // workers)
        chunks = [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]

        # 并行Map
        with ThreadPoolExecutor(max_workers=len(chunks)) as executor:
            map_futures = [
                executor.submit(self._map_chunk, chunk, mapper)
                for chunk in chunks
            ]

            mapped_results = []
            for future in as_completed(map_futures):
                try:
                    mapped_results.extend(future.result())
                except:
                    pass

        # Reduce阶段
        return reducer(mapped_results)

    def pipeline(self, stages: List[Callable], data: Any, buffer_size: int = 100) -> Any:
        """
        流水线处理

        Args:
            stages: 处理阶段
            data: 输入数据
            buffer_size: 缓冲区大小

        Returns:
            处理结果
        """
        # 创建阶段队列
        queues = [Queue(maxsize=buffer_size) for _ in range(len(stages))]

        # 启动工作线程
        threads = []
        for i, stage in enumerate(stages):
            if i == 0:
                input_queue = None
            else:
                input_queue = queues[i - 1]

            thread = threading.Thread(
                target=self._pipeline_stage,
                args=(stage, input_queue, queues[i], i == len(stages) - 1),
                daemon=True
            )
            thread.start()
            threads.append(thread)

        # 放入初始数据
        queues[0].put(data)

        # 等待完成
        for thread in threads:
            thread.join(timeout=self.timeout_default)

        # 返回最终结果
        return queues[-1].get_nowait() if not queues[-1].empty() else None

    def fan_out(self, handler: Callable, data_list: List[Any],
                workers: int = None, mode: str = 'thread') -> List[Any]:
        """
        扇出处理

        Args:
            handler: 处理函数
            data_list: 数据列表
            workers: 工作数
            mode: 模式(thread/process)

        Returns:
            结果列表
        """
        workers = workers or min(len(data_list), 100)
        pool = self.thread_pool if mode == 'thread' else self.process_pool

        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = [executor.submit(handler, data) for data in data_list]

            results = []
            for future in as_completed(futures, timeout=self.timeout_default):
                try:
                    results.append(future.result())
                except Exception as e:
                    results.append({'error': str(e)})

        return results

    def get_stats(self) -> ConcurrencyStats:
        """获取统计"""
        with self.stats_lock:
            # 计算实时吞吐量
            elapsed = time.time() - self.start_time
            if elapsed > 0:
                self.stats.throughput_rps = self.stats.completed_tasks / elapsed

            # 计算平均延迟
            if self.latencies:
                self.stats.avg_latency_ms = sum(self.latencies) / len(self.latencies)

            self.stats.queued_tasks = self.task_queue.qsize()
            self.stats.active_workers = len([
                w for w in self.workers.values()
                if w.status == 'busy'
            ])

            return self.stats

    def _dispatch_loop(self):
        """任务分发循环"""
        while self.running:
            try:
                # 获取任务
                try:
                    task = self.task_queue.get(timeout=0.1)
                except:
                    continue

                # 分配给工作器
                worker = self._get_available_worker()
                if worker:
                    self._assign_task(worker, task)
                else:
                    # 放回队列
                    self.task_queue.put(task)

            except Exception as e:
                pass

    def _initialize_workers(self):
        """初始化工作器"""
        with self.worker_lock:
            for i in range(min(self.max_workers, 100)):
                worker_id = f"worker_{i:04d}"
                self.workers[worker_id] = Worker(
                    worker_id=worker_id,
                    status='idle'
                )

    def _get_available_worker(self) -> Optional[Worker]:
        """获取可用工作器"""
        with self.worker_lock:
            for worker in self.workers.values():
                if worker.status == 'idle':
                    return worker
        return None

    def _assign_task(self, worker: Worker, task: Task):
        """分配任务"""
        worker.status = 'busy'
        worker.current_task = task.task_id

        # 提交到线程池
        future = self.thread_pool.submit(self._execute_task, task)

    def _execute_task(self, task: Task) -> Any:
        """执行任务"""
        start_time = time.time()

        try:
            result = task.handler(*task.args, **task.kwargs)

            latency = (time.time() - start_time) * 1000

            with self.stats_lock:
                self.stats.completed_tasks += 1
                self.latencies.append(latency)
                if len(self.latencies) > 1000:
                    self.latencies = self.latencies[-500:]

            # 标记工作器空闲
            self._mark_worker_idle(task.task_id)

            return result

        except Exception as e:
            with self.stats_lock:
                self.stats.failed_tasks += 1

            self._mark_worker_idle(task.task_id)
            return {'error': str(e)}

    def _mark_worker_idle(self, task_id: str):
        """标记工作器空闲"""
        with self.worker_lock:
            for worker in self.workers.values():
                if worker.current_task == task_id:
                    worker.status = 'idle'
                    worker.current_task = None
                    worker.tasks_processed += 1
                    break

    def _map_chunk(self, chunk: List, mapper: Callable) -> List:
        """Map一个数据块"""
        return [mapper(item) for item in chunk]

    def _pipeline_stage(self, stage: Callable, input_queue: Optional[Queue],
                       output_queue: Queue, is_last: bool):
        """流水线阶段"""
        while True:
            try:
                if input_queue:
                    data = input_queue.get(timeout=1.0)
                else:
                    break

                result = stage(data)

                if not is_last:
                    output_queue.put(result)
                else:
                    output_queue.put(result)
                    break

            except:
                break

    def _generate_task_id(self) -> str:
        """生成任务ID"""
        return f"T-{hashlib.md5(str(time.time()).encode()).hexdigest()[:16].upper()}"


# 示例函数
def sample_handler(data: Any) -> Dict:
    """示例处理函数"""
    time.sleep(0.001)  # 模拟处理
    return {'processed': True, 'data': data, 'timestamp': time.time()}


def sample_mapper(item: Any) -> Dict:
    """示例Map函数"""
    return {'key': str(item), 'value': item * 2}


def sample_reducer(results: List[Dict]) -> Dict:
    """示例Reduce函数"""
    return {'count': len(results), 'sum': sum(r.get('value', 0) for r in results)}


# 独立运行测试
if __name__ == "__main__":
    engine = MillionConcurrencyEngine({
        'max_workers': 10000,
        'max_queue_size': 100000,
        'batch_size': 1000,
        'timeout': 60.0
    })

    print("=" * 60)
    print("百万并发引擎测试")
    print("=" * 60)

    # 启动引擎
    print("\n1. 启动引擎...")
    engine.start()
    print("   引擎已启动")

    # 提交单个任务
    print("\n2. 提交单个任务...")
    task_id = engine.submit(sample_handler, args=({'id': 1},))
    print(f"   任务ID: {task_id}")

    # 批量提交任务
    print("\n3. 批量提交任务...")
    tasks = [{'handler': sample_handler, 'args': ({'id': i},), 'priority': 5}
             for i in range(100)]
    task_ids = engine.submit_batch(tasks)
    print(f"   提交任务: {len(task_ids)} 个")

    # 并行执行测试
    print("\n4. 并行执行测试...")
    handlers = [sample_handler for _ in range(100)]
    args_list = [({'id': i},) for i in range(100)]

    start = time.time()
    results = engine.submit_parallel(handlers, args_list)
    parallel_time = (time.time() - start) * 1000

    success_count = sum(1 for r in results if r.get('success'))
    print(f"   并行执行100个任务: {parallel_time:.2f}ms")
    print(f"   成功率: {success_count}/{len(results)}")

    # MapReduce测试
    print("\n5. MapReduce测试...")
    data = list(range(10000))
    start = time.time()
    mr_result = engine.map_reduce(data, sample_mapper, sample_reducer, workers=50)
    mr_time = (time.time() - start) * 1000
    print(f"   处理10000条数据: {mr_time:.2f}ms")
    print(f"   吞吐量: {10000/(mr_time/1000):.0f} items/s")

    # 扇出测试
    print("\n6. 扇出测试...")
    data_list = list(range(5000))
    start = time.time()
    fanout_results = engine.fan_out(sample_handler, data_list, workers=100)
    fanout_time = (time.time() - start) * 1000
    success = sum(1 for r in fanout_results if not r.get('error'))
    print(f"   扇出处理5000个任务: {fanout_time:.2f}ms")
    print(f"   吞吐量: {5000/(fanout_time/1000):.0f} items/s")

    # 流水线测试
    print("\n7. 流水线测试...")

    def stage1(x): return x * 2
    def stage2(x): return x + 10
    def stage3(x): return x / 2

    start = time.time()
    pipeline_results = []
    for _ in range(10000):
        result = engine.pipeline([stage1, stage2, stage3], 100)
        pipeline_results.append(result)
    pipeline_time = (time.time() - start) * 1000
    print(f"   流水线执行10000次: {pipeline_time:.2f}ms")
    print(f"   平均耗时: {pipeline_time/10000:.4f}ms")

    # 获取统计
    print("\n8. 并发统计:")
    stats = engine.get_stats()
    print(f"   总任务数: {stats.total_tasks}")
    print(f"   已完成任务: {stats.completed_tasks}")
    print(f"   失败任务: {stats.failed_tasks}")
    print(f"   活跃工作器: {stats.active_workers}")
    print(f"   队列任务: {stats.queued_tasks}")
    print(f"   吞吐量: {stats.throughput_rps:.0f} RPS")
    print(f"   平均延迟: {stats.avg_latency_ms:.2f}ms")

    # 停止引擎
    engine.stop()
    print("\n   引擎已停止")

    print("\n" + "=" * 60)
    print("百万并发引擎测试完成")
    print("=" * 60)
