"""
诱饵注入模块
Decoy Injection Module

提供诱饵数据注入功能
"""

__version__ = "v3.0.0"
__all__ = []
