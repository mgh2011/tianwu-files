"""
API模块
REST API Module

提供企业级综合安全引擎的REST API接口
"""

from .api_server import (
    SecurityAPIServer,
    SecurityAPIHandler,
    APIResponse,
    create_api_server,
    start_api_server
)

__version__ = "v3.0.0"
__all__ = [
    'SecurityAPIServer',
    'SecurityAPIHandler',
    'APIResponse',
    'create_api_server',
    'start_api_server'
]
