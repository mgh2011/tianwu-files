# dialog_engine/policy/response_generator.py
"""
回复生成器
支持文本、卡片、快捷按钮等多种形式
"""

import logging
import re
from typing import Dict, List, Optional, Any
from string import Template

from ..models.data_models import (
    DialogResponse, DialogRequest, IntentResult, SlotFillingResult,
    Message, QuickReply, Card, MessageType, DialogPolicy, DialogContext
)
from ..config.default_config import config


logger = logging.getLogger(__name__)


class ResponseGenerator:
    """
    多模态回复生成器
    支持文本、卡片、快捷按钮等多种形式
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        self.config = config_dict or config.RESPONSE_GENERATOR
        self.max_length = self.config.get("max_response_length", 2000)
        self.enable_template = self.config.get("enable_template_rendering", True)
        self.enable_multimodal = self.config.get("enable_multimodal", True)
        self.quick_reply_limit = self.config.get("quick_reply_limit", 5)
        
        # 响应模板库
        self.templates: Dict[str, Dict[str, str]] = {}
        self._init_default_templates()
        
    def _init_default_templates(self):
        """初始化默认模板"""
        self.templates = {
            "greeting": {
                "default": "您好！很高兴为您服务。有什么可以帮您的吗？",
                "morning": "早上好！请问有什么可以帮您？",
                "afternoon": "下午好！请问有什么需要？",
                "evening": "晚上好！请问有什么可以帮您？",
            },
            "goodbye": {
                "default": "再见！如有需要随时找我。",
                "satisfied": "感谢您的使用，祝您生活愉快！",
                "unsatisfied": "希望下次能更好地为您服务，再见！",
            },
            "help": {
                "default": "我可以帮您：\n1. 查询信息\n2. 预约服务\n3. 解答问题\n4. 处理投诉\n\n请告诉我您的需求。",
            },
            "slot_prompt": {
                "default": "请提供${slot_name}",
                "phone": "请留下您的联系电话",
                "email": "请提供您的邮箱地址",
                "date": "请选择日期",
                "time": "请选择时间",
                "location": "请告诉我您的位置",
            },
            "confirm": {
                "default": "您确认${slot_name}是${value}吗？",
            },
            "success": {
                "default": "好的，已为您${action}。",
                "booking": "预约成功！我们已收到您的请求。",
                "payment": "支付成功！感谢您的付款。",
            },
            "error": {
                "default": "抱歉，处理您的请求时遇到问题，请稍后重试。",
                "validation": "请检查输入信息是否正确。",
                "timeout": "请求超时，请重试。",
            },
            "fallback": {
                "default": "抱歉，我没能理解您的意思。您可以：\n1. 换个说法描述\n2. 联系人工客服\n3. 尝试其他问题",
            }
        }
    
    async def generate(self,
                      response_id: str,
                      request: DialogRequest,
                      intent_result: Optional[IntentResult],
                      entities: List,
                      slot_result: SlotFillingResult,
                      policy: Optional[DialogPolicy],
                      context: Optional[DialogContext]) -> DialogResponse:
        """
        回复生成
        
        Args:
            response_id: 响应ID
            request: 对话请求
            intent_result: 意图识别结果
            entities: 实体列表
            slot_result: 槽位填充结果
            policy: 对话策略
            context: 对话上下文
            
        Returns:
            DialogResponse: 对话响应
        """
        # 确定使用的模板
        template_key = self._get_template_key(intent_result, policy)
        
        # 获取响应模板
        template_data = self._get_template(template_key)
        
        # 准备模板参数
        params = self._prepare_template_params(
            intent_result, entities, slot_result, context
        )
        
        # 渲染文本内容
        content = await self._render_content(template_data.get("default", ""), params)
        
        # 生成快捷回复
        quick_replies = self._generate_quick_replies(intent_result, policy)
        
        # 创建消息对象
        message = Message(
            type=MessageType.TEXT,
            content=content,
            quick_replies=quick_replies
        )
        
        # 构建响应
        response = DialogResponse(
            response_id=response_id,
            session_id=request.session_id,
            message=message,
            intent=intent_result.intent.value if intent_result else None,
            entities=[e.to_dict() for e in entities] if entities else [],
            slots={k: v.value for k, v in slot_result.filled_slots.items()},
            is_final=True
        )
        
        return response
    
    def _get_template_key(self, intent_result: Optional[IntentResult],
                         policy: Optional[DialogPolicy]) -> str:
        """获取模板键"""
        if policy and policy.name != "fallback":
            return policy.name
        
        if intent_result:
            return intent_result.intent.value
        
        return "fallback"
    
    def _get_template(self, key: str) -> Dict[str, str]:
        """获取模板"""
        return self.templates.get(key, {"default": self.templates["fallback"]["default"]})
    
    def _prepare_template_params(self,
                                intent_result: Optional[IntentResult],
                                entities: List,
                                slot_result: SlotFillingResult,
                                context: Optional[DialogContext]) -> Dict[str, Any]:
        """准备模板参数"""
        params = {
            "user_name": context.variables.get("user_name", "用户") if context else "用户",
            "slots": {},
        }
        
        # 添加槽位值
        for slot_name, slot in slot_result.filled_slots.items():
            params["slots"][slot_name] = slot.value
            params[slot_name] = slot.value
        
        # 添加实体值
        for entity in entities:
            entity_type = str(entity.type.value)
            params[entity_type] = entity.value
            if entity.normalized_value:
                params[f"{entity_type}_normalized"] = entity.normalized_value
        
        # 添加意图信息
        if intent_result:
            params["intent"] = intent_result.intent.value
        
        return params
    
    async def _render_content(self, template: str,
                             params: Dict[str, Any]) -> str:
        """渲染内容"""
        if not self.enable_template:
            return template
        
        try:
            # 使用字符串模板
            t = Template(template)
            content = t.safe_substitute(params)
            
            # 限制长度
            if len(content) > self.max_length:
                content = content[:self.max_length - 3] + "..."
            
            return content
            
        except Exception as e:
            logger.error(f"Template rendering error: {e}")
            return template
    
    def _generate_quick_replies(self,
                              intent_result: Optional[IntentResult],
                              policy: Optional[DialogPolicy]) -> List[QuickReply]:
        """生成快捷回复"""
        quick_replies = []
        
        # 从策略获取
        if policy and hasattr(policy, 'quick_replies'):
            for text in policy.quick_replies[:self.quick_reply_limit]:
                quick_replies.append(QuickReply(text=text, value=text))
        
        # 根据意图添加默认快捷回复
        if intent_result:
            intent_name = intent_result.intent.value
            
            default_replies = {
                "greeting": ["查询信息", "预约服务", "联系客服"],
                "query": ["查看详情", "换个问题", "联系客服"],
                "booking": ["修改预约", "取消预约", "查看预约"],
            }
            
            if intent_name in default_replies:
                for text in default_replies[intent_name][:self.quick_reply_limit]:
                    if not any(qr.text == text for qr in quick_replies):
                        quick_replies.append(QuickReply(text=text, value=text))
        
        return quick_replies
    
    async def generate_card(self, card_type: str,
                           data: Dict[str, Any]) -> Card:
        """生成卡片"""
        card = Card(card_type=card_type)
        
        if card_type == "product":
            card.title = data.get("name", "")
            card.content = data.get("description", "")
            card.image_url = data.get("image_url")
            card.actions = [
                {"text": "购买", "value": "buy"},
                {"text": "收藏", "value": "favorite"},
            ]
        elif card_type == "info":
            card.title = data.get("title", "")
            card.content = data.get("content", "")
        
        return card
    
    async def generate_confirmation(self,
                                   slot_name: str,
                                   value: Any) -> DialogResponse:
        """生成确认消息"""
        template = self.templates.get("confirm", {}).get("default",
            "您确认${slot_name}是${value}吗？")
        
        params = {"slot_name": slot_name, "value": value}
        content = await self._render_content(template, params)
        
        message = Message(
            type=MessageType.TEXT,
            content=content,
            quick_replies=[
                QuickReply(text="是的", value="confirm"),
                QuickReply(text="不对", value="deny"),
            ]
        )
        
        return DialogResponse(
            response_id=f"conf_{id(self)}",
            session_id="",
            message=message
        )
    
    def register_template(self, key: str, templates: Dict[str, str]):
        """注册模板"""
        self.templates[key] = templates
        logger.info(f"Registered template: {key}")
    
    def update_template(self, key: str, sub_key: str, template: str):
        """更新模板"""
        if key not in self.templates:
            self.templates[key] = {}
        self.templates[key][sub_key] = template
        logger.info(f"Updated template: {key}.{sub_key}")
