"""
联动引擎模块
Linkage Engine Module

提供跨系统事件、数据、流程、告警、响应联动功能
"""

__version__ = "v3.0.0"
__all__ = []
