"""
网络防护模块
Network Protection Module

提供IDS/IPS等网络入侵检测功能
"""

from .ids import IDSModule

__version__ = "v3.0.0"
__all__ = [
    'IDSModule'
]
