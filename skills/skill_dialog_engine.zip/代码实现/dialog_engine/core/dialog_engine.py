# dialog_engine/core/dialog_engine.py
"""
对话引擎主控制器
负责协调各子模块，处理对话流程
"""

import asyncio
import logging
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from uuid import uuid4

from ..models.data_models import (
    DialogRequest, DialogResponse, DialogState, Session,
    IntentResult, Entity, Slot, SlotFillingResult,
    Message, QuickReply, Card, MessageType, IntentType,
    ResponseCode
)
from ..config.default_config import config
from .state_manager import DialogStateManager
from .context_manager import ContextManager

logger = logging.getLogger(__name__)


class DialogEngine:
    """
    对话引擎主控制器
    协调意图识别、策略选择、回复生成等模块
    """
    
    def __init__(self, config_dict: Optional[Dict] = None):
        # 加载配置
        self.config = config_dict or {}
        self._setup_components()
        
        # 组件引用(将由外部注入或使用默认实现)
        self.intent_classifier = None
        self.entity_extractor = None
        self.slot_filler = None
        self.policy_router = None
        self.response_generator = None
        self.short_term_memory = None
        self.long_term_memory = None
        self.user_profile = None
        self.content_filter = None
        self.privacy_guard = None
        self.audit_logger = None
        
        # 钩子函数
        self.pre_process_hook: Optional[Callable] = None
        self.post_process_hook: Optional[Callable] = None
        
    def _setup_components(self):
        """初始化组件"""
        # 状态管理器
        self.state_manager = DialogStateManager(
            self.config.get("state_manager", {})
        )
        
        # 上下文管理器
        self.context_manager = ContextManager(
            self.config.get("context_manager", {})
        )
        
        # 性能指标
        self.metrics = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "avg_response_time": 0,
        }
        
    def register_component(self, name: str, component: Any):
        """注册组件"""
        setattr(self, name, component)
        logger.info(f"Registered component: {name}")
        
    def set_hooks(self, pre_hook: Optional[Callable] = None,
                  post_hook: Optional[Callable] = None):
        """设置钩子函数"""
        self.pre_process_hook = pre_hook
        self.post_process_hook = post_hook
        
    async def process_message(self, request: DialogRequest) -> DialogResponse:
        """
        处理用户消息
        
        Args:
            request: 对话请求对象
            
        Returns:
            DialogResponse: 对话响应对象
        """
        start_time = time.time()
        response_id = f"resp_{uuid4().hex[:12]}"
        
        try:
            self.metrics["total_requests"] += 1
            
            # 检查会话是否存在
            session = self.state_manager.get_session(request.session_id)
            if not session:
                # 创建新会话
                session = self.state_manager.create_session(
                    request.session_id,
                    request.user_id
                )
                self.context_manager.create_context(
                    request.session_id,
                    request.user_id
                )
            
            # 触发前置钩子
            if self.pre_process_hook:
                request = await self.pre_process_hook(request) or request
            
            # 内容安全检查
            if self.content_filter:
                filter_result = await self.content_filter.check(request.message)
                if not filter_result.is_safe:
                    return self._create_error_response(
                        response_id,
                        request.session_id,
                        ResponseCode.CONTENT_BLOCKED,
                        filter_result.suggestion or "内容包含敏感信息"
                    )
            
            # 隐私保护
            if self.privacy_guard:
                protected_message = await self.privacy_guard.protect(request.message)
            else:
                protected_message = request.message
            
            # 状态转换: 等待意图识别
            self.state_manager.transition(request.session_id, "message")
            
            # 意图识别
            intent_result = await self._recognize_intent(protected_message, request)
            
            # 实体抽取
            entities = await self._extract_entities(protected_message, request)
            
            # 槽位填充
            slot_result = await self._fill_slots(
                intent_result, entities, request
            )
            
            # 策略路由
            policy = await self._route_policy(intent_result, request)
            
            # 更新上下文
            self.context_manager.update_context(
                request.session_id,
                intent=intent_result,
                entities=entities
            )
            self.context_manager.update_slots(
                request.session_id,
                slot_result.filled_slots
            )
            
            # 检查是否需要补槽
            if not slot_result.is_complete and slot_result.prompting_slot:
                response = await self._generate_slot_prompt(
                    response_id, request, slot_result
                )
                return response
            
            # 生成回复
            response = await self._generate_response(
                response_id, request, intent_result,
                entities, slot_result, policy
            )
            
            # 记录对话轮次
            self.context_manager.add_turn(
                request.session_id,
                request.message,
                response.message.content,
                intent=intent_result.intent.value if intent_result else None,
                entities=entities,
                slots={k: v.value for k, v in slot_result.filled_slots.items()},
                is_successful=True
            )
            
            # 状态转换: 回复完成
            self.state_manager.transition(request.session_id, "complete")
            
            # 更新记忆
            await self._update_memory(request, response)
            
            # 记录审计日志
            if self.audit_logger:
                await self.audit_logger.log(
                    request.session_id,
                    request.user_id,
                    "message_processed",
                    request.message,
                    "success"
                )
            
            # 触发后置钩子
            if self.post_process_hook:
                response = await self.post_process_hook(request, response) or response
            
            self.metrics["successful_requests"] += 1
            
            # 更新性能指标
            self._update_metrics(time.time() - start_time)
            
            return response
            
        except Exception as e:
            logger.error(f"Error processing message: {e}", exc_info=True)
            self.metrics["failed_requests"] += 1
            
            # 状态转换: 错误
            self.state_manager.transition(request.session_id, "error")
            
            return self._create_error_response(
                response_id,
                request.session_id,
                ResponseCode.GENERAL_ERROR,
                str(e)
            )
    
    async def _recognize_intent(self, message: str, 
                                 request: DialogRequest) -> Optional[IntentResult]:
        """意图识别"""
        if self.intent_classifier:
            context = self.context_manager.get_context(request.session_id)
            return await self.intent_classifier.classify(message, context)
        return None
    
    async def _extract_entities(self, message: str,
                                request: DialogRequest) -> List[Entity]:
        """实体抽取"""
        if self.entity_extractor:
            return await self.entity_extractor.extract(message)
        return []
    
    async def _fill_slots(self, intent_result: IntentResult,
                          entities: List[Entity],
                          request: DialogRequest) -> SlotFillingResult:
        """槽位填充"""
        if self.slot_filler:
            context = self.context_manager.get_context(request.session_id)
            return await self.slot_filler.fill_slots(intent_result, entities, context)
        
        # 默认返回完成
        return SlotFillingResult(
            is_complete=True,
            filled_slots={},
            missing_slots=[],
            invalid_slots=[]
        )
    
    async def _route_policy(self, intent_result: IntentResult,
                           request: DialogRequest):
        """策略路由"""
        if self.policy_router:
            context = self.context_manager.get_context(request.session_id)
            return await self.policy_router.route(intent_result, context)
        return None
    
    async def _generate_response(self, response_id: str,
                                 request: DialogRequest,
                                 intent_result: Optional[IntentResult],
                                 entities: List[Entity],
                                 slot_result: SlotFillingResult,
                                 policy) -> DialogResponse:
        """生成回复"""
        if self.response_generator:
            context = self.context_manager.get_context(request.session_id)
            return await self.response_generator.generate(
                response_id, request, intent_result, 
                entities, slot_result, policy, context
            )
        
        # 默认回复
        return self._create_default_response(
            response_id, request, intent_result, entities
        )
    
    async def _generate_slot_prompt(self, response_id: str,
                                   request: DialogRequest,
                                   slot_result: SlotFillingResult) -> DialogResponse:
        """生成槽位补全提示"""
        prompting_slot_name = slot_result.prompting_slot
        
        # 获取槽位配置
        slot_prompts = self.config.get("SLOT_FILLER", {}).get("common_slots", {})
        prompt_template = slot_prompts.get(prompting_slot_name, {}).get(
            "prompt", f"请提供{prompting_slot_name}"
        )
        
        message = Message(
            type=MessageType.TEXT,
            content=prompt_template,
            quick_replies=[
                QuickReply(text="跳过", value=f"skip_{prompting_slot_name}"),
                QuickReply(text="取消", value="cancel")
            ]
        )
        
        return DialogResponse(
            response_id=response_id,
            session_id=request.session_id,
            message=message,
            intent=request.message,
            entities=[e.to_dict() for e in []],
            slots={k: v.value for k, v in slot_result.filled_slots.items()},
            is_final=False
        )
    
    def _create_default_response(self, response_id: str,
                                request: DialogRequest,
                                intent_result: Optional[IntentResult],
                                entities: List[Entity]) -> DialogResponse:
        """创建默认响应"""
        intent_str = intent_result.intent.value if intent_result else "unknown"
        
        # 根据意图生成默认回复
        default_responses = {
            "greeting": "您好！有什么可以帮您的？",
            "goodbye": "再见！如有需要随时找我。",
            "help": "我可以帮您处理各种问题，请告诉我您的需求。",
            "unknown": "抱歉，我没能理解您的意思。请您换个方式描述。",
        }
        
        content = default_responses.get(intent_str, 
            "您好！请问有什么可以帮助您的？")
        
        message = Message(
            type=MessageType.TEXT,
            content=content
        )
        
        return DialogResponse(
            response_id=response_id,
            session_id=request.session_id,
            message=message,
            intent=intent_str,
            entities=[e.to_dict() for e in entities]
        )
    
    def _create_error_response(self, response_id: str, session_id: str,
                              code: int, message: str) -> DialogResponse:
        """创建错误响应"""
        msg = Message(
            type=MessageType.TEXT,
            content=f"抱歉，处理您的请求时遇到了问题：{message}"
        )
        
        return DialogResponse(
            response_id=response_id,
            session_id=session_id,
            message=msg,
            is_final=True,
            metadata={"error_code": code}
        )
    
    async def _update_memory(self, request: DialogRequest,
                            response: DialogResponse):
        """更新记忆"""
        # 更新短期记忆
        if self.short_term_memory:
            await self.short_term_memory.remember(
                f"last_message_{request.session_id}",
                request.message
            )
            await self.short_term_memory.remember(
                f"last_response_{request.session_id}",
                response.message.content
            )
        
        # 更新用户画像
        if self.user_profile:
            await self.user_profile.add_interaction(
                request.user_id,
                {
                    "timestamp": datetime.now().isoformat(),
                    "message": request.message,
                    "intent": response.intent
                }
            )
    
    def _update_metrics(self, response_time: float):
        """更新性能指标"""
        total = self.metrics["total_requests"]
        current_avg = self.metrics["avg_response_time"]
        
        # 移动平均
        self.metrics["avg_response_time"] = (
            (current_avg * (total - 1) + response_time) / total
        )
    
    async def start_session(self, session_id: str, user_id: str,
                          **kwargs) -> Session:
        """开始会话"""
        session = self.state_manager.create_session(session_id, user_id)
        self.context_manager.create_context(session_id, user_id)
        
        if self.audit_logger:
            await self.audit_logger.log(
                session_id, user_id, "session_start", "", "success"
            )
        
        logger.info(f"Session started: {session_id} for user: {user_id}")
        return session
    
    async def end_session(self, session_id: str) -> bool:
        """结束会话"""
        if self.audit_logger:
            session = self.state_manager.get_session(session_id)
            user_id = session.user_id if session else ""
            await self.audit_logger.log(
                session_id, user_id, "session_end", "", "success"
            )
        
        result = self.state_manager.end_session(session_id)
        self.context_manager.delete_context(session_id)
        
        logger.info(f"Session ended: {session_id}")
        return result
    
    async def get_session_state(self, session_id: str) -> Optional[Dict]:
        """获取会话状态"""
        session = self.state_manager.get_session(session_id)
        if not session:
            return None
        
        return {
            "session_id": session.session_id,
            "user_id": session.user_id,
            "state": session.state.value if isinstance(session.state, DialogState) else session.state,
            "current_turn": self.context_manager.get_context(session_id).current_turn,
            "created_at": session.created_at.isoformat(),
            "last_active_at": session.last_active_at.isoformat(),
            "context_summary": self.context_manager.get_context_summary(session_id)
        }
    
    def get_metrics(self) -> Dict:
        """获取性能指标"""
        return {
            **self.metrics,
            "success_rate": (
                self.metrics["successful_requests"] / 
                max(self.metrics["total_requests"], 1)
            )
        }
    
    def get_supported_intents(self) -> List[str]:
        """获取支持的意图列表"""
        return [intent.value for intent in IntentType]
    
    def health_check(self) -> Dict:
        """健康检查"""
        return {
            "status": "healthy",
            "components": {
                "state_manager": self.state_manager is not None,
                "context_manager": self.context_manager is not None,
                "intent_classifier": self.intent_classifier is not None,
                "entity_extractor": self.entity_extractor is not None,
                "slot_filler": self.slot_filler is not None,
                "policy_router": self.policy_router is not None,
                "response_generator": self.response_generator is not None,
            },
            "active_sessions": self.state_manager.get_active_session_count(),
            "metrics": self.get_metrics()
        }
