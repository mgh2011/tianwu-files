"""
独立安全系统 - 安全决策引擎
Security Decision Engine

【功能说明】
- 独立运行的安全决策引擎
- 基于威胁等级自动选择处理策略
- 多维度风险评估
- 完全本地化实现
"""

import re
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)


class SecurityDecisionEngine:
    """
    安全决策引擎 - 完全独立实现
    
    负责根据威胁评估结果做出安全决策
    支持多种决策策略和自定义规则
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 决策策略配置
        self._decision_strategies = {
            'strict': {
                'block_threshold': 0.5,
                'quarantine_threshold': 0.3,
                'alert_threshold': 0.1,
                'description': '严格模式 - 宁可误报不可漏报'
            },
            'balanced': {
                'block_threshold': 0.7,
                'quarantine_threshold': 0.4,
                'alert_threshold': 0.2,
                'description': '平衡模式 - 兼顾安全和用户体验'
            },
            'relaxed': {
                'block_threshold': 0.85,
                'quarantine_threshold': 0.6,
                'alert_threshold': 0.3,
                'description': '宽松模式 - 最小化误报影响'
            }
        }
        
        # 当前策略
        self._current_strategy = 'balanced'
        
        # 决策规则库
        self._decision_rules = self._init_decision_rules()
        
        # 决策历史
        self._decision_history: List[Dict] = []
    
    def _init_decision_rules(self) -> Dict[str, List[Dict]]:
        """初始化决策规则"""
        return {
            # 基于威胁类型的决策
            'threat_type_rules': [
                {
                    'condition': {'threat_type': 'phishing', 'confidence': 0.8},
                    'action': 'block',
                    'priority': 100
                },
                {
                    'condition': {'threat_type': 'malware', 'confidence': 0.9},
                    'action': 'block',
                    'priority': 100
                },
                {
                    'condition': {'threat_type': 'spam', 'confidence': 0.7},
                    'action': 'quarantine',
                    'priority': 80
                },
                {
                    'condition': {'threat_type': 'suspicious', 'confidence': 0.5},
                    'action': 'alert',
                    'priority': 60
                },
            ],
            
            # 基于检测模块组合的决策
            'combined_rules': [
                {
                    'modules': ['phishing_detector', 'domain_spoof_detector'],
                    'condition': 'all_detected',
                    'action': 'block',
                    'priority': 95
                },
                {
                    'modules': ['spam_filter', 'dlp'],
                    'condition': 'all_detected',
                    'action': 'quarantine',
                    'priority': 75
                },
                {
                    'modules': ['antivirus', 'ids'],
                    'condition': 'any_detected',
                    'action': 'block',
                    'priority': 90
                },
            ],
            
            # 基于上下文的决策
            'context_rules': [
                {
                    'context': 'external_sender',
                    'threat_score': 0.5,
                    'action': 'alert',
                    'priority': 50
                },
                {
                    'context': 'internal_sender',
                    'threat_score': 0.8,
                    'action': 'quarantine',
                    'priority': 70
                },
                {
                    'context': 'privileged_user',
                    'threat_score': 0.6,
                    'action': 'investigate',
                    'priority': 80
                },
            ]
        }
    
    def evaluate(self, threat_score: float, detections: Dict[str, Any], context: Dict) -> Dict:
        """
        评估并做出决策
        
        参数：
            threat_score: 威胁分数 (0-1)
            detections: 各模块检测结果
            context: 上下文信息
        
        返回：
            决策结果 {'action': str, 'reason': str, 'confidence': float}
        """
        # 获取当前策略
        strategy = self._decision_strategies.get(self._current_strategy, self._decision_strategies['balanced'])
        
        # 1. 检查威胁类型规则
        threat_type_decision = self._check_threat_type_rules(detections)
        if threat_type_decision:
            return threat_type_decision
        
        # 2. 检查组合规则
        combined_decision = self._check_combined_rules(detections)
        if combined_decision:
            return combined_decision
        
        # 3. 检查上下文规则
        context_decision = self._check_context_rules(context, threat_score)
        if context_decision:
            return context_decision
        
        # 4. 使用策略阈值
        action = self._apply_strategy_threshold(threat_score, strategy)
        
        # 5. 计算置信度
        confidence = self._calculate_decision_confidence(threat_score, detections)
        
        return {
            'action': action,
            'reason': f'基于{self._current_strategy}策略: 威胁分数{threat_score:.2%}',
            'confidence': confidence,
            'strategy': self._current_strategy
        }
    
    def _check_threat_type_rules(self, detections: Dict) -> Optional[Dict]:
        """检查威胁类型规则"""
        for rule in self._decision_rules['threat_type_rules']:
            condition = rule['condition']
            threat_type = condition.get('threat_type')
            required_confidence = condition.get('confidence', 0)
            
            # 查找对应的检测结果
            for module_name, result in detections.items():
                if result.get('threat_type') == threat_type:
                    if result.get('confidence', 0) >= required_confidence:
                        return {
                            'action': rule['action'],
                            'reason': f"威胁类型规则触发: {threat_type}",
                            'confidence': rule['priority'] / 100.0,
                            'rule': 'threat_type'
                        }
        
        return None
    
    def _check_combined_rules(self, detections: Dict) -> Optional[Dict]:
        """检查组合规则"""
        detected_modules = set(detections.keys())
        
        for rule in sorted(self._decision_rules['combined_rules'], key=lambda x: x['priority'], reverse=True):
            required_modules = set(rule['modules'])
            condition = rule['condition']
            
            if condition == 'all_detected':
                if required_modules.issubset(detected_modules):
                    return {
                        'action': rule['action'],
                        'reason': f"组合规则触发: {', '.join(rule['modules'])}全部检测到威胁",
                        'confidence': rule['priority'] / 100.0,
                        'rule': 'combined'
                    }
            elif condition == 'any_detected':
                if required_modules.intersection(detected_modules):
                    return {
                        'action': rule['action'],
                        'reason': f"组合规则触发: {', '.join(required_modules.intersection(detected_modules))}检测到威胁",
                        'confidence': rule['priority'] / 100.0,
                        'rule': 'combined'
                    }
        
        return None
    
    def _check_context_rules(self, context: Dict, threat_score: float) -> Optional[Dict]:
        """检查上下文规则"""
        ctx_type = context.get('sender_type', 'external_sender')
        
        for rule in self._decision_rules['context_rules']:
            if rule['context'] == ctx_type and threat_score >= rule['threat_score']:
                return {
                    'action': rule['action'],
                    'reason': f"上下文规则触发: {ctx_type}",
                    'confidence': rule['priority'] / 100.0,
                    'rule': 'context'
                }
        
        return None
    
    def _apply_strategy_threshold(self, threat_score: float, strategy: Dict) -> str:
        """应用策略阈值"""
        if threat_score >= strategy['block_threshold']:
            return 'block'
        elif threat_score >= strategy['quarantine_threshold']:
            return 'quarantine'
        elif threat_score >= strategy['alert_threshold']:
            return 'alert'
        return 'allow'
    
    def _calculate_decision_confidence(self, threat_score: float, detections: Dict) -> float:
        """计算决策置信度"""
        confidence = 0.5
        
        # 基于检测模块数量
        if len(detections) >= 3:
            confidence += 0.2
        elif len(detections) >= 1:
            confidence += 0.1
        
        # 基于检测一致性
        high_confidence_detections = sum(1 for d in detections.values() 
                                         if d.get('confidence', 0) >= 0.7)
        if high_confidence_detections >= 2:
            confidence += 0.15
        
        return min(confidence, 1.0)
    
    def set_strategy(self, strategy_name: str) -> bool:
        """设置决策策略"""
        if strategy_name in self._decision_strategies:
            self._current_strategy = strategy_name
            logger.info(f"决策策略已切换: {strategy_name}")
            return True
        return False
    
    def add_rule(self, rule_type: str, rule: Dict) -> bool:
        """添加决策规则"""
        if rule_type in self._decision_rules:
            self._decision_rules[rule_type].append(rule)
            return True
        return False
    
    def get_strategy(self) -> Dict:
        """获取当前策略"""
        return self._decision_strategies.get(self._current_strategy, {})
    
    def get_all_strategies(self) -> Dict:
        """获取所有策略"""
        return self._decision_strategies.copy()


# 安全策略引擎
class SecurityPolicyEngine:
    """
    安全策略引擎 - 完全独立实现
    
    管理和执行安全策略
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 策略库
        self._policies: Dict[str, Dict] = {}
        self._load_policies()
    
    def _load_policies(self):
        """加载策略"""
        self._policies = {
            'default': {
                'name': '默认安全策略',
                'enabled': True,
                'priority': 100,
                'rules': [
                    {'type': 'threat_level', 'operator': '>=', 'value': 0.7, 'action': 'block'},
                    {'type': 'threat_level', 'operator': '>=', 'value': 0.4, 'action': 'quarantine'},
                    {'type': 'threat_level', 'operator': '>=', 'value': 0.2, 'action': 'alert'},
                ]
            },
            'strict': {
                'name': '严格策略',
                'enabled': True,
                'priority': 90,
                'rules': [
                    {'type': 'threat_level', 'operator': '>=', 'value': 0.5, 'action': 'block'},
                    {'type': 'suspicious_count', 'operator': '>=', 'value': 1, 'action': 'quarantine'},
                ]
            },
            'compliance': {
                'name': '合规策略',
                'enabled': True,
                'priority': 80,
                'rules': [
                    {'type': 'pii_detected', 'operator': '==', 'value': True, 'action': 'alert'},
                    {'type': 'data_exposure', 'operator': '==', 'value': True, 'action': 'block'},
                ]
            }
        }
    
    def evaluate(self, context: Dict) -> Tuple[str, List[str]]:
        """评估策略"""
        sorted_policies = sorted(
            self._policies.values(),
            key=lambda p: p.get('priority', 0),
            reverse=True
        )
        
        applicable_policies = []
        action = 'allow'
        
        for policy in sorted_policies:
            if not policy.get('enabled', True):
                continue
            
            for rule in policy.get('rules', []):
                if self._check_condition(rule, context):
                    applicable_policies.append(policy['name'])
                    action = rule.get('action', action)
                    break
        
        return action, applicable_policies
    
    def _check_condition(self, rule: Dict, context: Dict) -> bool:
        """检查条件"""
        cond_type = rule.get('type', '')
        operator = rule.get('operator', '==')
        value = rule.get('value')
        
        context_value = context.get(cond_type, 0)
        
        if operator == '>=':
            return context_value >= value
        elif operator == '==':
            return context_value == value
        elif operator == '>':
            return context_value > value
        elif operator == '<':
            return context_value < value
        
        return False


# 安全规则引擎
class SecurityRulesEngine:
    """
    安全规则引擎 - 完全独立实现
    
    管理安全检测规则
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 规则库
        self._rules: Dict[str, Dict] = {}
        self._load_rules()
    
    def _load_rules(self):
        """加载规则"""
        self._rules = {
            'phishing_patterns': {
                'patterns': [
                    r'paypa1\.com', r'bank0fchina\.com', r'micros0ft\.com',
                    r'verify.*account', r'suspend.*account',
                ],
                'severity': 'high'
            },
            'malware_patterns': {
                'patterns': [
                    r'\.exe\s', r'\.bat\s', r'\.vbs\s',
                    r'powershell.*-enc', r'cmd\s/c',
                ],
                'severity': 'critical'
            },
            'data_leak_patterns': {
                'patterns': [
                    r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
                    r'\b\d{17}[\dXx]\b',
                ],
                'severity': 'high'
            }
        }
    
    def check(self, request: Dict) -> Dict:
        """检查规则"""
        text = request.get('body', '') + request.get('subject', '')
        detections = []
        
        for rule_name, rule_data in self._rules.items():
            for pattern in rule_data.get('patterns', []):
                if re.search(pattern, text, re.IGNORECASE):
                    detections.append({
                        'rule': rule_name,
                        'pattern': pattern,
                        'severity': rule_data.get('severity', 'medium')
                    })
        
        threat_score = len(detections) * 0.2
        
        return {
            'detected': len(detections) > 0,
            'threat_score': min(threat_score, 1.0),
            'rules_triggered': detections
        }


# 安全分析引擎
class SecurityAnalysisEngine:
    """
    安全分析引擎 - 完全独立实现
    
    进行安全事件分析
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 分析模式
        self._analysis_patterns = {
            'brute_force': {'failed_attempts': 5, 'time_window': 300},
            'data_exfil': {'size_threshold': 1000000},
            'privilege_escalation': {'indicators': ['sudo', 'admin', 'root']},
        }
    
    def analyze(self, data: Dict) -> Dict:
        """分析数据"""
        analysis_type = data.get('type', 'generic')
        
        if analysis_type == 'login':
            return self._analyze_login(data)
        elif analysis_type == 'access':
            return self._analyze_access(data)
        
        return {'analyzed': True, 'risk_level': 'unknown'}
    
    def _analyze_login(self, data: Dict) -> Dict:
        """分析登录"""
        failed_count = data.get('failed_attempts', 0)
        
        if failed_count >= 5:
            return {
                'analyzed': True,
                'risk_level': 'high',
                'pattern': 'brute_force',
                'recommendation': '建议封禁该IP'
            }
        
        return {'analyzed': True, 'risk_level': 'low'}
    
    def _analyze_access(self, data: Dict) -> Dict:
        """分析访问"""
        return {'analyzed': True, 'risk_level': 'medium'}
    
    def check(self, request: Dict) -> Dict:
        """检查请求"""
        analysis_result = self.analyze(request)
        return {
            'detected': analysis_result.get('risk_level') in ['high', 'critical'],
            'threat_score': 0.5 if analysis_result.get('risk_level') == 'high' else 0.2,
            'analysis': analysis_result
        }


# 安全评估引擎
class SecurityAssessmentEngine:
    """
    安全评估引擎 - 完全独立实现
    
    进行安全风险评估
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 评估维度
        self._dimensions = {
            'confidentiality': {'weight': 0.3},
            'integrity': {'weight': 0.3},
            'availability': {'weight': 0.2},
            'accountability': {'weight': 0.2}
        }
    
    def assess(self, asset: str, vulnerabilities: List[Dict], threats: List[Dict]) -> Dict:
        """评估风险"""
        scores = {}
        
        for dim, info in self._dimensions.items():
            vuln_score = sum(v.get(dim, 0.5) for v in vulnerabilities) / max(len(vulnerabilities), 1)
            threat_score = sum(t.get(dim, 0.5) for t in threats) / max(len(threats), 1)
            scores[dim] = (vuln_score + threat_score) / 2 * info['weight']
        
        total_score = sum(scores.values())
        
        return {
            'asset': asset,
            'risk_score': total_score,
            'risk_level': self._get_risk_level(total_score),
            'dimension_scores': scores,
            'recommendations': self._generate_recommendations(total_score)
        }
    
    def _get_risk_level(self, score: float) -> str:
        """获取风险等级"""
        if score >= 0.7: return 'critical'
        elif score >= 0.5: return 'high'
        elif score >= 0.3: return 'medium'
        return 'low'
    
    def _generate_recommendations(self, score: float) -> List[str]:
        """生成建议"""
        if score >= 0.7:
            return ['立即采取缓解措施', '启动应急响应']
        elif score >= 0.5:
            return ['制定应对计划', '加强监控']
        return ['维持现有措施']


# 测试
if __name__ == '__main__':
    print("=" * 60)
    print("独立安全系统 - 安全决策引擎测试")
    print("=" * 60)
    
    engine = SecurityDecisionEngine(None, None)
    
    # 测试策略
    print("\n【决策策略】")
    for name, strategy in engine.get_all_strategies().items():
        print(f"  {name}: {strategy['description']}")
    
    # 测试决策
    print("\n【决策测试】")
    test_cases = [
        (0.8, {}, {}, "高威胁"),
        (0.5, {}, {}, "中威胁"),
        (0.2, {}, {}, "低威胁"),
    ]
    
    for score, detections, context, desc in test_cases:
        result = engine.evaluate(score, detections, context)
        print(f"  {desc}: {result['action']} ({result['reason']})")
    
    print("\n" + "=" * 60)
