"""
反击执行系统 - 反击任务调度模块
Counterattack Task Scheduler - 调度和管理反击任务
"""

from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json
import threading
import queue


class TaskPriority(Enum):
    """任务优先级"""
    CRITICAL = 1  # 紧急
    HIGH = 2  # 高
    MEDIUM = 3  # 中
    LOW = 4  # 低


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


@dataclass
class CounterattackTask:
    """反击任务"""
    task_id: str
    name: str
    action_type: str
    target: Dict
    priority: TaskPriority
    status: TaskStatus
    created_at: str
    scheduled_at: Optional[str]
    started_at: Optional[str]
    completed_at: Optional[str]
    timeout: int = 300  # 秒
    retry_count: int = 0
    max_retries: int = 3
    result: Optional[Dict] = None
    error: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)


class CounterattackTaskScheduler:
    """反击任务调度器"""

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化任务调度器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.max_concurrent = self.config.get('max_concurrent_tasks', 10)
        self.default_timeout = self.config.get('default_timeout', 300)

        self.tasks: Dict[str, CounterattackTask] = {}
        self.task_queue = queue.PriorityQueue()
        self.running_tasks: Dict[str, threading.Thread] = {}
        self.task_handlers: Dict[str, Callable] = {}
        self.execution_history = []
        self.lock = threading.Lock()

    def register_handler(self, action_type: str, handler: Callable):
        """
        注册任务处理器

        Args:
            action_type: 动作类型
            handler: 处理函数
        """
        self.task_handlers[action_type] = handler

    def create_task(self, task_data: Dict) -> CounterattackTask:
        """
        创建任务

        Args:
            task_data: 任务数据，包含：
                - name: 任务名称
                - action_type: 动作类型
                - target: 目标信息
                - priority: 优先级
                - timeout: 超时时间
                - dependencies: 依赖任务

        Returns:
            任务对象
        """
        import hashlib

        task_id = f"TASK-{hashlib.md5(f'{task_data[\'name\']}:{datetime.now().isoformat()}'.encode()).hexdigest()[:12].upper()}"

        task = CounterattackTask(
            task_id=task_id,
            name=task_data['name'],
            action_type=task_data['action_type'],
            target=task_data['target'],
            priority=TaskPriority(task_data.get('priority', 3)),
            status=TaskStatus.PENDING,
            created_at=datetime.now().isoformat(),
            scheduled_at=task_data.get('scheduled_at'),
            timeout=task_data.get('timeout', self.default_timeout),
            max_retries=task_data.get('max_retries', 3),
            dependencies=task_data.get('dependencies', [])
        )

        self.tasks[task_id] = task
        return task

    def schedule_task(self, task_id: str, scheduled_at: str = None) -> bool:
        """
        调度任务

        Args:
            task_id: 任务ID
            scheduled_at: 计划执行时间

        Returns:
            是否成功
        """
        if task_id not in self.tasks:
            return False

        task = self.tasks[task_id]

        # 检查依赖
        if not self._check_dependencies(task):
            task.status = TaskStatus.PENDING
            task.error = "依赖任务未完成"
            return False

        # 设置调度时间
        task.scheduled_at = scheduled_at or datetime.now().isoformat()
        task.status = TaskStatus.QUEUED

        # 加入优先级队列
        self.task_queue.put((task.priority.value, task.task_id))

        return True

    def execute_task(self, task_id: str) -> Dict:
        """
        执行任务

        Args:
            task_id: 任务ID

        Returns:
            执行结果
        """
        if task_id not in self.tasks:
            return {'success': False, 'error': '任务不存在'}

        task = self.tasks[task_id]

        # 检查处理器
        if task.action_type not in self.task_handlers:
            task.status = TaskStatus.FAILED
            task.error = f"未找到处理器: {task.action_type}"
            return {'success': False, 'error': task.error}

        # 检查并发限制
        if len(self.running_tasks) >= self.max_concurrent:
            return {'success': False, 'error': '达到最大并发数'}

        # 开始执行
        task.status = TaskStatus.RUNNING
        task.started_at = datetime.now().isoformat()

        # 在线程中执行
        thread = threading.Thread(
            target=self._execute_task_async,
            args=(task_id,),
            daemon=True
        )
        self.running_tasks[task_id] = thread
        thread.start()

        return {
            'success': True,
            'task_id': task_id,
            'status': task.status.value
        }

    def _execute_task_async(self, task_id: str):
        """异步执行任务"""
        task = self.tasks[task_id]
        handler = self.task_handlers[task.action_type]

        try:
            # 设置超时
            import time
            start_time = time.time()

            # 执行任务
            result = handler(task.target)

            elapsed = time.time() - start_time

            # 检查超时
            if elapsed > task.timeout:
                task.status = TaskStatus.TIMEOUT
                task.error = f"任务超时 ({elapsed:.1f}s)"
                task.result = result
            else:
                task.status = TaskStatus.COMPLETED
                task.result = result

        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            task.retry_count += 1

            # 检查是否需要重试
            if task.retry_count < task.max_retries:
                task.status = TaskStatus.QUEUED
                self.task_queue.put((task.priority.value, task.task_id))

        finally:
            task.completed_at = datetime.now().isoformat()
            if task_id in self.running_tasks:
                del self.running_tasks[task_id]

            # 记录历史
            self._record_execution(task)

    def cancel_task(self, task_id: str) -> bool:
        """
        取消任务

        Args:
            task_id: 任务ID

        Returns:
            是否成功
        """
        if task_id not in self.tasks:
            return False

        task = self.tasks[task_id]

        if task.status in [TaskStatus.COMPLETED, TaskStatus.FAILED]:
            return False

        task.status = TaskStatus.CANCELLED
        task.completed_at = datetime.now().isoformat()

        return True

    def get_task(self, task_id: str) -> Optional[CounterattackTask]:
        """获取任务"""
        return self.tasks.get(task_id)

    def list_tasks(self, filters: Dict = None) -> List[CounterattackTask]:
        """
        列出任务

        Args:
            filters: 筛选条件

        Returns:
            任务列表
        """
        filters = filters or {}
        tasks = list(self.tasks.values())

        if 'status' in filters:
            tasks = [t for t in tasks if t.status == filters['status']]

        if 'action_type' in filters:
            tasks = [t for t in tasks if t.action_type == filters['action_type']]

        if 'priority' in filters:
            tasks = [t for t in tasks if t.priority == filters['priority']]

        return tasks

    def get_statistics(self) -> Dict:
        """获取统计"""
        total = len(self.tasks)
        by_status = {}
        by_priority = {}

        for task in self.tasks.values():
            status = task.status.value
            priority = task.priority.name
            by_status[status] = by_status.get(status, 0) + 1
            by_priority[priority] = by_priority.get(priority, 0) + 1

        return {
            'total_tasks': total,
            'running_tasks': len(self.running_tasks),
            'by_status': by_status,
            'by_priority': by_priority,
            'queue_size': self.task_queue.qsize()
        }

    def _check_dependencies(self, task: CounterattackTask) -> bool:
        """检查依赖"""
        for dep_id in task.dependencies:
            if dep_id not in self.tasks:
                return False
            dep_task = self.tasks[dep_id]
            if dep_task.status != TaskStatus.COMPLETED:
                return False
        return True

    def _record_execution(self, task: CounterattackTask):
        """记录执行历史"""
        self.execution_history.append({
            'task_id': task.task_id,
            'name': task.name,
            'action_type': task.action_type,
            'status': task.status.value,
            'duration': self._calculate_duration(task),
            'timestamp': task.completed_at or datetime.now().isoformat()
        })

        if len(self.execution_history) > 5000:
            self.execution_history = self.execution_history[-4000:]

    def _calculate_duration(self, task: CounterattackTask) -> float:
        """计算任务耗时"""
        if task.started_at and task.completed_at:
            start = datetime.fromisoformat(task.started_at)
            end = datetime.fromisoformat(task.completed_at)
            return (end - start).total_seconds()
        return 0.0


# 示例处理器
def example_block_handler(target: Dict) -> Dict:
    """示例阻断处理器"""
    import time
    time.sleep(0.1)  # 模拟执行
    return {
        'blocked_ips': [target.get('ip')],
        'duration': 3600
    }


# 独立运行测试
if __name__ == "__main__":
    scheduler = CounterattackTaskScheduler({'max_concurrent_tasks': 5})

    # 注册处理器
    scheduler.register_handler('block', example_block_handler)
    scheduler.register_handler('trace', lambda t: {'trace_result': 'completed'})
    scheduler.register_handler('honeypot', lambda t: {'honeypot_id': 'HP-001'})

    # 创建任务
    task1 = scheduler.create_task({
        'name': '阻断恶意IP',
        'action_type': 'block',
        'target': {'ip': '192.168.1.100'},
        'priority': 2  # HIGH
    })
    print(f"任务已创建: {task1.task_id}")

    task2 = scheduler.create_task({
        'name': '追踪攻击源',
        'action_type': 'trace',
        'target': {'ip': '192.168.1.100'},
        'priority': 3  # MEDIUM
    })
    print(f"任务已创建: {task2.task_id}")

    # 调度任务
    scheduler.schedule_task(task1.task_id)
    scheduler.schedule_task(task2.task_id)

    # 执行任务
    result = scheduler.execute_task(task1.task_id)
    print(f"\n执行结果: {result}")

    # 等待执行
    import time
    time.sleep(0.5)

    # 获取任务状态
    task = scheduler.get_task(task1.task_id)
    if task:
        print(f"\n任务状态: {task.status.value}")
        if task.result:
            print(f"执行结果: {task.result}")

    # 获取统计
    stats = scheduler.get_statistics()
    print(f"\n调度统计:")
    print(json.dumps(stats, indent=2))

    # 列出所有任务
    all_tasks = scheduler.list_tasks()
    print(f"\n总任务数: {len(all_tasks)}")
