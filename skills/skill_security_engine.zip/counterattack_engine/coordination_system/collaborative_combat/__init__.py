"""
协同作战模块
Collaborative Combat Module

提供多系统协同作战能力
"""

__version__ = "v3.0.0"
__all__ = []
