# ========== 邮件安全守门员企业级架构 v3.1.0 ==========
# 文件: scripts/enterprise_architecture.py
# 版本: 3.1.0
# 功能: 企业级配置管理、高可用性、可扩展性、监控告警、审计日志

"""
企业级邮件安全守门员架构
=========================

核心特性：
1. 高可用性设计 - 故障转移、重试机制、熔断器
2. 可扩展性设计 - 插件系统、微服务架构
3. 监控和告警 - 指标收集、告警规则、日志聚合
4. 审计日志 - 完整操作记录、合规审计
5. 多租户支持 - 租户隔离、权限管理
"""

import asyncio
import logging
import json
import time
import traceback
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
from collections import defaultdict
from functools import wraps
import threading
import queue
import hashlib

# 配置日志
logger = logging.getLogger(__name__)


# ========== 枚举定义 ==========

class HealthStatus(Enum):
    """健康状态枚举"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class AlertLevel(Enum):
    """告警级别枚举"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class AuditAction(Enum):
    """审计动作枚举"""
    EMAIL_PROCESSED = "email_processed"
    THREAT_DETECTED = "threat_detected"
    ACTION_TAKEN = "action_taken"
    CONFIG_CHANGED = "config_changed"
    USER_AUTHENTICATED = "user_authenticated"
    SYSTEM_ERROR = "system_error"


class TenantStatus(Enum):
    """租户状态枚举"""
    ACTIVE = "active"
    SUSPENDED = "suspended"
    TERMINATED = "terminated"


# ========== 数据结构定义 ==========

@dataclass
class TenantConfig:
    """租户配置"""
    tenant_id: str
    tenant_name: str
    status: TenantStatus = TenantStatus.ACTIVE
    max_requests_per_day: int = 100000
    max_attachments_size_mb: int = 50
    enabled_modules: List[str] = field(default_factory=list)
    custom_rules: Dict = field(default_factory=dict)
    metadata: Dict = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)


@dataclass
class AuditLogEntry:
    """审计日志条目"""
    log_id: str
    timestamp: datetime
    tenant_id: str
    user_id: str
    action: AuditAction
    resource_type: str
    resource_id: str
    details: Dict
    ip_address: str = ""
    user_agent: str = ""
    result: str = "success"
    error_message: str = ""
    
    def to_dict(self) -> Dict:
        return {
            'log_id': self.log_id,
            'timestamp': self.timestamp.isoformat(),
            'tenant_id': self.tenant_id,
            'user_id': self.user_id,
            'action': self.action.value,
            'resource_type': self.resource_type,
            'resource_id': self.resource_id,
            'details': self.details,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'result': self.result,
            'error_message': self.error_message
        }


@dataclass
class HealthCheckResult:
    """健康检查结果"""
    component: str
    status: HealthStatus
    response_time_ms: float
    message: str = ""
    details: Dict = field(default_factory=dict)


@dataclass
class MetricData:
    """指标数据"""
    name: str
    value: float
    unit: str
    timestamp: datetime
    tags: Dict = field(default_factory=dict)


# ========== 插件系统 ==========

class PluginInterface:
    """插件接口基类"""
    
    def __init__(self):
        self.name = self.__class__.__name__
        self.version = "1.0.0"
        self.enabled = True
    
    def initialize(self, config: Dict) -> bool:
        """初始化插件"""
        raise NotImplementedError
    
    def process(self, data: Any) -> Any:
        """处理数据"""
        raise NotImplementedError
    
    def shutdown(self):
        """关闭插件"""
        pass


class PluginRegistry:
    """插件注册表"""
    
    def __init__(self):
        self._plugins: Dict[str, PluginInterface] = {}
        self._hooks: Dict[str, List[Callable]] = defaultdict(list)
    
    def register(self, plugin: PluginInterface) -> bool:
        """注册插件"""
        try:
            self._plugins[plugin.name] = plugin
            logger.info(f"✅ 插件已注册: {plugin.name} v{plugin.version}")
            return True
        except Exception as e:
            logger.error(f"❌ 插件注册失败: {plugin.name}, 错误: {e}")
            return False
    
    def unregister(self, plugin_name: str) -> bool:
        """注销插件"""
        if plugin_name in self._plugins:
            self._plugins[plugin_name].shutdown()
            del self._plugins[plugin_name]
            logger.info(f"✅ 插件已注销: {plugin_name}")
            return True
        return False
    
    def get_plugin(self, plugin_name: str) -> Optional[PluginInterface]:
        """获取插件"""
        return self._plugins.get(plugin_name)
    
    def list_plugins(self) -> List[Dict]:
        """列出所有插件"""
        return [
            {
                'name': p.name,
                'version': p.version,
                'enabled': p.enabled
            }
            for p in self._plugins.values()
        ]
    
    def register_hook(self, hook_name: str, callback: Callable):
        """注册钩子"""
        self._hooks[hook_name].append(callback)
    
    def trigger_hook(self, hook_name: str, *args, **kwargs):
        """触发钩子"""
        for callback in self._hooks.get(hook_name, []):
            try:
                callback(*args, **kwargs)
            except Exception as e:
                logger.error(f"❌ 钩子执行失败: {hook_name}, 错误: {e}")


# ========== 熔断器模式 ==========

class CircuitBreakerState(Enum):
    """熔断器状态"""
    CLOSED = "closed"      # 正常
    OPEN = "open"          # 熔断
    HALF_OPEN = "half_open"  # 半开


@dataclass
class CircuitBreakerConfig:
    """熔断器配置"""
    failure_threshold: int = 5      # 失败次数阈值
    success_threshold: int = 2       # 成功次数阈值（半开→闭）
    timeout_seconds: float = 60.0    # 超时时间
    half_open_max_calls: int = 3    # 半开状态最大调用次数


class CircuitBreaker:
    """
    熔断器实现
    
    工作原理：
    1. CLOSED: 正常状态，失败计数
    2. OPEN: 失败次数超阈值，打开熔断器，拒绝请求
    3. HALF_OPEN: 超时后进入半开状态，允许部分请求
    """
    
    def __init__(self, name: str, config: CircuitBreakerConfig = None):
        self.name = name
        self.config = config or CircuitBreakerConfig()
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: Optional[datetime] = None
        self.half_open_calls = 0
        self._lock = threading.Lock()
    
    def call(self, func: Callable, *args, **kwargs):
        """带熔断保护的调用"""
        with self._lock:
            # 检查状态
            if self.state == CircuitBreakerState.OPEN:
                # 检查是否超时
                if self._should_attempt_reset():
                    self._transition_to_half_open()
                else:
                    raise CircuitBreakerOpenError(f"Circuit breaker '{self.name}' is OPEN")
            
            # 半开状态检查
            if self.state == CircuitBreakerState.HALF_OPEN:
                if self.half_open_calls >= self.config.half_open_max_calls:
                    raise CircuitBreakerOpenError(f"Circuit breaker '{self.name}' is HALF_OPEN, max calls reached")
                self.half_open_calls += 1
        
        # 执行调用
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            raise
    
    def _should_attempt_reset(self) -> bool:
        """检查是否应该尝试重置"""
        if self.last_failure_time is None:
            return True
        elapsed = (datetime.now() - self.last_failure_time).total_seconds()
        return elapsed >= self.config.timeout_seconds
    
    def _transition_to_half_open(self):
        """转换到半开状态"""
        self.state = CircuitBreakerState.HALF_OPEN
        self.half_open_calls = 0
        logger.warning(f"⚠️ 熔断器 '{self.name}' 进入 HALF_OPEN 状态")
    
    def _on_success(self):
        """记录成功"""
        with self._lock:
            if self.state == CircuitBreakerState.HALF_OPEN:
                self.success_count += 1
                if self.success_count >= self.config.success_threshold:
                    self._transition_to_closed()
            self.failure_count = 0
    
    def _on_failure(self):
        """记录失败"""
        with self._lock:
            self.failure_count += 1
            self.last_failure_time = datetime.now()
            
            if self.state == CircuitBreakerState.HALF_OPEN:
                self._transition_to_open()
            elif self.failure_count >= self.config.failure_threshold:
                self._transition_to_open()
    
    def _transition_to_open(self):
        """转换到打开状态"""
        self.state = CircuitBreakerState.OPEN
        self.success_count = 0
        logger.error(f"🔴 熔断器 '{self.name}' 已 OPEN")
    
    def _transition_to_closed(self):
        """转换到关闭状态"""
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.half_open_calls = 0
        logger.info(f"✅ 熔断器 '{self.name}' 已 CLOSED")


class CircuitBreakerOpenError(Exception):
    """熔断器打开异常"""
    pass


# ========== 重试机制 ==========

@dataclass
class RetryConfig:
    """重试配置"""
    max_attempts: int = 3
    initial_delay_ms: int = 100
    max_delay_ms: int = 5000
    exponential_base: float = 2.0
    jitter: bool = True


def with_retry(config: RetryConfig = None):
    """重试装饰器"""
    config = config or RetryConfig()
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            delay = config.initial_delay_ms
            
            for attempt in range(config.max_attempts):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < config.max_attempts - 1:
                        import random
                        actual_delay = delay
                        if config.jitter:
                            actual_delay = delay * (0.5 + random.random())
                        
                        logger.warning(
                            f"⚠️ {func.__name__} 失败 (尝试 {attempt + 1}/{config.max_attempts}), "
                            f"{actual_delay:.0f}ms后重试: {e}"
                        )
                        time.sleep(actual_delay / 1000)
                        delay = min(delay * config.exponential_base, config.max_delay_ms)
            
            logger.error(f"❌ {func.__name__} 重试失败: {last_exception}")
            raise last_exception
        
        return wrapper
    return decorator


# ========== 审计日志系统 ==========

class AuditLogger:
    """
    审计日志系统
    
    功能：
    1. 记录所有安全相关操作
    2. 支持多种存储后端
    3. 自动过期清理
    4. 合规保留期设置
    """
    
    def __init__(self, retention_days: int = 180):
        self.retention_days = retention_days
        self._logs: List[AuditLogEntry] = []
        self._lock = threading.Lock()
        self._log_queue = queue.Queue()
        self._persist_thread: Optional[threading.Thread] = None
        self._running = False
    
    def start(self):
        """启动审计日志系统"""
        self._running = True
        self._persist_thread = threading.Thread(target=self._persist_worker, daemon=True)
        self._persist_thread.start()
        logger.info("✅ 审计日志系统已启动")
    
    def stop(self):
        """停止审计日志系统"""
        self._running = False
        if self._persist_thread:
            self._persist_thread.join(timeout=5)
        self._cleanup_old_logs()
        logger.info("✅ 审计日志系统已停止")
    
    def log(
        self,
        tenant_id: str,
        user_id: str,
        action: AuditAction,
        resource_type: str,
        resource_id: str,
        details: Dict = None,
        ip_address: str = "",
        user_agent: str = "",
        result: str = "success",
        error_message: str = ""
    ):
        """记录审计日志"""
        entry = AuditLogEntry(
            log_id=self._generate_log_id(tenant_id, resource_id),
            timestamp=datetime.now(),
            tenant_id=tenant_id,
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            details=details or {},
            ip_address=ip_address,
            user_agent=user_agent,
            result=result,
            error_message=error_message
        )
        
        self._log_queue.put(entry)
        
        # 立即记录到内存
        with self._lock:
            self._logs.append(entry)
    
    def _persist_worker(self):
        """持久化工作线程"""
        while self._running:
            try:
                entry = self._log_queue.get(timeout=1)
                self._persist_entry(entry)
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"❌ 审计日志持久化失败: {e}")
    
    def _persist_entry(self, entry: AuditLogEntry):
        """持久化单条日志"""
        # 实际实现中应写入数据库或文件
        pass
    
    def _cleanup_old_logs(self):
        """清理过期日志"""
        cutoff = datetime.now() - timedelta(days=self.retention_days)
        with self._lock:
            self._logs = [log for log in self._logs if log.timestamp > cutoff]
    
    def _generate_log_id(self, tenant_id: str, resource_id: str) -> str:
        """生成日志ID"""
        raw = f"{tenant_id}:{resource_id}:{time.time()}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]
    
    def query(
        self,
        tenant_id: Optional[str] = None,
        action: Optional[AuditAction] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: int = 100
    ) -> List[Dict]:
        """查询审计日志"""
        with self._lock:
            results = self._logs.copy()
        
        if tenant_id:
            results = [r for r in results if r.tenant_id == tenant_id]
        if action:
            results = [r for r in results if r.action == action]
        if start_time:
            results = [r for r in results if r.timestamp >= start_time]
        if end_time:
            results = [r for r in results if r.timestamp <= end_time]
        
        results = sorted(results, key=lambda x: x.timestamp, reverse=True)
        return [r.to_dict() for r in results[:limit]]
    
    def export(self, format: str = "json") -> str:
        """导出审计日志"""
        with self._lock:
            logs = [r.to_dict() for r in self._logs]
        
        if format == "json":
            return json.dumps(logs, ensure_ascii=False, indent=2)
        elif format == "csv":
            return self._to_csv(logs)
        return ""
    
    def _to_csv(self, logs: List[Dict]) -> str:
        """转换为CSV格式"""
        if not logs:
            return ""
        
        headers = ["log_id", "timestamp", "tenant_id", "user_id", "action", "resource_type", "result"]
        rows = [[log.get(h, "") for h in headers] for log in logs]
        
        csv_lines = [",".join(headers)]
        for row in rows:
            csv_lines.append(",".join(str(v) for v in row))
        
        return "\n".join(csv_lines)


# ========== 监控指标系统 ==========

class MetricsCollector:
    """
    监控指标收集系统
    
    指标类型：
    1. Counter - 计数器
    2. Gauge - 仪表
    3. Histogram - 直方图
    4. Summary - 摘要
    """
    
    def __init__(self):
        self._counters: Dict[str, float] = defaultdict(float)
        self._gauges: Dict[str, float] = {}
        self._histograms: Dict[str, List[float]] = defaultdict(list)
        self._lock = threading.Lock()
    
    def increment(self, name: str, value: float = 1, tags: Dict = None):
        """递增计数器"""
        key = self._make_key(name, tags)
        with self._lock:
            self._counters[key] += value
    
    def decrement(self, name: str, value: float = 1, tags: Dict = None):
        """递减计数器"""
        key = self._make_key(name, tags)
        with self._lock:
            self._counters[key] -= value
    
    def set_gauge(self, name: str, value: float, tags: Dict = None):
        """设置仪表值"""
        key = self._make_key(name, tags)
        with self._lock:
            self._gauges[key] = value
    
    def observe(self, name: str, value: float, tags: Dict = None):
        """记录直方图值"""
        key = self._make_key(name, tags)
        with self._lock:
            self._histograms[key].append(value)
    
    def _make_key(self, name: str, tags: Dict = None) -> str:
        """生成指标键"""
        if not tags:
            return name
        tag_str = ",".join(f"{k}={v}" for k, v in sorted(tags.items()))
        return f"{name}{{{tag_str}}}"
    
    def get_stats(self) -> Dict:
        """获取所有统计信息"""
        with self._lock:
            stats = {
                'counters': dict(self._counters),
                'gauges': dict(self._gauges),
                'histograms': {}
            }
            
            for name, values in self._histograms.items():
                if values:
                    sorted_values = sorted(values)
                    stats['histograms'][name] = {
                        'count': len(values),
                        'sum': sum(values),
                        'min': min(values),
                        'max': max(values),
                        'avg': sum(values) / len(values),
                        'p50': sorted_values[len(sorted_values) // 2],
                        'p90': sorted_values[int(len(sorted_values) * 0.9)],
                        'p99': sorted_values[int(len(sorted_values) * 0.99)]
                    }
            
            return stats
    
    def reset(self):
        """重置所有指标"""
        with self._lock:
            self._counters.clear()
            self._gauges.clear()
            self._histograms.clear()


# ========== 健康检查系统 ==========

class HealthChecker:
    """
    健康检查系统
    
    功能：
    1. 检查各组件健康状态
    2. 计算整体健康度
    3. 自动恢复检测
    """
    
    def __init__(self):
        self._checks: Dict[str, Callable[[], HealthCheckResult]] = {}
        self._last_results: Dict[str, HealthCheckResult] = {}
    
    def register_check(self, name: str, check_func: Callable[[], HealthCheckResult]):
        """注册健康检查"""
        self._checks[name] = check_func
        logger.info(f"✅ 健康检查已注册: {name}")
    
    async def check_all(self) -> Dict:
        """执行所有健康检查"""
        results = {}
        overall_healthy = True
        degraded = False
        
        for name, check_func in self._checks.items():
            try:
                start_time = time.time()
                if asyncio.iscoroutinefunction(check_func):
                    result = await check_func()
                else:
                    result = check_func()
                
                result.response_time_ms = (time.time() - start_time) * 1000
                self._last_results[name] = result
                results[name] = {
                    'status': result.status.value,
                    'response_time_ms': result.response_time_ms,
                    'message': result.message,
                    'details': result.details
                }
                
                if result.status == HealthStatus.UNHEALTHY:
                    overall_healthy = False
                elif result.status == HealthStatus.DEGRADED:
                    degraded = True
                    
            except Exception as e:
                results[name] = {
                    'status': HealthStatus.UNHEALTHY.value,
                    'error': str(e)
                }
                overall_healthy = False
                self._last_results[name] = HealthCheckResult(
                    component=name,
                    status=HealthStatus.UNHEALTHY,
                    response_time_ms=0,
                    message=str(e)
                )
        
        # 计算整体状态
        if overall_healthy:
            overall_status = HealthStatus.HEALTHY if not degraded else HealthStatus.DEGRADED
        else:
            overall_status = HealthStatus.UNHEALTHY
        
        return {
            'overall_status': overall_status.value,
            'checks': results,
            'timestamp': datetime.now().isoformat()
        }


# ========== 告警系统 ==========

class AlertManager:
    """
    告警管理系统
    
    功能：
    1. 告警规则配置
    2. 多渠道通知（邮件、短信、webhook）
    3. 告警聚合和抑制
    4. 告警升级
    """
    
    def __init__(self):
        self._rules: List['AlertRule'] = []
        self._active_alerts: Dict[str, 'Alert'] = {}
        self._notification_channels: Dict[str, 'NotificationChannel'] = {}
        self._lock = threading.Lock()
    
    def add_rule(self, rule: 'AlertRule'):
        """添加告警规则"""
        self._rules.append(rule)
        logger.info(f"✅ 告警规则已添加: {rule.name}")
    
    def register_channel(self, name: str, channel: 'NotificationChannel'):
        """注册通知渠道"""
        self._notification_channels[name] = channel
        logger.info(f"✅ 通知渠道已注册: {name}")
    
    def evaluate(self, metrics: Dict, context: Dict = None):
        """评估告警规则"""
        for rule in self._rules:
            try:
                should_fire, alert_data = rule.evaluate(metrics, context)
                
                if should_fire:
                    self._fire_alert(rule, alert_data)
                else:
                    self._resolve_alert(rule.name)
                    
            except Exception as e:
                logger.error(f"❌ 告警规则评估失败: {rule.name}, 错误: {e}")
    
    def _fire_alert(self, rule: 'AlertRule', alert_data: Dict):
        """触发告警"""
        with self._lock:
            alert_id = rule.name
            
            # 检查是否已存在
            if alert_id in self._active_alerts:
                existing = self._active_alerts[alert_id]
                existing.count += 1
                existing.last_triggered = datetime.now()
                return
            
            # 创建新告警
            alert = Alert(
                alert_id=alert_id,
                rule_name=rule.name,
                level=rule.level,
                title=alert_data.get('title', rule.name),
                message=alert_data.get('message', ''),
                details=alert_data.get('details', {})
            )
            self._active_alerts[alert_id] = alert
            
            # 发送通知
            self._send_notifications(alert)
            
            logger.warning(f"🚨 告警已触发: [{alert.level.value}] {alert.title}")
    
    def _resolve_alert(self, rule_name: str):
        """解除告警"""
        with self._lock:
            if rule_name in self._active_alerts:
                del self._active_alerts[rule_name]
                logger.info(f"✅ 告警已解除: {rule_name}")
    
    def _send_notifications(self, alert: 'Alert'):
        """发送告警通知"""
        for channel in self._notification_channels.values():
            try:
                if alert.level in channel.supported_levels:
                    channel.send(alert)
            except Exception as e:
                logger.error(f"❌ 通知发送失败: {channel.name}, 错误: {e}")
    
    def get_active_alerts(self) -> List[Dict]:
        """获取活跃告警"""
        return [alert.to_dict() for alert in self._active_alerts.values()]


@dataclass
class AlertRule:
    """告警规则"""
    name: str
    condition: Callable[[Dict, Dict], bool]
    level: AlertLevel
    enabled: bool = True
    
    def evaluate(self, metrics: Dict, context: Dict) -> Tuple[bool, Dict]:
        """评估规则"""
        if not self.enabled:
            return False, {}
        
        if self.condition(metrics, context):
            return True, {
                'title': f"告警: {self.name}",
                'message': f"触发条件已满足",
                'details': {'metrics': metrics, 'context': context}
            }
        return False, {}


@dataclass
class Alert:
    """告警"""
    alert_id: str
    rule_name: str
    level: AlertLevel
    title: str
    message: str
    details: Dict
    count: int = 1
    created_at: datetime = field(default_factory=datetime.now)
    last_triggered: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        return {
            'alert_id': self.alert_id,
            'rule_name': self.rule_name,
            'level': self.level.value,
            'title': self.title,
            'message': self.message,
            'details': self.details,
            'count': self.count,
            'created_at': self.created_at.isoformat(),
            'last_triggered': self.last_triggered.isoformat()
        }


class NotificationChannel:
    """通知渠道基类"""
    
    def __init__(self, name: str, supported_levels: List[AlertLevel] = None):
        self.name = name
        self.supported_levels = supported_levels or list(AlertLevel)
    
    def send(self, alert: Alert):
        """发送通知"""
        raise NotImplementedError


class WebhookChannel(NotificationChannel):
    """Webhook通知渠道"""
    
    def __init__(self, name: str, url: str, headers: Dict = None):
        super().__init__(name, [AlertLevel.WARNING, AlertLevel.ERROR, AlertLevel.CRITICAL])
        self.url = url
        self.headers = headers or {}
    
    def send(self, alert: Alert):
        """发送Webhook通知"""
        # 实际实现中应调用HTTP API
        logger.info(f"📤 Webhook通知: {self.url} -> [{alert.level.value}] {alert.title}")


# ========== 多租户管理 ==========

class TenantManager:
    """
    多租户管理系统
    
    功能：
    1. 租户CRUD
    2. 租户隔离
    3. 资源配额
    4. 计费统计
    """
    
    def __init__(self):
        self._tenants: Dict[str, TenantConfig] = {}
        self._usage: Dict[str, Dict] = defaultdict(lambda: {
            'requests_today': 0,
            'threats_detected': 0,
            'storage_used_mb': 0,
            'last_reset': datetime.now()
        })
        self._lock = threading.Lock()
    
    def create_tenant(self, tenant_id: str, tenant_name: str, config: Dict = None) -> TenantConfig:
        """创建租户"""
        with self._lock:
            if tenant_id in self._tenants:
                raise ValueError(f"租户 {tenant_id} 已存在")
            
            tenant = TenantConfig(
                tenant_id=tenant_id,
                tenant_name=tenant_name,
                **(config or {})
            )
            self._tenants[tenant_id] = tenant
            logger.info(f"✅ 租户已创建: {tenant_id} ({tenant_name})")
            return tenant
    
    def get_tenant(self, tenant_id: str) -> Optional[TenantConfig]:
        """获取租户配置"""
        return self._tenants.get(tenant_id)
    
    def update_tenant(self, tenant_id: str, updates: Dict) -> bool:
        """更新租户配置"""
        with self._lock:
            if tenant_id not in self._tenants:
                return False
            
            tenant = self._tenants[tenant_id]
            for key, value in updates.items():
                if hasattr(tenant, key):
                    setattr(tenant, key, value)
            tenant.updated_at = datetime.now()
            return True
    
    def delete_tenant(self, tenant_id: str) -> bool:
        """删除租户"""
        with self._lock:
            if tenant_id in self._tenants:
                self._tenants[tenant_id].status = TenantStatus.TERMINATED
                return True
            return False
    
    def list_tenants(self, status: TenantStatus = None) -> List[Dict]:
        """列出租户"""
        tenants = list(self._tenants.values())
        if status:
            tenants = [t for t in tenants if t.status == status]
        return [
            {
                'tenant_id': t.tenant_id,
                'tenant_name': t.tenant_name,
                'status': t.status.value,
                'created_at': t.created_at.isoformat()
            }
            for t in tenants
        ]
    
    def check_quota(self, tenant_id: str, resource: str, amount: float = 1) -> bool:
        """检查配额"""
        tenant = self.get_tenant(tenant_id)
        if not tenant or tenant.status != TenantStatus.ACTIVE:
            return False
        
        self._reset_daily_usage(tenant_id)
        usage = self._usage[tenant_id]
        
        if resource == 'requests':
            return usage['requests_today'] + amount <= tenant.max_requests_per_day
        return True
    
    def record_usage(self, tenant_id: str, resource: str, amount: float = 1):
        """记录使用量"""
        self._reset_daily_usage(tenant_id)
        self._usage[tenant_id][f'{resource}_today'] += amount
    
    def _reset_daily_usage(self, tenant_id: str):
        """重置每日使用量"""
        usage = self._usage[tenant_id]
        if (datetime.now() - usage['last_reset']).days >= 1:
            usage['requests_today'] = 0
            usage['last_reset'] = datetime.now()


# ========== 企业配置管理 ==========

class EnterpriseConfig:
    """
    企业级配置管理
    
    功能：
    1. 分层配置（全局/租户/环境）
    2. 配置验证
    3. 配置版本控制
    4. 配置热更新
    """
    
    def __init__(self):
        self._config: Dict = {}
        self._tenant_configs: Dict[str, Dict] = {}
        self._version = 1
        self._lock = threading.Lock()
    
    def load_config(self, config: Dict):
        """加载配置"""
        with self._lock:
            self._validate_config(config)
            self._config = config
            self._version += 1
            logger.info(f"✅ 配置已加载 (版本 {self._version})")
    
    def get_config(self, key: str = None, tenant_id: str = None) -> Any:
        """获取配置"""
        # 租户配置优先
        if tenant_id and tenant_id in self._tenant_configs:
            config = self._tenant_configs[tenant_id]
        else:
            config = self._config
        
        if key is None:
            return config
        
        keys = key.split('.')
        value = config
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return None
        return value
    
    def set_config(self, key: str, value: Any, tenant_id: str = None):
        """设置配置"""
        with self._lock:
            if tenant_id:
                if tenant_id not in self._tenant_configs:
                    self._tenant_configs[tenant_id] = {}
                config = self._tenant_configs[tenant_id]
            else:
                config = self._config
            
            keys = key.split('.')
            current = config
            for k in keys[:-1]:
                if k not in current:
                    current[k] = {}
                current = current[k]
            current[keys[-1]] = value
            self._version += 1
    
    def _validate_config(self, config: Dict):
        """验证配置"""
        required_keys = ['system', 'security', 'logging']
        for key in required_keys:
            if key not in config:
                raise ValueError(f"缺少必需配置: {key}")


# ========== 企业架构主类 ==========

class EnterpriseArchitecture:
    """
    企业级邮件安全守门员架构
    
    整合所有企业级功能：
    1. 插件系统
    2. 熔断器
    3. 重试机制
    4. 审计日志
    5. 监控指标
    6. 健康检查
    7. 告警管理
    8. 多租户
    9. 配置管理
    """
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        
        # 初始化各组件
        self.plugin_registry = PluginRegistry()
        self.audit_logger = AuditLogger(
            retention_days=self.config.get('audit_retention_days', 180)
        )
        self.metrics = MetricsCollector()
        self.health_checker = HealthChecker()
        self.alert_manager = AlertManager()
        self.tenant_manager = TenantManager()
        self.enterprise_config = EnterpriseConfig()
        
        # 熔断器字典
        self.circuit_breakers: Dict[str, CircuitBreaker] = {}
        
        # 加载企业配置
        if 'enterprise' in self.config:
            self.enterprise_config.load_config(self.config['enterprise'])
        
        logger.info("✅ 企业级架构初始化完成 (v3.1.0)")
    
    def get_circuit_breaker(self, name: str) -> CircuitBreaker:
        """获取或创建熔断器"""
        if name not in self.circuit_breakers:
            self.circuit_breakers[name] = CircuitBreaker(name)
        return self.circuit_breakers[name]
    
    def start(self):
        """启动企业架构"""
        self.audit_logger.start()
        
        # 注册内置健康检查
        self.health_checker.register_check(
            "circuit_breakers",
            lambda: self._check_circuit_breakers()
        )
        self.health_checker.register_check(
            "plugins",
            lambda: self._check_plugins()
        )
        
        logger.info("✅ 企业级架构已启动")
    
    def stop(self):
        """停止企业架构"""
        self.audit_logger.stop()
        for cb in self.circuit_breakers.values():
            cb.state = CircuitBreakerState.CLOSED
        logger.info("✅ 企业级架构已停止")
    
    def _check_circuit_breakers(self) -> HealthCheckResult:
        """检查熔断器状态"""
        open_breakers = [
            name for name, cb in self.circuit_breakers.items()
            if cb.state == CircuitBreakerState.OPEN
        ]
        
        if open_breakers:
            return HealthCheckResult(
                component="circuit_breakers",
                status=HealthStatus.DEGRADED,
                response_time_ms=0,
                message=f"{len(open_breakers)} 个熔断器处于OPEN状态",
                details={'open_breakers': open_breakers}
            )
        
        return HealthCheckResult(
            component="circuit_breakers",
            status=HealthStatus.HEALTHY,
            response_time_ms=0,
            message="所有熔断器正常"
        )
    
    def _check_plugins(self) -> HealthCheckResult:
        """检查插件状态"""
        disabled = [
            p['name'] for p in self.plugin_registry.list_plugins()
            if not p['enabled']
        ]
        
        return HealthCheckResult(
            component="plugins",
            status=HealthStatus.HEALTHY if not disabled else HealthStatus.DEGRADED,
            response_time_ms=0,
            message=f"{len(disabled)} 个插件已禁用" if disabled else "所有插件正常",
            details={'disabled_plugins': disabled}
        )
    
    def get_status(self) -> Dict:
        """获取架构状态"""
        return {
            'version': '3.1.0',
            'plugins': self.plugin_registry.list_plugins(),
            'circuit_breakers': {
                name: cb.state.value
                for name, cb in self.circuit_breakers.items()
            },
            'active_alerts': self.alert_manager.get_active_alerts(),
            'tenants': self.tenant_manager.list_tenants(),
            'metrics_summary': self.metrics.get_stats()
        }


# ========== 便捷工厂函数 ==========

def create_enterprise_architecture(config: Dict = None) -> EnterpriseArchitecture:
    """创建企业架构实例"""
    return EnterpriseArchitecture(config)


def create_default_config() -> Dict:
    """创建默认企业配置"""
    return {
        'enterprise': {
            'system': {
                'name': 'Email Security Gatekeeper',
                'version': '3.1.0',
                'environment': 'production'
            },
            'security': {
                'encryption_enabled': True,
                'audit_logging': True,
                'tenant_isolation': True
            },
            'logging': {
                'level': 'INFO',
                'retention_days': 180,
                'audit_retention_days': 180
            },
            'circuit_breaker': {
                'failure_threshold': 5,
                'success_threshold': 2,
                'timeout_seconds': 60
            },
            'retry': {
                'max_attempts': 3,
                'initial_delay_ms': 100,
                'max_delay_ms': 5000
            },
            'monitoring': {
                'metrics_enabled': True,
                'health_check_interval': 60
            },
            'alerts': {
                'email_enabled': False,
                'webhook_enabled': True,
                'critical_threshold': 80
            }
        }
    }


# ========== 使用示例 ==========

if __name__ == "__main__":
    # 创建企业架构
    config = create_default_config()
    enterprise = create_enterprise_architecture(config)
    enterprise.start()
    
    try:
        # 注册插件示例
        class TestPlugin(PluginInterface):
            def initialize(self, config: Dict) -> bool:
                return True
            
            def process(self, data: Any) -> Any:
                return data
        
        enterprise.plugin_registry.register(TestPlugin())
        
        # 记录审计日志
        enterprise.audit_logger.log(
            tenant_id="tenant_001",
            user_id="admin",
            action=AuditAction.EMAIL_PROCESSED,
            resource_type="email",
            resource_id="email_123",
            details={'risk_score': 75}
        )
        
        # 更新指标
        enterprise.metrics.increment("emails_processed", tags={'tenant': 'tenant_001'})
        enterprise.metrics.observe("processing_time_ms", 150, tags={'tenant': 'tenant_001'})
        
        # 获取状态
        status = enterprise.get_status()
        print(json.dumps(status, indent=2, ensure_ascii=False))
        
    finally:
        enterprise.stop()
