"""
防护系统模块
Protection System Module

提供边界、网络、主机、应用、数据、身份等多层防护
"""

from .boundary.firewall import FirewallModule
from .boundary.waf import WAFModule
from .network.ids import IDSModule
from .host.antivirus import AntivirusModule

__version__ = "v3.0.0"
__all__ = [
    'FirewallModule',
    'WAFModule',
    'IDSModule',
    'AntivirusModule'
]
