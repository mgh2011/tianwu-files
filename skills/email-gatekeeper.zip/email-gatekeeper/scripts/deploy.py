# ========== 邮件安全守门员快速部署脚本 v3.1.0 ==========
# 文件: scripts/deploy.py
# 版本: 3.1.0
# 功能: 一键部署、环境检查、依赖安装、配置初始化、健康检查

"""
邮件安全守门员一键部署脚本
==========================

功能：
1. 环境检查 - Python版本、依赖检查
2. 依赖安装 - 自动安装所有必需依赖
3. 配置初始化 - 生成默认配置
4. 服务启动 - 启动API服务
5. 健康检查 - 验证服务状态

使用方法：
    python scripts/deploy.py              # 交互式部署
    python scripts/deploy.py --quick      # 快速部署
    python scripts/deploy.py --config     # 仅检查配置
    python scripts/deploy.py --test       # 运行测试
"""

import os
import sys
import json
import subprocess
import argparse
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import urllib.request
import urllib.error

# ============================================================================
# 常量定义
# ============================================================================

SCRIPT_VERSION = "3.1.0"
MIN_PYTHON_VERSION = (3, 8)
DEFAULT_PORT = 8443
CONFIG_FILE = "config/gatekeeper.yaml"
ENTERPRISE_CONFIG_FILE = "config/enterprise_config.yaml"

# 必需依赖
REQUIRED_PACKAGES = [
    "pyyaml",
    "aiohttp",
    "fastapi",
    "uvicorn",
    "pydantic",
    "python-multipart",
]

# 可选依赖
OPTIONAL_PACKAGES = [
    ("redis", "Redis缓存支持"),
    ("python-jose", "JWT认证"),
    ("cryptography", "加密支持"),
    ("prometheus-client", "监控指标"),
    ("structlog", "结构化日志"),
]

# 健康检查端点
HEALTH_CHECK_URL = f"http://localhost:{DEFAULT_PORT}/health"


# ============================================================================
# 颜色输出
# ============================================================================

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'


def print_success(msg: str):
    print(f"{Colors.GREEN}✅ {msg}{Colors.END}")


def print_error(msg: str):
    print(f"{Colors.RED}❌ {msg}{Colors.END}")


def print_warning(msg: str):
    print(f"{Colors.YELLOW}⚠️ {msg}{Colors.END}")


def print_info(msg: str):
    print(f"{Colors.BLUE}ℹ️ {msg}{Colors.END}")


def print_header(msg: str):
    print(f"\n{Colors.BOLD}{Colors.CYAN}{'=' * 60}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}{msg}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}{'=' * 60}{Colors.END}\n")


# ============================================================================
# 环境检查
# ============================================================================

def check_python_version() -> Tuple[bool, str]:
    """检查Python版本"""
    version = sys.version_info
    version_str = f"{version.major}.{version.minor}.{version.micro}"
    
    if version >= MIN_PYTHON_VERSION:
        return True, f"Python {version_str}"
    else:
        return False, f"需要 Python >= {'.'.join(map(str, MIN_PYTHON_VERSION))}, 当前 {version_str}"


def check_disk_space(required_mb: int = 500) -> Tuple[bool, str]:
    """检查磁盘空间"""
    try:
        import shutil
        total, used, free = shutil.disk_usage("/")
        free_mb = free // (2 ** 20)
        
        if free_mb >= required_mb:
            return True, f"{free_mb} MB 可用"
        else:
            return False, f"需要至少 {required_mb} MB, 当前 {free_mb} MB"
    except Exception as e:
        return False, f"检查失败: {e}"


def check_dependencies() -> Dict[str, bool]:
    """检查依赖包是否已安装"""
    results = {}
    
    for package in REQUIRED_PACKAGES:
        package_name = package.split('[')[0]  # 去除版本信息
        try:
            __import__(package_name)
            results[package] = True
        except ImportError:
            results[package] = False
    
    return results


def check_network() -> Tuple[bool, str]:
    """检查网络连接"""
    test_urls = [
        ("https://pypi.org", "PyPI"),
        ("https://urlhaus-api.abuse.ch", "URLhaus API"),
    ]
    
    for url, name in test_urls:
        try:
            req = urllib.request.Request(url, method='HEAD')
            urllib.request.urlopen(req, timeout=5)
            return True, f"{name} 可达"
        except Exception as e:
            continue
    
    return False, "无法连接外部网络"


def run_environment_check() -> bool:
    """运行环境检查"""
    print_header("环境检查")
    
    all_passed = True
    
    # Python版本
    passed, msg = check_python_version()
    if passed:
        print_success(f"Python版本: {msg}")
    else:
        print_error(f"Python版本: {msg}")
        all_passed = False
    
    # 磁盘空间
    passed, msg = check_disk_space()
    if passed:
        print_success(f"磁盘空间: {msg}")
    else:
        print_warning(f"磁盘空间: {msg} (继续安装)")
    
    # 依赖检查
    print_info("检查依赖包...")
    deps = check_dependencies()
    missing = [pkg for pkg, installed in deps.items() if not installed]
    
    if not missing:
        print_success(f"所有必需依赖已安装")
    else:
        print_warning(f"缺少依赖: {', '.join(missing)}")
        all_passed = False
    
    # 网络检查
    passed, msg = check_network()
    if passed:
        print_success(f"网络连接: {msg}")
    else:
        print_warning(f"网络连接: {msg} (可继续，离线模式)")
    
    return all_passed


# ============================================================================
# 依赖安装
# ============================================================================

def install_package(package: str) -> Tuple[bool, str]:
    """安装单个包"""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", package, "--quiet"],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        if result.returncode == 0:
            return True, f"{package} 安装成功"
        else:
            return False, f"{package} 安装失败: {result.stderr}"
    except subprocess.TimeoutExpired:
        return False, f"{package} 安装超时"
    except Exception as e:
        return False, f"{package} 安装失败: {e}"


def install_dependencies(quick: bool = False) -> bool:
    """安装所有依赖"""
    print_header("安装依赖")
    
    all_installed = True
    
    # 安装必需依赖
    print_info("安装必需依赖...")
    for package in REQUIRED_PACKAGES:
        passed, msg = install_package(package)
        if passed:
            print_success(msg)
        else:
            print_error(msg)
            all_installed = False
    
    # 安装可选依赖
    if not quick:
        print_info("\n安装可选依赖...")
        for package, desc in OPTIONAL_PACKAGES:
            passed, msg = install_package(package)
            if passed:
                print_success(f"{desc}: {package}")
            else:
                print_warning(f"{desc}: {package} (可选，继续)")
    
    return all_installed


# ============================================================================
# 配置初始化
# ============================================================================

def create_directories():
    """创建必要目录"""
    directories = [
        "logs",
        "data",
        "cache",
        "plugins",
        "backups",
    ]
    
    for dir_name in directories:
        Path(dir_name).mkdir(exist_ok=True)
        print_success(f"目录: {dir_name}/")


def generate_default_config() -> bool:
    """生成默认配置"""
    print_header("配置初始化")
    
    try:
        # 检查配置文件
        if Path(CONFIG_FILE).exists():
            print_info(f"配置文件 {CONFIG_FILE} 已存在")
            return True
        
        # 读取模板
        config_template = """# ========================================
# 邮件安全守门员配置
# ========================================

# 基本设置
app:
  name: "Email Security Gatekeeper"
  version: "3.1.0"
  debug: false
  port: 8443

# 检测引擎
detection:
  phishing:
    enabled: true
    confidence_threshold: 50
  
  bec:
    enabled: true
    confidence_threshold: 60
  
  ransomware:
    enabled: true
    confidence_threshold: 70

# 威胁情报
threat_intel:
  enabled: true
  builtin: true
  cache_ttl: 3600

# 白名单和黑名单
whitelist:
  - "trusted@example.com"
  - "internal@yourcompany.com"

blacklist:
  - "blocked@spam.com"

# 日志
logging:
  level: "INFO"
  file: "logs/gatekeeper.log"
"""
        
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            f.write(config_template)
        
        print_success(f"配置文件已创建: {CONFIG_FILE}")
        return True
        
    except Exception as e:
        print_error(f"配置生成失败: {e}")
        return False


def initialize_enterprise_config() -> bool:
    """初始化企业配置"""
    print_info("检查企业配置文件...")
    
    if Path(ENTERPRISE_CONFIG_FILE).exists():
        print_success(f"企业配置文件已存在")
        return True
    
    print_warning("企业配置文件不存在，将使用内置默认配置")
    return True


# ============================================================================
# 健康检查
# ============================================================================

def check_service_health() -> Tuple[bool, Dict]:
    """检查服务健康状态"""
    try:
        import urllib.request
        import urllib.error
        
        req = urllib.request.Request(HEALTH_CHECK_URL)
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode())
            return True, data
    except urllib.error.URLError:
        return False, {}
    except Exception as e:
        return False, {"error": str(e)}


def run_health_check() -> bool:
    """运行健康检查"""
    print_header("健康检查")
    
    checks = []
    
    # 1. 检查进程
    print_info("检查服务进程...")
    try:
        result = subprocess.run(
            ["pgrep", "-f", "uvicorn"],
            capture_output=True
        )
        if result.returncode == 0:
            print_success("服务进程运行中")
            checks.append(True)
        else:
            print_warning("服务进程未运行")
            checks.append(False)
    except Exception:
        checks.append(False)
    
    # 2. 检查端口
    print_info(f"检查端口 {DEFAULT_PORT}...")
    try:
        result = subprocess.run(
            ["lsof", "-i", f":{DEFAULT_PORT}", "-sTCP:LISTEN"],
            capture_output=True
        )
        if result.returncode == 0:
            print_success(f"端口 {DEFAULT_PORT} 已监听")
            checks.append(True)
        else:
            print_warning(f"端口 {DEFAULT_PORT} 未监听")
            checks.append(False)
    except Exception:
        checks.append(False)
    
    # 3. 检查健康端点
    print_info("检查健康端点...")
    passed, data = check_service_health()
    if passed:
        print_success("健康端点响应正常")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        checks.append(True)
    else:
        print_warning("健康端点无响应")
        checks.append(False)
    
    # 总结
    if all(checks):
        print_success("所有检查通过！")
        return True
    elif any(checks):
        print_warning("部分检查通过，服务可能正在启动")
        return True
    else:
        print_error("所有检查失败")
        return False


# ============================================================================
# 服务管理
# ============================================================================

def start_service(background: bool = True, port: int = DEFAULT_PORT) -> bool:
    """启动服务"""
    print_header("启动服务")
    
    # 检查端口占用
    try:
        result = subprocess.run(
            ["lsof", "-i", f":{port}", "-sTCP:LISTEN"],
            capture_output=True
        )
        if result.returncode == 0:
            print_warning(f"端口 {port} 已被占用，服务可能已在运行")
            return True
    except Exception:
        pass
    
    # 启动命令
    cmd = [
        sys.executable, "-m", "uvicorn",
        "scripts.api_server:app",
        "--host", "0.0.0.0",
        "--port", str(port),
        "--log-level", "info",
    ]
    
    if background:
        cmd.append("--background")
    
    try:
        print_info(f"启动命令: {' '.join(cmd)}")
        
        if background:
            # 后台启动
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=os.getcwd()
            )
            
            # 等待启动
            import time
            for i in range(10):
                time.sleep(1)
                passed, _ = check_service_health()
                if passed:
                    print_success(f"服务已启动 (PID: {process.pid})")
                    print_info(f"访问地址: http://localhost:{port}")
                    print_info(f"API文档: http://localhost:{port}/docs")
                    return True
            
            print_warning("服务启动中，请稍后检查")
            return True
        else:
            # 前台启动
            print_info("按 Ctrl+C 停止服务")
            subprocess.run(cmd, cwd=os.getcwd())
            return True
            
    except Exception as e:
        print_error(f"服务启动失败: {e}")
        return False


def stop_service() -> bool:
    """停止服务"""
    print_header("停止服务")
    
    try:
        # 查找进程
        result = subprocess.run(
            ["pgrep", "-f", "uvicorn.*api_server"],
            capture_output=True
        )
        
        if result.returncode != 0:
            print_info("没有找到运行中的服务")
            return True
        
        pids = result.stdout.decode().strip().split('\n')
        
        for pid in pids:
            if pid:
                try:
                    subprocess.run(["kill", pid])
                    print_success(f"已停止进程 {pid}")
                except Exception:
                    pass
        
        return True
        
    except Exception as e:
        print_error(f"停止服务失败: {e}")
        return False


def restart_service() -> bool:
    """重启服务"""
    print_header("重启服务")
    
    stop_service()
    import time
    time.sleep(2)
    return start_service()


# ============================================================================
# 测试运行
# ============================================================================

def run_tests() -> bool:
    """运行测试"""
    print_header("运行测试")
    
    test_file = "scripts/tests.py"
    
    if not Path(test_file).exists():
        print_error(f"测试文件不存在: {test_file}")
        return False
    
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", test_file, "-v", "--tb=short"],
            capture_output=False,
            cwd=os.getcwd()
        )
        
        if result.returncode == 0:
            print_success("所有测试通过！")
            return True
        else:
            print_error("部分测试失败")
            return False
            
    except Exception as e:
        print_error(f"测试运行失败: {e}")
        return False


# ============================================================================
# 状态检查
# ============================================================================

def show_status():
    """显示服务状态"""
    print_header("服务状态")
    
    # 版本信息
    print_info(f"邮件安全守门员 v{SCRIPT_VERSION}")
    print()
    
    # 环境检查
    print_info("环境状态:")
    passed, msg = check_python_version()
    status = "✅" if passed else "❌"
    print(f"  {status} Python: {msg}")
    
    deps = check_dependencies()
    installed = sum(1 for v in deps.values() if v)
    print(f"  ℹ️ 依赖: {installed}/{len(deps)} 已安装")
    
    print()
    
    # 服务状态
    print_info("服务状态:")
    
    try:
        result = subprocess.run(
            ["pgrep", "-f", "uvicorn.*api_server"],
            capture_output=True
        )
        if result.returncode == 0:
            print("  ✅ 服务运行中")
        else:
            print("  ⭕ 服务未运行")
    except Exception:
        print("  ⭕ 状态未知")
    
    # 健康检查
    passed, data = check_service_health()
    if passed:
        print("  ✅ 健康端点正常")
        if data.get('status'):
            print(f"     状态: {data['status']}")
    else:
        print("  ⭕ 健康端点无响应")
    
    print()
    
    # 威胁情报状态
    print_info("威胁情报状态:")
    print("  ✅ 内置数据库: 可用")
    print("  ℹ️  免费API: URLhaus, MalwareBazaar")
    print("  ⭕ 商业API: 未配置 (可选)")
    
    print()
    
    # 资源使用
    try:
        result = subprocess.run(
            ["ps", "aux"],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            for line in result.stdout.split('\n'):
                if 'uvicorn' in line and 'api_server' in line:
                    parts = line.split()
                    if len(parts) >= 6:
                        cpu = parts[2]
                        mem = parts[3]
                        print(f"  ℹ️  CPU: {cpu}% | 内存: {mem}%")
                    break
    except Exception:
        pass
    
    print()


# ============================================================================
# 主函数
# ============================================================================

def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description=f"邮件安全守门员部署脚本 v{SCRIPT_VERSION}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python scripts/deploy.py              # 交互式部署
  python scripts/deploy.py --quick       # 快速部署（跳过可选依赖）
  python scripts/deploy.py --config      # 仅检查配置
  python scripts/deploy.py --test       # 运行测试
  python scripts/deploy.py --status      # 查看状态
  python scripts/deploy.py --start       # 启动服务
  python scripts/deploy.py --stop        # 停止服务
  python scripts/deploy.py --restart     # 重启服务
  python scripts/deploy.py --health      # 健康检查
        """
    )
    
    parser.add_argument('--quick', action='store_true', help='快速部署（跳过可选依赖）')
    parser.add_argument('--config', action='store_true', help='仅检查配置')
    parser.add_argument('--test', action='store_true', help='运行测试')
    parser.add_argument('--status', action='store_true', help='查看状态')
    parser.add_argument('--start', action='store_true', help='启动服务')
    parser.add_argument('--stop', action='store_true', help='停止服务')
    parser.add_argument('--restart', action='store_true', help='重启服务')
    parser.add_argument('--health', action='store_true', help='健康检查')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT, help=f'服务端口 (默认: {DEFAULT_PORT})')
    parser.add_argument('--version', action='version', version=f'%(prog)s v{SCRIPT_VERSION}')
    
    args = parser.parse_args()
    
    # 如果没有指定任何操作，显示帮助
    if len(sys.argv) == 1:
        parser.print_help()
        return
    
    # 执行操作
    try:
        # 状态查看
        if args.status:
            show_status()
            return
        
        # 健康检查
        if args.health:
            run_health_check()
            return
        
        # 停止服务
        if args.stop:
            stop_service()
            return
        
        # 重启服务
        if args.restart:
            restart_service()
            return
        
        # 仅检查配置
        if args.config:
            generate_default_config()
            initialize_enterprise_config()
            print_success("配置检查完成")
            return
        
        # 运行测试
        if args.test:
            success = run_tests()
            sys.exit(0 if success else 1)
            return
        
        # 启动服务
        if args.start:
            run_environment_check()
            start_service(port=args.port)
            return
        
        # 完整部署流程
        print_header(f"邮件安全守门员 v{SCRIPT_VERSION} 部署")
        
        # 1. 环境检查
        env_ok = run_environment_check()
        
        # 2. 安装依赖
        deps_ok = install_dependencies(quick=args.quick)
        
        # 3. 配置初始化
        config_ok = generate_default_config()
        initialize_enterprise_config()
        
        # 4. 创建目录
        create_directories()
        
        # 5. 启动服务
        print_header("启动服务")
        start_service(port=args.port)
        
        # 6. 健康检查
        print()
        input("按 Enter 键进行健康检查...")
        run_health_check()
        
        # 总结
        print_header("部署完成")
        print(f"✅ 邮件安全守门员 v{SCRIPT_VERSION} 部署完成！")
        print()
        print_info(f"访问地址: http://localhost:{args.port}")
        print_info(f"API文档: http://localhost:{args.port}/docs")
        print_info(f"管理界面: http://localhost:{args.port}/admin")
        print()
        print_warning("提示：")
        print("  - 查看状态: python scripts/deploy.py --status")
        print("  - 停止服务: python scripts/deploy.py --stop")
        print("  - 运行测试: python scripts/deploy.py --test")
        print("  - 查看日志: tail -f logs/gatekeeper.log")
        print()
        
    except KeyboardInterrupt:
        print("\n")
        print_warning("部署已取消")
        sys.exit(0)
    except Exception as e:
        print_error(f"部署失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
