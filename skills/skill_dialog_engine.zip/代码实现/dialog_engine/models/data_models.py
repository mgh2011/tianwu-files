# 对话引擎核心模块实现

## 项目结构

```
代码实现/
├── dialog_engine/
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── dialog_engine.py          # 对话引擎主控制器
│   │   ├── state_manager.py         # 状态管理器
│   │   └── context_manager.py       # 上下文管理器
│   ├── nlu/
│   │   ├── __init__.py
│   │   ├── intent_classifier.py     # 意图分类器
│   │   ├── entity_extractor.py       # 实体抽取器
│   │   └── slot_filler.py           # 槽位填充器
│   ├── policy/
│   │   ├── __init__.py
│   │   ├── policy_router.py          # 策略路由器
│   │   └── response_generator.py    # 回复生成器
│   ├── memory/
│   │   ├── __init__.py
│   │   ├── short_term_memory.py      # 短期记忆
│   │   ├── long_term_memory.py       # 长期记忆
│   │   └── user_profile.py          # 用户画像
│   ├── security/
│   │   ├── __init__.py
│   │   ├── content_filter.py         # 内容过滤器
│   │   ├── privacy_guard.py          # 隐私保护
│   │   └── audit_logger.py           # 审计日志
│   ├── models/
│   │   ├── __init__.py
│   │   └── data_models.py           # 数据模型
│   ├── config/
│   │   ├── __init__.py
│   │   └── default_config.py        # 默认配置
│   └── utils/
│       ├── __init__.py
│       └── helpers.py               # 辅助函数
├── tests/
│   ├── __init__.py
│   ├── test_dialog_engine.py
│   ├── test_intent_classifier.py
│   ├── test_entity_extractor.py
│   ├── test_slot_filler.py
│   ├── test_memory.py
│   └── test_security.py
├── requirements.txt
└── README.md
```

## 1. 数据模型定义

```python
# dialog_engine/models/data_models.py
"""
对话引擎数据模型定义
包含所有核心数据结构和类型定义
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Callable
from uuid import uuid4


# ============== 枚举类型 ==============

class DialogState(Enum):
    """对话状态枚举"""
    INIT = "init"
    WAITING_INTENT = "waiting_intent"
    INTENT_CONFIRMED = "intent_confirmed"
    COLLECTING_SLOTS = "collecting_slots"
    CONFIRMING = "confirming"
    EXECUTING = "executing"
    RESPONDING = "responding"
    ERROR = "error"
    COMPLETED = "completed"
    EXPIRED = "expired"


class IntentType(Enum):
    """意图类型枚举"""
    # 通用意图
    GREETING = "greeting"
    GOODBYE = "goodbye"
    HELP = "help"
    COMPLAINT = "complaint"
    
    # 业务意图
    QUERY = "query"
    BOOKING = "booking"
    CANCELLATION = "cancellation"
    MODIFICATION = "modification"
    PAYMENT = "payment"
    REFUND = "refund"
    
    # 系统意图
    REPEAT = "repeat"
    CLARIFICATION = "clarification"
    CONFIRMATION = "confirmation"
    DENIAL = "denial"
    UNKNOWN = "unknown"


class EntityType(Enum):
    """实体类型枚举"""
    PERSON = "person"
    ORGANIZATION = "organization"
    LOCATION = "location"
    TIME = "time"
    DATE = "date"
    NUMBER = "number"
    MONEY = "money"
    PHONE = "phone"
    EMAIL = "email"
    URL = "url"
    PRODUCT = "product"
    SERVICE = "service"
    CUSTOM = "custom"


class SlotType(Enum):
    """槽位类型枚举"""
    REQUIRED = "required"
    OPTIONAL = "optional"
    DERIVED = "derived"
    SYSTEM = "system"


class SlotStatus(Enum):
    """槽位状态枚举"""
    EMPTY = "empty"
    FILLED = "filled"
    VALIDATED = "validated"
    INVALID = "invalid"
    EXPIRED = "expired"


class MessageType(Enum):
    """消息类型枚举"""
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    CARD = "card"
    QUICK_REPLY = "quick_reply"
    CUSTOM = "custom"


class OutputType(Enum):
    """输出类型枚举"""
    TEXT = "text"
    IMAGE = "image"
    CARD = "card"
    AUDIO = "audio"
    VIDEO = "video"
    QUICK_REPLY = "quick_reply"
    CUSTOM = "custom"


class SensitiveLevel(Enum):
    """敏感级别枚举"""
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    BLOCK = "block"


# ============== 核心数据类 ==============

@dataclass
class Entity:
    """实体对象"""
    type: EntityType
    value: str
    normalized_value: Optional[str] = None
    start_pos: int = 0
    end_pos: int = 0
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type.value if isinstance(self.type, EntityType) else self.type,
            "value": self.value,
            "normalized_value": self.normalized_value,
            "start_pos": self.start_pos,
            "end_pos": self.end_pos,
            "confidence": self.confidence,
            "metadata": self.metadata
        }


@dataclass
class IntentResult:
    """意图识别结果"""
    intent: IntentType
    confidence: float
    alternatives: List[tuple] = field(default_factory=list)  # [(intent, confidence), ...]
    requires_slots: List[str] = field(default_factory=dict)
    policy_name: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "intent": self.intent.value if isinstance(self.intent, IntentType) else self.intent,
            "confidence": self.confidence,
            "alternatives": [(a[0].value if isinstance(a[0], IntentType) else a[0], a[1]) for a in self.alternatives],
            "requires_slots": self.requires_slots,
            "policy_name": self.policy_name,
            "metadata": self.metadata
        }


@dataclass
class Slot:
    """槽位对象"""
    name: str
    type: SlotType
    value: Any = None
    status: SlotStatus = SlotStatus.EMPTY
    validation_rules: Optional[Callable] = None
    prompt_template: Optional[str] = None
    default_value: Any = None
    confidence: float = 1.0
    source: Optional[str] = None
    filled_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "type": self.type.value if isinstance(self.type, SlotType) else self.type,
            "value": self.value,
            "status": self.status.value if isinstance(self.status, SlotStatus) else self.status,
            "default_value": self.default_value,
            "confidence": self.confidence,
            "source": self.source,
            "filled_at": self.filled_at.isoformat() if self.filled_at else None
        }


@dataclass
class SlotFillingResult:
    """槽位填充结果"""
    is_complete: bool
    filled_slots: Dict[str, Slot]
    missing_slots: List[str]
    invalid_slots: List[str]
    prompting_slot: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_complete": self.is_complete,
            "filled_slots": {k: v.to_dict() for k, v in self.filled_slots.items()},
            "missing_slots": self.missing_slots,
            "invalid_slots": self.invalid_slots,
            "prompting_slot": self.prompting_slot
        }


@dataclass
class TurnContext:
    """单轮对话上下文"""
    turn_id: int
    user_message: str
    bot_response: Optional[str] = None
    intent: Optional[str] = None
    entities: List[Entity] = field(default_factory=list)
    slots: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    is_successful: bool = True
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DialogContext:
    """对话上下文"""
    session_id: str
    user_id: str
    current_turn: int = 0
    state: DialogState = DialogState.INIT
    history: List[TurnContext] = field(default_factory=list)
    slots: Dict[str, Slot] = field(default_factory=dict)
    entities: List[Entity] = field(default_factory=list)
    intent: Optional[IntentResult] = None
    variables: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "current_turn": self.current_turn,
            "state": self.state.value if isinstance(self.state, DialogState) else self.state,
            "history": [h.__dict__ for h in self.history],
            "slots": {k: v.to_dict() for k, v in self.slots.items()},
            "entities": [e.to_dict() for e in self.entities],
            "intent": self.intent.to_dict() if self.intent else None,
            "variables": self.variables,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }


@dataclass
class DialogPolicy:
    """对话策略"""
    name: str
    intent: IntentType
    response_templates: Dict[str, str] = field(default_factory=dict)
    slot_requirements: List[str] = field(default_factory=list)
    confirm_needed: bool = False
    max_turns: int = 10
    fallback_policy: Optional[str] = None
    custom_config: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "intent": self.intent.value if isinstance(self.intent, IntentType) else self.intent,
            "response_templates": self.response_templates,
            "slot_requirements": self.slot_requirements,
            "confirm_needed": self.confirm_needed,
            "max_turns": self.max_turns,
            "fallback_policy": self.fallback_policy,
            "custom_config": self.custom_config
        }


@dataclass
class QuickReply:
    """快捷回复"""
    text: str
    value: str
    action: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Card:
    """卡片消息"""
    card_type: str
    title: Optional[str] = None
    content: Optional[str] = None
    image_url: Optional[str] = None
    actions: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Message:
    """消息对象"""
    type: MessageType
    content: str
    image_url: Optional[str] = None
    audio_url: Optional[str] = None
    card: Optional[Card] = None
    quick_replies: List[QuickReply] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DialogResponse:
    """对话响应"""
    response_id: str
    session_id: str
    message: Message
    intent: Optional[str] = None
    entities: List[Dict] = field(default_factory=list)
    slots: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    is_final: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "response_id": self.response_id,
            "session_id": self.session_id,
            "message": {
                "type": self.message.type.value if isinstance(self.message.type, MessageType) else self.message.type,
                "content": self.message.content,
                "image_url": self.message.image_url,
                "audio_url": self.message.audio_url,
                "card": self.message.card.__dict__ if self.message.card else None,
                "quick_replies": [qr.__dict__ for qr in self.message.quick_replies]
            },
            "intent": self.intent,
            "entities": self.entities,
            "slots": self.slots,
            "context": self.context,
            "timestamp": self.timestamp.isoformat(),
            "is_final": self.is_final,
            "metadata": self.metadata
        }


@dataclass
class DialogRequest:
    """对话请求"""
    session_id: str
    user_id: str
    message: str
    message_type: MessageType = MessageType.TEXT
    context: Dict[str, Any] = field(default_factory=dict)
    stream: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Session:
    """会话对象"""
    session_id: str
    user_id: str
    state: DialogState = DialogState.INIT
    context: Optional[DialogContext] = None
    created_at: datetime = field(default_factory=datetime.now)
    last_active_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Memory:
    """记忆对象"""
    memory_id: str
    user_id: str
    content: str
    memory_type: str
    importance: float = 1.0
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    last_accessed_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UserPreferences:
    """用户偏好"""
    language: str = "zh-CN"
    theme: str = "auto"
    notification_enabled: bool = True
    silence_hours: Optional[Dict] = None
    custom_preferences: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UserProfile:
    """用户画像"""
    user_id: str
    name: Optional[str] = None
    age: Optional[int] = None
    gender: Optional[str] = None
    preferences: UserPreferences = field(default_factory=UserPreferences)
    tags: List[str] = field(default_factory=list)
    interaction_count: int = 0
    last_interaction_at: Optional[datetime] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ContentCheckResult:
    """内容检查结果"""
    is_safe: bool
    sensitive_level: SensitiveLevel
    sensitive_words: List[str] = field(default_factory=list)
    suggestion: Optional[str] = None
    filtered_content: Optional[str] = None


@dataclass
class AuditLog:
    """审计日志"""
    log_id: str
    session_id: str
    user_id: str
    action: str
    content: str
    result: str
    timestamp: datetime = field(default_factory=datetime.now)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


# ============== 响应码定义 ==============

class ResponseCode:
    """响应码定义"""
    SUCCESS = 0
    GENERAL_ERROR = 1000
    INVALID_REQUEST = 1001
    SESSION_NOT_FOUND = 1002
    SESSION_EXPIRED = 1003
    INTENT_NOT_RECOGNIZED = 1004
    SLOT_FILLING_FAILED = 1005
    POLICY_NOT_FOUND = 1006
    CONTENT_BLOCKED = 1007
    SERVICE_UNAVAILABLE = 1008
    RATE_LIMIT_EXCEEDED = 1009
    UNAUTHORIZED = 1010
