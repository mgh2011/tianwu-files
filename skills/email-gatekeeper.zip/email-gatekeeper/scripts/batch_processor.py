# ========== 批量邮件检测处理器 v3.0.5 ==========
# 文件: scripts/batch_processor.py
# 版本: 3.0.5
# 功能: 批量邮件处理、并发检测、结果汇总报告

"""
批量邮件检测处理器
支持: 批量处理、并发检测、自定义规则、结果汇总
"""

import asyncio
import logging
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import json

logger = logging.getLogger(__name__)


# ========== 数据结构定义 ==========

@dataclass
class BatchConfig:
    """批量处理配置"""
    max_workers: int = 10  # 最大并发数
    timeout: float = 30.0  # 单个邮件超时时间
    quick_mode: bool = False  # 快速模式
    generate_report: bool = True  # 生成报告
    report_format: str = "json"  # 报告格式: json, html, markdown


@dataclass
class BatchResult:
    """批量处理结果"""
    total_emails: int = 0
    processed: int = 0
    failed: int = 0
    phishing_detected: int = 0
    bec_detected: int = 0
    ransomware_detected: int = 0
    news_detected: int = 0
    fake_news_detected: int = 0
    quarantined: int = 0
    warnings: int = 0
    delivered: int = 0
    processing_time: float = 0.0
    details: List[Dict] = field(default_factory=list)
    summary: Dict = field(default_factory=dict)


# ========== 批量处理器 ==========

class BatchEmailProcessor:
    """批量邮件检测处理器 v3.0.5"""
    
    def __init__(self, config: BatchConfig = None):
        self.config = config or BatchConfig()
        self.custom_rules: List[Callable] = []
        self.stats = {
            'total_processed': 0,
            'total_phishing': 0,
            'total_bec': 0,
            'total_ransomware': 0,
        }
        logger.info(f"批量处理器初始化完成 v3.0.5 (并发数={self.config.max_workers})")
    
    def add_custom_rule(self, rule: Callable[[Any], Dict]) -> None:
        """
        添加自定义检测规则
        
        Args:
            rule: 检测规则函数，接收Email对象，返回检测结果字典
        """
        self.custom_rules.append(rule)
        logger.info(f"添加自定义规则: {rule.__name__ if hasattr(rule, '__name__') else 'anonymous'}")
    
    async def process_batch(
        self,
        emails: List[Any],
        gatekeeper: Any = None,
        news_detector: Any = None
    ) -> BatchResult:
        """
        批量处理邮件
        
        Args:
            emails: 邮件列表
            gatekeeper: 邮件安全守门员实例
            news_detector: 新闻邮件检测器实例
        
        Returns:
            BatchResult: 批量处理结果
        """
        start_time = datetime.now()
        result = BatchResult(total_emails=len(emails))
        
        # 使用线程池并发处理
        with ThreadPoolExecutor(max_workers=self.config.max_workers) as executor:
            loop = asyncio.get_event_loop()
            tasks = []
            
            for email in emails:
                task = loop.run_in_executor(
                    executor,
                    self._process_single_email,
                    email,
                    gatekeeper,
                    news_detector
                )
                tasks.append(task)
            
            # 等待所有任务完成
            try:
                results = await asyncio.gather(*tasks, return_exceptions=True)
                
                for i, res in enumerate(results):
                    if isinstance(res, Exception):
                        logger.error(f"邮件处理失败: {res}")
                        result.failed += 1
                    else:
                        result.processed += 1
                        result.details.append(res)
                        
                        # 统计
                        if res.get('is_phishing'):
                            result.phishing_detected += 1
                        if res.get('is_bec'):
                            result.bec_detected += 1
                        if res.get('is_ransomware'):
                            result.ransomware_detected += 1
                        if res.get('is_news'):
                            result.news_detected += 1
                        if res.get('is_fake_news'):
                            result.fake_news_detected += 1
                        
                        # 动作统计
                        action = res.get('recommended_action', 'deliver')
                        if action == 'quarantine':
                            result.quarantined += 1
                        elif action == 'deliver_with_warning':
                            result.warnings += 1
                        else:
                            result.delivered += 1
            
            except Exception as e:
                logger.error(f"批量处理异常: {e}")
                result.failed = result.total_emails - result.processed
        
        # 计算处理时间
        result.processing_time = (datetime.now() - start_time).total_seconds()
        
        # 生成汇总
        result.summary = self._generate_summary(result)
        
        # 更新统计
        self.stats['total_processed'] += result.processed
        self.stats['total_phishing'] += result.phishing_detected
        self.stats['total_bec'] += result.bec_detected
        self.stats['total_ransomware'] += result.ransomware_detected
        
        return result
    
    def _process_single_email(
        self,
        email: Any,
        gatekeeper: Any = None,
        news_detector: Any = None
    ) -> Dict:
        """
        处理单个邮件（同步方法，在线程池中执行）
        """
        result = {
            'message_id': getattr(email, 'message_id', 'unknown'),
            'sender': getattr(email, 'sender', 'unknown'),
            'subject': getattr(email, 'subject', ''),
            'is_phishing': False,
            'is_bec': False,
            'is_ransomware': False,
            'is_news': False,
            'is_fake_news': False,
            'recommended_action': 'deliver',
            'risk_score': 0,
            'custom_rules_triggered': [],
        }
        
        try:
            # 1. 使用守门员检测
            if gatekeeper:
                # 同步调用异步方法
                loop = asyncio.new_event_loop()
                try:
                    detection = loop.run_until_complete(gatekeeper.analyze_email(email))
                    result['is_phishing'] = detection.phishing_check.get('is_phishing', False)
                    result['is_bec'] = detection.phishing_check.get('bec_check', {}).get('is_bec', False)
                    result['is_ransomware'] = detection.phishing_check.get('ransomware_check', {}).get('is_ransomware', False)
                    result['risk_score'] = detection.risk_score
                    result['recommended_action'] = detection.recommended_action
                finally:
                    loop.close()
            
            # 2. 使用新闻检测器检测
            if news_detector and not result['is_phishing']:
                from scripts.news_email_detector import NewsEmail, NewsDetectionResult
                # 转换为新闻邮件格式
                news_email = NewsEmail(
                    message_id=getattr(email, 'message_id', ''),
                    sender=getattr(email, 'sender', ''),
                    subject=getattr(email, 'subject', ''),
                    body=getattr(email, 'body', ''),
                    links=getattr(email, 'links', []),
                )
                news_result = news_detector.quick_scan(news_email) if self.config.quick_mode else news_detector.detect(news_email)
                result['is_news'] = news_result.is_news if hasattr(news_result, 'is_news') else news_result.get('is_news', False)
                result['is_fake_news'] = news_result.is_fake_news if hasattr(news_result, 'is_fake_news') else False
            
            # 3. 执行自定义规则
            for rule in self.custom_rules:
                try:
                    rule_result = rule(email)
                    if rule_result.get('triggered'):
                        result['custom_rules_triggered'].append({
                            'rule': rule.__name__ if hasattr(rule, '__name__') else 'anonymous',
                            'result': rule_result
                        })
                        # 自定义规则可能修改推荐动作
                        if rule_result.get('action'):
                            result['recommended_action'] = rule_result['action']
                except Exception as e:
                    logger.warning(f"自定义规则执行失败: {e}")
        
        except Exception as e:
            logger.error(f"邮件处理异常: {e}")
            result['error'] = str(e)
        
        return result
    
    def _generate_summary(self, result: BatchResult) -> Dict:
        """生成汇总报告"""
        return {
            'total': result.total_emails,
            'processed': result.processed,
            'success_rate': f"{result.processed / max(1, result.total_emails) * 100:.1f}%",
            'threats_detected': result.phishing_detected + result.bec_detected + result.ransomware_detected,
            'threat_rate': f"{(result.phishing_detected + result.bec_detected + result.ransomware_detected) / max(1, result.processed) * 100:.1f}%",
            'quarantine_rate': f"{result.quarantined / max(1, result.processed) * 100:.1f}%",
            'avg_processing_time': f"{result.processing_time / max(1, result.processed) * 1000:.1f}ms",
            'total_time': f"{result.processing_time:.2f}s",
        }
    
    def generate_report(self, result: BatchResult, format: str = None) -> str:
        """
        生成报告
        
        Args:
            result: 批量处理结果
            format: 报告格式 (json, html, markdown)
        
        Returns:
            str: 报告内容
        """
        format = format or self.config.report_format
        
        if format == "json":
            return json.dumps({
                'summary': result.summary,
                'stats': {
                    'total_emails': result.total_emails,
                    'processed': result.processed,
                    'failed': result.failed,
                    'phishing_detected': result.phishing_detected,
                    'bec_detected': result.bec_detected,
                    'ransomware_detected': result.ransomware_detected,
                    'quarantined': result.quarantined,
                    'warnings': result.warnings,
                    'delivered': result.delivered,
                },
                'details': result.details[:100],  # 限制详情数量
            }, ensure_ascii=False, indent=2)
        
        elif format == "html":
            return self._generate_html_report(result)
        
        else:  # markdown
            return self._generate_markdown_report(result)
    
    def _generate_markdown_report(self, result: BatchResult) -> str:
        """生成Markdown报告"""
        report = f"""# 邮件批量检测报告

## 汇总统计

| 指标 | 数值 |
|------|------|
| 总邮件数 | {result.total_emails} |
| 处理成功 | {result.processed} |
| 处理失败 | {result.failed} |
| 处理成功率 | {result.summary.get('success_rate', 'N/A')} |
| 处理时间 | {result.summary.get('total_time', 'N/A')} |
| 平均处理时间 | {result.summary.get('avg_processing_time', 'N/A')} |

## 威胁检测

| 威胁类型 | 检测数量 |
|----------|----------|
| 钓鱼邮件 | {result.phishing_detected} |
| BEC诈骗 | {result.bec_detected} |
| 勒索邮件 | {result.ransomware_detected} |
| 假新闻 | {result.fake_news_detected} |
| **总计** | **{result.summary.get('threats_detected', 0)}** |

## 处理结果

| 动作 | 数量 | 比例 |
|------|------|------|
| 已隔离 | {result.quarantined} | {result.summary.get('quarantine_rate', 'N/A')} |
| 警告放行 | {result.warnings} | - |
| 正常放行 | {result.delivered} | - |

---

*报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
*处理器版本: v3.0.5*
"""
        return report
    
    def _generate_html_report(self, result: BatchResult) -> str:
        """生成HTML报告"""
        return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>邮件批量检测报告</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1 {{ color: #333; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #4CAF50; color: white; }}
        tr:nth-child(even) {{ background-color: #f2f2f2; }}
        .danger {{ color: red; font-weight: bold; }}
        .success {{ color: green; }}
    </style>
</head>
<body>
    <h1>🛡️ 邮件批量检测报告</h1>
    
    <h2>汇总统计</h2>
    <table>
        <tr><th>指标</th><th>数值</th></tr>
        <tr><td>总邮件数</td><td>{result.total_emails}</td></tr>
        <tr><td>处理成功</td><td>{result.processed}</td></tr>
        <tr><td>处理失败</td><td>{result.failed}</td></tr>
        <tr><td>处理成功率</td><td>{result.summary.get('success_rate', 'N/A')}</td></tr>
        <tr><td>总处理时间</td><td>{result.summary.get('total_time', 'N/A')}</td></tr>
    </table>
    
    <h2>威胁检测</h2>
    <table>
        <tr><th>威胁类型</th><th>检测数量</th></tr>
        <tr class="danger"><td>钓鱼邮件</td><td>{result.phishing_detected}</td></tr>
        <tr class="danger"><td>BEC诈骗</td><td>{result.bec_detected}</td></tr>
        <tr class="danger"><td>勒索邮件</td><td>{result.ransomware_detected}</td></tr>
        <tr><td>假新闻</td><td>{result.fake_news_detected}</td></tr>
    </table>
    
    <h2>处理结果</h2>
    <table>
        <tr><th>动作</th><th>数量</th><th>比例</th></tr>
        <tr class="danger"><td>已隔离</td><td>{result.quarantined}</td><td>{result.summary.get('quarantine_rate', 'N/A')}</td></tr>
        <tr><td>警告放行</td><td>{result.warnings}</td><td>-</td></tr>
        <tr class="success"><td>正常放行</td><td>{result.delivered}</td><td>-</td></tr>
    </table>
    
    <p><small>报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 处理器版本: v3.0.5</small></p>
</body>
</html>"""
    
    def get_stats(self) -> Dict:
        """获取累计统计"""
        return self.stats.copy()


# ========== 使用示例 ==========

if __name__ == "__main__":
    import asyncio
    
    async def main():
        # 创建配置
        config = BatchConfig(
            max_workers=5,
            quick_mode=True,
            generate_report=True
        )
        
        # 创建处理器
        processor = BatchEmailProcessor(config)
        
        # 添加自定义规则示例
        def high_value_sender_rule(email):
            """高价值发件人规则：来自CEO的邮件需要特别注意"""
            high_value_senders = ['ceo@company.com', 'cfo@company.com']
            if getattr(email, 'sender', '').lower() in high_value_senders:
                return {
                    'triggered': True,
                    'reason': '高价值发件人，需要验证',
                    'action': 'deliver_with_warning'
                }
            return {'triggered': False}
        
        processor.add_custom_rule(high_value_sender_rule)
        
        print("批量处理器初始化完成")
        print(f"配置: 并发数={config.max_workers}, 快速模式={config.quick_mode}")
    
    asyncio.run(main())
