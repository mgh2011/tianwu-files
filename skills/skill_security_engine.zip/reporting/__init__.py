"""
报表模块
Reporting Module

提供安全检测报告生成功能
"""

from .report_generator import (
    ReportGenerator,
    SecurityReport,
    ReportType,
    ReportFormat,
    create_report_generator
)

__version__ = "v3.0.0"
__all__ = [
    'ReportGenerator',
    'SecurityReport',
    'ReportType',
    'ReportFormat',
    'create_report_generator'
]
