"""
边界防护模块
Boundary Protection Module

提供防火墙和WAF防护功能
"""

from .firewall import FirewallModule
from .waf import WAFModule

__version__ = "v3.0.0"
__all__ = [
    'FirewallModule',
    'WAFModule'
]
