# dialog_engine/core/context_manager.py
"""
对话上下文管理器
负责管理对话上下文、历史记录和上下文压缩
"""

import logging
import copy
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

from ..models.data_models import (
    DialogContext, TurnContext, Entity, IntentResult, 
    Slot, DialogState, MessageType
)


logger = logging.getLogger(__name__)


class ContextManager:
    """
    对话上下文管理器
    负责维护和管理对话上下文，包括历史记录、槽位、实体等
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.max_history_turns = self.config.get("max_history_turns", 20)
        self.max_context_size = self.config.get("max_context_size", 10000)
        self.enable_compression = self.config.get("enable_context_compression", True)
        
        self.contexts: Dict[str, DialogContext] = {}
        self.context_backups: Dict[str, List[DialogContext]] = {}
        
    def create_context(self, session_id: str, user_id: str) -> DialogContext:
        """
        创建新的对话上下文
        
        Args:
            session_id: 会话ID
            user_id: 用户ID
            
        Returns:
            DialogContext: 创建的上下文对象
        """
        context = DialogContext(
            session_id=session_id,
            user_id=user_id,
            current_turn=0,
            state=DialogState.INIT,
            history=[],
            slots={},
            entities=[],
            variables={},
            metadata={}
        )
        
        self.contexts[session_id] = context
        logger.debug(f"Created context for session: {session_id}")
        
        return context
    
    def get_context(self, session_id: str) -> Optional[DialogContext]:
        """获取对话上下文"""
        return self.contexts.get(session_id)
    
    def update_context(self, session_id: str, **kwargs) -> bool:
        """更新上下文"""
        context = self.contexts.get(session_id)
        if not context:
            return False
        
        for key, value in kwargs.items():
            if hasattr(context, key):
                setattr(context, key, value)
        
        context.updated_at = datetime.now()
        return True
    
    def add_turn(self, session_id: str, user_message: str,
                 bot_response: Optional[str] = None,
                 intent: Optional[str] = None,
                 entities: Optional[List[Entity]] = None,
                 slots: Optional[Dict[str, Any]] = None,
                 is_successful: bool = True,
                 error_message: Optional[str] = None) -> Optional[TurnContext]:
        """
        添加一轮对话到上下文
        
        Args:
            session_id: 会话ID
            user_message: 用户消息
            bot_response: 机器人回复
            intent: 意图
            entities: 实体列表
            slots: 槽位字典
            is_successful: 是否成功
            error_message: 错误信息
            
        Returns:
            TurnContext: 创建的轮次上下文
        """
        context = self.contexts.get(session_id)
        if not context:
            logger.error(f"Context not found for session: {session_id}")
            return None
        
        context.current_turn += 1
        
        turn = TurnContext(
            turn_id=context.current_turn,
            user_message=user_message,
            bot_response=bot_response,
            intent=intent,
            entities=entities or [],
            slots=slots or {},
            timestamp=datetime.now(),
            is_successful=is_successful,
            error_message=error_message
        )
        
        context.history.append(turn)
        
        # 限制历史长度
        if len(context.history) > self.max_history_turns:
            # 执行上下文压缩
            if self.enable_compression:
                self._compress_context(session_id)
            else:
                context.history.pop(0)
        
        context.updated_at = datetime.now()
        logger.debug(f"Added turn {context.current_turn} to session: {session_id}")
        
        return turn
    
    def _compress_context(self, session_id: str):
        """
        压缩上下文
        保留关键信息，移除冗余数据
        """
        context = self.contexts.get(session_id)
        if not context or len(context.history) <= self.max_history_turns:
            return
        
        # 备份压缩前的上下文
        if session_id not in self.context_backups:
            self.context_backups[session_id] = []
        self.context_backups[session_id].append(copy.deepcopy(context))
        
        # 保留最近N轮和关键轮次
        recent_turns = context.history[-self.max_history_turns:]
        
        # 提取关键信息
        key_turns = []
        for i, turn in enumerate(context.history):
            # 保留意图变更的轮次
            if i == 0 or (i > 0 and turn.intent != context.history[i-1].intent):
                key_turns.append(turn)
        
        # 合并关键轮次和最近轮次
        key_turn_ids = {t.turn_id for t in key_turns}
        merged_turns = []
        for turn in recent_turns:
            if turn.turn_id not in key_turn_ids:
                merged_turns.append(turn)
        
        context.history = key_turns + merged_turns[-self.max_history_turns:]
        
        # 更新turn_id
        for i, turn in enumerate(context.history):
            turn.turn_id = i + 1
        
        logger.info(f"Compressed context for session: {session_id}, "
                   f"removed {len(context.history) - self.max_history_turns} turns")
    
    def update_slots(self, session_id: str, slots: Dict[str, Slot]) -> bool:
        """更新槽位"""
        context = self.contexts.get(session_id)
        if not context:
            return False
        
        context.slots.update(slots)
        context.updated_at = datetime.now()
        return True
    
    def get_slot(self, session_id: str, slot_name: str) -> Optional[Slot]:
        """获取指定槽位"""
        context = self.contexts.get(session_id)
        if context:
            return context.slots.get(slot_name)
        return None
    
    def update_entities(self, session_id: str, entities: List[Entity]) -> bool:
        """更新实体列表"""
        context = self.contexts.get(session_id)
        if not context:
            return False
        
        # 合并实体，去重
        existing_types = {e.type for e in context.entities}
        for entity in entities:
            if entity.type not in existing_types:
                context.entities.append(entity)
        
        context.updated_at = datetime.now()
        return True
    
    def set_intent(self, session_id: str, intent: IntentResult) -> bool:
        """设置当前意图"""
        context = self.contexts.get(session_id)
        if not context:
            return False
        
        context.intent = intent
        context.updated_at = datetime.now()
        return True
    
    def set_variable(self, session_id: str, key: str, value: Any) -> bool:
        """设置上下文变量"""
        context = self.contexts.get(session_id)
        if not context:
            return False
        
        context.variables[key] = value
        context.updated_at = datetime.now()
        return True
    
    def get_variable(self, session_id: str, key: str, default: Any = None) -> Any:
        """获取上下文变量"""
        context = self.contexts.get(session_id)
        if context:
            return context.variables.get(key, default)
        return default
    
    def get_history(self, session_id: str, limit: Optional[int] = None) -> List[TurnContext]:
        """获取对话历史"""
        context = self.contexts.get(session_id)
        if not context:
            return []
        
        history = context.history
        if limit:
            history = history[-limit:]
        return history
    
    def get_last_turn(self, session_id: str) -> Optional[TurnContext]:
        """获取最后一轮对话"""
        context = self.contexts.get(session_id)
        if context and context.history:
            return context.history[-1]
        return None
    
    def get_last_n_turns(self, session_id: str, n: int) -> List[TurnContext]:
        """获取最近N轮对话"""
        return self.get_history(session_id, limit=n)
    
    def clear_history(self, session_id: str) -> bool:
        """清空对话历史"""
        context = self.contexts.get(session_id)
        if context:
            context.history = []
            context.updated_at = datetime.now()
            return True
        return False
    
    def delete_context(self, session_id: str) -> bool:
        """删除上下文"""
        if session_id in self.contexts:
            del self.contexts[session_id]
            logger.info(f"Deleted context for session: {session_id}")
            return True
        return False
    
    def get_context_summary(self, session_id: str) -> Dict[str, Any]:
        """获取上下文摘要"""
        context = self.contexts.get(session_id)
        if not context:
            return {}
        
        return {
            "session_id": context.session_id,
            "user_id": context.user_id,
            "current_turn": context.current_turn,
            "state": context.state.value if isinstance(context.state, DialogState) else context.state,
            "intent": context.intent.intent.value if context.intent else None,
            "slots_count": len(context.slots),
            "entities_count": len(context.entities),
            "history_count": len(context.history),
            "created_at": context.created_at.isoformat(),
            "updated_at": context.updated_at.isoformat()
        }
    
    def export_context(self, session_id: str) -> Optional[Dict[str, Any]]:
        """导出上下文为字典"""
        context = self.contexts.get(session_id)
        if context:
            return context.to_dict()
        return None
    
    def import_context(self, data: Dict[str, Any]) -> Optional[DialogContext]:
        """从字典导入上下文"""
        try:
            # 简化实现，实际应使用完整的反序列化
            context = DialogContext(
                session_id=data.get("session_id", ""),
                user_id=data.get("user_id", ""),
                current_turn=data.get("current_turn", 0),
                state=DialogState(data.get("state", "init")),
                variables=data.get("variables", {}),
                metadata=data.get("metadata", {})
            )
            return context
        except Exception as e:
            logger.error(f"Failed to import context: {e}")
            return None
    
    def get_recent_entities(self, session_id: str, 
                           entity_type: Optional[str] = None,
                           limit: int = 10) -> List[Entity]:
        """获取最近的实体"""
        context = self.contexts.get(session_id)
        if not context:
            return []
        
        entities = context.entities
        if entity_type:
            entities = [e for e in entities if e.type.value == entity_type]
        
        return entities[-limit:]
    
    def get_conversation_text(self, session_id: str, 
                             include_bot: bool = True) -> str:
        """获取对话文本"""
        history = self.get_history(session_id)
        lines = []
        
        for turn in history:
            lines.append(f"用户: {turn.user_message}")
            if include_bot and turn.bot_response:
                lines.append(f"助手: {turn.bot_response}")
        
        return "\n".join(lines)
    
    def get_context_size(self, session_id: str) -> int:
        """估算上下文大小(字符数)"""
        context = self.contexts.get(session_id)
        if not context:
            return 0
        
        # 简单估算
        return len(str(context.to_dict()))
    
    def cleanup_contexts(self, max_age_hours: int = 24) -> int:
        """清理过期的上下文"""
        now = datetime.now()
        to_delete = []
        
        for session_id, context in self.contexts.items():
            age = (now - context.updated_at).total_seconds() / 3600
            if age > max_age_hours:
                to_delete.append(session_id)
        
        for session_id in to_delete:
            self.delete_context(session_id)
        
        if to_delete:
            logger.info(f"Cleaned up {len(to_delete)} expired contexts")
        
        return len(to_delete)
