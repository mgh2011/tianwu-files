"""
反击收益分析模块
Counterattack Benefit Analyzer - 分析反击行动的潜在收益
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


class BenefitCategory(Enum):
    """收益类别"""
    THREAT_NEUTRALIZATION = "threat_neutralization"  # 威胁消除
    DAMAGE_PREVENTION = "damage_prevention"  # 损失预防
    ATTACKER_DETERRENCE = "attacker_deterrence"  # 攻击威慑
    INTELLIGENCE_GATHERING = "intelligence_gathering"  # 情报收集
    LEGAL_EVIDENCE = "legal_evidence"  # 法律证据
    SYSTEM_HARDENING = "system_hardening"  # 系统加固
    REPUTATION_PROTECTION = "reputation_protection"  # 声誉保护


@dataclass
class BenefitItem:
    """收益项目"""
    category: BenefitCategory
    description: str
    estimated_value: float
    probability: float  # 实现的概率
    timeframe: str  # 预期实现时间
    evidence: List[str] = field(default_factory=list)


@dataclass
class BenefitAnalysis:
    """收益分析结果"""
    total_benefit: float
    weighted_benefit: float
    breakdown: Dict[str, float]
    benefits: List[BenefitItem]
    confidence: float
    feasibility: str
    recommendations: List[str]


class CounterattackBenefitAnalyzer:
    """反击收益分析器"""

    # 收益估算基准
    BASE_VALUES = {
        'per_attack_blocked': 50000,  # 每次成功阻断的价值
        'per_data_exfil_prevented': 500000,  # 每次防止数据外泄的价值
        'per_hour_downtime_saved': 100000,  # 每节省一小时停机
        'per_attacker_deterred': 10000,  # 每次威慑攻击者
        'per_intelligence_collected': 50000,  # 每份情报价值
        'per_evidence_package': 100000,  # 每份证据包价值
    }

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化反击收益分析器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.base_values = self.BASE_VALUES.copy()
        self.analysis_history = []

    def analyze(self, counterattack_plan: Dict) -> BenefitAnalysis:
        """
        分析反击收益

        Args:
            counterattack_plan: 反击计划，包含：
                - action_type: 反击动作类型
                - target: 目标信息
                - attack_info: 攻击信息
                - current_threat_level: 当前威胁等级
                - action_effectiveness: 预估有效性
                - resource_requirements: 资源需求

        Returns:
            收益分析结果
        """
        action_type = counterattack_plan.get('action_type', 'unknown')
        target = counterattack_plan.get('target', {})
        attack_info = counterattack_plan.get('attack_info', {})
        current_threat_level = counterattack_plan.get('current_threat_level', 'medium')
        action_effectiveness = counterattack_plan.get('action_effectiveness', 0.7)
        resource_requirements = counterattack_plan.get('resource_requirements', {})

        benefits = []

        # 1. 威胁消除收益
        threat_neutral = self._analyze_threat_neutralization(
            action_type, attack_info, action_effectiveness
        )
        benefits.append(threat_neutral)

        # 2. 损失预防收益
        damage_prevention = self._analyze_damage_prevention(
            attack_info, current_threat_level, action_effectiveness
        )
        benefits.append(damage_prevention)

        # 3. 攻击者威慑收益
        deterrence = self._analyze_deterrence(
            attack_info, action_type, action_effectiveness
        )
        benefits.append(deterrence)

        # 4. 情报收集收益
        intelligence = self._analyze_intelligence_gathering(
            action_type, attack_info
        )
        benefits.append(intelligence)

        # 5. 法律证据收益
        legal_evidence = self._analyze_legal_evidence(
            action_type, attack_info
        )
        benefits.append(legal_evidence)

        # 6. 系统加固收益
        hardening = self._analyze_system_hardening(
            action_type, target
        )
        benefits.append(hardening)

        # 7. 声誉保护收益
        reputation = self._analyze_reputation_protection(
            action_type, current_threat_level
        )
        benefits.append(reputation)

        # 计算总收益
        breakdown = {}
        for benefit in benefits:
            breakdown[benefit.category.value] = benefit.estimated_value

        total_benefit = sum(b.estimated_value for b in benefits)

        # 计算加权收益（考虑概率）
        weighted_benefit = sum(
            b.estimated_value * b.probability
            for b in benefits
        )

        # 计算置信度
        confidence = self._calculate_confidence(benefits, action_effectiveness)

        # 评估可行性
        feasibility = self._assess_feasibility(
            action_type, resource_requirements, action_effectiveness
        )

        # 生成建议
        recommendations = self._generate_recommendations(
            benefits, action_type, feasibility
        )

        # 构建分析结果
        analysis = BenefitAnalysis(
            total_benefit=round(total_benefit, 2),
            weighted_benefit=round(weighted_benefit, 2),
            breakdown=breakdown,
            benefits=benefits,
            confidence=round(confidence, 2),
            feasibility=feasibility,
            recommendations=recommendations
        )

        # 更新历史
        self._update_history(analysis, counterattack_plan)

        return analysis

    def _analyze_threat_neutralization(self, action_type: str,
                                        attack_info: Dict,
                                        effectiveness: float) -> BenefitItem:
        """分析威胁消除收益"""
        # 估算消除威胁的价值
        value = 0.0
        evidence = []

        # 成功阻断的价值
        if action_type in ['block', 'ban', 'blackhole']:
            value += self.base_values['per_attack_blocked'] * 2
            evidence.append("直接阻断攻击源")

        # 阻止进一步攻击
        if effectiveness > 0.7:
            value += self.base_values['per_attack_blocked'] * effectiveness
            evidence.append(f"高有效性({effectiveness:.0%})增加收益")

        # 保护资产价值
        assets_protected = attack_info.get('assets_at_risk', [])
        if assets_protected:
            asset_value = sum(a.get('value', 0) for a in assets_protected)
            value += asset_value * effectiveness
            evidence.append(f"保护{len(assets_protected)}项资产")

        return BenefitItem(
            category=BenefitCategory.THREAT_NEUTRALIZATION,
            description="通过反击消除或减弱威胁的收益",
            estimated_value=max(value, 10000),
            probability=effectiveness,
            timeframe="即时",
            evidence=evidence
        )

    def _analyze_damage_prevention(self, attack_info: Dict,
                                   threat_level: str,
                                   effectiveness: float) -> BenefitItem:
        """分析损失预防收益"""
        value = 0.0
        evidence = []

        # 潜在损失评估
        potential_loss = attack_info.get('potential_loss', 0)
        if potential_loss > 0:
            value += potential_loss * effectiveness
            evidence.append(f"预防潜在损失${potential_loss:,.0f}")

        # 基于威胁等级
        level_multipliers = {
            'critical': 3.0,
            'high': 2.0,
            'medium': 1.5,
            'low': 1.0
        }
        multiplier = level_multipliers.get(threat_level, 1.0)
        value *= multiplier
        evidence.append(f"威胁等级系数: {multiplier}")

        # 停机时间预防
        potential_downtime = attack_info.get('potential_downtime_hours', 0)
        if potential_downtime > 0:
            downtime_value = potential_downtime * self.base_values['per_hour_downtime_saved']
            value += downtime_value * effectiveness
            evidence.append(f"预防{potential_downtime}小时停机")

        return BenefitItem(
            category=BenefitCategory.DAMAGE_PREVENTION,
            description="通过反击预防未来损失的收益",
            estimated_value=max(value, 5000),
            probability=effectiveness * 0.8,
            timeframe="短期(1-7天)",
            evidence=evidence
        )

    def _analyze_deterrence(self, attack_info: Dict,
                           action_type: str,
                           effectiveness: float) -> BenefitItem:
        """分析威慑收益"""
        value = 0.0
        evidence = []

        # 主动反击的威慑效应
        if action_type in ['counterattack', 'deception', 'honeypot']:
            value += self.base_values['per_attacker_deterred'] * 5
            evidence.append("主动反击产生威慑")

        # 攻击者特征
        attacker_sophistication = attack_info.get('attacker_sophistication', 'medium')
        if attacker_sophistication in ['low', 'medium']:
            value *= 1.5  # 对中等水平攻击者更有效
            evidence.append("对目标攻击者威慑效果较好")
        else:
            value *= 0.7  # 高水平攻击者可能不受影响

        # 历史攻击记录
        attack_history = attack_info.get('attack_history_count', 0)
        if attack_history > 10:
            value *= 1.3
            evidence.append("多次攻击者更需威慑")

        return BenefitItem(
            category=BenefitCategory.ATTACKER_DETERRENCE,
            description="通过反击威慑攻击者的收益",
            estimated_value=max(value, 5000),
            probability=effectiveness * 0.6,
            timeframe="中期(1-30天)",
            evidence=evidence
        )

    def _analyze_intelligence_gathering(self, action_type: str,
                                        attack_info: Dict) -> BenefitItem:
        """分析情报收集收益"""
        value = 0.0
        evidence = []

        # 蜜罐和诱捕行动
        if action_type in ['honeypot', 'deception', 'trap']:
            value += self.base_values['per_intelligence_collected'] * 3
            evidence.append("蜜罐/诱捕获取情报")

        # 溯源分析
        if action_type in ['trace', 'investigate']:
            value += self.base_values['per_intelligence_collected']
            evidence.append("溯源分析获取情报")

        # 攻击者信息
        attacker_info_available = attack_info.get('attacker_info', {})
        if attacker_info_available:
            value += 5000
            evidence.append("利用现有攻击者信息")

        # 指纹信息
        tool_fingerprints = attack_info.get('tool_fingerprints', [])
        if tool_fingerprints:
            value += len(tool_fingerprints) * 5000
            evidence.append(f"获取{len(tool_fingerprints)}个工具指纹")

        return BenefitItem(
            category=BenefitCategory.INTELLIGENCE_GATHERING,
            description="通过反击收集威胁情报的收益",
            estimated_value=max(value, 10000),
            probability=0.7,
            timeframe="中期(7-30天)",
            evidence=evidence
        )

    def _analyze_legal_evidence(self, action_type: str,
                               attack_info: Dict) -> BenefitItem:
        """分析法律证据收益"""
        value = 0.0
        evidence = []

        # 证据收集行动
        if action_type in ['trace', 'collect', 'capture']:
            value += self.base_values['per_evidence_package']
            evidence.append("收集攻击证据")

        # 攻击者信息完整性
        attacker_identified = attack_info.get('attacker_identified', False)
        if attacker_identified:
            value *= 1.5
            evidence.append("攻击者身份已确认")

        # 证据链完整性
        evidence_chain = attack_info.get('evidence_chain_complete', False)
        if evidence_chain:
            value *= 1.3
            evidence.append("证据链完整")

        # 法律行动支持
        if attack_info.get('cross_border', False):
            value *= 1.5
            evidence.append("跨境攻击需要国际法律支持")

        return BenefitItem(
            category=BenefitCategory.LEGAL_EVIDENCE,
            description="通过反击获取法律证据的收益",
            estimated_value=max(value, 20000),
            probability=0.5,
            timeframe="长期(30+天)",
            evidence=evidence
        )

    def _analyze_system_hardening(self, action_type: str,
                                 target: Dict) -> BenefitItem:
        """分析系统加固收益"""
        value = 0.0
        evidence = []

        # 反击过程中发现的新漏洞
        if action_type in ['probe', 'scan', 'test']:
            value += 30000
            evidence.append("安全测试发现新漏洞")

        # 防御能力提升
        defensive_improvements = target.get('defensive_improvements', [])
        if defensive_improvements:
            value += len(defensive_improvements) * 10000
            evidence.append(f"实施{len(defensive_improvements)}项防御改进")

        # 安全更新
        security_updates = target.get('security_updates', [])
        if security_updates:
            value += len(security_updates) * 5000
            evidence.append(f"部署{len(security_updates)}项安全更新")

        return BenefitItem(
            category=BenefitCategory.SYSTEM_HARDENING,
            description="通过反击发现和修复安全问题的收益",
            estimated_value=max(value, 20000),
            probability=0.8,
            timeframe="短期(1-7天)",
            evidence=evidence
        )

    def _analyze_reputation_protection(self, action_type: str,
                                      threat_level: str) -> BenefitItem:
        """分析声誉保护收益"""
        value = 50000  # 基础声誉保护价值
        evidence = ["保护企业声誉"]

        # 高威胁等级
        if threat_level in ['critical', 'high']:
            value *= 2
            evidence.append("高威胁等级需重点保护声誉")

        # 主动防御展示
        if action_type in ['counterattack', 'active_defense']:
            value *= 1.3
            evidence.append("主动防御展示提升形象")

        # 客户影响
        # 简化处理，假设有正面影响
        value *= 1.1

        return BenefitItem(
            category=BenefitCategory.REPUTATION_PROTECTION,
            description="通过反击保护企业声誉的收益",
            estimated_value=value,
            probability=0.6,
            timeframe="中期(7-30天)",
            evidence=evidence
        )

    def _calculate_confidence(self, benefits: List[BenefitItem],
                             effectiveness: float) -> float:
        """计算分析置信度"""
        # 基础置信度
        confidence = 0.7

        # 基于有效性的调整
        confidence *= (0.5 + effectiveness)

        # 基于收益数量的调整
        if len(benefits) >= 5:
            confidence *= 1.1
        elif len(benefits) < 3:
            confidence *= 0.9

        return min(0.95, max(0.3, confidence))

    def _assess_feasibility(self, action_type: str,
                          resource_requirements: Dict,
                          effectiveness: float) -> str:
        """评估可行性"""
        # 检查资源需求
        required_resources = resource_requirements.get('required', [])
        available_resources = resource_requirements.get('available', [])

        if not required_resources:
            return "高度可行"

        shortage = set(required_resources) - set(available_resources)
        if shortage:
            return f"资源受限(缺少: {', '.join(shortage)})"

        # 基于有效性
        if effectiveness > 0.8:
            return "高度可行"
        elif effectiveness > 0.5:
            return "中等可行"
        else:
            return "可行性较低"

    def _generate_recommendations(self, benefits: List[BenefitItem],
                                 action_type: str,
                                 feasibility: str) -> List[str]:
        """生成建议"""
        recommendations = []

        # 基于可行性的建议
        if "可行" in feasibility:
            recommendations.append(f"建议执行反击行动（{feasibility}）")

        # 基于收益的建议
        high_value_benefits = [b for b in benefits if b.estimated_value > 50000]
        if high_value_benefits:
            recommendations.append(f"高价值收益包括: {[b.category.value for b in high_value_benefits]}")

        # 优化建议
        if action_type == 'passive':
            recommendations.append("考虑升级为主动防御策略以提高收益")

        # 风险提示
        low_prob_benefits = [b for b in benefits if b.probability < 0.5]
        if low_prob_benefits:
            recommendations.append(f"部分收益实现概率较低，需要降低预期")

        return recommendations

    def _update_history(self, analysis: BenefitAnalysis, plan: Dict):
        """更新历史记录"""
        self.analysis_history.append({
            'total_benefit': analysis.total_benefit,
            'weighted_benefit': analysis.weighted_benefit,
            'confidence': analysis.confidence,
            'feasibility': analysis.feasibility,
            'plan': plan,
            'timestamp': datetime.now().isoformat()
        })

        if len(self.analysis_history) > 500:
            self.analysis_history = self.analysis_history[-400:]


# 独立运行测试
if __name__ == "__main__":
    analyzer = CounterattackBenefitAnalyzer()

    # 测试反击计划分析
    counterattack_plan = {
        'action_type': 'honeypot',
        'target': {
            'system': 'web_server',
            'defensive_improvements': ['firewall_rule', 'ids_signature'],
            'security_updates': ['patch_cve_2024_001']
        },
        'attack_info': {
            'attacker_identified': True,
            'attack_history_count': 15,
            'potential_loss': 1000000,
            'potential_downtime_hours': 24,
            'assets_at_risk': [
                {'name': 'customer_db', 'value': 500000},
                {'name': 'source_code', 'value': 200000}
            ],
            'tool_fingerprints': ['sqlmap', 'nikto']
        },
        'current_threat_level': 'high',
        'action_effectiveness': 0.75,
        'resource_requirements': {
            'required': ['honeypot_server', 'monitoring_tool'],
            'available': ['honeypot_server', 'monitoring_tool']
        }
    }

    analysis = analyzer.analyze(counterattack_plan)
    print("反击收益分析结果:")
    print(f"总收益: ${analysis.total_benefit:,.2f}")
    print(f"加权收益: ${analysis.weighted_benefit:,.2f}")
    print(f"置信度: {analysis.confidence:.0%}")
    print(f"可行性: {analysis.feasibility}")
    print(f"\n收益分布:")
    for category, value in analysis.breakdown.items():
        print(f"  {category}: ${value:,.2f}")
    print(f"\n建议:")
    for rec in analysis.recommendations:
        print(f"  - {rec}")
