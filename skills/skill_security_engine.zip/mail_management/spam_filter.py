"""
邮件安全系统 - 垃圾邮件过滤器
Spam Email Filter

【功能说明】
- 多维度垃圾邮件识别
- 关键词权重分析
- 行为模式检测
- 完全本地化实现
"""

import re
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


class SpamFilter:
    """
    垃圾邮件过滤器
    
    基于多维度分析的垃圾邮件检测
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 垃圾邮件关键词
        self._spam_keywords = {
            'promotion': {
                'keywords': ['免费', '优惠', '促销', '打折', '折扣', '特价', 'free', 'discount', 'sale'],
                'weight': 0.08
            },
            'clickbait': {
                'keywords': ['点击', '立即', '立刻', '马上', 'click', 'now', 'act now'],
                'weight': 0.1
            },
            'money': {
                'keywords': ['中奖', '奖金', '赚钱', '兼职', 'win', 'prize', 'cash', 'bonus'],
                'weight': 0.15
            },
            'threat': {
                'keywords': ['过期', '失效', '取消', '冻结', 'expire', 'cancel', 'suspended'],
                'weight': 0.12
            }
        }
        
        # 标题党模式
        self._spam_subject_patterns = [
            (r'【.*?】', 0.1),
            (r'!{2,}', 0.1),
            (r'\?{2,}', 0.08),
        ]
    
    def check(self, request: Dict) -> Dict:
        """检测垃圾邮件"""
        subject = request.get('subject', '')
        body = request.get('body', '')
        
        score = 0.0
        matched_categories = []
        details = []
        
        # 关键词分析
        all_text = subject + ' ' + body
        
        for category, data in self._spam_keywords.items():
            count = sum(all_text.lower().count(kw.lower()) for kw in data['keywords'])
            if count > 0:
                category_score = min(count * data['weight'], 0.5)
                score += category_score
                matched_categories.append(category)
                details.append(f'{category}: {count}个')
        
        # 标题模式检查
        for pattern, weight in self._spam_subject_patterns:
            if re.search(pattern, subject):
                score += weight
                details.append(f'标题党: {pattern}')
        
        # URL数量检查
        urls = re.findall(r'https?://\S+', body)
        if len(urls) > 3:
            score += 0.2
            details.append(f'过多链接: {len(urls)}个')
        
        # 全大写检查
        if len(subject) > 10:
            upper_ratio = sum(1 for c in subject if c.isupper()) / len(subject)
            if upper_ratio > 0.5:
                score += 0.1
                details.append('标题全大写')
        
        threat_score = min(score, 1.0)
        
        return {
            'detected': threat_score >= 0.4,
            'threat_score': threat_score,
            'confidence': 0.7,
            'is_spam': threat_score >= 0.5,
            'categories': matched_categories,
            'details': details,
            'url_count': len(urls)
        }


if __name__ == '__main__':
    print("垃圾邮件过滤器测试")
    
    filter = SpamFilter(None, None)
    
    test_cases = [
        {
            'subject': '【限时优惠】免费领取iphone！',
            'body': '点击立即领取，不容错过！名额有限，马上行动！',
        },
        {
            'subject': '项目进度汇报',
            'body': '您好，本周三下午有项目会议，请准时参加。',
        }
    ]
    
    for test in test_cases:
        result = filter.check(test)
        print(f"\n主题: {test['subject']}")
        print(f"垃圾邮件: {'是' if result['is_spam'] else '否'}")
        print(f"威胁分数: {result['threat_score']:.2%}")
