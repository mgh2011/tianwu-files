"""
防护系统 - 防火墙模块
Firewall Module
"""

import re
from typing import Dict, List, Optional
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)


class FirewallModule:
    """
    智能防火墙模块
    
    提供网络访问控制和威胁阻断
    """
    
    def __init__(self, config, storage):
        self.config = config
        self.storage = storage
        
        # 防火墙规则
        self._rules = []
        
        # IP黑名单
        self._ip_blacklist = set()
        
        # 端口白名单
        self._allowed_ports = {80, 443, 22, 3389}
        
        # 危险端口
        self._dangerous_ports = {21, 23, 25, 445, 1433, 3306}
    
    def check(self, request: Dict) -> Dict:
        """检查请求"""
        source_ip = request.get('source_ip', '')
        dest_ip = request.get('dest_ip', '')
        port = request.get('port', 0)
        protocol = request.get('protocol', 'tcp')
        
        blocked = False
        reason = None
        score = 0.0
        
        # 检查IP黑名单
        if source_ip in self._ip_blacklist:
            blocked = True
            reason = 'ip_blacklist'
            score = 0.9
        
        # 检查危险端口
        elif port in self._dangerous_ports:
            blocked = True
            reason = 'dangerous_port'
            score = 0.7
        
        # 检查是否为外部访问高危端口
        elif port in {22, 3389} and not self._is_internal_ip(source_ip):
            blocked = True
            reason = 'remote_access_blocked'
            score = 0.6
        
        return {
            'detected': blocked,
            'blocked': blocked,
            'threat_score': score,
            'reason': reason,
            'source_ip': source_ip,
            'port': port
        }
    
    def _is_internal_ip(self, ip: str) -> bool:
        """检查是否为内网IP"""
        return (
            ip.startswith('10.') or
            ip.startswith('172.16.') or
            ip.startswith('192.168.') or
            ip == '127.0.0.1' or
            ip == 'localhost'
        )
    
    def add_ip_to_blacklist(self, ip: str, reason: str = ''):
        """添加IP到黑名单"""
        self._ip_blacklist.add(ip)
        logger.info(f"IP已加入黑名单: {ip}, 原因: {reason}")
    
    def remove_ip_from_blacklist(self, ip: str):
        """从黑名单移除IP"""
        self._ip_blacklist.discard(ip)


if __name__ == '__main__':
    print("防火墙模块测试")
    
    fw = FirewallModule(None, None)
    
    # 测试
    result = fw.check({
        'source_ip': '192.168.1.100',
        'dest_ip': '10.0.0.1',
        'port': 445,
        'protocol': 'tcp'
    })
    
    print(f"拦截: {result['blocked']}")
    print(f"原因: {result['reason']}")
