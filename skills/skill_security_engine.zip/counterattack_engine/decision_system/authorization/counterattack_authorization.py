"""
反击授权管理模块
Counterattack Authorization - 管理反击行动的授权和审批
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import json
import hashlib


class AuthorizationLevel(Enum):
    """授权级别"""
    NONE = 0  # 无授权
    AUTO_DEFENSE = 1  # 自动防御（被动）
    ACTIVE_DEFENSE = 2  # 主动防御
    COUNTERATTACK_L1 = 3  # 反击级别1（低风险）
    COUNTERATTACK_L2 = 4  # 反击级别2（中风险）
    COUNTERATTACK_L3 = 5  # 反击级别3（高风险）
    FULL_COUNTERATTACK = 6  # 完全反击授权


class AuthorizationStatus(Enum):
    """授权状态"""
    PENDING = "pending"  # 待审批
    APPROVED = "approved"  # 已批准
    REJECTED = "rejected"  # 已拒绝
    EXPIRED = "expired"  # 已过期
    REVOKED = "revoked"  # 已撤销


@dataclass
class AuthorizationRequest:
    """授权请求"""
    request_id: str
    requester: str
    requested_level: AuthorizationLevel
    target_info: Dict
    justification: str
    duration: int  # 请求授权时长（分钟）
    timestamp: str
    attachments: List[str] = field(default_factory=list)


@dataclass
class Authorization:
    """授权"""
    auth_id: str
    request_id: str
    requester: str
    authorized_by: str
    level: AuthorizationLevel
    scope: Dict  # 授权范围
    start_time: str
    end_time: str
    status: AuthorizationStatus
    conditions: List[str] = field(default_factory=list)
    restrictions: List[str] = field(default_factory=list)


class AuthorizationManager:
    """反击授权管理器"""

    # 授权级别对应的风险阈值
    LEVEL_RISK_THRESHOLDS = {
        AuthorizationLevel.NONE: 0,
        AuthorizationLevel.AUTO_DEFENSE: 20,
        AuthorizationLevel.ACTIVE_DEFENSE: 40,
        AuthorizationLevel.COUNTERATTACK_L1: 50,
        AuthorizationLevel.COUNTERATTACK_L2: 65,
        AuthorizationLevel.COUNTERATTACK_L3: 80,
        AuthorizationLevel.FULL_COUNTERATTACK: 100,
    }

    # 授权级别对应的威胁等级要求
    LEVEL_THREAT_REQUIREMENTS = {
        AuthorizationLevel.AUTO_DEFENSE: 20,
        AuthorizationLevel.ACTIVE_DEFENSE: 40,
        AuthorizationLevel.COUNTERATTACK_L1: 50,
        AuthorizationLevel.COUNTERATTACK_L2: 60,
        AuthorizationLevel.COUNTERATTACK_L3: 70,
        AuthorizationLevel.FULL_COUNTERATTACK: 80,
    }

    def __init__(self, config: Optional[Dict] = None):
        """
        初始化授权管理器

        Args:
            config: 配置字典
        """
        self.config = config or {}
        self.requests = {}
        self.authorizations = {}
        self.approval_workflow = self._init_approval_workflow()
        self.max_auth_duration = self.config.get('max_auth_duration', 360)  # 分钟
        self.pending_approvals = []

    def request_authorization(self, request_data: Dict) -> AuthorizationRequest:
        """
        请求授权

        Args:
            request_data: 请求数据，包含：
                - requester: 请求者
                - requested_level: 请求级别
                - target_info: 目标信息
                - justification: 理由
                - duration: 持续时间
                - attachments: 附件

        Returns:
            授权请求
        """
        request_id = self._generate_request_id(request_data)

        request = AuthorizationRequest(
            request_id=request_id,
            requester=request_data['requester'],
            requested_level=request_data['requested_level'],
            target_info=request_data.get('target_info', {}),
            justification=request_data['justification'],
            duration=min(request_data.get('duration', 60), self.max_auth_duration),
            timestamp=datetime.now().isoformat(),
            attachments=request_data.get('attachments', [])
        )

        self.requests[request_id] = request

        # 添加到待审批列表
        self.pending_approvals.append({
            'request_id': request_id,
            'timestamp': request.timestamp,
            'level': request.requested_level.name
        })

        return request

    def approve_request(self, request_id: str, approver: str,
                       conditions: List[str] = None,
                       restrictions: List[str] = None) -> Optional[Authorization]:
        """
        批准请求

        Args:
            request_id: 请求ID
            approver: 审批人
            conditions: 附加条件
            restrictions: 限制条件

        Returns:
            授权对象
        """
        if request_id not in self.requests:
            return None

        request = self.requests[request_id]

        # 生成授权
        auth_id = self._generate_auth_id(request_id, approver)
        now = datetime.now()

        authorization = Authorization(
            auth_id=auth_id,
            request_id=request_id,
            requester=request.requester,
            authorized_by=approver,
            level=request.requested_level,
            scope=self._determine_scope(request),
            start_time=now.isoformat(),
            end_time=(now + timedelta(minutes=request.duration)).isoformat(),
            status=AuthorizationStatus.APPROVED,
            conditions=conditions or [],
            restrictions=restrictions or []
        )

        self.authorizations[auth_id] = authorization

        # 从待审批列表移除
        self.pending_approvals = [
            p for p in self.pending_approvals
            if p['request_id'] != request_id
        ]

        return authorization

    def reject_request(self, request_id: str, rejector: str,
                      reason: str) -> bool:
        """
        拒绝请求

        Args:
            request_id: 请求ID
            rejector: 拒绝人
            reason: 拒绝原因

        Returns:
            是否成功
        """
        if request_id not in self.requests:
            return False

        # 从待审批列表移除
        self.pending_approvals = [
            p for p in self.pending_approvals
            if p['request_id'] != request_id
        ]

        return True

    def check_authorization(self, action: Dict) -> Tuple[bool, Optional[Authorization], str]:
        """
        检查是否已授权

        Args:
            action: 动作信息，包含：
                - action_type: 动作类型
                - risk_level: 风险等级
                - threat_level: 威胁等级
                - requester: 请求者

        Returns:
            (是否授权, 授权对象, 原因)
        """
        action_type = action.get('action_type', '')
        risk_level = action.get('risk_level', 0)
        threat_level = action.get('threat_level', 0)
        requester = action.get('requester', '')

        # 检查是否有有效的授权
        for auth in self.authorizations.values():
            if auth.status != AuthorizationStatus.APPROVED:
                continue

            if not self._is_auth_valid(auth):
                auth.status = AuthorizationStatus.EXPIRED
                continue

            # 检查请求者
            if auth.requester != requester and auth.requester != '*':
                continue

            # 检查风险等级
            required_level = self._get_required_level(risk_level, threat_level)
            if auth.level.value < required_level.value:
                continue

            # 检查限制
            if auth.restrictions:
                if not self._check_restrictions(action, auth.restrictions):
                    continue

            return True, auth, "授权有效"

        # 无有效授权
        reason = self._get_no_auth_reason(risk_level, threat_level)
        return False, None, reason

    def revoke_authorization(self, auth_id: str, revoker: str, reason: str) -> bool:
        """
        撤销授权

        Args:
            auth_id: 授权ID
            revoker: 撤销人
            reason: 撤销原因

        Returns:
            是否成功
        """
        if auth_id not in self.authorizations:
            return False

        auth = self.authorizations[auth_id]
        auth.status = AuthorizationStatus.REVOKED
        return True

    def get_authorization(self, auth_id: str) -> Optional[Authorization]:
        """获取授权"""
        return self.authorizations.get(auth_id)

    def get_pending_requests(self) -> List[Dict]:
        """获取待审批请求"""
        pending = []
        for request_id in [p['request_id'] for p in self.pending_approvals]:
            if request_id in self.requests:
                request = self.requests[request_id]
                pending.append({
                    'request_id': request.request_id,
                    'requester': request.requester,
                    'level': request.requested_level.name,
                    'justification': request.justification,
                    'timestamp': request.timestamp,
                    'duration': request.duration
                })
        return pending

    def get_user_authorizations(self, user: str) -> List[Authorization]:
        """获取用户的授权"""
        return [
            auth for auth in self.authorizations.values()
            if auth.requester == user and auth.status == AuthorizationStatus.APPROVED
        ]

    def _init_approval_workflow(self) -> Dict:
        """初始化审批流程"""
        return {
            'levels': [
                {'level': AuthorizationLevel.ACTIVE_DEFENSE, 'approvers': ['security_analyst']},
                {'level': AuthorizationLevel.COUNTERATTACK_L1, 'approvers': ['security_lead']},
                {'level': AuthorizationLevel.COUNTERATTACK_L2, 'approvers': ['security_manager']},
                {'level': AuthorizationLevel.COUNTERATTACK_L3, 'approvers': ['ciso']},
                {'level': AuthorizationLevel.FULL_COUNTERATTACK, 'approvers': ['executive']},
            ]
        }

    def _generate_request_id(self, data: Dict) -> str:
        """生成请求ID"""
        content = f"{data['requester']}:{data['requested_level']}:{datetime.now().isoformat()}"
        return f"REQ-{hashlib.md5(content.encode()).hexdigest()[:12].upper()}"

    def _generate_auth_id(self, request_id: str, approver: str) -> str:
        """生成授权ID"""
        content = f"{request_id}:{approver}:{datetime.now().isoformat()}"
        return f"AUTH-{hashlib.md5(content.encode()).hexdigest()[:12].upper()}"

    def _determine_scope(self, request: AuthorizationRequest) -> Dict:
        """确定授权范围"""
        level = request.requested_level

        if level == AuthorizationLevel.AUTO_DEFENSE:
            scope = {'actions': ['block', 'rate_limit'], 'targets': ['self']}
        elif level == AuthorizationLevel.ACTIVE_DEFENSE:
            scope = {'actions': ['block', 'honeypot', 'deceive'], 'targets': ['self', 'adjacent']}
        elif level == AuthorizationLevel.COUNTERATTACK_L1:
            scope = {'actions': ['investigate', 'trace'], 'targets': ['self']}
        elif level == AuthorizationLevel.COUNTERATTACK_L2:
            scope = {'actions': ['investigate', 'trace', 'disrupt'], 'targets': ['self', 'direct']}
        elif level == AuthorizationLevel.COUNTERATTACK_L3:
            scope = {'actions': ['*'], 'targets': ['self', 'direct', 'indirect']}
        else:
            scope = {'actions': ['*'], 'targets': ['*']}

        return scope

    def _is_auth_valid(self, auth: Authorization) -> bool:
        """检查授权是否有效"""
        if auth.status != AuthorizationStatus.APPROVED:
            return False

        end_time = datetime.fromisoformat(auth.end_time)
        return datetime.now() < end_time

    def _get_required_level(self, risk_level: float,
                           threat_level: float) -> AuthorizationLevel:
        """获取所需的授权级别"""
        # 基于风险和威胁确定最低级别
        for level in sorted(self.LEVEL_THREAT_REQUIREMENTS.keys(),
                           key=lambda x: x.value, reverse=True):
            if threat_level >= self.LEVEL_THREAT_REQUIREMENTS[level]:
                if risk_level <= self.LEVEL_RISK_THRESHOLDS[level]:
                    return level

        return AuthorizationLevel.ACTIVE_DEFENSE

    def _check_restrictions(self, action: Dict, restrictions: List[str]) -> bool:
        """检查限制"""
        for restriction in restrictions:
            if restriction.startswith('max_risk:'):
                max_risk = float(restriction.split(':')[1])
                if action.get('risk_level', 0) > max_risk:
                    return False
            elif restriction.startswith('time_limit:'):
                time_limit = int(restriction.split(':')[1])
                if action.get('duration', 0) > time_limit:
                    return False
        return True

    def _get_no_auth_reason(self, risk_level: float,
                           threat_level: float) -> str:
        """获取无授权原因"""
        required_level = self._get_required_level(risk_level, threat_level)
        return f"需要{required_level.name}级别授权才能执行此操作"


# 独立运行测试
if __name__ == "__main__":
    manager = AuthorizationManager()

    # 请求授权
    request_data = {
        'requester': 'security_analyst_01',
        'requested_level': AuthorizationLevel.COUNTERATTACK_L2,
        'target_info': {
            'target_ip': '192.168.1.100',
            'attack_type': 'ddos'
        },
        'justification': '持续DDoS攻击需要主动反制',
        'duration': 120
    }

    request = manager.request_authorization(request_data)
    print(f"授权请求已创建: {request.request_id}")
    print(f"待审批请求: {len(manager.get_pending_requests())}")

    # 批准请求
    auth = manager.approve_request(
        request.request_id,
        'security_manager',
        conditions=['必须在监控下执行', '每30分钟报告进度'],
        restrictions=['max_risk:60', 'time_limit:120']
    )

    if auth:
        print(f"\n授权已批准: {auth.auth_id}")
        print(f"授权级别: {auth.level.name}")
        print(f"有效期: {auth.start_time} 至 {auth.end_time}")

    # 检查授权
    check_result, retrieved_auth, reason = manager.check_authorization({
        'action_type': 'disrupt',
        'risk_level': 55,
        'threat_level': 70,
        'requester': 'security_analyst_01'
    })

    print(f"\n授权检查: {check_result}")
    print(f"原因: {reason}")

    # 获取用户授权
    user_auths = manager.get_user_authorizations('security_analyst_01')
    print(f"\n用户授权数量: {len(user_auths)}")
